<?php
/*
Plugin Name: BRW - Booking & Rental Plugin
Plugin URI: https://themeforest.net/user/ovatheme/portfolio
Description: OvaTheme Booking, Rental WooCommerce Plugin.
Author: Ovatheme
Version: 1.7.6
Author URI: https://themeforest.net/user/ovatheme
Text Domain: ova-brw
Domain Path: /languages/
Requires Plugins: woocommerce
*/
if ( ! defined( 'ABSPATH' ) ) exit();

if ( ! class_exists( 'OVABRW' ) ) {
	final class OVABRW {
		/**
		 * OVABRW version.
		 *
		 * @var string
		 */
		public $version = null;

		/**
		 * The single instance of the class.
		 *
		 * @var TourBooking
		 * @since 1.0
		 */
		protected static $_instance = null;

		/**
		 * Get Data
		 * @var object
		 */
		public $options = null;

		/**
		 * OVABRW Constructor
		 */
		public function __construct() {
			// Version
			$this->set_version();

			// Define
			$this->define_constants();

			// Includes
			$this->includes();

			// Load textdomain
			add_action( 'init', array( $this, 'load_textdomain' ) );

			// Woocommerce loaded
			add_action( 'woocommerce_loaded', array( $this, 'ovabrw_woocommerce_loaded' ) );
		}

		/**
		 * Set plugin version
		 * @return string
		 */
		private function set_version() {
			$plugin_data 	= get_plugin_data( __FILE__, false, false );
			$this->version 	= isset( $plugin_data['Version'] ) ? $plugin_data['Version'] : null;
		}

		/**
		 * Define constants
		 */
		public function define_constants() {
			define( 'OVABRW_PLUGIN_FILE', __FILE__ );
			define( 'OVABRW_PLUGIN_URI', plugin_dir_url( __FILE__ ) );
			define( 'OVABRW_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );

			// Global Prefix
			if ( !defined( 'OVABRW_PREFIX' ) ) define( 'OVABRW_PREFIX', 'ovabrw_' );
			if ( !defined( 'OVABRW_RENTAL' ) ) define( 'OVABRW_RENTAL', 'ovabrw_car_rental' );
		}

		/**
		 * Include files
		 */
		public function includes() {
			// Funciton
			require_once( OVABRW_PLUGIN_PATH.'inc/ovabrw-functions.php' );

			// Get Data
			require_once( OVABRW_PLUGIN_PATH.'inc/ovabrw-get-data.php' );

			if ( class_exists( 'OVABRW_Get_Data', false ) ) {
				$this->options = OVABRW_Get_Data::instance();
			}

			// Admin
			add_action( 'init', function() {
				require_once OVABRW_PLUGIN_PATH.'admin/class-ovabrw-admin-init.php';
			});

			// Add taxonomy type
			require_once( OVABRW_PLUGIN_PATH.'inc/ovabrw-taxonomy.php' );

			// Add Js Css
			require_once( OVABRW_PLUGIN_PATH.'inc/ovabrw-assets.php' );
			
			// Cart
			require_once( OVABRW_PLUGIN_PATH.'inc/ovabrw-cart.php' );

			// Filter name
			require_once( OVABRW_PLUGIN_PATH.'inc/ovabrw_hooks.php' );

			// Deposit
			require_once( OVABRW_PLUGIN_PATH.'inc/ovabrw_deposit.php' );

			// Ajax
			require_once( OVABRW_PLUGIN_PATH.'inc/ovabrw_ajax.php' );

			// Register Custom Post Type
			require_once( OVABRW_PLUGIN_PATH.'custom-post-type/ovabrw-register-cpt.php' );		

			// Shortcode
			require_once( OVABRW_PLUGIN_PATH.'shortcodes/class-ovabrw-shortcodes.php' );

			// Cron
			require_once( OVABRW_PLUGIN_PATH.'inc/ovabrw-cron.php' );

			// Send mail
			require_once( OVABRW_PLUGIN_PATH.'inc/ovabrw-mail.php' );

			// Woo
			require_once( OVABRW_PLUGIN_PATH.'inc/ovabrw-wc-template-functions.php' );
			require_once( OVABRW_PLUGIN_PATH.'inc/ovabrw-wc-template-hooks.php' );

			// Abstracts
			require_once( OVABRW_PLUGIN_PATH.'rental-types/abstracts/abstract-ovabrw-rental-types.php' );

			// Rental Types Init
			require_once( OVABRW_PLUGIN_PATH.'rental-types/class-ovabrw-rental-types.php' );

			// Elementor
			if ( defined( 'ELEMENTOR_VERSION' ) ) {
				require_once( OVABRW_PLUGIN_PATH.'inc/ovabrw-elementor.php' );
			}
		}

		/**
		 * Load textdomain
		 */
		public function load_textdomain() {
			if ( is_textdomain_loaded( 'ova-brw' ) ) return;

			load_plugin_textdomain( 'ova-brw', false, basename( dirname( __FILE__ ) ) .'/languages' );
		}

		/**
		 * Woocommerce loaded
		 */
		function ovabrw_woocommerce_loaded() {
			// Rental Product
			require_once OVABRW_PLUGIN_PATH . 'inc/ovabrw-rental-product.php';

			// Cart & Checkout Blocks Integrations
			require_once OVABRW_PLUGIN_PATH . 'inc/ovabrw-block-cart.php';

			// Register IntegrationInterface
			if ( class_exists( 'OVABRW_Block_Cart' ) ) {
				add_action(
				    'woocommerce_blocks_mini-cart_block_registration',
				    function( $integration_registry ) {
				        $integration_registry->register( new OVABRW_Block_Cart() );
				    }
				);
				add_action(
				    'woocommerce_blocks_cart_block_registration',
				    function( $integration_registry ) {
				        $integration_registry->register( new OVABRW_Block_Cart() );
				    }
				);
				add_action(
				    'woocommerce_blocks_checkout_block_registration',
				    function( $integration_registry ) {
				        $integration_registry->register( new OVABRW_Block_Cart() );
				    }
				);
			}
		}

		/**
		 * Main OVABRW Instance.
		 */
		public static function instance() {
			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self();
			}
			return self::$_instance;
		}
	}
}

if ( ! function_exists( 'is_plugin_active' ) ) {
	include_once( ABSPATH . 'wp-admin/includes/plugin.php' ); // Require plugin.php to use is_plugin_active() below
}

if ( is_plugin_active( 'woocommerce/woocommerce.php' ) ) {
	/**
	 * Returns the main instance of OVABRW.
	 */
	function OVABRW() {
		return OVABRW::instance();
	}

	// Global for backwards compatibility.
	$GLOBALS['OVABRW'] = OVABRW();
}