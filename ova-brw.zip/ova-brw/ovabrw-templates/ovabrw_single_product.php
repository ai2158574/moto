<?php defined( 'ABSPATH' ) || exit;

// Get product_id from do_action - use when insert shortcode
if ( ovabrw_get_meta_data( 'id', $args ) ) {
	$product_id = $args['id'];
} else {
	$product_id = get_the_id();
}

$product 	= wc_get_product( $product_id );
$template 	= ovabrw_get_meta_data( 'template', $args );
if ( !$template ) $template = ovabrw_get_product_template( $product_id );

get_header( 'shop' );
	while ( have_posts() ): the_post(); 
		// If the product type isn't ovabrw_car_rental
		if ( !$product || !$product->is_type( 'ovabrw_car_rental' ) ) {
			wc_get_template_part( 'content', 'single-product' );
		} else {  
			do_action( 'woocommerce_before_single_product' );
			echo Elementor\Plugin::instance()->frontend->get_builder_content_for_display( $template );
			do_action( 'woocommerce_after_single_product' );
		}
	endwhile; // end of the loop. ?>
<?php get_footer( 'shop' );