<?php defined( 'ABSPATH' ) || exit;

global $product;

// if the product type isn't ovabrw_car_rental
if ( !$product || !$product->is_type( 'ovabrw_car_rental' ) ) {
    add_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10 );
    return;
}

// Remove price from Woo
remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10 );

$product_id     = $product->get_id();
$price_format   = OVABRW()->options->get_archive_price_by_format( $product_id );
$price_search   = OVABRW()->options->get_price_by_search( $product_id, $_REQUEST );
?>
<p class="<?php echo esc_attr( apply_filters( 'woocommerce_product_price_class', 'ovabrw-price price' ) ); ?>">
    <?php if ( $price_search ): ?>
        <?php echo wp_kses_post( $price_search ); ?>
    <?php elseif ( $price_format ): ?>
        <?php echo wp_kses_post( $price_format ); ?>
    <?php else:
        $rental_type = get_post_meta( $product_id, 'ovabrw_price_type', true ) ? get_post_meta( $product_id, 'ovabrw_price_type', true ) : 'day';

        if ( 'day' == $rental_type ):
            $price_day  = get_post_meta( $product_id, '_regular_price', true );
            $define     = get_post_meta( $product_id, 'ovabrw_define_1_day', true );
        ?>
            <span class="amount">
                <?php echo ovabrw_wc_price( $price_day, [], false ); ?>
            </span>
            <?php if ( 'hotel' == $rental_type ): ?>
                <span class="label">
                    <?php esc_html_e( '/ Night', 'ova-brw' ); ?>
                </span>
            <?php else: ?>
                <span class="label">
                    <?php esc_html_e( '/ Day', 'ova-brw' ); ?>
                </span>
            <?php endif;
        elseif ( 'hour' == $rental_type ):
            $price_hour = get_post_meta( $product_id, 'ovabrw_regul_price_hour', true );
        ?>
            <span class="amount">
                <?php echo ovabrw_wc_price( $price_hour) ; ?>
            </span>
            <span class="label">
                <?php esc_html_e( '/ Hour', 'ova-brw' ); ?>
            </span>
        <?php elseif ( 'mixed' == $rental_type ):
            $price_day  = get_post_meta( $product_id, '_regular_price', true );
            $price_hour = get_post_meta( $product_id, 'ovabrw_regul_price_hour', true );
        ?>
            <span class="ovabrw_woo_price">
                <span class="amount">
                    <?php echo ovabrw_wc_price( $price_hour ); ?>
                </span>
                <span class="label">
                    <?php esc_html_e( '/ Hour', 'ova-brw' ); ?>
                </span>
            </span>
            <span class="ovabrw_woo_price">
                <span class="amount">
                    <?php echo ovabrw_wc_price( $price_day ); ?>
                </span>
                <span class="label">
                    <?php esc_html_e( '/ Day', 'ova-brw' ); ?>
                </span>
            </span>
        <?php elseif ( 'period_time' == $rental_type ):
            $min = $max = 0;
            $petime_price = get_post_meta( $product_id, 'ovabrw_petime_price', true );

            if ( $petime_price && is_array( $petime_price ) ) {
                $min = min( $petime_price );
                $max = max( $petime_price );
            }

            if ( $min && $max && $min == $max ): ?>
                <span class="amount">
                    <?php echo ovabrw_wc_price( $min ); ?>
                </span>
            <?php elseif ( $min && $max ): ?>
                <span class="amount">
                    <?php echo ovabrw_wc_price( $min ). ' - ' .ovabrw_wc_price( $max ); ?>
                </span>
            <?php else:
                esc_html_e( 'Option Price', 'ova-brw' );
            endif;
        elseif ( 'transportation' === $rental_type ):
            $min = $max = 0;
            $price_location = get_post_meta( $product_id, 'ovabrw_price_location', true );

            if ( $price_location && is_array( $price_location ) ) {
                $min = min( $price_location );
                $max = max( $price_location );
            }
            
            if ( $min && $max && $min == $max ): ?>
                <span class="amount">
                    <?php echo ovabrw_wc_price( $min ); ?>
                </span>
            <?php elseif ( $min && $max ): ?>
                <span class="amount">
                    <?php echo ovabrw_wc_price( $min ). ' - ' .ovabrw_wc_price( $max ); ?>
                </span>
            <?php else:
                esc_html_e( 'Option Price', 'ova-brw' );
            endif;
        elseif ( 'taxi' == $rental_type ):
            $price_taxi = get_post_meta( $product_id, 'ovabrw_regul_price_taxi', true );
            $price_by   = get_post_meta( $product_id, 'ovabrw_map_price_by', true );

            if ( !$price_by ) $price_by = 'km';
        ?>
            <span class="amount">
                <?php echo ovabrw_wc_price( $price_taxi ) ; ?>
            </span>
            <?php if ( 'km' == $price_by ): ?>
                <span class="label">
                    <?php esc_html_e( '/ Km', 'ova-brw' ); ?>
                </span>
            <?php else: ?>
                <span class="label">
                    <?php esc_html_e( '/ Mi', 'ova-brw' ); ?>
                </span>
            <?php endif;
        elseif ( 'hotel' == $rental_type ):
            $price = get_post_meta( $product_id, 'ovabrw_regular_price_hotel', true );
        ?>
            <span class="amount">
                <?php echo ovabrw_wc_price( $price ) ; ?>
            </span>
            <span class="label">
                <?php esc_html_e( '/ Night', 'ova-brw' ); ?>
            </span>
        <?php else:
            esc_html_e( 'Option Price', 'ova-brw' );
        endif;
    endif; ?>
</p>