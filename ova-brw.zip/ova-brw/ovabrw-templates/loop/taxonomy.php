<?php defined( 'ABSPATH' ) || exit;
/**
 * The template for displaying custom taxonomy content within loop
 *
 * This template can be overridden by copying it to yourtheme/ovabrw-templates/loop/taxonomy.php
 *
 */

global $product;
if ( !$product || !$product->is_type( 'ovabrw_car_rental' ) ) return;

// Get custom taxonomies
$taxonomies = ovabrw_get_custom_taxonomies( $product->get_id() );

if ( ovabrw_array_exists( $taxonomies ) ): ?>
	<ul class="product_listing_custom_tax">
		<?php foreach ( $taxonomies as $key => $value ): ?>
			<li class="<?php echo esc_attr( 'tax_'.$value['slug'] ); ?> ">
				<?php echo esc_html( $value['name'] ); ?>
			</li>
		<?php endforeach; ?>
	</ul>
<?php endif; ?>
