<?php if ( ! defined( 'ABSPATH' ) ) exit();
	// Get product
	$product = ovabrw_get_rental_product( $args );
	if ( ! $product ) return;

	$product_id 		= $product->get_id();
	$features_featured 	= get_post_meta( $product_id, 'ovabrw_features_featured', true );
	$card 				= ovabrw_get_card_template();
?>

<?php if ( $product && $product->is_featured() ): ?>
	<span class="ovabrw-product-is-featured">
		<?php esc_html_e( 'Featured', 'ova-brw' ); ?>
	</span>
<?php endif; ?>
<?php if ( get_option( 'ova_brw_template_show_special_feature', 'yes' ) === 'yes' && ! empty( $features_featured ) && is_array( $features_featured ) ): ?>
	<?php foreach ( $features_featured as $k => $val ): ?>
		<?php if ( $val === 'yes' ):
			$features_desc = get_post_meta( $product_id, 'ovabrw_features_desc', true );

			$desc = isset( $features_desc[$k] ) ? $features_desc[$k] : '';

			if ( ! $desc ) continue;
		?>
			<span class="ovabrw-product-features-is-featured">
				<?php echo esc_html( $desc ); ?>
			</span>
		<?php break; endif; ?>
	<?php endforeach; ?>
<?php endif; ?>