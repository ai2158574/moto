<?php if ( ! defined( 'ABSPATH' ) ) exit();
/**
 * Variables used in this file.
 *
 * @var int   	$product_id 	The product ID
 * @var int   	$zoom 			The zoom map
 * @var int   	$latitude 		The latitude map
 * @var int   	$longitude 		The longitude map
 * @var string 	$address 		The address map
 */
?>
<div class="ovabrw-product-map">
	<div id="ovabrw-show-map" class="ovabrw-show-map"></div>
	<input
		type="hidden"
		class="ovabrw-data-product-map"
		data-zoom="<?php echo esc_attr( $zoom ); ?>"
		latitude="<?php echo esc_attr( $latitude ); ?>"
		longitude="<?php echo esc_attr( $longitude ); ?>"
	/>
	<input
		type="hidden"
		name="pac-input"
		id="pac-input"
		class="pac-input"
		value="<?php echo esc_attr( $address ); ?>"
		autocomplete="off"
		autocapitalize="none"
	/>
</div>