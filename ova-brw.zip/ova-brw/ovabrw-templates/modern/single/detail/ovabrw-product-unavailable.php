<?php defined( 'ABSPATH' ) || exit();
if ( get_option( 'ova_brw_template_show_maintenance', 'yes' ) !== 'yes' ) return;

// Get product
$product = ovabrw_get_rental_product( $args );
if ( !$product ) return;

$product_id 		= $product->get_id();
$unavailable_from 	= get_post_meta( $product_id, 'ovabrw_untime_startdate', true );

if ( ovabrw_array_exists( $unavailable_from ) ):
	// Rental type
	$rental_type = get_post_meta( $product_id, 'ovabrw_price_type', true );

	// Date format
	$date_format = ovabrw_get_datetime_format();
	if ( 'hotel' == $rental_type ) $date_format = ovabrw_get_date_format();

	// Get unavailabel to
	$unavailable_to = get_post_meta( $product_id, 'ovabrw_untime_enddate', true );
?>
	<div class="ovabrw-product-unavailable">
		<label class="ovabrw-label">
			<?php esc_html_e( 'You can\'t rent product in this time', 'ova-brw' ); ?>
		</label>
		<table class="ovabrw-table">
			<tbody>
			<?php foreach ( $unavailable_from as $k => $from ):
				$to = ovabrw_get_meta_data( $k, $unavailable_to );

				if ( $from && $to ):
			?>
				<tr>
					<td><?php echo date( $date_format, strtotime( $from ) ). ' - '. date( $date_format, strtotime( $to ) ); ?></td>
				</tr>
			<?php endif;
			endforeach; ?>
			</tbody>
		</table>
	</div>
<?php endif; ?>