<?php defined( 'ABSPATH' ) || exit();

// Get product
$product = ovabrw_get_rental_product( $args );
if ( !$product ) return;

$terms_conditions 	= get_option( 'ova_brw_request_booking_terms_conditions', '' );
$terms_content 		= get_option( 'ova_brw_request_booking_terms_conditions_content', '' );

if ( $terms_conditions === 'yes' && $terms_content ): ?>
	<div class="terms-conditions">
		<label>
			<input
				type="checkbox"
				class="ovabrw-conditions ovabrw-input-required"
				name="ovabrw-request_booking-terms-conditions"
				value="yes"
			/>
			<span class="terms-conditions-content">
				<?php echo wp_kses_post( $terms_content ); ?>
				<span class="terms-conditions-required">*</span>
			</span>
		</label>
	</div>
<?php endif; ?>
<div class="ovabrw-request-form-error"></div>
<?php if ( ovabrw_get_recaptcha_form( 'request' ) ): ?>
	<div class="ovabrw-recaptcha">
		<div id="ovabrw-g-recaptcha-request"></div>
	    <input
	        type="text"
	        id="ovabrw-recaptcha-request-token"
	        class="ovabrw-recaptcha-token ovabrw-input-required"
	        name="ovabrw-recaptcha-token"
	    />
	</div>
<?php endif; ?>
<button type="submit" class="submit">
	<?php esc_html_e( 'Send', 'ova-brw' ); ?>
	<div class="ajax_loading">
		<div></div><div></div><div></div><div></div>
		<div></div><div></div><div></div><div></div>
		<div></div><div></div><div></div><div></div>
	</div>
</button>
<input type="hidden" name="product_name" value="<?php echo esc_attr( get_the_title() ); ?>" />
<input type="hidden" name="product_id" value="<?php echo esc_attr( $product->get_id() ); ?>" />
<input type="hidden" name="request_booking" value="request_booking" />