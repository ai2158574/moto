<?php if ( ! defined( 'ABSPATH' ) ) exit();
	// Get product
    $product = ovabrw_get_rental_product( $args );
    if ( ! $product ) return;

	$title = $product->get_title();
?>
<?php if ( $title ): ?>
	<h2 class="ovabrw-product-title"><?php echo esc_html( $title ); ?></h2>
<?php endif; ?>