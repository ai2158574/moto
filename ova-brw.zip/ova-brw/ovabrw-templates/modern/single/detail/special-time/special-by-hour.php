<?php defined( 'ABSPATH' ) || exit();

// Get product
$product = ovabrw_get_rental_product( $args );
if ( !$product ) return;

$product_id 	= $product->get_id();
$special_price 	= get_post_meta( $product_id, 'ovabrw_rt_price_hour', true );

if ( ! empty( $special_price ) && is_array( $special_price ) ):
	// Date format
	$date_format = ovabrw_get_date_format();

	// Time format
	$time_format = ovabrw_get_time_format();

	$special_startdate 	= get_post_meta( $product_id, 'ovabrw_rt_startdate', true ); 
	$special_enddate 	= get_post_meta( $product_id, 'ovabrw_rt_enddate', true );
	$special_starttime 	= get_post_meta( $product_id, 'ovabrw_rt_starttime', true );
	$special_endtime 	= get_post_meta( $product_id, 'ovabrw_rt_endtime', true) ;
	$special_discount 	= get_post_meta( $product_id, 'ovabrw_rt_discount', true );
?>
	<div class="ovabrw-product-special-time">
		<label class="ovabrw-label"><?php esc_html_e( 'Special Time', 'ova-brw' ); ?></label>
		<table class="ovabrw-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Start Date', 'ova-brw' ); ?></th>
					<th><?php esc_html_e( 'End Date', 'ova-brw' ); ?></th>
					<th><?php esc_html_e( 'Price/Hour', 'ova-brw' ); ?></th>
					<?php if ( ovabrw_array_exists( $special_discount ) ): ?>
						<th><?php esc_html_e( 'Discount', 'ova-brw' ); ?></th>
					<?php endif; ?>
				</tr>
			</thead>
			<tbody>
			<?php foreach ( $special_price as $k => $price ):
				// Start date
				$start_date = ovabrw_get_meta_data( $k, $special_startdate );

				// End date
				$end_date = ovabrw_get_meta_data( $k, $special_enddate );

				// Start time
				$start_time = ovabrw_get_meta_data( $k, $special_starttime );
				if ( !$start_time ) {
					$start_time = strtotime( $start_date ) ? date( $time_format, strtotime( $start_date ) ) : '';
				}

				// End time
				$end_time = isset( $special_endtime[$k] ) ? $special_endtime[$k] : '';
				if ( !$end_time ) {
					$end_time = strtotime( $end_date ) ? date( $time_format, strtotime( $end_date ) ) : '';
				}

				// Start & end dates
				$start = $end = '';

				if ( $start_date ) {
					$start = date( $date_format, strtotime( $start_date ) );
					if ( $start_time ) $start .= ' '.$start_time;
				}

				if ( $end_date ) {
					$end = date( $date_format, strtotime( $end_date ) );
					if ( $end_time ) $end .= ' '.$end_time;
				}
				if ( $price != '' && $start && $end ): ?>
					<tr>
						<td><?php echo esc_html( $start ); ?></td>
						<td><?php echo esc_html( $end ); ?></td>
						<td><?php echo ovabrw_wc_price( $price ); ?></td>
						<?php if ( ovabrw_array_exists( $special_discount ) ):
							$dsc_price 	= isset( $special_discount[$k]['price'] ) ? $special_discount[$k]['price'] : '';
							$dsc_min 	= isset( $special_discount[$k]['min'] ) ? $special_discount[$k]['min'] : '';
							$dsc_max 	= isset( $special_discount[$k]['max'] ) ? $special_discount[$k]['max'] : '';
							$dsc_type 	= isset( $special_discount[$k]['duration_type'] ) ? $special_discount[$k]['duration_type'] : '';
						?>
							<td>
								<a href="#" class="ovabrw_open_popup">
									<?php esc_html_e( 'View', 'ova-brw' ); ?>
								</a>
								<div class="popup">
									<div class="popup-inner">
										<div class="price_table">
											<div class="time_discount">
												<span>
													<?php esc_html_e( 'Time: ', 'ova-brw' ); ?>
												</span>
												<span class="start-time">
													<?php echo esc_html( $start ); ?>
												</span>
												<span class="seperate">-</span>
												<span class="end-time">
													<?php echo esc_html( $end ); ?>
												</span>
											</div>
											<?php if ( $dsc_price ): ?>
												<table class="ovabrw-table">
													<thead>
														<tr>
															<th><?php esc_html_e( 'Min - Max (Hours)', 'ova-brw' ); ?></th>
															<th><?php esc_html_e( 'Price/Hour', 'ova-brw' ); ?></th>
														</tr>
													</thead>
													<tbody>
														<?php foreach ( $dsc_price as $dsc_k => $dsc_v_price ):
															$dsc_v_type = ovabrw_get_meta_data( $dsc_k, $dsc_type );
															$dsc_v_min 	= ovabrw_get_meta_data( $dsc_k, $dsc_min );
															$dsc_v_max 	= ovabrw_get_meta_data( $dsc_k, $dsc_max );
														?>
															<?php if ( 'hours' == $dsc_v_type && $dsc_v_min != '' && $dsc_v_max != '' && $dsc_v_price != '' ): ?>
																<tr>
																	<td>
																		<span>
																			<?php echo esc_html( $dsc_v_min ); ?>
																		</span>
																		<span>-</span>
																		<span>
																			<?php echo esc_html( $dsc_v_max ); ?>
																		</span>
																	</td>
																	<td>
																		<?php echo ovabrw_wc_price( $dsc_v_price ); ?>
																	</td>
																</tr>
														<?php endif;
														endforeach; ?>
													</tbody>
												</table>
											<?php endif; ?>
										</div>
										<div class="close_discount">
											<a class="popup-close-2" href="#">
												<?php esc_html_e( 'Close', 'ova-brw' ); ?>
											</a>
										</div>
										<a class="popup-close" href="#">x</a>
									</div>
								</div>
							</td>
						<?php endif; ?>
					</tr>
			<?php endif;
			endforeach; ?>
			</tbody>
		</table>
	</div>
<?php endif; ?>