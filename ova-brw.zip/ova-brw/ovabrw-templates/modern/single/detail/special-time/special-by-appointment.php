<?php defined( 'ABSPATH' ) || exit;

// Get product
$product = ovabrw_get_rental_product( $args );
if ( !$product ) return;

// Product ID
$product_id = $product->get_id();

// Special price
$special_price 	= ovabrw_get_post_meta( $product_id, 'special_price' );
	
if ( ovabrw_array_exists( $special_price ) ):
	// Date time format
	$datetime_format = ovabrw_get_datetime_format();

	// Special start date
	$special_startdate = ovabrw_get_post_meta( $product_id, 'special_startdate' ); 

	// Special end date
	$special_enddate = ovabrw_get_post_meta( $product_id, 'special_enddate' );
?>
	<div class="ovabrw-product-special-time">
		<label class="ovabrw-label">
			<?php esc_html_e( 'Special Time', 'ova-brw' ); ?>
		</label>
		<table class="ovabrw-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Start Date', 'ova-brw' ); ?></th>
					<th><?php esc_html_e( 'End Date', 'ova-brw' ); ?></th>
					<th><?php esc_html_e( 'Price', 'ova-brw' ); ?></th>
				</tr>
			</thead>
			<tbody>
			<?php foreach ( $special_price as $k => $price ):
				// Start date
				$start_date = strtotime( ovabrw_get_meta_data( $k, $special_startdate ) );

				// End date
				$end_date = strtotime( ovabrw_get_meta_data( $k, $special_enddate ) );
				
				if ( $price != '' && $start_date && $end_date ): ?>
					<tr>
						<td>
							<?php echo esc_html( date( $datetime_format, $start_date ) ); ?>
						</td>
						<td>
							<?php echo esc_html( date( $datetime_format, $end_date ) ); ?>
						</td>
						<td>
							<?php echo ovabrw_wc_price( $price ); ?>
						</td>
					</tr>
			<?php endif;
			endforeach; ?>
			</tbody>
		</table>
	</div>
<?php endif; ?>