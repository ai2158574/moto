<?php defined( 'ABSPATH' ) || exit;

// Get product
$product = ovabrw_get_rental_product( $args );
if ( !$product ) return;

$product_id 	= $product->get_id();
$rental_type 	= get_post_meta( $product_id, 'ovabrw_price_type', true );

if ( 'day' == $rental_type ) {
	ovabrw_get_template( 'modern/single/detail/special-time/special-by-day.php' );
} elseif ( 'hour' == $rental_type ) {
	ovabrw_get_template( 'modern/single/detail/special-time/special-by-hour.php' );
} elseif ( 'mixed' == $rental_type ) {
	ovabrw_get_template( 'modern/single/detail/special-time/special-by-mixed.php' );
} elseif ( 'taxi' == $rental_type ) {
	ovabrw_get_template( 'modern/single/detail/special-time/special-by-taxi.php' );
} elseif ( 'hotel' == $rental_type ) {
	ovabrw_get_template( 'modern/single/detail/special-time/special-by-hotel.php' );
} elseif ( 'appointment' == $rental_type ) {
	ovabrw_get_template( 'modern/single/detail/special-time/special-by-appointment.php' );
}