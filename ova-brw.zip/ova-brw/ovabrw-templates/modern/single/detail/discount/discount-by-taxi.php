<?php if ( ! defined( 'ABSPATH' ) ) exit();
	// Get product
	$product = ovabrw_get_rental_product( $args );
	if ( ! $product ) return;

	$product_id 	= $product->get_id();
	$discount_price = get_post_meta( $product_id, 'ovabrw_discount_distance_price', true );
	$price_by 		= get_post_meta( $product_id, 'ovabrw_map_price_by', true );

	if ( ! $price_by ) $price_by = 'km';
?>
<?php if ( ! empty( $discount_price ) ):
	$discount_from 	= get_post_meta( $product_id, 'ovabrw_discount_distance_from', true );
	$discount_to 	= get_post_meta( $product_id, 'ovabrw_discount_distance_to', true );
?>
	<div class="ovabrw-product-discount">
		<label class="ovabrw-label"><?php esc_html_e( 'Global Discount', 'ova-brw' ); ?></label>
		<table class="ovabrw-table">
			<thead>
				<tr>
					<?php if ( $price_by === 'km' ): ?>
						<th><?php esc_html_e( 'From (Km)', 'ova-brw' ); ?></th>
						<th><?php esc_html_e( 'To (Km)', 'ova-brw' ); ?></th>
						<th><?php esc_html_e( 'Price/Km', 'ova-brw' ); ?></th>
					<?php else: ?>
						<th><?php esc_html_e( 'From (Mi)', 'ova-brw' ); ?></th>
						<th><?php esc_html_e( 'To (Mi)', 'ova-brw' ); ?></th>
						<th><?php esc_html_e( 'Price/Mi', 'ova-brw' ); ?></th>
					<?php endif; ?>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $discount_price as $k => $price ):
					$from 	= isset( $discount_from[$k] ) ? $discount_from[$k] : '';
					$to 	= isset( $discount_to[$k] ) ? $discount_to[$k] : '';
				?>
					<?php if ( $price != '' && $from != '' && $to != '' ): ?>
						<tr>
							<td><?php echo esc_html( $from ); ?></td>
							<td><?php echo esc_html( $to ); ?></td>
							<td><?php echo ovabrw_wc_price( $price ); ?></td>
						</tr>
				<?php endif; endforeach; ?>
			</tbody>
		</table>
	</div>
<?php endif; ?>