<?php defined( 'ABSPATH' ) || exit();

if ( get_option( 'ova_brw_template_show_calendar' ) != 'yes' ) return;

// Get product
$product = ovabrw_get_rental_product( $args );
if ( !$product ) return;

// Product ID
$product_id = $product->get_id();

// Calendar background
$background = get_option( 'ova_brw_bg_calendar', '#e56e00' );

// Disable weekdays
$disable_weekdays = $product->get_meta_value( 'product_disable_week_day' );
if ( !$disable_weekdays ) {
    $disable_weekdays = get_option( 'ova_brw_calendar_disable_week_day', '' );
}
if ( ovabrw_array_exists( $disable_weekdays ) ) {
	$key = array_search( '7', $disable_weekdays );
	if ( $key !== false ) $disable_weekdays[$key] = '7';
} else {
	if ( $disable_weekdays && !is_array( $disable_weekdays ) ) {
		$disable_weekdays = explode( ',', $disable_weekdays );
		$disable_weekdays = array_map( 'trim', $disable_weekdays );
	}
}
// End

// Order booked
$order_booked = OVABRW()->options->get_booked_dates( $product_id );

// Calendar price
$calendar_price = ovabw_get_calendar_prices( $product_id );

// Header toolbar left
$toolbar[] 	= 'yes' == get_option( 'ova_brw_calendar_show_nav_month', 'yes' ) ? 'dayGridMonth' : '';
$toolbar[] 	= 'yes' == get_option( 'ova_brw_calendar_show_nav_week', 'yes' ) ? 'timeGridWeek' : '';
$toolbar[] 	= 'yes' == get_option( 'ova_brw_calendar_show_nav_day', 'yes' ) ? 'timeGridDay' : '';
$toolbar[] 	= 'yes' == get_option( 'ova_brw_calendar_show_nav_list', 'yes' ) ? 'listWeek' : '';
$show_time 	= 'yes' == get_option( 'ova_brw_template_show_time_in_calendar', 'yes' ) ? '' : 'ova-hide-time-calendar';
$nav 		= implode( ',', array_filter( $toolbar ) );

// Calendar default view
$default_view = get_option( 'ova_brw_calendar_default_view', 'dayGridMonth' );

// Rental type
$rental_type = $product->get_rental_type();

// Charged by
$charged_by = ovabrw_get_charged_by( $product_id );

// Default start time
$default_start_time = ovabrw_get_default_time( $product_id, 'start' );

// Default end time
$default_end_time = ovabrw_get_default_time( $product_id, 'end' );

// Allow start times
$allow_start_times = ovabrw_get_group_time( $product_id, 'start' );

// Allow end times
$allow_end_times = ovabrw_get_group_time( $product_id, 'end' );

// Special times
$special_times = ovabrw_get_special_time( $product_id, $rental_type );

?>
<div class="ovabrw-product-calendar">
	<h2 class="title">
		<?php esc_html_e( 'Calendar', 'ova-brw' ); ?>
	</h2>
	<div class="wrap_calendar">
		<div class="ovabrw__product_calendar <?php echo esc_attr( $show_time ); ?>"></div>
		<?php ovabrw_text_input([
			'type' 	=> 'hidden',
			'name' 	=> 'ovabrw-product-calendar',
			'value' => json_encode([
				'productID' 		=> $product_id,
				'rentalType' 		=> $rental_type,
				'chargedBy' 		=> $charged_by,
				'nav' 				=> $nav,
				'defaultView' 		=> $default_view,
				'disableDateBg' 	=> $background,
				'defaultStartTime' 	=> $default_start_time,
				'defaultEndTime' 	=> $default_end_time,
				'allowStartTimes' 	=> $allow_start_times,
				'allowEndTimes' 	=> $allow_end_times,
				'calendarPrices' 	=> $calendar_price,
				'specialTimes' 		=> $special_times,
				'disableWeekDays' 	=> $disable_weekdays,
				'orderBooked' 		=> $order_booked,
				'eventNumber' 		=> apply_filters( 'ovabrw_event_number_cell', 2 )
			])
		]); ?>
	</div>
	<ul class="intruction_calendar">
		<li>
			<span class="ovabrw-box ovabrw-available"></span>
			<span><?php esc_html_e( 'Available','ova-brw' ); ?></span>		
		</li>
		<li>
			<span class="ovabrw-box ovabrw-unavailable"></span>
			<span><?php esc_html_e( 'Unavailable','ova-brw' ); ?></span>
		</li>
	</ul>
</div>