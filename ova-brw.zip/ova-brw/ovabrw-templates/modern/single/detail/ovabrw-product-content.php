<?php defined( 'ABSPATH' ) || exit();

the_content();