<?php if ( ! defined( 'ABSPATH' ) ) exit();
	$card = isset( $args['card_template'] ) && $args['card_template'] ? $args['card_template'] : ovabrw_get_card_template();
	if ( get_option( 'ovabrw_glb_'.$card.'_short_description' , 'yes' ) != 'yes' ) return;

	// Get product
	$product = ovabrw_get_rental_product( $args );
	if ( ! $product ) return;

	$short_description = $product->get_short_description();
?>
<?php if ( $short_description ): ?>
	<div class="ovabrw-short-description">
		<?php echo apply_filters( 'woocommerce_short_description', $short_description ); ?>
	</div>
<?php endif; ?>