<?php defined( 'ABSPATH' ) || exit;

$card = isset( $args['card_template'] ) && $args['card_template'] ? $args['card_template'] : ovabrw_get_card_template();
if ( get_option( 'ovabrw_glb_'.$card.'_price' , 'yes' ) != 'yes' ) return;

// Get product
$product = ovabrw_get_rental_product( $args );
if ( ! $product ) return;

$product_id 	= $product->get_id();
$price_format 	= OVABRW()->options->get_archive_price_by_format( $product_id );
$price_search   = OVABRW()->options->get_price_by_search( $product_id, $_REQUEST );

?>
<div class="ovabrw-price">
	<?php if ( $price_search ):
		echo wp_kses_post( $price_search );
	elseif ( $price_format ):
		echo wp_kses_post( $price_format );
	else:
		$rental_type = get_post_meta( $product_id, 'ovabrw_price_type', true );
	
		if ( 'day' == $rental_type ):
			$price 	= get_post_meta( $product_id, '_regular_price', true );
			$unit 	= esc_html__( '/ Day', 'ova-brw' );
			$define = get_post_meta( $product_id, 'ovabrw_define_1_day', true );

			if ( 'hotel' == $define ) $unit = esc_html__( '/ Night', 'ova-brw' );
		?>
			<span class="amount">
				<?php echo ovabrw_wc_price( $price, [], false ); ?>
			</span>
			<span class="unit">
				<?php echo esc_html( $unit ); ?>
			</span>
		<?php elseif ( 'hour' == $rental_type ):
			$price = get_post_meta( $product_id, 'ovabrw_regul_price_hour', true );
		?>
			<span class="amount">
				<?php echo ovabrw_wc_price( $price ); ?>
			</span>
			<span class="unit">
				<?php esc_html_e( '/ Hour', 'ova-brw' ); ?>
			</span>
		<?php elseif ( 'mixed' == $rental_type ):
			$price = get_post_meta( $product_id, 'ovabrw_regul_price_hour', true );
		?>
			<span class="unit">
				<?php esc_html_e( 'From', 'ova-brw' ); ?>
			</span>
			<span class="amount">
				<?php echo ovabrw_wc_price( $price ); ?>
			</span>
			<span class="unit">
				<?php esc_html_e( '/ Hour', 'ova-brw' ); ?>
			</span>
		<?php elseif ( 'period_time' == $rental_type ):
			$min = $max = 0;

			// Get prices
			$petime_price = get_post_meta( $product_id, 'ovabrw_petime_price', true );

			if ( ovabrw_array_exists( $petime_price ) ) {
			    $min = min( $petime_price );
			    $max = max( $petime_price );
			}
			
			if ( $min && $max && $min == $max ): ?>
		        <span class="unit">
		        	<?php esc_html_e( 'From', 'ova-brw' ); ?>
		        </span>
				<span class="amount">
					<?php echo ovabrw_wc_price( $min ); ?>
				</span>
	    	<?php elseif ( $min && $max ): ?>
	    		<span class="amount">
	    			<?php echo ovabrw_wc_price( $min ); ?>
	    		</span>
		        <span class="unit">
		        	<?php esc_html_e( '-', 'ova-brw' ); ?>
		        </span>
				<span class="amount">
					<?php echo ovabrw_wc_price( $max ); ?>
				</span>
	    	<?php else: ?>
		        <span class="amount">
					<a href="<?php echo esc_url( get_the_permalink( $product_id ) ); ?>">
						<?php esc_html_e( 'Option Price', 'ova-brw' ); ?>
					</a>
				</span>
	    	<?php endif; ?>
		<?php elseif ( 'transportation' == $rental_type ):
			$min = $max = 0;

			// Get prices
			$price_location = get_post_meta( $product_id, 'ovabrw_price_location', true );

			if ( ovabrw_array_exists( $price_location ) ) {
			    $min = min( $price_location );
			    $max = max( $price_location );
			}
		?>
			<?php if ( $min && $max && $min == $max ): ?>
		        <span class="unit">
		        	<?php esc_html_e( 'From', 'ova-brw' ); ?>
		        </span>
				<span class="amount">
					<?php echo ovabrw_wc_price( $min ); ?>
				</span>
	    	<?php elseif ( $min && $max ): ?>
	    		<span class="amount">
	    			<?php echo ovabrw_wc_price( $min ); ?>
	    		</span>
		        <span class="unit">
		        	<?php esc_html_e( '-', 'ova-brw' ); ?>
		        </span>
				<span class="amount">
					<?php echo ovabrw_wc_price( $max ); ?>
				</span>
	    	<?php else: ?>
		        <span class="amount">
					<a href="<?php echo esc_url( get_the_permalink( $product_id ) ); ?>">
						<?php esc_html_e( 'Option Price', 'ova-brw' ); ?>
					</a>
				</span>
	    	<?php endif;
	    elseif ( 'taxi' == $rental_type ):
			$price 		= get_post_meta( $product_id, 'ovabrw_regul_price_taxi', true );
			$price_by 	= get_post_meta( $product_id, 'ovabrw_map_price_by', true );

			if ( !$price_by ) $price_by = 'km';
		?>
			<span class="amount">
				<?php echo ovabrw_wc_price( $price ); ?>
			</span>
			<?php if ( 'km' == $price_by ): ?>
				<span class="unit">
					<?php esc_html_e( '/ Km', 'ova-brw' ); ?>
				</span>
			<?php else: ?>
				<span class="unit">
					<?php esc_html_e( '/ Mi', 'ova-brw' ); ?>
				</span>
			<?php endif;
		elseif ( 'hotel' == $rental_type ):
			$price = get_post_meta( $product_id, 'ovabrw_regular_price_hotel', true );
		?>
			<span class="amount">
				<?php echo ovabrw_wc_price( $price ); ?>
			</span>
			<span class="unit">
				<?php esc_html_e( '/ Night', 'ova-brw' ); ?>
			</span>
		<?php elseif ( 'appointment' == $rental_type ):
			$min = $max = '';

			// Get timeslot prices
			$timeslost_prices = get_post_meta( $product_id, 'ovabrw_time_slots_price', true );

			if ( ovabrw_array_exists( $timeslost_prices ) ) {
			    foreach ( $timeslost_prices as $prices ) {
			    	// Min price
			    	$min_price = (float)min( $prices );
			    	if ( '' == $min ) $min = $min_price;
			    	if ( $min > $min_price ) $min = $min_price;

			    	$max_price = (float)max( $prices );
			    	if ( '' == $max ) $max = $max_price;
			    	if ( $max < $max_price ) $max = $max_price;
			    }
			}

			if ( $min && $max && $min == $max ): ?>
		        <span class="unit">
		        	<?php esc_html_e( 'From', 'ova-brw' ); ?>
		        </span>
				<span class="amount">
					<?php echo ovabrw_wc_price( $min ); ?>
				</span>
			<?php elseif ( $min && $max ): ?>
				<span class="amount">
					<?php echo ovabrw_wc_price( $min ); ?>
				</span>
		        <span class="unit">
		        	<?php esc_html_e( '-', 'ova-brw' ); ?>
		        </span>
				<span class="amount">
					<?php echo ovabrw_wc_price( $max ); ?>
				</span>
			<?php else: ?>
		        <span class="amount">
					<a href="<?php echo esc_url( get_the_permalink( $product_id ) ); ?>">
						<?php esc_html_e( 'Option Price', 'ova-brw' ); ?>
					</a>
				</span>
			<?php endif;
		else: ?>
			<span class="amount">
				<a href="<?php echo esc_url( get_the_permalink( $product_id ) ); ?>">
					<?php esc_html_e( 'Option Price', 'ova-brw' ); ?>
				</a>
			</span>
		<?php endif; ?>
	<?php endif; ?>
</div>