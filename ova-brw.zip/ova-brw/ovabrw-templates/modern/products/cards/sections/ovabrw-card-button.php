<?php if ( ! defined( 'ABSPATH' ) ) exit();
	$card = isset( $args['card_template'] ) && $args['card_template'] ? $args['card_template'] : ovabrw_get_card_template();
	if ( get_option( 'ovabrw_glb_'.$card.'_button' , 'yes' ) != 'yes' ) return;

	// Get product
	$product = ovabrw_get_rental_product( $args );
	if ( ! $product ) return;

	$product_id 	= $product->get_id();
	$product_url 	= $product->get_permalink();

	// Keep data from search
	if ( apply_filters( 'ovabrw_get_parameter_from_url', true ) ) {
		$product_url = OVABRW()->options->get_parameter_from_url( $product_id, $product_url, $_REQUEST );
	}
?>
<?php if ( $product_url ): ?>
	<a href="<?php echo esc_url( $product_url ); ?>" class="ovabrw-button">
		<?php esc_html_e( 'Book Now', 'ova-brw' ); ?>
		<i aria-hidden="true" class="brwicon-right"></i>
	</a>
<?php endif; ?>