<?php if ( ! defined( 'ABSPATH' ) ) exit();
	// Get product
	$product = ovabrw_get_rental_product( $args );
	if ( ! $product ) return;

	$product_id 	= $product->get_id();
	$product_title 	= get_the_title( $product_id );
	$product_url 	= get_the_permalink( $product_id );

	// Keep data from search
	if ( apply_filters( 'ovabrw_get_parameter_from_url', true ) ) {
		$product_url = OVABRW()->options->get_parameter_from_url( $product_id, $product_url, $_REQUEST );
	}
?>
<?php if ( $product_title ): ?>
	<h2 class="ovabrw-title">
		<a href="<?php echo esc_url( $product_url ); ?>"><?php echo esc_html( $product_title ); ?></a>
	</h2>
<?php endif; ?>