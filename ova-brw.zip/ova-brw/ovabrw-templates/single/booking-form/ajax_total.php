<div class="ajax_show_total">
	<div class="ajax_loading"></div>
	<div class="show_ajax_content">
		<span class="ovabrw-total-amount"></span>
		<?php if ( get_option( 'ova_brw_booking_form_show_insurance_amount', 'no' ) === 'yes' ): ?>
			<div class="ovabrw-insurance-amount">
				<span class="show-amount-insurance"></span>
			</div>
		<?php endif; ?>
		<?php if ( get_option( 'ova_brw_booking_form_show_availables_vehicle', 'yes' ) === 'yes' ): ?>
			<span class="ovabrw-items-available">
				<?php esc_html_e( 'Items available:', 'ova-brw' ); ?>
				<span class="number-available"></span>
			</span>
		<?php endif; ?>
	</div>
	<div class="ajax-show-error"></div>
</div>