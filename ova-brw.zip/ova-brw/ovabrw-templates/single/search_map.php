<?php if( ! defined( 'ABSPATH' ) ) exit();

extract( $args );

$date_format 	= ovabrw_get_date_format();
$time_format 	= ovabrw_get_time_format();
$lat_default 	= get_option( 'ova_brw_latitude_map_default', '39.177972' );
$lng_default 	= get_option( 'ova_brw_longitude_map_default', '-100.36375' );

if ( empty( $lat_default ) ) {
	$lat_default = '39.177972';
}

if ( empty( $lng_default ) ) {
	$lng_default = '-100.36375';
}

$exclude_id = $include_id = '';
if ( $args['category_not_in'] ) {
	$exclude_id = explode( '|', $args['category_not_in'] );
}
if ( $args['category_not_in_select'] ) {
	$exclude_id = $args['category_not_in_select'];
}
if ( $args['category_in'] ) {
	$include_id = explode( '|', $args['category_in'] );
}
if ( $args['category_in_select'] ) {
	$include_id = $args['category_in_select'];
}

// default value get from url
$data_get = $_GET;
$ovabrw_name_product 	= isset( $data_get['ovabrw_name_product'] ) ? sanitize_text_field( $data_get['ovabrw_name_product'] ) : '';
$default_cat 		    = isset( $data_get['cat'] ) ? sanitize_text_field( $data_get['cat'] ) : '';
$ovabrw_pickup_loc 		= isset( $data_get['ovabrw_pickup_loc'] ) ? sanitize_text_field( $data_get['ovabrw_pickup_loc'] ) : '';
$ovabrw_dropoff_loc 	= isset( $data_get['ovabrw_dropoff_loc'] ) ? sanitize_text_field( $data_get['ovabrw_dropoff_loc'] ) : '';
$ovabrw_pickup_date 	= isset( $data_get['ovabrw_pickup_date'] ) ? sanitize_text_field( $data_get['ovabrw_pickup_date'] ) : '';
$ovabrw_pickoff_date 	= isset( $data_get['ovabrw_pickoff_date'] ) ? sanitize_text_field( $data_get['ovabrw_pickoff_date'] ) : '';
$ovabrw_tag_product 	= isset( $data_get['ovabrw_tag_product'] ) ? sanitize_text_field( $data_get['ovabrw_tag_product'] ) : '';
$ovabrw_quantity  		= isset( $data_get['ovabrw_quantity'] ) ? absint( $data_get['ovabrw_quantity'] ) : '';
$map_lat 				= isset( $data_get['map_lat'] ) ? sanitize_text_field( $data_get['map_lat'] ) : '';
$map_lng 				= isset( $data_get['map_lng'] ) ? sanitize_text_field( $data_get['map_lng'] ) : '';
$map_address 			= isset( $data_get['map_address'] ) ? sanitize_text_field( $data_get['map_address'] ) : '';
$map_name 				= isset( $data_get['map_name'] ) ? sanitize_text_field( $data_get['map_name'] ) : '';

// default value from settings
if ($default_cat == '') {
	$default_cat = $args['default_cat'];
}
if ($ovabrw_pickup_loc == '') {
	$ovabrw_pickup_loc = $args['default_pickup_loc'];
}
if ($ovabrw_dropoff_loc == '') {
	$ovabrw_dropoff_loc = $args['default_dropoff_loc'];
}

$data = array(
	'orderby' 	=> $orderby,
	'order' 	=> $order,
	'posts_per_page' => $posts_per_page,
);

$products = OVABRW()->options->get_products_search( $data );
$have_map = $show_map === 'yes' ? ' ova_have_map' : '';

// Card Template
$card = isset( $args['card'] ) ? $args['card'] : '';

if ( $card === 'card5' || $card === 'card6' ) $column = 'one-column';

?>

<div class="elementor_search_map<?php printf( $have_map ); ?><?php echo $card ? ' ovabrw-search-modern' : ''; ?>">
	<?php if ( $show_map == 'yes'): ?>
		<div class="toggle_wrap">
			<span data-value="wrap_search" class="active"><?php esc_html_e( 'Results', 'ova-brw' ); ?></span>
			<span data-value="wrap_map"><?php esc_html_e( 'Map', 'ova-brw' ); ?></span>
		</div>
	<?php endif; ?>
	<div class="wrap_search_map">
		<!-- Search Map -->
		<div class="wrap_search">
			<?php if ( $show_filter == 'yes' ): ?>
			<div class="fields_search ovabrw_wd_search">
				<span class="toggle_filters ">
					<?php esc_html_e( 'Toggle Filters', 'ova-brw' ); ?>
					<i class="icon_down arrow_triangle-down"></i>
					<i class="icon_up arrow_triangle-up"></i>
				</span>
				<form class="form_search_map" autocomplete="nope" autocorrect="off" autocapitalize="none">
					<div class="wrap_content field">
						<?php
							$show_radius = false;
							// Fields
							foreach ( $args as $key => $value) {
								if ( strpos( $key,'field_' ) !== false ) {
									switch ( $args[$key] ) {
										case 'name': ?>
											<div class="label_search wrap_search_name">
												<input
													type="text"
													name="ovabrw_name_product"
													autocomplete="nope"
													autocorrect="off"
													autocapitalize="none"
													value="<?php echo esc_attr( $ovabrw_name_product ); ?>" 
													placeholder="<?php esc_attr_e( 'Product Name', 'ova-brw' ); ?>"
												/>
											</div>
										<?php break;
										case 'category': ?>
											<div class="label_search wrap_search_category">
												<?php echo OVABRW()->options->get_html_dropdown_categories( $default_cat, '', $exclude_id, '', $include_id ); ?>
											</div>
										<?php break;
										case 'location': ?>
											<div class="label_search wrap_search_location">
												<input
													type="hidden"
													name="map_lat"
													id="map_lat"
													value="<?php echo esc_attr( $map_lat ); ?>"
												/>
												<input
													type="hidden"
													name="map_lng"
													id="map_lng"
													value="<?php echo esc_attr( $map_lng ); ?>"
												/>
												<input
													type="text"
													id="pac-input"
													name="map_address"
													value="<?php echo esc_attr( $map_address ); ?>"
													class="controls"
													placeholder="<?php esc_attr_e( 'Location', 'ova-brw' ); ?>"
													autocomplete="nope"
													autocorrect="off"
													autocapitalize="none"
												/>
												<i class="locate_me icon_circle-slelected" id="locate_me" title="<?php esc_attr_e( 'Use My Location', 'ova-brw' ); ?>"></i>
												<input
													type="hidden"
													value="<?php echo esc_attr( $map_name ); ?>"
													name="map_name"
													id="map_name"
												/>
											</div>
										<?php break;
										case 'start_location': ?>
											<div class="label_search wrap_search_start_location">
												<?php echo OVABRW()->options->get_html_location( 'ovabrw_pickup_loc', 'required', $ovabrw_pickup_loc, '', 'pickup', false ); ?>
											</div>
										<?php break;
										case 'end_location': ?>
											<div class="label_search wrap_search_end_location">
												<?php echo OVABRW()->options->get_html_location( 'ovabrw_dropoff_loc', 'required', $ovabrw_dropoff_loc, '', 'dropoff', false ); ?>
											</div>
										<?php break;
										case 'start_date': ?>
											<div class="label_search wrap_search_start_date">
												<?php ovabrw_text_input([
													'type' 			=> 'text',
													'id' 			=> ovabrw_unique_id( 'ovabrw_start_date' ),
													'class' 		=> 'ovabrw_start_date',
													'name' 			=> 'ovabrw_pickup_date',
													'value' 		=> $ovabrw_pickup_date,
													'placeholder' 	=> esc_html__( 'Pick-up date ...', 'ova-brw' ),
													'data_type' 	=> 'datetimepicker-start',
													'attrs' 		=> [
														'data-date' => strtotime( $ovabrw_pickup_date ) ? date( $date_format, strtotime( $ovabrw_pickup_date ) ) : '',
														'data-time' => strtotime( $ovabrw_pickup_date ) ? date( $time_format, strtotime( $ovabrw_pickup_date ) ) : ''
													]
												]); ?>
											</div>
										<?php break;
										case 'end_date': ?>
											<div class="label_search wrap_search_end_date">
												<?php ovabrw_text_input([
													'type' 			=> 'text',
													'id' 			=> ovabrw_unique_id( 'ovabrw_pickoff_date' ),
													'class' 		=> 'ovabrw_end_date',
													'name' 			=> 'ovabrw_pickoff_date',
													'value' 		=> $ovabrw_pickoff_date,
													'placeholder' 	=> esc_html__( 'Drop-off date ...', 'ova-brw' ),
													'data_type' 	=> 'datetimepicker-end',
													'attrs' 		=> [
														'data-date' => strtotime( $ovabrw_pickoff_date ) ? date( $date_format, strtotime( $ovabrw_pickoff_date ) ) : '',
														'data-time' => strtotime( $ovabrw_pickoff_date ) ? date( $time_format, strtotime( $ovabrw_pickoff_date ) ) : ''
													]
												]); ?>
											</div>
										<?php break;
										case 'attribute':
											$data_html_attr = OVABRW()->options->get_html_dropdown_attributes();

											if ( $data_html_attr['html_attr'] ):
											?>
												<div class="label_search wrap_search_attribute ovabrw_search">
													<?php echo $data_html_attr['html_attr']; ?>
												</div>
											<?php
											endif;

											if ( $data_html_attr['html_attr_value'] ):
											?>
												<?php echo $data_html_attr['html_attr_value']; ?>
											<?php
											endif;
											break;
										case 'tag': ?>
											<div class="label_search wrap_search_tag ovabrw_wd_search">
												<input
													type="text"
													name="ovabrw_tag_product"
													autocomplete="nope"
													autocorrect="off"
													autocapitalize="none"
													value="<?php echo esc_attr( $ovabrw_tag_product ); ?>"
													placeholder="<?php esc_html_e('Tag Product', 'ova-brw'); ?>"
												/>
											</div>
										<?php
										case 'quantity': ?>
										<div class="label_search wrap_search_quantity">
											<input
												type="number"
												name="ovabrw_quantity"
												value="<?php echo esc_attr( $ovabrw_quantity ); ?>"
												placeholder="<?php esc_html_e('Quantity', 'ova-brw'); ?>"
												min="1"
											/>
										</div>
										<?php
										default:
											// code...
											break;
									}
								}
							}
							// End Fields

							// Taxonomies
							$args_taxonomy 	= array();
							$taxonomies 	= get_option( 'ovabrw_custom_taxonomy', array() );
							$show_taxonomy 	= get_option( 'ova_brw_search_show_tax_depend_cat', 'yes' );
							if ( $list_taxonomy_custom && is_array( $list_taxonomy_custom ) ) {
								foreach ( $list_taxonomy_custom as $obj_taxonomy ) {
									$taxonomy_slug = $obj_taxonomy['taxonomy_custom'];

									if ( isset( $taxonomies[$taxonomy_slug] ) && ! empty( $taxonomies[$taxonomy_slug] ) ) {
										$taxonomy_name = $taxonomies[$taxonomy_slug]['name'];
										$html_taxonomy = OVABRW()->options->get_html_dropdown_taxonomies_search( $taxonomy_slug, $taxonomy_name );
										if ( ! empty( $taxonomy_name ) && $html_taxonomy ):
											$args_taxonomy[$taxonomy_slug] = $taxonomy_name;
										?>
											<div class="label_search wrap_search_taxonomies <?php echo $taxonomy_slug; ?>">
												<?php echo $html_taxonomy; ?>
											</div>
										<?php
										endif;
									}
								}
								?>
								<div class="show_taxonomy" data-show_taxonomy="<?php echo esc_html( $show_taxonomy ); ?>"></div>
								<?php
							}
							// End Taxonomies
						?>
						<input 	type="hidden" id="data_taxonomy_custom" name="data_taxonomy_custom" 
								value="<?php echo esc_attr( json_encode( $args_taxonomy ) ); ?>" />
					</div><!-- wrap_content -->

					<!-- Radius -->
					<div class="wrap_search_radius" 
						data-map_range_radius="<?php echo apply_filters( 'ovabrw_ft_map_range_radius', 50 ); ?>" 
						data-map_range_radius_min="<?php echo apply_filters( 'ovabrw_ft_map_range_radius_min', 0 ); ?>" 
						data-map_range_radius_max="<?php echo apply_filters( 'ovabrw_ft_map_range_radius_max', 100 ); ?>">
						<span>
							<?php esc_html_e( 'Radius:', 'ova-brw' ); ?>
						</span>
						<span class="result_radius">
							<?php echo apply_filters( 'ovabrw_ft_map_range_radius', 50 ); ?>
							<?php esc_html_e( 'km', 'ova-brw' ); ?>
						</span>
						<div id="wrap_pointer"></div>
						<input
							type="hidden"
							value="<?php echo apply_filters( 'ovabrw_ft_map_range_radius', 50 ); ?>"
							name="radius"
						/>
					</div>
					<!-- End Radius -->

					<!-- Filter title -->
					<div class="wrap_search_filter_title">
						<div class="results_found">
							<?php if ( $products->found_posts == 1 ): ?>
							<span>
								<?php echo sprintf( esc_html__( '%s Result Found', 'ova-brw' ), esc_html( $products->found_posts ) ); ?>
							</span>
							<?php else: ?>
							<span>
								<?php echo sprintf( esc_html__( '%s Results Found', 'ova-brw' ), esc_html( $products->found_posts ) ); ?>
							</span>
							<?php endif; ?>

							<?php if ( 1 == ceil( $products->found_posts/ $products->query_vars['posts_per_page']) && $products->have_posts() ): ?>
								<span>
									<?php echo sprintf( esc_html__( '(Showing 1-%s)', 'ova-brw' ), esc_html( $products->found_posts ) ); ?>
								</span>
							<?php elseif ( !$products->have_posts() ): ?>
								<span></span>
							<?php else: ?>
								<span>
									<?php echo sprintf( esc_html__( '(Showing 1-%s)', 'ova-brw' ), esc_html( $products->query_vars['posts_per_page'] ) ); ?>
								</span>
							<?php endif; ?>
						</div>

						<div id="search_sort">
							<?php
								$sort = apply_filters( 'search_sort_default', $orderby );

								if ( 'date' === $orderby && 'DESC' === $order ) {
									$sort = 'date-desc';
								} elseif ( 'date' === $orderby && 'ASC' === $order ) {
									$sort = 'date-asc';
								} elseif ( 'title' === $orderby && 'DESC' === $order ) {
									$sort = 'a-z';
								} elseif ( 'title' === $orderby && 'ASC' === $order ) {
									$sort = 'z-a';
								} elseif ( 'rating' === $orderby ) {
									$sort = 'rating';
								}
							?>
							<select name="sort">
								<option value=""><?php esc_html_e( 'Sort By', 'ova-brw' ); ?></option>
								<option value="date-desc"<?php selected( $sort, 'date-desc' ); ?>>
									<?php esc_html_e( 'Newest First', 'ova-brw' ); ?>
								</option>
								<option value="date-asc"<?php selected( $sort, 'date-asc' ); ?>>
									<?php esc_html_e( 'Oldest First', 'ova-brw' ); ?>
								</option>
								<?php if ( 'yes' === get_option( 'woocommerce_enable_reviews' ) ): ?>
									<option value="rating"<?php selected( $sort, 'rating' ); ?>>
										<?php esc_html_e( 'Average rating', 'ova-brw' ); ?>
									</option>
								<?php endif; ?>
								<option value="a-z" <?php selected( $sort, 'a-z' ); ?>>
									<?php esc_html_e( 'A-Z', 'ova-brw' ); ?>
								</option>
								<option value="z-a" <?php selected( $sort, 'z-a' ); ?> >
									<?php esc_html_e( 'Z-A', 'ova-brw' ); ?>
								</option>
							</select>
						</div>
					</div><!-- End filter title -->
				</form>
			</div><!-- fields_search -->
			<?php endif; ?>

			<!-- Load more -->
			<div class="wrap_load_more" style="display: none;">
				<svg class="loader" width="50" height="50">
					<circle cx="25" cy="25" r="10" stroke="#e86c60"/>
					<circle cx="25" cy="25" r="20" stroke="#e86c60"/>
				</svg>
			</div>
			<!-- End load more -->

			<!-- Search result -->
			<div
				id="search_result"
				class="search_result"
				data-card="<?php echo esc_attr( $card ); ?>"
				data-column="<?php echo esc_attr( $column ); ?>"
				data-zoom="<?php echo esc_attr( $zoom ); ?>"
				data-default-location="<?php echo esc_attr( $show_default_location ); ?>"
				data-order="<?php echo esc_attr( $order ); ?>"
				data-orderby="<?php echo esc_attr( $orderby ); ?>"
				data-per_page="<?php echo esc_attr( $posts_per_page ); ?>"
				data-lat="<?php echo esc_attr( $lat_default ); ?>"
				data-lng="<?php echo esc_attr( $lng_default ); ?>"
				data-marker_option="<?php echo esc_attr( $marker_option ); ?>"
				data-marker_icon="<?php echo esc_attr( $marker_icon['url'] ); ?>"
				data-show_featured="<?php echo esc_attr( $show_featured ); ?>">
				<?php
					$total = $products->max_num_pages;
					if (  $total > 1 ): ?>
						<div class="ovabrw_pagination_ajax">
						<?php
							echo OVABRW()->options->get_html_pagination_ajax( $products->found_posts, $products->query_vars['posts_per_page'], 1 );
						?>
						</div>
						<?php
					endif;
				?>
			</div><!-- search_result -->
		</div><!-- wrap_search -->

		<?php if ( $show_map == 'yes' ): ?>
			<div class="wrap_map">
				<div id="show_map"></div>
			</div>
		<?php endif; ?>
	</div>
</div>