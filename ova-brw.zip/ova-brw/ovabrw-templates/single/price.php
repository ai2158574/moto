<?php defined ( 'ABSPATH' ) || exit;

global $product;

if ( !$product && isset( $args['id'] ) && $args['id'] ) {
    $product = wc_get_product( $args['id'] );
}

// Check product type: rental
if ( !$product || !$product->is_type('ovabrw_car_rental') ) return;

// Remove price from Woo
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 10 );

$product_id     = $product->get_id();
$price_format   = OVABRW()->options->get_single_price_by_format( $product_id );

?>
<p class="<?php echo esc_attr( apply_filters( 'woocommerce_product_price_class', 'ovabrw-price price' ) ); ?>">
    <?php if ( $price_format ):
        echo wp_kses_post( $price_format );
    else:
        $rental_type = get_post_meta( $product_id, 'ovabrw_price_type', true ) ? get_post_meta( $product_id, 'ovabrw_price_type', true ) : 'day' ;
    
        if ( 'day' == $rental_type ):
            $price_day  = get_post_meta( $product_id, '_regular_price', true );
            $define     = get_post_meta( $product_id, 'ovabrw_define_1_day', true );
        ?>
            <span class="amount">
                <?php echo ovabrw_wc_price( $price_day, [], false ); ?>
            </span>
            <?php if ( 'hotel' == $define ): ?>
                <span class="label">
                    <?php esc_html_e( '/ Night', 'ova-brw' ); ?>
                </span>
            <?php else: ?>
                <span class="label">
                    <?php esc_html_e( '/ Day', 'ova-brw' ); ?>
                </span>
            <?php endif;
        elseif ( 'hour' == $rental_type ):
            $price_hour = get_post_meta( $product_id, 'ovabrw_regul_price_hour', true );
        ?>
            <span class="amount">
                <?php echo ovabrw_wc_price( $price_hour) ; ?>
            </span>
            <span class="label">
                <?php esc_html_e( '/ Hour', 'ova-brw' ); ?>
            </span>
        <?php elseif ( 'mixed' == $rental_type ):
            $price_day  = get_post_meta( $product_id, '_regular_price', true );
            $price_hour = get_post_meta( $product_id, 'ovabrw_regul_price_hour', true );
        ?>
            <span class="ovabrw_woo_price">
                <span class="amount">
                    <?php echo ovabrw_wc_price( $price_hour ); ?>
                </span>
                <span class="label">
                    <?php esc_html_e( '/ Hour', 'ova-brw' ); ?>
                </span>
            </span>
            <span class="ovabrw_woo_price">
                <span class="amount">
                    <?php echo ovabrw_wc_price( $price_day ); ?>
                </span>
                <span class="label">
                    <?php esc_html_e( '/ Day', 'ova-brw' ); ?>
                </span>
            </span>
        <?php elseif ( 'period_time' == $rental_type ):
            $min = $max = 0;

            // Get prices
            $petime_price = get_post_meta( $product_id, 'ovabrw_petime_price', true );

            if ( ovabrw_array_exists( $petime_price ) ) {
                $min = min( $petime_price );
                $max = max( $petime_price );
            }
        
            if ( $min && $max && $min == $max ): ?>
                <span class="amount">
                    <?php echo ovabrw_wc_price( $min ); ?>
                </span>
            <?php elseif ( $min && $max ): ?>
                <span class="amount">
                    <?php echo ovabrw_wc_price( $min ). ' - ' .ovabrw_wc_price( $max ); ?>
                </span>
            <?php else:
                esc_html_e( 'Option Price', 'ova-brw' );
            endif;
        elseif ( 'transportation' == $rental_type ):
            $min = $max = 0;

            // Get prices
            $price_location = get_post_meta( $product_id, 'ovabrw_price_location', true );

            if ( ovabrw_array_exists( $price_location ) ) {
                $min = min( $price_location );
                $max = max( $price_location );
            }
        
            if ( $min && $max && $min == $max ): ?>
                <span class="amount">
                    <?php echo ovabrw_wc_price( $min ); ?>
                </span>
            <?php elseif ( $min && $max ): ?>
                <span class="amount">
                    <?php echo ovabrw_wc_price( $min ). ' - ' .ovabrw_wc_price( $max ); ?>
                </span>
            <?php else:
                esc_html_e( 'Option Price', 'ova-brw' );
            endif;
        elseif ( 'taxi' == $rental_type ):
            $price_taxi = get_post_meta( $product_id, 'ovabrw_regul_price_taxi', true );
            $price_by   = get_post_meta( $product_id, 'ovabrw_map_price_by', true );

            if ( !$price_by ) $price_by = 'km';
        ?>
            <span class="amount">
                <?php echo ovabrw_wc_price( $price_taxi ) ; ?>
            </span>
            <?php if ( $price_by == 'km' ): ?>
                <span class="label">
                    <?php esc_html_e( '/ Km', 'ova-brw' ); ?>
                </span>
            <?php else: ?>
                <span class="label">
                    <?php esc_html_e( '/ Mi', 'ova-brw' ); ?>
                </span>
            <?php endif;
        elseif ( 'hotel' == $rental_type ):
            $price = get_post_meta( $product_id, 'ovabrw_regular_price_hotel', true );
        ?>
            <span class="amount">
                <?php echo ovabrw_wc_price( $price ) ; ?>
            </span>
            <span class="label">
                <?php esc_html_e( '/ Night', 'ova-brw' ); ?>
            </span>
        <?php elseif ( 'appointment' == $rental_type ):
            $min = $max = '';

            // Get timeslot prices
            $timeslost_prices = get_post_meta( $product_id, 'ovabrw_time_slots_price', true );

            if ( ovabrw_array_exists( $timeslost_prices ) ) {
                foreach ( $timeslost_prices as $prices ) {
                    // Min price
                    $min_price = (float)min( $prices );
                    if ( '' == $min ) $min = $min_price;
                    if ( $min > $min_price ) $min = $min_price;

                    $max_price = (float)max( $prices );
                    if ( '' == $max ) $max = $max_price;
                    if ( $max < $max_price ) $max = $max_price;
                }
            }
            
            if ( $min && $max && $min == $max ): ?>
                <span class="amount">
                    <?php echo ovabrw_wc_price( $min ); ?>
                </span>
            <?php elseif ( $min && $max ): ?>
                <span class="amount">
                    <?php echo ovabrw_wc_price( $min ). ' - ' .ovabrw_wc_price( $max ); ?>
                </span>
            <?php else:
                esc_html_e( 'Option Price', 'ova-brw' );
            endif;  
        else:
            esc_html_e( 'Option Price', 'ova-brw' );
        endif;
    endif; ?>
</p>