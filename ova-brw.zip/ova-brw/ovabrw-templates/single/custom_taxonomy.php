<?php 
/**
 * The template for displaying contact form 7 within single
 *
 * This template can be overridden by copying it to yourtheme/ovabrw-templates/single/custom_taxonomy.php
 *
 */

if ( ! defined( 'ABSPATH' ) ) exit();

global $product;

if ( !$product && isset( $args['id'] ) && $args['id'] ) {
	$product = wc_get_product( $args['id'] );
}

// Check product type: rental
if ( !$product || $product->get_type() !== 'ovabrw_car_rental' ) return;

// Get product ID
$pid = $product->get_id();

// Get custom taxonomies
$taxonomies = ovabrw_get_taxonomy_choosed_product( $pid );

if ( $taxonomies ): ?>
	<ul class="ovabrw_cus_taxonomy">
		<?php foreach ( $taxonomies as $key => $value ): ?>
			<li class="<?php echo $key; ?>">
				<label>
					<?php echo $value['name']; ?>
				</label>
				<span>
					<?php echo implode(', ', $value['value']); ?>
				</span>
			</li>
		<?php endforeach; ?>			
	</ul>
<?php endif; ?>