<?php defined( 'ABSPATH' ) || exit;

$products 	= OVABRW()->options->get_vehicle_ids_available( $_GET );
$card 		= ovabrw_get_card_template();
$column 	= wc_get_loop_prop( 'columns' );

if ( 'modern' !== get_option( 'ova_brw_search_template', 'modern' ) ) $card = '';
if ( in_array( $card , ['card5', 'card6'] ) ) $column = 1;

get_header( 'shop' );

do_action( 'woocommerce_before_main_content' );

?>
<header class="woocommerce-products-header">
	<?php if ( apply_filters( 'woocommerce_show_page_title', true ) ) : ?>
		<h1 class="woocommerce-products-header__title page-title">
			<?php esc_html_e( 'Search Result', 'ova-brw' ); ?>
		</h1>
	<?php endif;
		do_action( 'woocommerce_archive_description' );
	?>
</header>
<?php if ( $products && $products->have_posts() ): ?>
	<ul class="products columns-<?php echo esc_attr( $column ); ?>">
		<?php while ( $products->have_posts() ) : $products->the_post();
			global $product;

			// Ensure visibility.
			if ( empty( $product ) || ! $product->is_visible() ) continue;

			if ( $card ) {
				$thumbnail_type = get_option( 'ovabrw_glb_'.$card.'_thumbnail_type', 'slider' );
				?>
				<li <?php wc_product_class( 'item', $product ); ?>>
					<?php ovabrw_get_template( 'modern/products/cards/ovabrw-'.$card.'.php', [
						'thumbnail_type' => $thumbnail_type
					]); ?>
				</li>
				<?php
			} else {
				wc_get_template_part( 'content', 'product' );
			}
		endwhile; wp_reset_postdata(); ?>
	</ul>
<?php else:
	do_action( 'woocommerce_no_products_found' );
endif;

do_action( 'woocommerce_after_main_content' );
do_action( 'woocommerce_sidebar' );

get_footer( 'shop' );