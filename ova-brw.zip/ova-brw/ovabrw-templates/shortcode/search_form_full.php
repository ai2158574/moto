<?php defined( 'ABSPATH' ) || exit;

// Import variables
extract( $args );

// Date format
$date_format = ovabrw_get_date_format();

// Time format
$time_format = ovabrw_get_time_format();

// Modern template
if ( ovabrw_global_typography() ) {
    $class .= ' ovabrw-modern-product';
}

?>
<div class="ovabrw_wd_search">
    <form 
        action="<?php echo esc_url( home_url() ); ?>"
        class="ovabrw_search form_ovabrw row <?php echo esc_attr( $class ); ?>"
        enctype="multipart/form-data">
        <div class="wrap_content <?php echo esc_attr( $column ); ?>">
            <?php if ( $show_name_product === 'yes' ): ?>
                <div class="s_field">
                    <div class="content">
                        <label>
                            <?php esc_html_e( 'Product Name', 'ova-brw' ); ?>
                        </label>
                        <?php ovabrw_text_input([
                            'type'          => 'text',
                            'class'         => $name_product_required,
                            'value'         => $name_product,
                            'placeholder'   => esc_html__( 'Product Name', 'ova-brw' )
                        ]); ?>
                    </div>
                </div>
            <?php endif; ?>
            <?php if ( 'yes' == $show_cat ): ?>
                <div class="s_field">
                    <div class="content">
                        <label>
                            <?php esc_html_e( 'Category', 'ova-brw' ); ?>
                        </label>
                        <?php echo OVABRW()->options->get_html_dropdown_categories( $cat, $category_required, $remove_cats_id ); ?>
                    </div>
                </div>
            <?php endif; ?>
            <?php if ( 'yes' == $show_pickup_loc ): ?>
                <div class="s_field">
                    <div class="content">
                        <label>
                            <?php esc_html_e( 'Pick-up Location', 'ova-brw' ); ?>
                        </label>
                        <?php echo OVABRW()->options->get_html_location( 'ovabrw_pickup_loc', $pickup_loc_required, $pickup_loc ); ?>
                    </div>
                </div>
            <?php endif; ?>
            <?php if ( 'yes' == $show_dropoff_loc ): ?>
                <div class="s_field">
                    <div class="content">
                        <label>
                            <?php esc_html_e( 'Drop-off Location', 'ova-brw' ); ?>
                        </label>
                        <?php echo OVABRW()->options->get_html_location( 'ovabrw_pickoff_loc', $dropoff_loc_required, $pickoff_loc ); ?>
                    </div>
                </div>
            <?php endif; ?>
            <?php if ( 'yes' == $show_pickup_date ): ?>
                <div class="s_field">
                    <div class="content">
                        <label>
                            <?php esc_html_e( 'Pick-up Date', 'ova-brw' ); ?>
                        </label>
                        <?php ovabrw_text_input([
                            'type'      => 'text',
                            'id'        => ovabrw_unique_id( 'ovabrw_pickup_date' ),
                            'class'     => 'ovabrw_start_date',
                            'name'      => 'ovabrw_pickup_date',
                            'value'     => $pickup_date,
                            'data_type' => $timepicker ? 'datetimepicker-start' : 'datepicker-start',
                            'required'  => $pickup_date_required ? true : false,
                            'attrs'     => [
                                'data-date' => strtotime( $pickup_date ) ? date( $date_format, strtotime( $pickup_date ) ) : '',
                                'data-time' => strtotime( $pickup_date ) ? date( $time_format, strtotime( $pickup_date ) ) : ''
                            ]
                        ]); ?>
                    </div>
                </div>
            <?php endif; ?>
            <?php if ( 'yes' == $show_dropoff_date ): ?>
                <div class="s_field">
                    <div class="content">
                        <label>
                            <?php esc_html_e( 'Drop-off Date', 'ova-brw' ); ?>
                        </label>
                        <?php ovabrw_text_input([
                            'type'      => 'text',
                            'id'        => ovabrw_unique_id( 'ovabrw_pickoff_date' ),
                            'class'     => 'ovabrw_end_date',
                            'name'      => 'ovabrw_pickoff_date',
                            'value'     => $pickoff_date,
                            'data_type' => $timepicker ? 'datetimepicker-end' : 'datepicker-end',
                            'required'  => $dropoff_date_required ? true : false,
                            'attrs'     => [
                                'data-date' => strtotime( $pickoff_date ) ? date( $date_format, strtotime( $pickoff_date ) ) : '',
                                'data-time' => strtotime( $pickoff_date ) ? date( $time_format, strtotime( $pickoff_date ) ) : ''
                            ]
                        ]); ?>
                    </div>
                </div>
            <?php endif; ?>
            <?php if ( 'yes' == $show_attribute ): ?>
                <div class="s_field">
                    <div class="content">
                        <label>
                            <?php esc_html_e( 'Name Attribute', 'ova-brw' ); ?>
                        </label>
                        <?php echo $html_select_attribute; ?>
                    </div>
                </div>
                <?php echo $html_select_value_attribute; ?>
            <?php endif; ?>
            <?php if ( 'yes' == $show_tag_product ): ?>
                <div class="s_field">
                    <div class="content">
                        <label>
                            <?php esc_html_e( 'Tag Product', 'ova-brw' ); ?>
                        </label>
                        <?php ovabrw_text_input([
                            'type'          => 'text',
                            'class'         => $tag_product_required,
                            'name'          => 'ovabrw_tag_product',
                            'value'         => $tag_product,
                            'placeholder'   => esc_html__( 'Tag Product', 'ova-brw' )
                        ]); ?>
                    </div>
                </div>
            <?php endif; ?>
            <?php
                $list_taxonomy      = ovabrw_get_meta_data( 'taxonomy_list_all', $taxonomy_list_wrap, [] );
                $require_taxonomy   = ovabrw_get_meta_data( 'taxonomy_require', $taxonomy_list_wrap, [] );
                $hide_taxonomy      = ovabrw_get_meta_data( 'taxonomy_hide', $taxonomy_list_wrap, [] );
                $get_taxonomy       = ovabrw_get_meta_data( 'taxonomy_get', $taxonomy_list_wrap, [] );

                if ( ovabrw_array_exists( $list_taxonomy ) && 'yes' == $show_tax ) {
                    foreach ( $list_taxonomy as $taxonomy ) {
                        $slug       = ovabrw_get_meta_data( 'slug', $taxonomy );
                        $name       = ovabrw_get_meta_data( 'name', $taxonomy );
                        $required   = '';

                        if ( 'required' == ovabrw_get_meta_data( $slug, $require_taxonomy ) ) {
                            $required = 'ovabrw-input-required';
                        } else {
                            $required = '';
                        }

                        if ( 'hide' != ovabrw_get_meta_data( $slug, $hide_taxonomy ) ): ?>
                            <div class="s_field s_field_cus_tax <?php echo esc_attr( $column. ' '. $slug ); ?>">
                                <div class="content">
                                    <label>
                                        <?php echo esc_html( $name ); ?>
                                    </label>
                                    <?php echo OVABRW()->options->get_html_dropdown_taxonomies( $get_taxonomy[$slug], $required , '', $slug, $name ); ?>
                                </div>
                            </div>
                        <?php endif;
                    }
                }

                ovabrw_text_input([
                    'type'  => 'hidden',
                    'name'  => 'order',
                    'value' => $order
                ]);
                ovabrw_text_input([
                    'type'  => 'hidden',
                    'name'  => 'orderby',
                    'value' => $orderby
                ]);
            ?>
        </div>
        <div class="s_submit">
            <button class="ovabrw_btn_submit" type="submit">
                <?php esc_html_e( 'Search', 'ova-brw' ); ?>
            </button>
        </div>
        <?php ovabrw_text_input([
            'type'  => 'hidden',
            'name'  => 'ovabrw_search_product',
            'value' => 'ovabrw_search_product'
        ]); ?>
        <?php ovabrw_text_input([
            'type'  => 'hidden',
            'name'  => 'ovabrw_search',
            'value' => 'search_item'
        ]); ?>
        <?php ovabrw_text_input([
            'type'  => 'hidden',
            'name'  => 'post_type',
            'value' => 'product'
        ]); ?>
    </form>
</div>