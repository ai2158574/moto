<?php defined( 'ABSPATH' ) || exit();

if ( ! class_exists( 'OVABRW_Abstract_Rental_Types', false ) ) {
	abstract class OVABRW_Abstract_Rental_Types {
		protected $ID 		= null;
		protected $type 	= null;
		protected $prefix 	= OVABRW_PREFIX;

		public function __construct() {
			// Cart Validation
			add_filter( 'woocommerce_add_to_cart_validation', array( $this, 'ovabrw_wc_add_to_cart_validation' ), 11, 3 );

			// Cart add item data
			add_filter( 'woocommerce_add_cart_item_data', array( $this, 'ovabrw_wc_add_cart_item_data' ), 11, 4 );

			// Cart show item data
			add_filter( 'woocommerce_get_item_data', array( $this, 'ovabrw_show_item_data' ), 11, 2 );

			// Cart show item price
			add_filter( 'woocommerce_cart_item_price', array( $this, 'ovabrw_cart_show_item_price' ), 11, 3 );

			// Cart show item quantity
			add_filter( 'woocommerce_cart_item_quantity', array( $this, 'ovabrw_cart_show_item_quantity' ), 11, 3 );

			// Checkout show item quantity
			add_filter( 'woocommerce_checkout_cart_item_quantity', array( $this, 'ovabrw_checkout_show_item_quantity' ), 11, 3 );

			// Order item quantity html
			add_filter( 'woocommerce_order_item_quantity_html', array( $this, 'ovabrw_order_item_quantity_html' ), 11, 2 );

			// Get Product Price in Backend
			add_filter( 'woocommerce_get_price_html', array( $this, 'ovabrw_get_product_price_html' ), 11, 2 );
		}

		abstract public function ovabrw_wc_add_to_cart_validation( $passed_validation, $product_id, $quantity );
		abstract public function ovabrw_wc_add_cart_item_data( $cart_item_data, $product_id, $variation_id, $quantity );
		abstract public function ovabrw_show_item_data( $item_data, $cart_item );
		abstract public function ovabrw_cart_show_item_price( $product_price, $cart_item, $cart_item_key );
		abstract public function ovabrw_cart_show_item_quantity( $product_quantity, $cart_item_key, $cart_item );
		abstract public function ovabrw_checkout_show_item_quantity( $product_quantity, $cart_item, $cart_item_key );
		abstract public function ovabrw_order_item_quantity_html( $item_quantity, $item );
		abstract public function ovabrw_get_product_price_html( $price_html, $product );

		public function set_ID( $id = null ) {
			$this->ID = $id;
		}

		public function get_id() {
			return $this->ID;
		}

		public function get_type() {
			return $this->type;
		}

		public function get_name( $name = '' ) {
			return $this->prefix . $name;
		}

		public function get_value( $key = '', $default = false ) {
			if ( ! $this->ID ) return $default;
			
			$value = get_post_meta( $this->ID, $this->prefix . $key, true );

			if ( $value == '' && $default != '' ) {
				$value = $default;
			}

			return $value;
		}

		public function get_value_by_id( $product_id = '', $key = '', $default = false ) {
			if ( ! $product_id || ! $key ) return $default;

			$value = get_post_meta( $product_id, $this->prefix . $key, true );

			if ( $value == '' && $default != '' ) {
				$value = $default;
			}

			return $value;
		}

		public function get_max_rental_day( $pickup_date = '', $dropoff_date = '', $max_rental_day = '' ) {
			if ( ! $pickup_date || ! $dropoff_date || ! $max_rental_day ) return false;

			// 1 day = 86400s
			return ( $dropoff_date - $pickup_date ) > $max_rental_day*86400 ? true : false;
		}

		public function get_min_rental_day( $pickup_date = '', $dropoff_date = '', $min_rental_day = '' ) {
			if ( ! $pickup_date || ! $dropoff_date || ! $min_rental_day ) return false;

			// 1 day = 86400s
			return ( $dropoff_date - $pickup_date ) < $min_rental_day*86400 ? true : false;
		}

		public function get_max_rental_hour( $pickup_date = '', $dropoff_date = '', $max_rental_hour = '' ) {
			if ( ! $pickup_date || ! $dropoff_date || ! $max_rental_hour ) return false;

			// 1 hour = 3600s
			return ( $dropoff_date - $pickup_date ) > $max_rental_hour*3600 ? true : false;
		}

		public function get_min_rental_hour( $pickup_date = '', $dropoff_date = '', $min_rental_hour = '' ) {
			if ( ! $pickup_date || ! $dropoff_date || ! $min_rental_hour ) return false;

			// 1 day = 3600s
			return ( $dropoff_date - $pickup_date ) < $min_rental_hour*3600 ? true : false;
		}

		public function get_custom_checkout_fields() {
			if ( ! $this->ID ) return false;

			$list_ckf = [];
			$data_ckf = get_option( 'ovabrw_booking_form', [] );

			if ( empty( $data_ckf ) || ! is_array( $data_ckf ) ) return $list_ckf;

			$product_manage_ckf = $this->get_value( 'manage_custom_checkout_field' );

			if ( $product_manage_ckf === 'new' ) {
				$product_ckf 	= $this->get_value( 'product_custom_checkout_field' );
				$arr_ckf 		= explode( ',', $product_ckf );
				$arr_ckf 		= array_map( 'trim', $arr_ckf );

				if ( ovabrw_array_exists( $arr_ckf ) ) {
					foreach ( $arr_ckf as $name ) {
						if ( array_key_exists( $name, $data_ckf ) ) {
							$list_ckf[$name] = $data_ckf[$name];
						}
					}
				}
			} else {
				$categories = wp_get_post_terms( $this->ID, 'product_cat' );
				$term_id 	= isset( $categories[0] ) && is_object( $categories[0] ) ? $categories[0]->term_id : '';
				$term_manager_ckf = $term_id ? get_term_meta( $term_id, 'ovabrw_choose_custom_checkout_field', true ) : '';
				
				if ( $term_manager_ckf === 'all' ) {
					return $data_ckf;
				} elseif ( $term_manager_ckf === 'special' ) {
					$term_ckf = get_term_meta( $term_id, 'ovabrw_custom_checkout_field', true );

					if ( ovabrw_array_exists( $term_ckf ) ) {
						foreach ( $term_ckf as $name ) {
							if ( array_key_exists( $name, $data_ckf ) ) {
								$list_ckf[$name] = $data_ckf[$name];
							}
						}
					}
				} else {
					return $data_ckf;
				}
			}

			return $list_ckf;
		}

		public function get_qty_available( $pickup_date = '', $dropoff_date = '', $pickup_location = '', $dropoff_location = '', $validate = 'cart' ) {
			if ( ! $pickup_date || ! $dropoff_date ) return false;

			$data_available = [
				'qty_available' 	=> 0,
				'vehicle_available' => ''
			];

			$manage_store 	= $this->get_value( 'manage_store' );
			$total_qty 		= $this->get_total_quantity( $manage_store );

			if ( 'store' == $manage_store ) {
				$qty_in_cart 	= 0;
				$qty_in_order 	= $this->get_qty_booked_in_order( $pickup_date, $dropoff_date );

				if ( 'cart' == $validate ) {
					$qty_in_cart = $this->get_qty_booked_in_cart( $pickup_date, $dropoff_date );
				}

				// Unavailabel Time
				if ( $this->check_unavailable_time( $pickup_date, $dropoff_date, $validate ) ) {
					return false;
				}

				$data_available['qty_available'] = $total_qty - ( $qty_in_cart + $qty_in_order );
			} else {
				$vehicle_available = $this->get_vehicle_available( $pickup_date, $dropoff_date, $pickup_location, $dropoff_location, $validate );
				$data_available['vehicle_available'] 	= $vehicle_available;
				$data_available['qty_available'] 		= count( $vehicle_available );
			}			

			return apply_filters( 'ovabrw_get_qty_available', $data_available, $pickup_date, $dropoff_date, $pickup_location, $dropoff_location, $validate, $this->ID );
		}

		public function get_qty_booked_in_cart( $pickup_date = '', $dropoff_date = '' ) {
			$qty_booked = 0;

			if ( !$pickup_date || !$dropoff_date ) return $qty_booked;

			if ( ovabrw_array_exists( WC()->cart->get_cart() ) ) {
				// Multi lang
				$product_ids 	= $this->get_product_ids_with_multi_lang();
				$time_between 	= $this->get_time_between_rentals();

				foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
					$product_id = isset( $cart_item['product_id'] ) ? $cart_item['product_id'] : '';

					if ( in_array( $product_id, $product_ids ) ) {
						// Pickup date item
						$pickup_date_item = isset( $cart_item[$this->get_name('pickup_date')] ) ? strtotime( $cart_item[$this->get_name('pickup_date')] ) : '';

						// Pickup date real
						$pickup_date_real = isset( $cart_item[$this->get_name('pickup_date_real')] ) ? strtotime( $cart_item[$this->get_name('pickup_date_real')] ) : '';

						if ( !$pickup_date_real || !$pickup_date_item ) continue;
						$pickup_date_real += $time_between;

						// Dropoff date item
						$dropoff_date_item = isset( $cart_item[$this->get_name('pickoff_date')] ) ? strtotime( $cart_item[$this->get_name('pickoff_date')] ) : '';

						// Dropoff date real
						$dropoff_date_real = isset( $cart_item[$this->get_name('pickoff_date_real')] ) ? strtotime( $cart_item[$this->get_name('pickoff_date_real')] ) : '';

						if ( !$dropoff_date_real || !$dropoff_date_item ) continue;
						$dropoff_date_real += $time_between;

						// When Drop-off date hidden
						if ( $pickup_date_item === $dropoff_date_item ) {
							$dropoff_date_real 	-= 1;
							$dropoff_date 		+= 1;
						}

						// Qty Cart
						$cart_qty = isset( $cart_item[$this->get_name('number_vehicle')] ) ? absint( $cart_item[$this->get_name('number_vehicle')] ) : '';

						if ( ! $cart_qty ) continue;

						// Check booking period
						if ( apply_filters( 'ovabrw_check_equal_booking_times', false, $product_id ) ) {
							if ( ! ( $pickup_date > $dropoff_date_real || $dropoff_date < $pickup_date_real ) ) {
								$qty_booked += $cart_qty;
							}
						} else {
							if ( ! ( $pickup_date >= $dropoff_date_real || $dropoff_date <= $pickup_date_real ) ) {
								$qty_booked += $cart_qty;
							}
						}
					}
				}
			}

			return apply_filters( 'ovabrw_get_qty_booked_in_cart', $qty_booked, $pickup_date, $dropoff_date, $this->ID );
		}

		public function get_qty_booked_in_order( $pickup_date = '', $dropoff_date = '' ) {
			$qty_booked = 0;

			if ( !$pickup_date || !$dropoff_date ) return $qty_booked;

			$status   	= ovabrw_get_order_status();
        	$order_ids 	= OVABRW()->options->get_orders_by_product_id( $this->ID, $status );

        	if ( ovabrw_array_exists( $order_ids ) ) {
        		// Multi lang
				$product_ids 	= $this->get_product_ids_with_multi_lang();
				$time_between 	= $this->get_time_between_rentals();

				foreach ( $order_ids as $order_id ) {
					$order = wc_get_order( $order_id );

					if ( !$order || !is_object( $order ) ) continue;

                	$items = $order->get_items();

                	if ( !ovabrw_array_exists( $items ) ) continue;

                	foreach ( $items as $item_id => $item ) {
                		if ( !$item || !is_object( $item ) ) continue;

            			$product_id = $item->get_product_id();

            			if ( in_array( $product_id , $product_ids ) ) {
            				// Pickup date item
            				$pickup_date_item = strtotime( $item->get_meta($this->get_name('pickup_date')) );

            				// Pickup date real
            				$pickup_date_real = strtotime( $item->get_meta($this->get_name('pickup_date_real')) );

            				if ( !$pickup_date_real || !$pickup_date_item ) continue;
            				$pickup_date_real += $time_between;

            				// Dropoff date item
        					$dropoff_date_item = strtotime( $item->get_meta($this->get_name('pickoff_date')) );

            				// Dropoff date real
        					$dropoff_date_real = strtotime( $item->get_meta($this->get_name('pickoff_date_real')) );

        					if ( !$dropoff_date_real || !$dropoff_date_item ) continue;
            				$dropoff_date_real += $time_between;

            				// When Drop-off date hidden
							if ( $pickup_date_item === $dropoff_date_item ) {
								$dropoff_date_real 	-= 1;
								$dropoff_date 		+= 1;
							}

            				// Qty item
        					$qty_item = absint( $item->get_meta($this->get_name('number_vehicle')) );

        					if ( ! $qty_item ) continue;

        					// Check booking period
            				if ( $dropoff_date_real >= current_time( 'timestamp' ) ) {
            					if ( apply_filters( 'ovabrw_check_equal_booking_times', false, $product_id ) ) {
            						if ( ! ( $pickup_date > $dropoff_date_real || $dropoff_date < $pickup_date_real ) ) {
	            						$qty_booked += $qty_item;
	            					}
            					} else {
            						if ( ! ( $pickup_date >= $dropoff_date_real || $dropoff_date <= $pickup_date_real ) ) {
	            						$qty_booked += $qty_item;
	            					}
            					}
            				}
            			}
            		}
				}
        	}

        	return apply_filters( 'ovabrw_get_qty_booked_in_order', $qty_booked, $pickup_date, $dropoff_date, $this->ID );
		}

		public function get_vehicle_available( $pickup_date = '', $dropoff_date = '', $pickup_location = '', $dropoff_location = '', $validate = 'cart' ) {
			$vehicle_available = [];

			if ( ! $pickup_date || ! $dropoff_date ) return $vehicle_available;

			$product_vehicle_id = $this->get_value( 'id_vehicles' );
			if ( empty( $product_vehicle_id ) || ! is_array( $product_vehicle_id ) ) {
				$product_vehicle_id = array();
			}

			$vehicle_in_cart = [];

			if ( $validate === 'cart' ) {
				$vehicle_in_cart = $this->get_vehicle_booked_in_cart( $pickup_date, $dropoff_date );
			}

			$vehicle_in_order 	= $this->get_vehicle_booked_in_order( $pickup_date, $dropoff_date );
			$vehicle_booked 	= array_unique( array_merge( $vehicle_in_cart, $vehicle_in_order ) );

			// Vehicle ids available
			$vehicle_diff = array_diff( $product_vehicle_id, $vehicle_booked );

			// Check vehicle ids available
			if ( ovabrw_array_exists( $vehicle_diff ) ) {
				foreach ( $vehicle_diff as $vehicle_id ) {
					$data_vehicle = $this->get_data_vehicle_by_id( $vehicle_id );

					$vehicle_start_untime = $vehicle_end_untime = '';

					if ( ovabrw_array_exists( $data_vehicle['untime'] ) ) {
						$vehicle_start_untime 	= isset( $data_vehicle['untime']['startdate'] ) ? $data_vehicle['untime']['startdate'] : '';
						$vehicle_end_untime 	= isset( $data_vehicle['untime']['enddate'] ) ? $data_vehicle['untime']['enddate'] : '';
					}

					if ( $data_vehicle['required_location'] === 'yes' ) {
						if ( $pickup_location === $data_vehicle['location'] ) {
							if ( $vehicle_start_untime && $vehicle_end_untime ) {
								if ( ! ( $pickup_date >= strtotime( $vehicle_end_untime ) || $dropoff_date <= strtotime( $vehicle_start_untime ) ) ) {
									continue;
								} else {
									array_push( $vehicle_available, $vehicle_id );
								}
							} else {
								array_push( $vehicle_available, $vehicle_id );
							}
						}
					} else {
						if ( $vehicle_start_untime && $vehicle_end_untime ) {
							if ( ! ( $pickup_date >= strtotime( $vehicle_end_untime ) || $dropoff_date <= strtotime( $vehicle_start_untime ) ) ) {
								continue;
							} else {
								array_push( $vehicle_available, $vehicle_id );
							}
						} else {
							array_push( $vehicle_available, $vehicle_id );
						}
					}
				}
			}

			return apply_filters( 'ovabrw_get_vehicle_available', $vehicle_available, $pickup_date, $dropoff_date, $pickup_location, $dropoff_location, $validate, $this->ID );
		}

		public function get_vehicle_booked_in_cart( $pickup_date = '', $dropoff_date = '' ) {
			$vehicle_ids = [];

			if ( !$pickup_date || !$dropoff_date ) return $vehicle_ids;

			if ( ovabrw_array_exists( WC()->cart->get_cart() ) ) {
				// Multi lang
				$product_ids 	= $this->get_product_ids_with_multi_lang();
				$time_between 	= $this->get_time_between_rentals();

				foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
					$product_id = isset( $cart_item['product_id'] ) ? $cart_item['product_id'] : '';

					if ( in_array( $product_id, $product_ids ) ) {
						// Pickup date item
						$pickup_date_item = isset( $cart_item[$this->get_name('pickup_date')] ) ? strtotime( $cart_item[$this->get_name('pickup_date')] ) : '';

						// Pickup date real
						$pickup_date_real = isset( $cart_item[$this->get_name('pickup_date_real')] ) ? strtotime( $cart_item[$this->get_name('pickup_date_real')] ) : '';

						if ( !$pickup_date_real || !$pickup_date_item ) continue;
						$pickup_date_real += $time_between;

						// Dropoff date item
						$dropoff_date_item = isset( $cart_item[$this->get_name('pickoff_date')] ) ? strtotime( $cart_item[$this->get_name('pickoff_date')] ) : '';

						// Dropoff date real
						$dropoff_date_real = isset( $cart_item[$this->get_name('pickoff_date_real')] ) ? strtotime( $cart_item[$this->get_name('pickoff_date_real')] ) : '';

						if ( !$dropoff_date_real || !$dropoff_date_item ) continue;
						$dropoff_date_real += $time_between;

						// When Drop-off date hidden
						if ( $pickup_date_item === $dropoff_date_item ) {
							$dropoff_date_real 	-= 1;
							$dropoff_date 		+= 1;
						}

						// String vehicle id
						$str_vehicle_id = isset( $cart_item['id_vehicle'] ) ? $cart_item['id_vehicle'] : '';

						if ( ! $str_vehicle_id ) continue;

						// Check booking period
						if ( ! ( $pickup_date >= $dropoff_date_real || $dropoff_date <= $pickup_date_real ) ) {
							$vehicle_arr = explode( ',', $str_vehicle_id );
							$vehicle_arr = array_map( 'trim', $vehicle_arr );
							
							foreach ( $vehicle_arr as $vehicle_id ) {
								if ( $vehicle_id ) {
									array_push( $vehicle_ids , $vehicle_id );
								}
							}
						}
					}
				}
			}

			return apply_filters( 'ovabrw_get_vehicle_booked_in_cart', $vehicle_ids, $pickup_date, $dropoff_date, $this->ID );
		}

		public function get_vehicle_booked_in_order( $pickup_date = '', $dropoff_date = '' ) {
			$vehicle_ids = [];

			if ( !$pickup_date || !$dropoff_date ) return $vehicle_ids;

			$status   	= ovabrw_get_order_status();
        	$order_ids 	= OVABRW()->options->get_orders_by_product_id( $this->ID, $status );

        	if ( ovabrw_array_exists( $order_ids ) ) {
        		// Multi lang
				$product_ids 	= $this->get_product_ids_with_multi_lang();
				$time_between 	= $this->get_time_between_rentals();

				foreach ( $order_ids as $order_id ) {
					$order = wc_get_order( $order_id );

					if ( !$order || !is_object( $order ) ) continue;

                	$items = $order->get_items();

                	if ( !ovabrw_array_exists( $items ) ) continue;

                	foreach ( $items as $item_id => $item ) {
                		if ( !$item || !is_object( $item ) ) continue;

            			$product_id = $item->get_product_id();

            			if ( in_array( $product_id , $product_ids ) ) {
            				// Pickup date item
							$pickup_date_item = strtotime( $item->get_meta($this->get_name('pickup_date')) );

            				// Pickup date real
            				$pickup_date_real = strtotime( $item->get_meta($this->get_name('pickup_date_real')) );

            				if ( !$pickup_date_real || !$pickup_date_item ) continue;
            				$pickup_date_real += $time_between;

            				// Dropoff date item
        					$dropoff_date_item = strtotime( $item->get_meta($this->get_name('pickoff_date')) );

            				// Dropoff date real
        					$dropoff_date_real = strtotime( $item->get_meta($this->get_name('pickoff_date_real')) );

        					if ( !$dropoff_date_real || !$dropoff_date_item ) continue;
            				$dropoff_date_real += $time_between;

            				// When Drop-off date hidden
							if ( $pickup_date_item === $dropoff_date_item ) {
								$dropoff_date_real 	-= 1;
								$dropoff_date 		+= 1;
							}

            				// String vehicle id
        					$str_vehicle_id = trim( $item->get_meta('id_vehicle') );

        					if ( ! $str_vehicle_id ) continue;

        					// Check booking period
            				if ( $dropoff_date_real >= current_time( 'timestamp' ) ) {
            					if ( ! ( $pickup_date >= $dropoff_date_real || $dropoff_date <= $pickup_date_real ) ) {
            						$vehicle_arr = explode( ',', $str_vehicle_id );
									$vehicle_arr = array_map( 'trim', $vehicle_arr );
									
									foreach ( $vehicle_arr as $vehicle_id ) {
										if ( $vehicle_id ) {
											array_push( $vehicle_ids , $vehicle_id );
										}
									}
            					}
            				}
            			}
            		}
				}
        	}

        	return apply_filters( 'ovabrw_get_vehicle_booked_in_order', $vehicle_ids, $pickup_date, $dropoff_date, $this->ID );
		}

		public function get_data_vehicle_by_id( $vehicle_id = '' ) {
			if ( ! $vehicle_id ) return false;

			$data_vehicle = [];

			$vehicle_ids = get_posts( array(
		            'post_type'         => 'vehicle',
		            'post_status'       => 'publish',
		            'posts_per_page'    => 1,
		            'fields'            => 'ids',
		            'meta_query'        => array(
		                array(
		                    'key'     => 'ovabrw_id_vehicle',
		                    'value'   => $vehicle_id,
		                    'compare' => '=',
		                ),
		            ),
		        ));

		        if ( ovabrw_array_exists( $vehicle_ids ) ) {
		            foreach ( $vehicle_ids as $id ) {
		            	$data_vehicle['vehicle_id']  		= get_post_meta( $id, 'ovabrw_id_vehicle', true );
		            	$data_vehicle['title']       		= get_the_title( $id );
		                $data_vehicle['location'] 			= get_post_meta( $id, 'ovabrw_id_vehicle_location', true );
		                $data_vehicle['required_location'] 	= get_post_meta( $id, 'ovabrw_vehicle_require_location', true );
		                $data_vehicle['untime']      		= get_post_meta( $id, 'ovabrw_id_vehicle_untime_from_day', true );
		            }
		        }

			return apply_filters( 'ovabrw_get_data_vehicle_by_id', $data_vehicle, $vehicle_id, $this->ID );
		}

		public function get_product_ids_with_multi_lang() {
			if ( ! $this->ID ) return [];

			$product_ids = array( $this->ID );

			// get plugin active
			$active_plugins = get_option('active_plugins');

			if ( in_array ( 'polylang/polylang.php', $active_plugins ) || in_array ( 'polylang-pro/polylang.php', $active_plugins ) ) {
				$languages = pll_languages_list();

				if ( ovabrw_array_exists( $languages ) ) {
					foreach ( $languages as $lang ) {
						$product_ids[] = pll_get_post( $this->ID, $lang );
					}
				}
			} elseif ( in_array ( 'sitepress-multilingual-cms/sitepress.php', $active_plugins ) ) {
				global $sitepress;
			
				if ( isset( $sitepress ) && is_object( $sitepress ) ) {
					$trid 			= $sitepress->get_element_trid( $this->ID, 'post_product' );
					$translations 	= $sitepress->get_element_translations( $trid, 'product' );

					if ( !ovabrw_array_exists( $translations ) ) {
						foreach ( $translations as $lang => $translation ) {
						    $product_ids[] = $translation->element_id;
						}
					}
				}
			} else {
				// nothing
			}

			return apply_filters( 'ovabrw_filter_multiple_languages', $product_ids, $this->ID );
		}

		public function get_time_between_rentals() {
			$time_between = 0;

			if ( $this->type === 'day' || $this->type === 'transportation' ) {
				// 1 day = 86400s
				$time_between = floatval( $this->get_value( 'prepare_vehicle_day' ) ) * 86400;
			} else {
				// 1 hour = 60s
				$time_between = floatval( $this->get_value( 'prepare_vehicle' ) ) * 60;
			}

			return $time_between;
		}

		public function get_total_quantity( $manage_store = 'store' ) {
			$total_qty = 0;

			if ( $manage_store === 'store' ) {
				$total_qty = absint( $this->get_value( 'car_count' ) );
			} else {
				$vehicle_ids 	= $this->get_value( 'id_vehicles' );
				$total_qty 		= ovabrw_array_exists( $vehicle_ids ) ? count( $vehicle_ids ) : 0;
			}

			return $total_qty;
		}

		public function get_price_by_weekday_start( $weekstart, $number_rental_days, $arr_price ) {
			if ( $weekstart == '' || $number_rental_days == '' || !ovabrw_array_exists( $arr_price ) ) return 0;

	        $day_of_week 		= $number_rental_days % 7;
	        $number_weeks 		= floor( $number_rental_days / 7 );
	        $price_monday    	= $arr_price[0];
	        $price_tuesday   	= $arr_price[1];
	        $price_wednesday 	= $arr_price[2];
	        $price_thursday  	= $arr_price[3];
	        $price_friday    	= $arr_price[4];
	        $price_saturday  	= $arr_price[5];
	        $price_sunday    	= $arr_price[6];

	        $price_total = $price_number_week = $price_rent_day_of_week = 0;

	        // Price week ( > 7 days )
	        if ( $number_weeks > 0 ) {
                $price_number_week = $number_weeks * ( $price_monday + $price_tuesday + $price_wednesday + $price_thursday + $price_friday + $price_saturday + $price_sunday );
            }

	        switch ( $weekstart ) {
	            // Monday
	            case 1:
	            	if ( $day_of_week > 0 ) {
	            		switch ( $day_of_week ) {
	                		case 1:
	                			$price_rent_day_of_week = $price_monday;
	                			break;
	                		case 2:
	                			$price_rent_day_of_week = $price_monday + $price_tuesday;
	                			break;
	                		case 3:
	                			$price_rent_day_of_week = $price_monday + $price_tuesday + $price_wednesday;
	                			break;
	                		case 4:
	                			$price_rent_day_of_week = $price_monday + $price_tuesday + $price_wednesday + $price_thursday;
	                			break;
	                		case 5:
	                			$price_rent_day_of_week = $price_monday + $price_tuesday + $price_wednesday + $price_thursday + $price_friday;
	                			break;
	                		case 6:
	                			$price_rent_day_of_week = $price_monday + $price_tuesday + $price_wednesday + $price_thursday + $price_friday + $price_saturday;
	                			break;
	                	}
	            	}

	                $price_total = $price_number_week + $price_rent_day_of_week;
	                break;
	            // Tuesday
	            case 2:
	            	if ( $day_of_week > 0 ) {
	                	switch ( $day_of_week ) {
	                		case 1:
	                			$price_rent_day_of_week = $price_tuesday;
	                			break;
	                		case 2:
	                			$price_rent_day_of_week = $price_tuesday + $price_wednesday;
	                			break;
	                		case 3:
	                			$price_rent_day_of_week = $price_tuesday + $price_wednesday + $price_thursday;
	                			break;
	                		case 4:
	                			$price_rent_day_of_week = $price_tuesday + $price_wednesday + $price_thursday + $price_friday;
	                			break;
	                		case 5:
	                			$price_rent_day_of_week = $price_tuesday + $price_wednesday + $price_thursday + $price_friday + $price_saturday;
	                			break;
	                		case 6:
	                			$price_rent_day_of_week = $price_tuesday + $price_wednesday + $price_thursday + $price_friday + $price_saturday + $price_sunday;
	                			break;
	                	}
	                }

	                $price_total = $price_number_week + $price_rent_day_of_week;
	                break;
	            // Wecnesday
	            case 3:
	            	if ( $day_of_week > 0 ) {
	                	switch ( $day_of_week ) {
	                		case 1:
	                			$price_rent_day_of_week = $price_wednesday;
	                			break;
	                		case 2:
	                			$price_rent_day_of_week = $price_wednesday + $price_thursday;
	                			break;
	                		case 3:
	                			$price_rent_day_of_week = $price_wednesday + $price_thursday + $price_friday;
	                			break;
	                		case 4:
	                			$price_rent_day_of_week = $price_wednesday + $price_thursday + $price_friday + $price_saturday;
	                			break;
	                		case 5:
	                			$price_rent_day_of_week = $price_wednesday + $price_thursday + $price_friday + $price_saturday + $price_sunday;
	                			break;
	                		case 6:
	                			$price_rent_day_of_week = $price_wednesday + $price_thursday + $price_friday + $price_saturday + $price_sunday + $price_monday;
	                			break;
	                	}
	                }

	                $price_total = $price_number_week + $price_rent_day_of_week;
	                break;
	            // Thursday
	            case 4:
	            	if ( $day_of_week > 0 ) {
		            	switch ( $day_of_week ) {
	                		case 1:
	                			$price_rent_day_of_week = $price_thursday;
	                			break;
	                		case 2:
	                			$price_rent_day_of_week = $price_thursday + $price_friday;
	                			break;
	                		case 3:
	                			$price_rent_day_of_week = $price_thursday + $price_friday + $price_saturday;
	                			break;
	                		case 4:
	                			$price_rent_day_of_week = $price_thursday + $price_friday + $price_saturday + $price_sunday;
	                			break;
	                		case 5:
	                			$price_rent_day_of_week = $price_thursday + $price_friday + $price_saturday + $price_sunday + $price_monday;
	                			break;
	                		case 6:
	                			$price_rent_day_of_week = $price_thursday + $price_friday + $price_saturday + $price_sunday + $price_monday + $price_tuesday;
	                			break;
	                	}
	                }

	                $price_total = $price_number_week + $price_rent_day_of_week;
	                break;
	            // Friday
	            case 5:
	            	if ( $day_of_week > 0 ) {
		            	switch ( $day_of_week ) {
	                		case 1:
	                			$price_rent_day_of_week = $price_friday;
	                			break;
	                		case 2:
	                			$price_rent_day_of_week = $price_friday + $price_saturday;
	                			break;
	                		case 3:
	                			$price_rent_day_of_week = $price_friday + $price_saturday + $price_sunday;
	                			break;
	                		case 4:
	                			$price_rent_day_of_week = $price_friday + $price_saturday + $price_sunday + $price_monday;
	                			break;
	                		case 5:
	                			$price_rent_day_of_week = $price_friday + $price_saturday + $price_sunday + $price_monday + $price_tuesday;
	                			break;
	                		case 6:
	                			$price_rent_day_of_week = $price_friday + $price_saturday + $price_sunday + $price_monday + $price_tuesday + $price_wednesday;
	                			break;
	                	}
	                }

	                $price_total = $price_number_week + $price_rent_day_of_week;
	                break;
	            // Saturday
	            case 6:
	            	if ( $day_of_week > 0 ) {
		            	switch ( $day_of_week ) {
	                		case 1:
	                			$price_rent_day_of_week = $price_saturday;
	                			break;
	                		case 2:
	                			$price_rent_day_of_week = $price_saturday + $price_sunday;
	                			break;
	                		case 3:
	                			$price_rent_day_of_week = $price_saturday + $price_sunday + $price_monday;
	                			break;
	                		case 4:
	                			$price_rent_day_of_week = $price_saturday + $price_sunday + $price_monday + $price_tuesday;
	                			break;
	                		case 5:
	                			$price_rent_day_of_week = $price_saturday + $price_sunday + $price_monday + $price_tuesday + $price_wednesday;
	                			break;
	                		case 6:
	                			$price_rent_day_of_week = $price_saturday + $price_sunday + $price_monday + $price_tuesday + $price_wednesday + $price_thursday;
	                			break;
	                	}
	                }

	                $price_total = $price_number_week + $price_rent_day_of_week;
	                break;
	            // Sunday
	            case 7:
	            	if ( $day_of_week > 0 ) {
		            	switch ( $day_of_week ) {
	                		case 1:
	                			$price_rent_day_of_week = $price_sunday;
	                			break;
	                		case 2:
	                			$price_rent_day_of_week = $price_sunday + $price_monday;
	                			break;
	                		case 3:
	                			$price_rent_day_of_week = $price_sunday + $price_monday + $price_tuesday;
	                			break;
	                		case 4:
	                			$price_rent_day_of_week = $price_sunday + $price_monday + $price_tuesday + $price_wednesday;
	                			break;
	                		case 5:
	                			$price_rent_day_of_week = $price_sunday + $price_monday + $price_tuesday + $price_wednesday + $price_thursday;
	                			break;
	                		case 6:
	                			$price_rent_day_of_week = $price_sunday + $price_monday + $price_tuesday + $price_wednesday + $price_thursday + $price_friday;
	                			break;
	                	}
	                }

	                $price_total = $price_number_week + $price_rent_day_of_week;
	                break;
	            default:
	            	$price_total = 0;
	            	break;
	        }

	        return floatval( $price_total );
	    }

	    public function get_global_price_by_weekday_start( $weekstart, $regular_price ) {
	    	if ( $weekstart == '' ) return $regular_price;

	    	// Week price
			$monday_price 		= floatval( $this->get_value( 'daily_monday', $regular_price ) );
			$tuesday_price 		= floatval( $this->get_value( 'daily_tuesday', $regular_price ) );
			$wednesday_price 	= floatval( $this->get_value( 'daily_wednesday', $regular_price ) );
			$thursday_price 	= floatval( $this->get_value( 'daily_thursday', $regular_price ) );
			$friday_price 		= floatval( $this->get_value( 'daily_friday', $regular_price ) );
			$saturday_price 	= floatval( $this->get_value( 'daily_saturday', $regular_price ) );
			$sunday_price 		= floatval( $this->get_value( 'daily_sunday', $regular_price ) );

			switch ( $weekstart ) {
				case 1:
					return $monday_price;
				case 2:
					return $tuesday_price;
				case 3:
					return $wednesday_price;
				case 4:
					return $thursday_price;
				case 5:
					return $friday_price;
				case 6:
					return $saturday_price;
				case 7:
					return $sunday_price;
				default:
					return 0;
			}
	    }

	    public function get_resource_prices( $pickup_date = '', $dropoff_date = '', $resources = [], $resources_qty = [] ) {
	    	$resource_prices = 0;

	    	if ( !$this->ID || !$pickup_date || !$dropoff_date || !ovabrw_array_exists( $resources ) ) return $resource_prices;

	    	// Resource qtys
	    	if ( !ovabrw_array_exists( $resources_qty ) ) $resources_qty = [];

	    	// Resource qtys
	    	$res_ids = $this->get_value( 'resource_id', [] );
	    	if ( !ovabrw_array_exists( $res_ids ) ) $res_ids = [];

	    	// Get Ceil Time Between
	    	$time_between 	= $this->get_ceil_time_between( $pickup_date, $dropoff_date );
	    	$qty_rent_days 	= $time_between['qty_rent_days'];
	    	$qty_rent_hours = $time_between['qty_rent_hours'];
	        $res_prices 	= $this->get_value( 'resource_price', [] );
	        $res_duration  	= $this->get_value( 'resource_duration_type', [] );

	        foreach ( array_keys( $resources ) as $k ) {
	        	$res_index = array_search( $k, $res_ids );

	        	if ( is_bool( $res_index ) ) continue;

	        	$qty 		= isset( $resources_qty[$k] ) ? absint( $resources_qty[$k] ) : 1;
	        	$price 		= isset( $res_prices[$res_index] ) ? floatval( $res_prices[$res_index] ) : 0;
	        	$duration 	= isset( $res_duration[$res_index] ) ? $res_duration[$res_index] : '';

	        	if ( $duration === 'total' ) {
	        		$resource_prices += $price * $qty;
	        	} elseif ( $duration === 'days' ) {
	        		$resource_prices += $price * $qty_rent_days * $qty;
	        	} elseif ( $duration === 'hours' ) {
	        		$resource_prices += $price * $qty_rent_hours * $qty;
	        	} else {
	        		continue;
	        	}
	        }

	    	return floatval( $resource_prices );
	    }

	    public function get_service_prices( $pickup_date = '', $dropoff_date = '', $services = [], $services_qty = [] ) {
	    	$service_prices = 0;

	    	if ( !$this->ID || !$pickup_date || !$dropoff_date || !ovabrw_array_exists( $services ) ) return $service_prices;

	    	// Service qtys
	    	if ( empty( $services_qty ) ) $services_qty = [];

	    	// Service ids
	    	$serv_ids = $this->get_value( 'service_id', [] );
	    	if ( !ovabrw_array_exists( $serv_ids ) ) $serv_ids = [];

	    	// Get Ceil Time Between
	    	$time_between 	= $this->get_ceil_time_between( $pickup_date, $dropoff_date );
	    	$qty_rent_days 	= $time_between['qty_rent_days'];
	    	$qty_rent_hours = $time_between['qty_rent_hours'];
	    	$serv_prices 	= $this->get_value( 'service_price', [] );
	    	$serv_duration 	= $this->get_value( 'service_duration_type', [] );

	    	foreach ( $services as $k ) {
	    		if ( ovabrw_array_exists( $serv_ids ) ) {
	    			foreach ( $serv_ids as $i => $ids ) {
	    				$option_index = array_search( $k, $ids );

	        			if ( is_bool( $option_index ) ) continue;

	        			$qty 		= isset( $services_qty[$k] ) ? absint( $services_qty[$k] ) : 1;
	        			$price 		= isset( $serv_prices[$i][$option_index] ) ? floatval( $serv_prices[$i][$option_index] ) : 0;
	        			$duration 	= isset( $serv_duration[$i][$option_index] ) ? $serv_duration[$i][$option_index] : '';

	        			if ( $duration === 'total' ) {
	        				$service_prices += $price * $qty;
	        			} elseif ( $duration === 'days' ) {
	        				$service_prices += $price * $qty_rent_days * $qty;
	        			} elseif ( $duration === 'hours' ) {
	        				$service_prices += $price * $qty_rent_hours * $qty;
	        			} else {
	        				continue;
	        			}
	    			}
	    		}
	    	}

	    	return floatval( $service_prices );
	    }

	    public function get_ckf_prices( $custom_ckf = [], $custom_ckf_qty = [] ) {
	    	$ckf_prices = 0;

	    	if ( !$this->ID || !ovabrw_array_exists( $custom_ckf ) ) return $ckf_prices;

	    	// Get custom checkout fields
	    	$list_ckf = $this->get_custom_checkout_fields();

	    	foreach ( $custom_ckf as $key => $val ) {
	            if ( isset( $list_ckf[$key] ) && ! empty( $list_ckf[$key] ) ) {
	                $type = $list_ckf[$key]['type'];

	                if ( !$type || !in_array( $type, array( 'radio', 'select', 'checkbox' ) ) ) continue;

	                if ( $type === 'radio' && isset( $list_ckf[$key]['ova_values'] ) && $list_ckf[$key]['ova_values'] ) {
	                    foreach ( $list_ckf[$key]['ova_values'] as $k => $v ) {
	                        if ( $val === $v && isset( $list_ckf[$key]['ova_prices'][$k] ) ) {
	                            $qty = isset( $custom_ckf_qty[$key] ) && absint( $custom_ckf_qty[$key] ) ? absint( $custom_ckf_qty[$key] ) : 1;
	                            $ckf_prices += floatval( $list_ckf[$key]['ova_prices'][$k] ) * $qty;
	                            break;
	                        }
	                    }
	                }

	                if ( $type === 'select' && isset( $list_ckf[$key]['ova_options_key'] ) && $list_ckf[$key]['ova_options_key'] ) {
	                    foreach ( $list_ckf[$key]['ova_options_key'] as $k => $v ) {
	                        if ( $val === $v && isset( $list_ckf[$key]['ova_options_price'][$k] ) ) {
	                            $qty = isset( $custom_ckf_qty[$val] ) && absint( $custom_ckf_qty[$val] ) ? absint( $custom_ckf_qty[$val] ) : 1;
	                            $ckf_prices += floatval( $list_ckf[$key]['ova_options_price'][$k] ) * $qty;
	                            break;
	                        }
	                    }
	                }

	                if ( $type === 'checkbox' && ! empty( $val ) && is_array( $val ) ) {
	                    $checkbox_key   = isset( $list_ckf[$key]['ova_checkbox_key'] ) ? $list_ckf[$key]['ova_checkbox_key'] : '';
	                    $checkbox_price = isset( $list_ckf[$key]['ova_checkbox_price'] ) ? $list_ckf[$key]['ova_checkbox_price'] : '';
	                    if ( ! empty( $checkbox_key ) && ! empty( $checkbox_price ) ) {
	                        foreach ( $val as $val_cb ) {
	                            $key_cb = array_search( $val_cb, $checkbox_key );

	                            if ( ! is_bool( $key_cb ) ) {
	                                if ( ovabrw_check_array( $checkbox_price, $key_cb ) ) {
	                                    $qty = isset( $custom_ckf_qty[$val_cb] ) && absint( $custom_ckf_qty[$val_cb] ) ? absint( $custom_ckf_qty[$val_cb] ) : 1;
	                                    $ckf_prices += floatval( $checkbox_price[$key_cb] ) * $qty;
	                                }
	                            }
	                        }
	                    }
	                }
	            }
	        }

	    	return floatval( $ckf_prices );
	    }

		public function get_ceil_time_between( $pickup_date = '', $dropoff_date = '' ) {
			$time_between = array(
				'qty_rent_days' 	=> 0,
				'qty_rent_hours' 	=> 0
			);

			if ( ! $pickup_date || ! $dropoff_date ) {
				return apply_filters( 'ovabrw_filter_ceil_time_between', $time_between, $pickup_date, $dropoff_date, $this );
			}

			$rent_time_day_raw 	= ( $dropoff_date - $pickup_date ) / 86400;
		    $rent_time_hour_raw = ( $dropoff_date - $pickup_date ) / 3600;
		    $rent_time_days 	= ceil( $rent_time_day_raw );
		    $rent_time_hours 	= ceil( $rent_time_hour_raw );

		    $time_between['qty_rent_days'] 	= $rent_time_days;
		    $time_between['qty_rent_hours'] = $rent_time_hours;

		    return apply_filters( 'ovabrw_filter_ceil_time_between', $time_between, $pickup_date, $dropoff_date, $this );
		}

		public function show_location( $type = 'pickup' ) {
			$show_location = $this->get_value( 'show_pickup_location_product' );

			if ( $type === 'dropoff' ) $show_location = $this->get_value( 'show_pickoff_location_product' );

			switch ( $show_location ) {
				case 'yes':
					return true;
				case 'no':
					return false;
				default:
					$categories 	= wp_get_post_terms( $this->ID, 'product_cat' );
					$term_id 		= isset( $categories[0] ) ? $categories[0]->term_id : '';
					$term_location 	= $term_id ? get_term_meta( $term_id, 'ovabrw_show_loc_booking_form', true ) : '';

					if ( $type == 'pickup' ) {
						if ( ovabrw_array_exists( $term_location ) ) {
							if ( in_array( 'pickup_loc', $term_location ) ) {
								return true;
							} else {
								return false;
							}
						} else {
							if ( 'yes' == get_option( 'ova_brw_booking_form_show_pickup_location', 'no' ) ) {
								return true;
							} else {
								return false;
							}
						}
					} elseif ( $type == 'dropoff' ) {
						if ( ovabrw_array_exists( $term_location ) ) {
							if ( in_array( 'dropoff_loc', $term_location ) ) {
								return true;
							} else {
								return false;
							}
						} else {
							if ( 'yes' == get_option( 'ova_brw_booking_form_show_pickoff_location', 'no' ) ) {
								return true;
							} else {
								return false;
							}
						}
					}

					break;
			}

			return true;
		}

		public function show_date( $type = 'pickup' ) {
			$show_date = $this->get_value( 'show_pickup_date_product' );

			if ( $type == 'dropoff' ) $show_date = $this->get_value( 'show_pickoff_date_product' );

			switch ( $show_date ) {
				case 'yes':
					return true;
				case 'no':
					return false;
				default:
					if ( $type == 'pickup' ) {
						return true;
					}

					if ( $type == 'dropoff' ) {
						if ( get_option( 'ova_brw_booking_form_show_dropoff_date', 'yes' ) === 'yes' ) {
							return true;
						} else {
							return false;
						}
					}
			}

			return true;
		}

		public function show_quantity() {
			$show_quantity = $this->get_value( 'show_number_vehicle', 'in_setting' );
			
			switch ( $show_quantity ) {
				case 'in_setting':
					if ( get_option( 'ova_brw_booking_form_show_number_vehicle', 'yes' ) == 'yes' ) {
						return true;
					} else {
						return false;
					}
				case 'yes':
					return true;
				case 'no':
					return false;
				default:
					return true;
			}

			return true;
		}

		public function required_service_fields() {
			// Get services
			$services = ovabrw_get_meta_data( 'ovabrw_service', $_REQUEST );

            if ( ovabrw_array_exists( $services ) ) {
	            $service_required 	= $this->get_value( 'service_required' );
	            $service_labels 	= $this->get_value( 'label_service' );

	            if ( ovabrw_array_exists( $service_required ) ) {
	                foreach ( $service_required as $k => $value ) {
	                    if ( 'yes' == $value ) {
	                        if ( !ovabrw_get_meta_data( $k, $services ) ) {
	                        	$service_label = ovabrw_get_meta_data( $k, $service_labels );

	                            wc_clear_notices();
	                            echo wc_add_notice( sprintf( esc_html__( '%s field is required', 'ova-brw' ), $service_label ), 'error' );   
	                            return true;
	                        }
	                    }
	                }
	            }
	        }

			return false;
		}

		public function required_custom_checkout_fields() {
			do_action( 'ovabrw_before_required_custom_checkout_fields' );

			// Get custom checkout fields
			$list_ckf = $this->get_custom_checkout_fields();

			if ( ovabrw_array_exists( $list_ckf ) ) {
				foreach ( $list_ckf as $key => $field ) {
	                if ( $field['enabled'] ) {
	                    if ( 'file' == $field['type'] ) {
	                        $files      = isset( $_FILES[$key] ) ? $_FILES[$key] : '';
	                        $file_name  = isset( $files['name'] ) ? $files['name'] : '';

	                        if ( $field['required'] === 'on' && ! $file_name  ) {
	                            wc_clear_notices();
	                            echo wc_add_notice( sprintf( esc_html__( '%s field is required', 'ova-brw'), $field['label'] ), 'error' );
	                            return true;
	                        }

	                        if ( $file_name ) {
	                            if ( isset( $files['size'] ) && $files['size'] ) {
	                                $mb = absint( $files['size'] ) / 1048576;

	                                if ( $mb > $field['max_file_size'] ) {
	                                    wc_clear_notices();
	                                    echo wc_add_notice( sprintf( esc_html__( '%s max file size %sMB', 'ova-brw'), $field['label'], $field['max_file_size'] ), 'error' );
	                                    return true;
	                                }
	                            }

	                            $overrides = [
	                                'test_form' => false,
	                                'mimes'     => apply_filters( 'ovabrw_ft_file_mimes', [
	                                    'jpg'   => 'image/jpeg',
	                                    'jpeg'  => 'image/pjpeg',
	                                    'png'   => 'image/png',
	                                    'pdf'   => 'application/pdf',
	                                    'doc'   => 'application/msword',
	                                ]),
	                            ];

	                            require_once( ABSPATH . 'wp-admin/includes/admin.php' );

	                            $upload = wp_handle_upload( $files, $overrides );

	                            if ( isset( $upload['error'] ) ) {
	                                wc_clear_notices();
	                                echo wc_add_notice( $upload['error'] , 'error' );
	                                return true;
	                            }
	                            
	                            $object = array(
	                                'name' => basename( $upload['file'] ),
	                                'url'  => $upload['url'],
	                                'mime' => $upload['type'],
	                            );

	                            $prefix = 'ovabrw_'.$key;

	                            $_REQUEST[$prefix] = $object;
	                        }
	                    } elseif ( 'date' == $field['type'] ) {
	                    	$value = isset( $_REQUEST[$key] ) ? strtotime( $_REQUEST[$key] ) : '';

	                    	if ( ! $value && $field['required'] === 'on' ) {
	                            wc_clear_notices();
	                            echo wc_add_notice( sprintf( esc_html__( '%s field is required', 'ova-brw'), $field['label'] ), 'error' );
	                            return true;
	                        }

	                        $min_date = isset( $field['min_date'] ) && $field['min_date'] ? strtotime( $field['min_date'] ) : '';
	                        $max_date = isset( $field['max_date'] ) && $field['max_date'] ? strtotime( $field['max_date'] ) : '';

	                        if ( $min_date && $value < $min_date ) {
	                        	wc_clear_notices();
	                            echo wc_add_notice( sprintf( esc_html__( '%s must be greater than %s', 'ova-brw'), $field['label'], $field['min_date'] ), 'error' );
	                            return true;
	                        }

	                        if ( $max_date && $value > $max_date ) {
	                        	wc_clear_notices();
	                            echo wc_add_notice( sprintf( esc_html__( '%s must be less than %s', 'ova-brw'), $field['label'], $field['max_date'] ), 'error' );
	                            return true;
	                        }
	                    } else {
	                        $value = isset( $_REQUEST[$key] ) ? $_REQUEST[$key] : '';

	                        if ( ! $value && $field['required'] === 'on' ) {
	                            wc_clear_notices();
	                            echo wc_add_notice( sprintf( esc_html__( '%s field is required', 'ova-brw'), $field['label'] ), 'error' );
	                            return true;
	                        }
	                    }
	                }
	            }
			}

			do_action( 'ovabrw_after_required_custom_checkout_fields' );

			return false;
		}

		public function check_preparation_time( $pickup_date = '' ) {
			if ( ! $pickup_date ) return false;

			$preparation_time = floatval( $this->get_value( 'preparation_time' ) );

			if ( $preparation_time ) {
	            $today = strtotime( date( 'Y-m-d', current_time( 'timestamp' ) ) );

	            if ( $pickup_date < ( $today + $preparation_time*86400 ) ) {
	                wc_clear_notices();

	                if ( $preparation_time == 1 ) {
	                	echo wc_add_notice( sprintf( esc_html__( 'Book in advance %s day from the current date', 'ova-brw' ), $preparation_time ), 'error' );
	                } else {
	                	echo wc_add_notice( sprintf( esc_html__( 'Book in advance %s days from the current date', 'ova-brw' ), $preparation_time ), 'error' );
	                }

	                return true;
	            }
	        }

	        return false;
		}

		public function check_unavailable_time( $pickup_date = '', $dropoff_date = '', $validate = 'cart' ) {
			if ( !$pickup_date || !$dropoff_date ) return false;

			$untime_startdate = $this->get_value( 'untime_startdate' );
        	$untime_enddate   = $this->get_value( 'untime_enddate' );

        	if ( ovabrw_array_exists( $untime_startdate ) && ovabrw_array_exists( $untime_enddate ) ) {
        		foreach ( $untime_startdate as $k => $start_date ) {
        			$start_date = strtotime( $start_date );
        			$end_date 	= isset( $untime_enddate[$k] ) ? strtotime( $untime_enddate[$k] ) : '';

        			if ( !( $start_date > $dropoff_date || $end_date < $pickup_date ) ) {
        				if ( 'cart' == $validate ) {
        					wc_clear_notices();
                        	echo wc_add_notice( esc_html__( 'This time is not available for renting', 'ova-brw' ), 'error' );
        				}

                        return true;
        			}
        		}
        	}

        	return false;
		}

		public function check_disable_week_day( $pickup_date = '', $dropoff_date = '' ) {
			if ( !$pickup_date || !$dropoff_date ) return false;

	        $disable_weekdays = $this->get_value( 'product_disable_week_day' );

	        if ( !$disable_weekdays ) {
	            $disable_weekdays = get_option( 'ova_brw_calendar_disable_week_day', [] );
	        }
	        if ( ovabrw_array_exists( $disable_weekdays ) ) {
	        	$key = array_search( '7', $disable_weekdays );
	        	if ( $key !== false ) $disable_weekdays[$key] = '0';
	        } else {
	        	if ( $disable_weekdays && !is_array( $disable_weekdays ) ) {
	        		$disable_weekdays = explode( ',', $disable_weekdays );
	        		$disable_weekdays = array_map( 'trim', $disable_weekdays );
	        	}
	        }

	        if ( ovabrw_array_exists( $disable_weekdays ) ) {
	        	if ( ovabrw_allow_boooking_incl_disable_week_day() ) {
	                $pickup_date_of_week    = date('w', $pickup_date );
	                $dropoff_date_of_week   = date('w', $dropoff_date );

	                if ( in_array( $pickup_date_of_week, $disable_weekdays ) || in_array( $dropoff_date_of_week, $disable_weekdays ) ) {
	                    wc_clear_notices();
	                    echo wc_add_notice( esc_html__( 'This time is not available for renting', 'ova-brw' ), 'error' );
	                    return true;
	                }
	            } else {
	                $datediff       = (int)$dropoff_date - (int)$pickup_date;
	                $total_datediff = round( $datediff / (60 * 60 * 24), wc_get_price_decimals() ) + 1;

	                // get number day
	                $pickup_date_of_week   = date('w', $pickup_date );
	                $pickup_date_timestamp = $pickup_date;
	                
	                $i = 0;
	                while ( $i <= $total_datediff ) {
	                    if ( in_array( $pickup_date_of_week, $disable_weekdays ) ) {
	                        wc_clear_notices();
	                        echo wc_add_notice( esc_html__( 'This time is not available for renting', 'ova-brw' ), 'error' );
	                        return true;
	                    }

	                    $pickup_date_of_week    = date('w', $pickup_date_timestamp );
	                    $pickup_date_timestamp  = strtotime('+1 day', $pickup_date_timestamp);
	                    $i++;
	                }
	            }
	        }

	        return false;
		}
	}
}