<?php defined( 'ABSPATH' ) || exit();

if ( ! class_exists( 'OVABRW_Rental_Types' ) ) {
	class OVABRW_Rental_Types {
		protected static $_instance = null;
		public $rental_types = [];

		public function __construct() {
			// Load
			ovabrw_autoload( OVABRW_PLUGIN_PATH .'rental-types/types/class-ovabrw-rental-by-*.php' );

			// Object Rental Types
			$this->get_rental_types();

			// Hook calculate totals
			add_action( 'woocommerce_before_calculate_totals', array( $this, 'ovabrw_before_calculate_totals' ), 11 );

			// Checkout Validate
			add_action( 'woocommerce_after_checkout_validation', array( $this, 'ovabrw_after_checkout_validation' ), 11, 2 );

			// 	Validate cart
			add_action( 'woocommerce_store_api_cart_errors', array( $this, 'ovabrw_store_api_cart_errors' ), 11, 2 );

			// Checkout order created
			add_action( 'woocommerce_checkout_order_created', array( $this, 'ovabrw_reserve_stock_for_order' ), 11 );

			// Checkout create order line item
			add_action( 'woocommerce_checkout_create_order_line_item', array( $this, 'ovabrw_checkout_create_order_line_item' ), 11, 4 );

			// Checkout create order fee item
			add_action( 'woocommerce_checkout_create_order_fee_item', array( $this, 'ovabrw_checkout_create_order_fee_item' ), 10, 4 );

			// Order item display meta from backend
			add_filter( 'woocommerce_order_item_display_meta_key', array( $this, 'ovabrw_order_item_display_meta_key' ), 11, 3 );

			// Order item display meta from email
			add_filter( 'woocommerce_order_item_display_meta_value', array( $this, 'ovabrw_order_item_display_meta_value' ), 11, 3 );

			// Hide meta item fields
			add_filter( 'woocommerce_order_item_get_formatted_meta_data', array( $this, 'ovabrw_order_item_get_formatted_meta_data' ), 11, 2 );

			// Email Order Items - Quantity
			add_filter( 'woocommerce_email_order_item_quantity', array( $this, 'ovabrw_email_order_item_quantity' ), 11, 2 );

			// HTML Product Sticky
			add_action( 'woocommerce_after_single_product', array( $this, 'ovabrw_product_sticky' ) );
		}

		public function ovabrw_product_sticky() {
			do_action( 'ovabrw_before_product_sticky' );

			if ( ! apply_filters( 'ovabrw_before_product_sticky', true ) ) return;

			global $product;

			if ( isset( $args['product_id'] ) && $args['product_id'] ) {
				$product = wc_get_product( $args['product_id'] );
			}

			if ( ! $product ) return;
			$product_id = $product->get_id();
			if ( ! ovabrw_is_rental_product( $product_id ) ) return;

			$rental_type 	= get_post_meta( $product_id, 'ovabrw_price_type', true );
			$rental_object 	= isset( $this->rental_types[$rental_type] ) ? $this->rental_types[$rental_type] : '';
        	if ( empty( $rental_object ) || ! is_object( $rental_object ) ) return;
        	$price_format 	= OVABRW()->options->get_single_price_by_format( $product_id );

        	$btn_link = '#booking_form';

        	if ( get_option( 'ova_brw_template_show_booking_form', 'yes' ) != 'yes' ) {
        		if ( get_option( 'ova_brw_template_show_request_booking', 'yes' ) === 'yes' ) {
        			$btn_link = '#request_booking';
        		} else {
        			$btn_link = '#';
        		}
        	}
		?>
			<div class="ovabrw-product-sticky">
				<div class="ovabrw-sticky-content">
					<div class="ovabrw-product-price">
						<span class="ovabrw-regular-price">
							<?php if ( $price_format ):
								echo wp_kses_post( $price_format );
							else: ?>
							<label>
								<?php esc_html_e( 'From', 'ova-brw' ); ?>
							</label>
							<?php $rental_object->get_html_price( $product_id );
							endif; ?>
						</span>
					</div>
					<div class="ovabrw-product-btn">
						<a href="<?php echo esc_attr( $btn_link ); ?>">
							<?php esc_html_e( 'Booking', 'ova-brw' ); ?>
						</a>
					</div>
				</div>
			</div>
		<?php
			do_action( 'ovabrw_after_product_sticky' );
		}

		public function get_rental_types() {
			$this->rental_types['day'] 				= new OVABRW_Rental_By_Day();
			$this->rental_types['hour'] 			= new OVABRW_Rental_By_Hour();
			$this->rental_types['mixed'] 			= new OVABRW_Rental_By_Mixed();
			$this->rental_types['period_time'] 		= new OVABRW_Rental_By_Period_Time();
			$this->rental_types['transportation'] 	= new OVABRW_Rental_By_Transportation();
			$this->rental_types['taxi'] 			= new OVABRW_Rental_By_Taxi();
			$this->rental_types['hotel'] 			= new OVABRW_Rental_By_Hotel();
			$this->rental_types['appointment'] 		= new OVABRW_Rental_By_Appointment();
		}

		public function ovabrw_before_calculate_totals( $cart_obj ) {
			$deposit_amount 	= $remaining_amount = $remaining_tax = 0;
			$insurance_amount 	= $insurance_tax = $remaining_insurance = $remaining_insurance_tax = 0;
			$has_deposit 		= false;

			// Init deposit
			WC()->cart->deposit_info = array();

			// Loop
			foreach ( $cart_obj->get_cart() as $cart_item_key => $cart_item ) {
				// Get product id
				$product_id = $cart_item['data']->get_id();

				// Check rental product
				if ( ! $product_id || ! $cart_item['data']->is_type( 'ovabrw_car_rental' ) ) continue;

				// Rental type
				$type = isset( $cart_item['rental_type'] ) ? $cart_item['rental_type'] : '';

				// Get rental object
				$rental = isset( $this->rental_types[$type] ) ? $this->rental_types[$type] : '';
				if ( ! $rental || ! is_object( $rental ) ) continue;

				// Set ID
				$rental->set_ID( $product_id );

				// Quantity
        		$quantity = isset( $cart_item['ovabrw_number_vehicle'] ) ? absint( $cart_item['ovabrw_number_vehicle'] ) : 1;

        		// Sub insurance
        		$sub_insurance = floatval( $rental->get_value( 'amount_insurance' ) ) * $quantity;
        		$sub_remaining_insurance = 0;

				// Get sub total
				$subtotal = $rental->get_total( $cart_item );

				// Multi currency - Convert subtotal
				if ( is_plugin_active( 'woocommerce-multilingual/wpml-woocommerce.php' ) ) {
	                $subtotal 		= ovabrw_convert_price( $subtotal );
	                $sub_insurance 	= ovabrw_convert_price( $sub_insurance );
	            }

	            // Get deposit
	            $is_deposit = isset( $cart_item['is_deposit'] ) ? $cart_item['is_deposit'] : false;

	            if ( $is_deposit ) {
	            	$has_deposit 	= true;
	            	$sub_deposit 	= 0;
	            	$deposit_type 	= $rental->get_value( 'type_deposit' );
	            	$deposit_value 	= floatval( $rental->get_value( 'amount_deposit' ) );

	            	// Calculate deposit
	            	if ( 'percent' === $deposit_type ) {
	            		$sub_deposit = ( $subtotal * $deposit_value ) / 100;

	            		if ( $sub_insurance && OVABRW()->options->remaining_amount_incl_insurance() ) {
	            			$sub_remaining_insurance = $sub_insurance - floatval( ( $sub_insurance * $deposit_value ) / 100 );
			            	$sub_insurance = floatval( ( $sub_insurance * $deposit_value ) / 100 );
			            }
	            	} elseif ( 'value' === $deposit_type ) {
	            		$sub_deposit = $deposit_value;
	            	}

	            	// Sub remaining
	            	$sub_remaining 			= floatval( $subtotal - $sub_deposit );
	            	$sub_remaining_taxes 	= OVABRW()->options->get_taxes_by_price( $cart_item['data'], ovabrw_convert_price( $sub_remaining, array(), false ) );
	            	$remaining_tax 			+= $sub_remaining_taxes;

	            	// Cart item add data
	            	$cart_item['data']->add_meta_data( 'is_deposit', $is_deposit, true );
	            	$cart_item['data']->add_meta_data( 'deposit_type', $deposit_type, true );
	            	$cart_item['data']->add_meta_data( 'deposit_value', $deposit_value, true );
	            	$cart_item['data']->add_meta_data( 'deposit_amount', round( $sub_deposit, wc_get_price_decimals() ), true );
		            $cart_item['data']->add_meta_data( 'remaining_amount', round( $sub_remaining, wc_get_price_decimals() ), true );
		            $cart_item['data']->add_meta_data( 'remaining_tax', round( $sub_remaining_taxes, wc_get_price_decimals() ), true );
		            $cart_item['data']->add_meta_data( 'total_payable', round( $subtotal, wc_get_price_decimals() ), true );
		            // Set item price
		            $cart_item['data']->set_price( round( $sub_deposit / $quantity, wc_get_price_decimals() ) );

		            $deposit_amount 	+= $sub_deposit;
	            	$remaining_amount 	+= $sub_remaining;
	            } else {
	            	// Set item price
	            	$cart_item['data']->set_price( round( $subtotal / $quantity, wc_get_price_decimals() ) );
	            }

	            // Insurance
	            if ( $sub_insurance ) {
	            	$insurance_amount += $sub_insurance;
	            	$cart_item['data']->add_meta_data( 'insurance_amount', round( $sub_insurance, wc_get_price_decimals() ), true );

	            	$sub_insurance_tax = OVABRW()->options->get_insurance_tax_amount( ovabrw_convert_price( $sub_insurance, array(), false ) );

	            	if ( $sub_insurance_tax ) {
	            		$insurance_tax += $sub_insurance_tax;

	            		$cart_item['data']->add_meta_data( 'insurance_tax', round( $sub_insurance_tax, wc_get_price_decimals() ), true );
	            	}
	            }
	            if ( $sub_remaining_insurance ) {
	            	$remaining_insurance += $sub_remaining_insurance;
	            	$cart_item['data']->add_meta_data( 'remaining_insurance', round( $sub_remaining_insurance, wc_get_price_decimals() ), true );

	            	$sub_remaining_insurance_tax = OVABRW()->options->get_insurance_tax_amount( ovabrw_convert_price( $sub_remaining_insurance, array(), false ) );

	            	if ( $sub_remaining_insurance_tax ) {
	            		$remaining_insurance_tax += $sub_remaining_insurance_tax;

	            		$cart_item['data']->add_meta_data( 'remaining_insurance_tax', round( $sub_remaining_insurance_tax, wc_get_price_decimals() ), true );
	            	}
	            }

	            // Quantity
            	$cart_obj->cart_contents[ $cart_item_key ]['quantity'] = $quantity;
			}

			// Deposit info
			if ( $has_deposit ) {
				WC()->cart->deposit_info[ 'has_deposit' ] 		= $has_deposit;
	            WC()->cart->deposit_info[ 'deposit_amount' ] 	= round( $deposit_amount, wc_get_price_decimals() );
	            WC()->cart->deposit_info[ 'remaining_amount' ]  = round( $remaining_amount, wc_get_price_decimals() );
	            WC()->cart->deposit_info[ 'remaining_tax' ]   	= round( $remaining_tax, wc_get_price_decimals() );
			}

			// Cart fee - Insurance
			if ( $insurance_amount ) {
				$insurance_name 		= OVABRW()->options->get_insurance_name();
				$enable_insurance_tax 	= OVABRW()->options->enable_insurance_tax();
				$tax_class 				= OVABRW()->options->get_insurance_tax_class();

				WC()->cart->add_fee( $insurance_name, ovabrw_convert_price( $insurance_amount, array(), false ), $enable_insurance_tax, $tax_class );

				WC()->cart->deposit_info[ 'insurance_amount' ] 	= $insurance_amount;
				WC()->cart->deposit_info[ 'insurance_tax' ] 	= $insurance_tax;
				WC()->cart->deposit_info[ 'insurance_key' ] 	= sanitize_title( $insurance_name );
			}
			if ( $remaining_insurance ) {
				WC()->cart->deposit_info[ 'remaining_insurance' ] 		= $remaining_insurance;
				WC()->cart->deposit_info[ 'remaining_insurance_tax' ] 	= $remaining_insurance_tax;
			}
		}

		public function ovabrw_after_checkout_validation( $data, $errors ) {
			foreach ( WC()->cart->get_cart() as $cart_item ) {
				$product = isset( $cart_item['data'] ) ? $cart_item['data'] : '';

				if ( ! empty( $product ) && is_object( $product ) && $product->is_type( 'ovabrw_car_rental' ) ) {
					$product_id = $product->get_id();

					$rental_type = isset( $cart_item['rental_type'] ) ? $cart_item['rental_type'] : '';

					// Object Rental Types
	            	$rental_object = isset( $this->rental_types[$rental_type] ) ? $this->rental_types[$rental_type] : '';
	            	if ( empty( $rental_object ) || ! is_object( $rental_object ) ) continue;

	            	// Set Product ID
	            	$rental_object->set_ID( $product_id );

	            	// Check qty available
	            	$pickup_location 	= ovabrw_get_meta_data( 'ovabrw_pickup_loc', $cart_item );
	            	if ( !$pickup_location ) {
	            		$pickup_location = ovabrw_get_meta_data( 'ovabrw_location', $cart_item );
	            	}
		            $dropoff_location 	= ovabrw_get_meta_data( 'ovabrw_pickoff_loc', $cart_item );
	            	$pickup_date    	= ovabrw_get_meta_data( 'ovabrw_pickup_date', $cart_item );
		            $dropoff_date   	= ovabrw_get_meta_data( 'ovabrw_pickoff_date', $cart_item );
		            $input_qty 			= (int)ovabrw_get_meta_data( 'ovabrw_number_vehicle', $cart_item, 1 );
			        $check_in 			= ovabrw_get_meta_data( 'ovabrw_checkin', $cart_item, strtotime( $pickup_date ) );
			        $check_out 			= ovabrw_get_meta_data( 'ovabrw_checkout', $cart_item, strtotime( $dropoff_date ) );

			        // Get qty available
			        $data_available = $rental_object->get_qty_available( $check_in, $check_out, $pickup_location, $dropoff_location, 'checkout' );
	        		$qty_available 	= $data_available['qty_available'];

	        		// Get reserved quantity
	        		$reserved_quantity = OVABRW()->options->get_reserved_quantity( $product, $check_in, $check_out );
	        		
	        		if ( $reserved_quantity ) $qty_available -= $reserved_quantity;

	        		if ( $input_qty > $qty_available ) {
	        			$errors->add( 'validation', sprintf( esc_html__( '%s isn\'t available for this time, Please book other time.', 'ova-brw' ), $product->get_title() ) );
	        		}
				}
			}
		}

		public function ovabrw_store_api_cart_errors( $cart_errors, $cart ) {
			global $wpdb;

			if ( isset( $cart->cart_contents ) && !empty( $cart->cart_contents ) ) {
				foreach ( $cart->cart_contents as $cart_item ) {
					$product = isset( $cart_item['data'] ) ? $cart_item['data'] : '';

					if ( ! empty( $product ) && is_object( $product ) && $product->is_type( 'ovabrw_car_rental' ) ) {
						$product_id = $product->get_id();

						$rental_type = isset( $cart_item['rental_type'] ) ? $cart_item['rental_type'] : '';

						// Object Rental Types
		            	$rental_object = isset( $this->rental_types[$rental_type] ) ? $this->rental_types[$rental_type] : '';
		            	if ( empty( $rental_object ) || ! is_object( $rental_object ) ) continue;

		            	// Set Product ID
		            	$rental_object->set_ID( $product_id );

		            	// Pick-up location
		            	$pickup_location = ovabrw_get_meta_data( 'ovabrw_pickup_loc', $cart_item );

		            	// Location - Appointment
		            	$location = ovabrw_get_meta_data( 'ovabrw_location', $cart_item );
		            	if ( $location ) $pickup_location = $location;

		            	// Drop-off location
			            $dropoff_location = ovabrw_get_meta_data( 'ovabrw_pickoff_loc', $cart_item );

			            // Pick-up date
		            	$pickup_date = ovabrw_get_meta_data( 'ovabrw_pickup_date', $cart_item );

		            	// Drop-off date
			            $dropoff_date = ovabrw_get_meta_data( 'ovabrw_pickoff_date', $cart_item );

			            // Quantity
			            $input_qty = (int)ovabrw_get_meta_data( 'ovabrw_number_vehicle', $cart_item, 1 );

			            // Check-in date
				        $check_in = ovabrw_get_meta_data( 'ovabrw_checkin', $cart_item, strtotime( $pickup_date ) );

				        // Check-out date
				        $check_out = ovabrw_get_meta_data( 'ovabrw_checkout', $cart_item, strtotime( $dropoff_date ) );

				        // Get qty available
				        $data_available = $rental_object->get_qty_available( $check_in, $check_out, $pickup_location, $dropoff_location, 'checkout' );
		        		$qty_available 	= $data_available['qty_available'];

		        		// Get reserved quantity
		        		$reserved_quantiry = OVABRW()->options->get_reserved_quantity( $product, $check_in, $check_out );
		        		if ( $reserved_quantiry ) $qty_available -= $reserved_quantiry;

		        		if ( $input_qty > $qty_available ) {
		        			$cart_errors->add( 'validation', sprintf( esc_html__( '%s isn\'t available for this time, Please book other time.', 'ova-brw' ), $product->get_title() ) );
		        		}
					}
				}
			}
		}

		public function ovabrw_reserve_stock_for_order( $order ) {
			OVABRW()->options->reserve_stock_for_order( $order );
		}

		public function ovabrw_checkout_create_order_line_item( $item, $cart_item_key, $values, $order ) {
			$product_id = $item->get_product_id();

	        // Check product type: rental
	        $product = wc_get_product( $product_id );
	        if ( !$product || !$product->is_type( 'ovabrw_car_rental' ) ) return;

	        // Rental Type
	        $rental_type = ovabrw_get_meta_data( 'rental_type', $values );
	        
	        // Object Rental Types
        	$rental_object = ovabrw_get_meta_data( $rental_type, $this->rental_types );
        	if ( empty( $rental_object ) || !is_object( $rental_object ) ) return;

        	// Set Product ID
        	$rental_object->set_ID( $product_id );

        	// Save
        	$rental_object->ovabrw_save_order_line_item( $item, $values );
		}

		public function ovabrw_checkout_create_order_fee_item( $item, $fee_key, $fee, $order ) {
			$insurance_key = isset( WC()->cart->deposit_info[ 'insurance_key' ] ) ? WC()->cart->deposit_info[ 'insurance_key' ] : '';

			if ( $insurance_key == $fee_key ) {
				$order->add_meta_data( '_ova_insurance_key', $insurance_key, true );
			}
        }

		public function ovabrw_order_item_display_meta_key( $display_key, $meta, $item ) {
			// Get product ID
			$product_id = method_exists( $item, 'get_product_id' ) ? $item->get_product_id() : '';

			// Location
			if ( 'ovabrw_location' == $meta->key ) {
				$display_key = esc_html__( 'Location', 'ova-brw' );
			}

			// Pick-up location
			if ( 'ovabrw_pickup_loc' == $meta->key ) {
				$display_key = esc_html__( 'Pick-up Location', 'ova-brw' );
			}

			// Drop-off location
        	if ( 'ovabrw_pickoff_loc' == $meta->key ) {
        		$display_key = esc_html__( 'Drop-off Location', 'ova-brw' );
        	}

        	// Pick-up date
        	if ( 'ovabrw_pickup_date' == $meta->key ) {
        		$display_key = OVABRW()->options->get_label_pickup_date( $product_id );
        	}

        	// Drop-off date
        	if ( 'ovabrw_pickoff_date' === $meta->key ) {
        		$display_key = OVABRW()->options->get_label_pickoff_date( $product_id );
        	}

        	// Pick-up date real
        	if ( 'ovabrw_pickup_date_real' == $meta->key ) {
        		$display_key = esc_html__( 'Pick-up Date Real', 'ova-brw' );
        	}

        	// Drop-off date real
        	if ( 'ovabrw_pickoff_date_real' == $meta->key ) {
        		$display_key = esc_html__( 'Drop-off Date Real', 'ova-brw' );
        	}

        	// Package label
        	if ( 'period_label' == $meta->key ) {
        		$display_key = esc_html__(' Package ', 'ova-brw' );
        	}

        	// Package ID
        	if ( 'package_id' == $meta->key ) {
        		$display_key = esc_html__(' Package ID ', 'ova-brw' );
        	}

        	// Quantity
        	if ( 'ovabrw_number_vehicle' == $meta->key ) {
        		$display_key = esc_html__( 'Quantity', 'ova-brw' );
        	}

        	// Vebicle ID
        	if ( 'id_vehicle' == $meta->key ) {
        		$display_key = esc_html__( 'Vehicle ID(s)', 'ova-brw' );
        	}

        	// Total time
        	if ( 'ovabrw_total_days' == $meta->key ) {
        		$display_key = esc_html__( 'Total Time', 'ova-brw' );
        	}

        	// Distance
        	if ( 'ovabrw_distance' == $meta->key ) {
        		$display_key = esc_html__( 'Distance', 'ova-brw' );
        	}

        	// Extra time
	        if ( 'ovabrw_extra_time' == $meta->key ) {
	        	$display_key = esc_html__( 'Extra Time', 'ova-brw' );
	        }

	        // Duration
	        if ( 'ovabrw_duration' == $meta->key ) {
	        	$display_key = esc_html__( 'Duration', 'ova-brw' );
	        }

	        // Origina order ID
	        if ( 'ovabrw_original_order_id' == $meta->key ) {
	        	$display_key = esc_html__( 'Original Order', 'ova-brw' );
	        }

	        // Ramaining order
	        if ( 'ovabrw_remaining_balance_order_id' == $meta->key ) {
	        	$display_key = esc_html__( 'Remaining Order', 'ova-brw' );
	        }

	        // Number of adults
	        if ( 'ovabrw_adults' == $meta->key ) {
	        	$display_key = esc_html__( 'Number of Adults', 'ova-brw' );
	        }

	        // Number of children
	        if ( 'ovabrw_children' == $meta->key ) {
	        	$display_key = esc_html__( 'Number of Children', 'ova-brw' );
	        }

	        // Number of babies
	        if ( 'ovabrw_babies' == $meta->key ) {
	        	$display_key = esc_html__( 'Number of Babies', 'ova-brw' );
	        }

        	// Custom Checkout Fields
        	$cckf = get_option( 'ovabrw_booking_form', array() );

	        if ( ovabrw_array_exists( $cckf ) ) {
	            foreach ( $cckf as $key => $field ) {
	                if ( $key == $meta->key ) {
	                    $display_key = $field['label'];
	                }
	            }
	        }

	        // Deposit
	        $tax_text = $tax_text_remaining = '';

	        if ( wc_tax_enabled() ) {
	            $order = $item->get_order();

	            $remaining_item  = $item->get_meta( 'ovabrw_remaining_amount_product' );
	            $is_tax_included = $order->get_meta( '_ova_tax_display_cart', true );
	            $remaining_taxes = $order->get_meta( '_ova_remaining_taxes', true );
	            $tax_message     = $is_tax_included ? esc_html__( '(incl. tax)', 'ova-brw' ) : esc_html__( '(excl. tax)', 'ova-brw' );

	            if ( ! empty( $remaining_taxes ) ) {
	                $tax_tex = ' <small class="tax_label">' . $tax_message . '</small>';
	            }

	            if ( ! empty( $remaining_item && ! empty( $remaining_taxes ) ) ) {
	                $tax_text_remaining = ' <small class="tax_label">' . $tax_message . '</small>';
	            }
	        }

	        // Insurance amount
	        if ( 'ovabrw_amount_insurance_product' == $meta->key ) {
	        	$display_key = esc_html__( 'Amount Of Insurance', 'ova-brw' );
	        }

	        // Deposit amount
	        if ( 'ovabrw_deposit_amount_product' == $meta->key ) {
	        	$display_key = esc_html__( 'Deposit Amount', 'ova-brw' ).$tax_text;
	        }

	        // Reaming amount
	        if ( 'ovabrw_remaining_amount_product' == $meta->key ) {
	        	$display_key = esc_html__( 'Remaining Amount', 'ova-brw' ).$tax_text_remaining;
	        }

	        // Full amount
	        if ( 'ovabrw_deposit_full_amount' == $meta->key ) {
	        	$display_key = esc_html__( 'Full Amount', 'ova-brw' ).$tax_text;
	        }
	        
        	return $display_key;
		}

		public function ovabrw_order_item_display_meta_value( $meta_value, $meta, $item ) {
			$order = $item->get_order();

			if ( 'ovabrw_amount_insurance_product' == $meta->key ) { 
	            $meta_value = wc_price( $meta->value, array( 'currency' => $order->get_currency() ) );
	        }
	        if ( 'ovabrw_deposit_amount_product' == $meta->key ) { 
	            $meta_value = wc_price( $meta->value, array( 'currency' => $order->get_currency() ) );
	        }
	        if ( 'ovabrw_remaining_amount_product' == $meta->key ) { 
	            $meta_value = wc_price( $meta->value, array( 'currency' => $order->get_currency() ) );
	        }
	        if ( 'ovabrw_deposit_full_amount' == $meta->key ) { 
	            $meta_value = wc_price( $meta->value, array( 'currency' => $order->get_currency() ) );
	        }

			return $meta_value;
		}

		public function ovabrw_order_item_get_formatted_meta_data( $meta_data, $item ) {
			$hide_fields = array(
	            'rental_type',
	            'ovabrw_price_detail',
	            'ovabrw_total_days',
	            'package_id',
	            'package_type',
	            'define_day',
	            'ovabrw_pickup_date_real',
	            'ovabrw_pickoff_date_real',
	            'ovabrw_pickup_date_strtotime',
	            'ovabrw_pickoff_date_strtotime',
	            'ovabrw_insurance_amount',
	            'ovabrw_remaining_insurance',
	            'ovabrw_remaining_insurance_tax',
	            'ovabrw_insurance_tax',
	            'ovabrw_deposit_type',
	            'ovabrw_deposit_value',
	            'ovabrw_deposit_amount',
	            'ovabrw_remaining_amount',
	            'ovabrw_remaining_tax',
	            'ovabrw_total_payable',
	            'ovabrw_parent_order_id'
	        );

	        // Get product
			$product = method_exists( $item, 'get_product' ) ? $item->get_product() : '';
			if ( $product && $product->is_type( 'ovabrw_car_rental' ) ) {
				// Get product id
				$product_id = $product->get_id();

		        // Show pick-up location
		        if ( !OVABRW()->options->get_show_location( $product_id ) ) {
		        	$hide_fields[] = 'ovabrw_pickup_loc';
		        }

		        // Show drop-off location
		        if ( !OVABRW()->options->get_show_location( $product_id, 'dropoff' ) ) {
		        	$hide_fields[] = 'ovabrw_pickoff_loc';
		        }

		        // Show pick-up date
		        if ( !OVABRW()->options->get_show_date( $product_id ) ) {
		        	$hide_fields[] = 'ovabrw_pickup_date';
		        }

		        // Show drop-off date
		        if ( !OVABRW()->options->get_show_date( $product_id, 'dropoff' ) ) {
		        	$hide_fields[] = 'ovabrw_pickoff_date';
		        }

		        // Show quantity
		        if ( !OVABRW()->options->get_show_quantity( $product_id ) ) {
		        	$hide_fields[] = 'ovabrw_number_vehicle';
		        }
			}
	        
	        $new_meta = array();

	        foreach ( $meta_data as $id => $meta_array ) {
	            if ( in_array( $meta_array->key , apply_filters( 'ovabrw_ft_hide_fields', $hide_fields, $item ) ) ) { continue; }
	            $new_meta[ $id ] = $meta_array;
	        }

	        return $new_meta;
		}

		public function ovabrw_email_order_item_quantity( $qty_display, $item ) {
			$qty_rental = intval( $item->get_meta( 'ovabrw_number_vehicle' ) );

		    if ( $qty_rental ) return $qty_rental;

		    return $qty_display;
		}

		public static function instance() {
			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self();
			}

			return self::$_instance;
		}
	}

	new OVABRW_Rental_Types();
}