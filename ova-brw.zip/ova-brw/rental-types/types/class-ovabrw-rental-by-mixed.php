<?php defined( 'ABSPATH' ) || exit();

if ( ! class_exists( 'OVABRW_Rental_By_Mixed' ) ) {
	class OVABRW_Rental_By_Mixed extends OVABRW_Abstract_Rental_Types {
		protected $_instance = null;

		public function __construct() {
			$this->ID 		= '';
			$this->type 	= 'mixed';
			$this->prefix 	= OVABRW_PREFIX;

			parent::__construct();
		}

		// Abstract Method
		public function ovabrw_wc_add_to_cart_validation( $passed_validation, $product_id, $quantity ) {
			if ( ! ovabrw_is_rental_product( $product_id ) ) return $passed_validation;

			// Set Product ID
			$this->set_ID( $product_id );

			// Get Type
			$rental_type = $this->get_value( 'price_type' );

			// Check Type
			if ( $rental_type != $this->type ) return $passed_validation;

			// Data Form
			$pickup_location 	= isset( $_REQUEST[$this->get_name('pickup_loc')] ) ? trim( sanitize_text_field( $_REQUEST[$this->get_name('pickup_loc')] ) ) : '';
			$dropoff_location 	= isset( $_REQUEST[$this->get_name('pickoff_loc')] ) ? trim( sanitize_text_field( $_REQUEST[$this->get_name('pickoff_loc')] ) ) : '';
			$pickup_date 		= isset( $_REQUEST[$this->get_name('pickup_date')] ) ? strtotime( sanitize_text_field( $_REQUEST[$this->get_name('pickup_date')] ) ) : '';
			$dropoff_date 		= isset( $_REQUEST[$this->get_name('pickoff_date')] ) ? strtotime( sanitize_text_field( $_REQUEST[$this->get_name('pickoff_date')] ) ) : '';
			$input_qty 			= isset( $_REQUEST[$this->get_name('number_vehicle')] ) ? absint( sanitize_text_field( $_REQUEST[$this->get_name('number_vehicle')] ) ) : '';

			// Stock quantity does not exist
	        if ( ! absint( $input_qty ) ) $input_qty = 1;

	        // Required Pickup Location
	        if ( ! $pickup_location && $this->show_location( 'pickup' ) ) {
	        	wc_clear_notices();
	            echo wc_add_notice( esc_html__( 'Pick-up location is required', 'ova-brw' ), 'error' );
	            return false;
	        }

	        // Required Dropoff Location
	        if ( ! $dropoff_location && $this->show_location( 'dropoff' ) ) {
	        	wc_clear_notices();
	            echo wc_add_notice( esc_html__( 'Drop-off location is required', 'ova-brw' ), 'error' );
	            return false;
	        }

	        // Get strtotime input date
	        $new_input_date = $this->get_strtotime_input_date( $pickup_date, $dropoff_date );
	        $pickup_date 	= $new_input_date['pickup_date_new'];
	        $dropoff_date 	= $new_input_date['dropoff_date_new'] ? $new_input_date['dropoff_date_new'] : $pickup_date;

	        // Get Pick-up and Drop-off labels
	        $pickup_label 	= OVABRW()->options->get_label_pickup_date( $product_id );
	        $dropoff_label 	= OVABRW()->options->get_label_pickoff_date( $product_id );

	        // Required Pickup Date & Dropoff Date
            if ( ! $pickup_date ) {
            	wc_clear_notices();
                echo wc_add_notice( sprintf( esc_html__( '%s is required', 'ova-brw' ), $pickup_label ), 'error' );
                return false;
			}

			// Current time
			$current_time = OVABRW()->options->get_current_time( $this->ID );

            if ( $pickup_date < $current_time ) {
	            wc_clear_notices();
	            echo wc_add_notice( sprintf( esc_html__( '%s must be greater than current time', 'ova-brw' ), $pickup_label ), 'error' );   
	            return false;
	        }

	        if ( ! $dropoff_date ) {
				wc_clear_notices();
                echo wc_add_notice( sprintf( esc_html__( '%s is required', 'ova-brw' ), $dropoff_label ), 'error' );
                return false;
			}

			// Check show drop-off date
			$show_dropoff_date = ovabrw_show_date( $this->ID, 'dropoff' );

			if ( ! $show_dropoff_date ) {
				if ( $pickup_date > $dropoff_date ) {
	                wc_clear_notices();
	                echo wc_add_notice( sprintf( esc_html__( '%s must be greater than %s', 'ova-brw' ), $dropoff_label, $pickup_label ), 'error' );
	                return false;
	            }
			} else {
				if ( $pickup_date >= $dropoff_date ) {
	                wc_clear_notices();
	                echo wc_add_notice( sprintf( esc_html__( '%s must be greater than %s', 'ova-brw' ), $dropoff_label, $pickup_label ), 'error' );
	                return false;
	            }
			}

            // Check Perparation Time
	        if ( $this->check_preparation_time( $pickup_date ) ) {
	        	return false;
	        }

	        // Check rental period
	        $max_rental_hour = floatval( $this->get_value( 'rent_hour_max' ) );
	        $min_rental_hour = floatval( $this->get_value( 'rent_hour_min' ) );

	        if ( $this->get_max_rental_hour( $pickup_date, $dropoff_date, $max_rental_hour ) ) {
	        	if ( $max_rental_hour === 1 ) {
            		echo wc_add_notice( sprintf( esc_html__( 'Max rental period: %s hour', 'ova-brw' ), $max_rental_hour ), 'error' );
            	} else {
            		echo wc_add_notice( sprintf( esc_html__( 'Max rental period: %s hours', 'ova-brw' ), $max_rental_hour ), 'error' );
            	}
                
                return false; 
	        }

	        if ( $this->get_min_rental_hour( $pickup_date, $dropoff_date, $min_rental_hour ) ) {
                wc_clear_notices();

            	if ( $min_rental_hour === 1 ) {
            		echo wc_add_notice( sprintf( esc_html__( 'Min rental period: %s hour', 'ova-brw' ), $min_rental_hour ), 'error' );
            	} else {
            		echo wc_add_notice( sprintf( esc_html__( 'Min rental period: %s hours', 'ova-brw' ), $min_rental_hour ), 'error' );
            	}
                
                return false; 
            }
            // End
            
            // Check input quantity
            if ( $input_qty < 1 ) {
            	wc_clear_notices();
                echo wc_add_notice( esc_html__( 'Quantity must be greater than 0', 'ova-brw' ), 'error' );
                return false;
            }

            // Check Services required
            if ( $this->required_service_fields() ) {
            	return false;
            }
	        // End
	        
	        // Custom Checkout Field
	        if ( $this->required_custom_checkout_fields() ) {
	        	return false;
	        }
	        // End
	        
	        // Check unavailable time
	        if ( $this->check_unavailable_time( $pickup_date, $dropoff_date ) ) {
	        	return false;
	        }
	        // End
	        
	        // Check disable week day
	        if ( $this->check_disable_week_day( $pickup_date, $dropoff_date ) ) {
	        	return false;
	        }
	        // End
	        
	        // Check available quantity
	        $data_available = $this->get_qty_available( $pickup_date, $dropoff_date, $pickup_location, $dropoff_location, 'cart' );
	        $qty_available 		= $data_available['qty_available'];
	        $vehicle_available 	= $data_available['vehicle_available'];

	        if ( $input_qty > $qty_available ) {
	        	wc_clear_notices();

	        	if ( $qty_available > 0 ) {
                	echo wc_add_notice( sprintf( esc_html__( 'Available vehicle is %s', 'ova-brw'  ), $qty_available ), 'error');
	        	} else {
	        		echo wc_add_notice( esc_html__( 'Vehicle isn\'t available for this time. Please book other time.', 'ova-brw' ), 'error' );
	        	}

                return false;
	        }

	        // Add vehicle ids to Woo session
	        if ( ovabrw_array_exists( $vehicle_available ) ) {
	        	WC()->session->set( 'id_vehicle_available', implode( ', ', array_slice( $vehicle_available, 0, $input_qty ) ) );
	        }
	        // End
	        
			return apply_filters( 'ovabrw_wc_add_to_cart_validation', $passed_validation, $product_id, $quantity, $this );
		}

		public function ovabrw_wc_add_cart_item_data( $cart_item_data, $product_id, $variation_id, $quantity ) {
			if ( ! ovabrw_is_rental_product( $product_id ) || empty( $_REQUEST ) ) return $cart_item_data;

			// Set Product ID
			$this->set_ID( $product_id );

			// Get Type
			$rental_type = $this->get_value( 'price_type' );

			// Check Type
			if ( $rental_type != $this->type ) return $cart_item_data;

			// Data Form
			$pickup_location 	= isset( $_REQUEST[$this->get_name('pickup_loc')] ) ? trim( sanitize_text_field( $_REQUEST[$this->get_name('pickup_loc')] ) ) : '';
			$dropoff_location 	= isset( $_REQUEST[$this->get_name('pickoff_loc')] ) ? trim( sanitize_text_field( $_REQUEST[$this->get_name('pickoff_loc')] ) ) : '';
			$pickup_date 		= isset( $_REQUEST[$this->get_name('pickup_date')] ) ? trim( sanitize_text_field( $_REQUEST[$this->get_name('pickup_date')] ) ) : '';
			$dropoff_date 		= isset( $_REQUEST[$this->get_name('pickoff_date')] ) ? trim( sanitize_text_field( $_REQUEST[$this->get_name('pickoff_date')] ) ) : '';
			$input_qty 			= isset( $_REQUEST[$this->get_name('number_vehicle')] ) ? absint( sanitize_text_field( $_REQUEST[$this->get_name('number_vehicle')] ) ) : '';

			if ( ! $dropoff_date ) $dropoff_date = $pickup_date;

			// Stock quantity does not exist
	        if ( ! absint( $input_qty ) ) $input_qty = 1;

	        // Check input
	        if ( ! $pickup_date || ! $dropoff_date ) {
	            return $cart_item_data;
	        }

	        // Rental Type
	        $cart_item_data['rental_type'] = $this->type;

	        // Pickup & Dropoff locations
	        $cart_item_data['ovabrw_pickup_loc'] 	= $pickup_location;
	        $cart_item_data['ovabrw_pickoff_loc'] 	= $dropoff_location;

	        // Pickup & Dropoff dates
	        $cart_item_data['ovabrw_pickup_date'] 	= $pickup_date;
	        $cart_item_data['ovabrw_pickoff_date'] 	= $dropoff_date;

	        // Real pickup & dropoff dates
	        $cart_item_data['ovabrw_pickup_date_real'] 	= $pickup_date;
	        $cart_item_data['ovabrw_pickoff_date_real'] = $dropoff_date;

	        // Validate
	        $cart_item_data['ovabrw_checkin'] 	= strtotime( $pickup_date );
	        $cart_item_data['ovabrw_checkout'] 	= strtotime( $dropoff_date );

	        // Quantity
	        $cart_item_data['ovabrw_number_vehicle'] = $input_qty;

	        // Vehicle ids
	        $vehicle_available = '';

	        if ( WC()->session->__isset( 'id_vehicle_available' ) ) {
	            $vehicle_available = WC()->session->get( 'id_vehicle_available' );
	            WC()->session->__unset( 'id_vehicle_available' );
	        }

        	$cart_item_data['id_vehicle'] = trim( $vehicle_available );

        	// Real Quantity and Price
        	$real_data = $this->get_real_data( strtotime( $pickup_date ), strtotime( $dropoff_date ) );
        	$cart_item_data['real_quantity'] 	= $real_data['real_quantity'];
        	$cart_item_data['real_price'] 		= $real_data['real_price'];

	        // Custom Checkout Fields
	        $list_ckf = $this->get_custom_checkout_fields();
	        $args_ckf = $args_ckf_qty = [];

	        if ( ovabrw_array_exists( $list_ckf ) ) {
	            foreach( $list_ckf as $key => $field ) {
	                if ( $field['enabled'] == 'on' ) {
	                    if ( $field['type'] === 'file' ) {
	                        $prefix = 'ovabrw_'.$key;

	                        if ( isset( $_REQUEST[$prefix] ) && is_array( $_REQUEST[$prefix] ) ) {
	                            $cart_item_data[$key] = '<a href="'.esc_url( $_REQUEST[$prefix]['url'] ).'" title="'.esc_attr( $_REQUEST[$prefix]['name'] ).'" target="_blank">'.esc_attr( $_REQUEST[$prefix]['name'] ).'</a>';
	                        } else {
	                            $cart_item_data[$key] = '';
	                        }
	                    } elseif ( $field['type'] === 'select' ) {
	                        $options_key = $options_text = array();

	                        $val_op = sanitize_text_field( filter_input( INPUT_POST, $key ) );
	                        $args_ckf[$key] = $val_op;

	                        if ( isset( $_REQUEST[$key.'_qty'] ) && ! empty( $_REQUEST[$key.'_qty'] ) ) {
	                            if ( isset( $_REQUEST[$key.'_qty'][$val_op] ) && absint( $_REQUEST[$key.'_qty'][$val_op] ) ) {
	                                $args_ckf_qty[$val_op] = absint( $_REQUEST[$key.'_qty'][$val_op] );
	                            }
	                        }
	                        
	                        if ( ovabrw_check_array( $field, 'ova_options_key' ) ) {
	                            $options_key = $field['ova_options_key'];
	                        }

	                        if ( ovabrw_check_array( $field, 'ova_options_text' ) ) {
	                            $options_text = $field['ova_options_text'];
	                        }

	                        $key_op = array_search( $val_op, $options_key );

	                        if ( ! is_bool( $key_op ) ) {
	                            if ( ovabrw_check_array( $options_text, $key_op ) ) {
	                                if ( isset( $args_ckf_qty[$val_op] ) && absint( $args_ckf_qty[$val_op] ) ) {
	                                    $val_op = $options_text[$key_op] . ' (x'.absint( $args_ckf_qty[$val_op] ).')';
	                                } else {
	                                    $val_op = $options_text[$key_op];
	                                }
	                            }
	                        }

	                        $cart_item_data[$key] = $val_op;
	                    } elseif ( $field['type'] === 'checkbox' ) {
	                        $checkbox_val = $checkbox_key = $checkbox_text = array();

	                        $val_checkbox = isset( $_REQUEST[$key] ) && $_REQUEST[$key] ? $_REQUEST[$key] : '';

	                        if ( ! empty( $val_checkbox ) && is_array( $val_checkbox ) ) {
	                            $args_ckf[$key] = $val_checkbox;

	                            if ( isset( $_REQUEST[$key.'_qty'] ) && ! empty( $_REQUEST[$key.'_qty'] && is_array( $_REQUEST[$key.'_qty'] ) ) ) {
	                                $args_ckf_qty = $args_ckf_qty + $_REQUEST[$key.'_qty'];
	                            }

	                            if ( ovabrw_check_array( $field, 'ova_checkbox_key' ) ) {
	                                $checkbox_key = $field['ova_checkbox_key'];
	                            }

	                            if ( ovabrw_check_array( $field, 'ova_checkbox_text' ) ) {
	                                $checkbox_text = $field['ova_checkbox_text'];
	                            }

	                            foreach ( $val_checkbox as $val_cb ) {
	                                $key_cb = array_search( $val_cb, $checkbox_key );

	                                if ( ! is_bool( $key_cb ) ) {
	                                    if ( ovabrw_check_array( $checkbox_text, $key_cb ) ) {
	                                        if ( isset( $args_ckf_qty[$val_cb] ) && absint( $args_ckf_qty[$val_cb] ) ) {
	                                            array_push( $checkbox_val , $checkbox_text[$key_cb] . ' (x'.absint( $args_ckf_qty[$val_cb] ).')' );
	                                        } else {
	                                            array_push( $checkbox_val , $checkbox_text[$key_cb] );
	                                        }
	                                    }
	                                }
	                            }
	                        }

	                        if ( ! empty( $checkbox_val ) && is_array( $checkbox_val ) ) {
	                            $cart_item_data[$key] = join( ", ", $checkbox_val );
	                        }
	                    } else {
	                        $cart_item_data[$key] = sanitize_text_field( filter_input( INPUT_POST, $key ) );

	                        if ( in_array( $field['type'], array( 'radio' ) ) ) {
	                            $args_ckf[$key] = sanitize_text_field( filter_input( INPUT_POST, $key ) );

	                            if ( $args_ckf[$key] && isset( $_REQUEST[$key.'_qty'] ) && ! empty( $_REQUEST[$key.'_qty'] ) ) {
	                                if ( isset( $_REQUEST[$key.'_qty'][$cart_item_data[$key]] ) && absint( $_REQUEST[$key.'_qty'][$cart_item_data[$key]] ) ) {
	                                    $args_ckf_qty[$key] = absint( $_REQUEST[$key.'_qty'][$cart_item_data[$key]] );
	                                    $cart_item_data[$key] .= ' (x'.absint( $_REQUEST[$key.'_qty'][$cart_item_data[$key]] ).')';
	                                }
	                            }
	                        }
	                    }
	                }
	            }
	        }

	        if ( ovabrw_array_exists( $args_ckf ) ) {
	            $cart_item_data['custom_ckf']       = $args_ckf;
	            $cart_item_data['custom_ckf_qty']   = $args_ckf_qty;
	        }
	        // End

	        // Resources
	        $resources      = isset( $_REQUEST['ovabrw_resource_checkboxs'] ) ? $_REQUEST['ovabrw_resource_checkboxs'] : [];
	        $resources_qty  = isset( $_REQUEST['ovabrw_resource_quantity'] ) ? $_REQUEST['ovabrw_resource_quantity'] : [];

	        $cart_item_data['resources'] 		= $resources;
        	$cart_item_data['resources_qty'] 	= $resources_qty;
        	// End

        	// Services
        	$services       = isset( $_REQUEST['ovabrw_service'] ) ? $_REQUEST['ovabrw_service'] : [];
	        $ser_qty        = isset( $_REQUEST['ovabrw_service_qty'] ) ? $_REQUEST['ovabrw_service_qty'] : [];
	        $services_qty   = [];
	        $data_services 	= [];

	        if ( ovabrw_array_exists( $services ) ) {
	            foreach ( $services as $ser_id ) {
	            	if ( $ser_id ) {
	            		$data_services[] = $ser_id;
	            	}

	                if ( isset( $ser_qty[$ser_id] ) && absint( $ser_qty[$ser_id] ) ) {
	                    $services_qty[$ser_id] = absint( $ser_qty[$ser_id] );
	                }
	            }
	        }

	        $cart_item_data['ovabrw_service']       = $data_services;
        	$cart_item_data['ovabrw_service_qty']   = $services_qty;
        	// End
        	
        	// Deposit
        	$type_deposit = isset( $_REQUEST['ova_type_deposit'] ) ? sanitize_text_field( $_REQUEST['ova_type_deposit'] ) : '';
        	if ( 'deposit' === $type_deposit ) {
        		$cart_item_data['is_deposit'] = true;
        	}

			return apply_filters( 'ovabrw_wc_add_cart_item_data', $cart_item_data, $product_id, $quantity, $this );
		}

		public function ovabrw_show_item_data( $item_data, $cart_item ) {
			if ( ! $cart_item['data']->is_type('ovabrw_car_rental') ) return $item_data;

			$product_id = isset( $cart_item['product_id'] ) ? $cart_item['product_id'] : '';
			if ( ! $product_id ) return $item_data;

			// Set Product ID
			$this->set_ID( $product_id );

			// Get Type
			$rental_type = $this->get_value( 'price_type' );

			// Check Type
			if ( $rental_type != $this->type ) return $item_data;
			
			if ( ovabrw_array_exists( $item_data ) ) $item_data = [];

			$pickup_location 	= isset( $cart_item['ovabrw_pickup_loc'] ) ? $cart_item['ovabrw_pickup_loc'] : '';
			$dropoff_location 	= isset( $cart_item['ovabrw_pickoff_loc'] ) ? $cart_item['ovabrw_pickoff_loc'] : '';
			$pickup_date 		= isset( $cart_item['ovabrw_pickup_date'] ) ? $cart_item['ovabrw_pickup_date'] : '';
			$dropoff_date 		= isset( $cart_item['ovabrw_pickoff_date'] ) ? $cart_item['ovabrw_pickoff_date'] : '';

			if ( ! $pickup_date || ! $dropoff_date ) return $item_data;

			// Pickup Location
			if ( $this->show_location( 'pickup' ) ) {
				$item_data[] = array(
	                'key'     => esc_html__( 'Pick-up Location', 'ova-brw' ),
	                'value'   => wc_clean( $pickup_location ),
	                'display' => ''
	            );
			}

			// Dropoff Location
			if ( $this->show_location( 'dropoff' ) ) {
				$item_data[] = array(
	                'key'     => esc_html__( 'Drop-off Location', 'ova-brw' ),
	                'value'   => wc_clean( $dropoff_location ),
	                'display' => ''
	            );
			}

			// Pickup Date
			$item_data[] = array(
                'key'     => OVABRW()->options->get_label_pickup_date( $product_id ),
                'value'   => wc_clean( $pickup_date ),
                'display' => ''
            );

			// Dropoff Date
            if ( $this->show_date( 'dropoff' ) ) {
            	$item_data[] = array(
                    'key'     => OVABRW()->options->get_label_pickoff_date( $product_id ),
                    'value'   => wc_clean( $dropoff_date ),
                    'display' => ''
                );
            }

            // Quantity
            if ( $this->show_quantity() ) {
            	$quantity = isset( $cart_item['ovabrw_number_vehicle'] ) ? absint( $cart_item['ovabrw_number_vehicle'] ) : 1;

            	$item_data[] = array(
	                'key'     => esc_html__( 'Quantity', 'ova-brw' ),
	                'value'   => wc_clean( $quantity ),
	                'display' => ''
	            );
            }

            // Vehicle ID
            $vehicle_ids = isset( $cart_item['id_vehicle'] ) ? $cart_item['id_vehicle'] : '';

            if ( $vehicle_ids && apply_filters( 'brw_show_vehicle_order_frontend', false ) ) {
                $item_data[] = array(
                    'key'     => esc_html__( 'Vehicle ID', 'ova-brw' ),
                    'value'   => wc_clean( $vehicle_ids ),
                    'display' => ''
                );
            }

            // Custom Checkout Fields
            $list_fields = $this->get_custom_checkout_fields();

	        if ( is_array( $list_fields ) && ! empty( $list_fields ) ) {
	            foreach ( $list_fields as $key => $field ) {
	                $value = array_key_exists( $key, $cart_item ) ? $cart_item[$key] : '';

	                if ( ! empty( $value ) && $field['enabled'] == 'on' ) {
	                    if ( $field['type'] === 'file' ) {
	                        $item_data[] = array(
	                            'key'     => $field['label'],
	                            'value'   => $value,
	                            'display' => ''
	                        );
	                    } else {
	                        $item_data[] = array(
	                            'key'     => $field['label'],
	                            'value'   => wc_clean( $value ),
	                            'display' => ''
	                        );
	                    }
	                }
	            }
	        }

	        // Resources
	        if ( isset( $cart_item['resources'] ) && $cart_item['resources'] ) {
	            $resources_name = $cart_item['resources'];

	            if ( isset( $cart_item['resources_qty'] ) && $cart_item['resources_qty'] ) {
	                foreach ( $resources_name as $k => $v ) {
	                    if ( isset( $cart_item['resources_qty'][$k] ) && absint( $cart_item['resources_qty'][$k] ) ) {
	                        $resources_name[$k] = $v.' (x'.absint( $cart_item['resources_qty'][$k] ).')';
	                    }
	                }
	            }

	            if ( count( $cart_item['resources'] ) == 1 ) {
	                $item_data[] = array(
	                    'key'     => esc_html__( 'Resource', 'ova-brw' ),
	                    'value'   => wc_clean( join( ', ', $resources_name ) ),
	                    'display' => '',
	                );   
	            } else {
	                $item_data[] = array(
	                    'key'     => esc_html__( 'Resources', 'ova-brw' ),
	                    'value'   => wc_clean( join( ', ', $resources_name ) ),
	                    'display' => '',
	                );   
	            }
	        }

	        // Services
	        if ( isset( $cart_item['ovabrw_service'] ) && $cart_item['ovabrw_service'] ) {
	        	$services 		= $cart_item['ovabrw_service'];
	        	$services_qty 	= $cart_item['ovabrw_service_qty'];

	        	if ( ovabrw_array_exists( $services ) ) {
	        		$serv_labels 	= $this->get_value( 'label_service', [] );
	        		$serv_ids 		= $this->get_value( 'service_id', [] );
	        		$serv_names 	= $this->get_value( 'service_name', [] );

	        		foreach ( $services as $k ) {
			    		if ( ovabrw_array_exists( $serv_ids ) ) {
			    			$qty = isset( $services_qty[$k] ) ? $services_qty[$k] : '';

			    			foreach ( $serv_ids as $i => $ids ) {
			    				$option_index = array_search( $k, $ids );

			        			if ( is_bool( $option_index ) ) continue;

			        			$name   = isset( $serv_names[$i][$option_index] ) ? $serv_names[$i][$option_index] : '';
                                $label  = isset( $serv_labels[$i] ) ? $serv_labels[$i] : '';

                                if ( $qty ) {
                                    $name .= ' (x'.absint( $qty ).')';
                                }

                                $item_data[] = array(
                                    'key'     => $label,
                                    'value'   => wc_clean( $name ),
                                    'display' => '',
                                );
			    			}
			    		}
			    	}
	        	}
	        }

			return apply_filters( 'ovabrw_show_item_data', $item_data, $cart_item, $this );
		}

		public function ovabrw_cart_show_item_price( $product_price, $cart_item, $cart_item_key ) {
			$rental_type = isset( $cart_item['rental_type'] ) ? $cart_item['rental_type'] : '';

			if ( $cart_item['data']->is_type('ovabrw_car_rental') && $this->type === $rental_type ) {
				if ( isset( $cart_item['real_price'] ) && $cart_item['real_price'] ) {
					$product_price = $cart_item['real_price'];
				} else {
					$product_price = '';
				}
			}

			return apply_filters( 'ovabrw_cart_show_item_price', $product_price, $cart_item, $cart_item_key, $this );
		}

		public function ovabrw_cart_show_item_quantity( $product_quantity, $cart_item_key, $cart_item ) {
			$rental_type = isset( $cart_item['rental_type'] ) ? $cart_item['rental_type'] : '';

			if ( $cart_item['data']->is_type('ovabrw_car_rental') && $this->type === $rental_type ) {
				$quantity = isset( $cart_item['quantity'] ) ? (int) $cart_item['quantity'] : 1;
				
				if ( isset( $cart_item['real_quantity'] ) && $cart_item['real_quantity'] ) {
					$product_quantity = $cart_item['real_quantity'];

					if ( $quantity && $quantity > 1 ) {
						$product_quantity = sprintf( '%s x %s', $quantity, $product_quantity );
					}
				} else {
					$product_quantity = '';
				}
			}

			return apply_filters( 'ovabrw_cart_show_item_quantity', $product_quantity, $cart_item_key, $cart_item, $this );
		}

		public function ovabrw_checkout_show_item_quantity( $product_quantity, $cart_item, $cart_item_key ) {
			$rental_type = isset( $cart_item['rental_type'] ) ? $cart_item['rental_type'] : '';

			if ( $cart_item['data']->is_type('ovabrw_car_rental') && $this->type === $rental_type ) {
				$quantity = isset( $cart_item['quantity'] ) ? (int) $cart_item['quantity'] : 1;

				if ( $quantity && $quantity > 1 ) {
					$product_quantity = sprintf( 'x %s', $quantity );
				} else {
					$product_quantity = '';
				}
			}

			return apply_filters( 'ovabrw_checkout_show_item_quantity', $product_quantity, $cart_item, $cart_item_key, $this );
		}

		public function ovabrw_order_item_quantity_html( $item_quantity, $item ) {
			$rental_type = $item->get_meta( 'rental_type' );

			if ( $this->type === $rental_type ) {
				$total_days = $item->get_meta( 'ovabrw_total_days' );

				if ( ! $total_days ) return '';

				$item_quantity = ' <strong class="product-quantity">' . sprintf( '&times;&nbsp;%s', str_replace( '<br>', ', ', $total_days ) ) . '</strong>';
			}

			return apply_filters( 'ovabrw_order_item_quantity_html', $item_quantity, $item, $this );
		}

		public function ovabrw_get_product_price_html( $price_html, $product ) {
			if ( $product && $product->is_type('ovabrw_car_rental') ) {
				$rental_type = $this->get_value_by_id( $product->get_id(), 'price_type' );

				if ( $this->type === $rental_type ) {
					$price_hour = floatval( $this->get_value_by_id( $product->get_id(), 'regul_price_hour' ) );
	                $price_day  = floatval( $this->get_value_by_id( $product->get_id(), 'regular_price_day' ) );

	                if ( ! $price_day ) $price_day = floatval( get_post_meta( $product->get_id(), '_regular_price', true ) );

	                $price_html = sprintf( esc_html__( '%s / Hour', 'ova-brw' ), wc_price( $price_hour ) ) .'<br>'. sprintf( esc_html__( '%s / Day', 'ova-brw' ), wc_price( $price_day ) );
				}
			}

			return apply_filters( 'ovabrw_get_product_price_html', $price_html, $product, $this );
		}

		// Ajax validation data booking
		public function ovabrw_ajax_validation_booking( $pickup_date = '', $dropoff_date = '', $args = [] ) {
			// Product ID
			$product_id = isset( $args['id'] ) ? $args['id'] : '';

			// Get pick-up and drop-off labels
			$pickup_label 	= OVABRW()->options->get_label_pickup_date( $product_id );
			$dropoff_label 	= OVABRW()->options->get_label_pickoff_date( $product_id );

			if ( ! $pickup_date ) {
				return sprintf( esc_html__( '%s is required', 'ova-brw' ), $pickup_label );
			}

			if ( ! $dropoff_date ) {
				return sprintf( esc_html__( '%s is required', 'ova-brw' ), $dropoff_label );
			}
			
			// Current time
			$current_time = OVABRW()->options->get_current_time( $this->ID );
			
			if ( $pickup_date < $current_time ) {
	            return sprintf( esc_html__( '%s must be greater than current time', 'ova-brw' ), $pickup_label );   
	        }

	        // Check show drop-off date
			$show_dropoff_date = ovabrw_show_date( $this->ID, 'dropoff' );

			if ( ! $show_dropoff_date ) {
				if ( $pickup_date > $dropoff_date ) {
	            	return sprintf( esc_html__( '%s must be greater than %s', 'ova-brw' ), $dropoff_label, $pickup_label );
	            }
			} else {
				if ( $pickup_date >= $dropoff_date ) {
	            	return sprintf( esc_html__( '%s must be greater than %s', 'ova-brw' ), $dropoff_label, $pickup_label );
	            }
			}

            // Perparation Time
	        $preparation_time = floatval( $this->get_value( 'preparation_time' ) );

	        if ( $preparation_time ) {
	            $today = strtotime( date( 'Y-m-d', current_time( 'timestamp' ) ) );

	            if ( $pickup_date < ( $today + $preparation_time*86400 ) ) {
	                if ( $preparation_time == 1 ) {
	                    return sprintf( esc_html__( 'Book in advance %s day from the current date', 'ova-brw' ), $preparation_time );
	                } else {
	                    return sprintf( esc_html__( 'Book in advance %s days from the current date', 'ova-brw' ), $preparation_time );
	                }
	            }
	        }

	        // Check rental period
	        $max_rental_hour = floatval( $this->get_value( 'rent_hour_max' ) );
	        $min_rental_hour = floatval( $this->get_value( 'rent_hour_min' ) );

	        if ( $this->get_max_rental_hour( $pickup_date, $dropoff_date, $max_rental_hour ) ) {
	        	if ( $max_rental_hour === 1 ) {
            		return sprintf( esc_html__( 'Max rental period: %s hour', 'ova-brw' ), $max_rental_hour );
            	} else {
            		return sprintf( esc_html__( 'Max rental period: %s hours', 'ova-brw' ), $max_rental_hour );
            	}
	        }

	        if ( $this->get_min_rental_hour( $pickup_date, $dropoff_date, $min_rental_hour ) ) {
            	if ( $min_rental_hour === 1 ) {
            		return sprintf( esc_html__( 'Min rental period: %s hour', 'ova-brw' ), $min_rental_hour );
            	} else {
            		return sprintf( esc_html__( 'Min rental period: %s hours', 'ova-brw' ), $min_rental_hour );
            	}
            }
            
            // Check unavailable time
            $untime_startdate = $this->get_value( 'untime_startdate' );
        	$untime_enddate   = $this->get_value( 'untime_enddate' );

        	if ( ovabrw_array_exists( $untime_startdate ) && ovabrw_array_exists( $untime_enddate ) ) {
        		foreach ( $untime_startdate as $k => $start_date ) {
        			$start_date = strtotime( $start_date );
        			$end_date 	= isset( $untime_enddate[$k] ) ? strtotime( $untime_enddate[$k] ) : '';

        			if ( ! ( $start_date > $dropoff_date || $end_date < $pickup_date ) ) {
        				return esc_html__( 'This time is not available for renting', 'ova-brw' );
        			}
        		}
        	}

        	// Check disable weekdays
        	$disable_weekdays = $this->get_value( 'product_disable_week_day' );

	        if ( !$disable_weekdays ) {
	            $disable_weekdays = get_option( 'ova_brw_calendar_disable_week_day', [] );
	        }
	        if ( ovabrw_array_exists( $disable_weekdays ) ) {
	        	$key = array_search( '7', $disable_weekdays );
	        	if ( $key !== false ) $disable_weekdays[$key] = '0';
	        } else {
	        	if ( $disable_weekdays && !is_array( $disable_weekdays ) ) {
	        		$disable_weekdays = explode( ',', $disable_weekdays );
	        		$disable_weekdays = array_map( 'trim', $disable_weekdays );
	        	}
	        }

	        if ( ovabrw_array_exists( $disable_weekdays ) ) {	        	
	        	if ( ovabrw_allow_boooking_incl_disable_week_day() ) {
	                $pickup_date_of_week    = date('w', $pickup_date );
	                $dropoff_date_of_week   = date('w', $dropoff_date );

	                if ( in_array( $pickup_date_of_week, $disable_weekdays ) || in_array( $dropoff_date_of_week, $disable_weekdays ) ) {
	                    return esc_html__( 'This time is not available for renting', 'ova-brw' );
	                }
	            } else {
	                $datediff       = (int)$dropoff_date - (int)$pickup_date;
	                $total_datediff = round( $datediff / (60 * 60 * 24), wc_get_price_decimals() ) + 1;

	                // get number day
	                $pickup_date_of_week   = date('w', $pickup_date );
	                $pickup_date_timestamp = $pickup_date;
	                
	                $i = 0;
	                while ( $i <= $total_datediff ) {
	                    if ( in_array( $pickup_date_of_week, $disable_weekdays ) ) {
	                        return esc_html__( 'This time is not available for renting', 'ova-brw' );
	                    }

	                    $pickup_date_of_week    = date('w', $pickup_date_timestamp );
	                    $pickup_date_timestamp  = strtotime('+1 day', $pickup_date_timestamp);
	                    $i++;
	                }
	            }
	        }

			return apply_filters( 'ovabrw_ajax_validation_booking', false, $pickup_date, $dropoff_date, $args, $this );
		}
		
		// Save Order Item
		public function ovabrw_save_order_line_item( $item, $values ) {
			do_action( 'ovabrw_before_save_order_line_item', $item, $values, $this );

			// Rental Type
	        $item->add_meta_data( 'rental_type', $values['rental_type'], true );

			// Pickup location
            if ( $this->show_location( 'pickup' ) ) {
            	$item->add_meta_data( 'ovabrw_pickup_loc', $values['ovabrw_pickup_loc'], true );
            }

            // Dropoff location
            if ( $this->show_location( 'dropoff' ) ) {
            	$item->add_meta_data( 'ovabrw_pickoff_loc', $values['ovabrw_pickoff_loc'], true );
            }

            // Pickup date
            $item->add_meta_data( 'ovabrw_pickup_date', $values['ovabrw_pickup_date'], true );

            // Dropoff date
        	$item->add_meta_data( 'ovabrw_pickoff_date', $values['ovabrw_pickoff_date'], true );

        	// Pick-up & Drop-off strtotime
        	$item->add_meta_data( 'ovabrw_pickup_date_strtotime', strtotime( $values['ovabrw_pickup_date'] ), true );
        	$item->add_meta_data( 'ovabrw_pickoff_date_strtotime', strtotime( $values['ovabrw_pickoff_date'] ), true );

        	// Pickup date real
        	$item->add_meta_data( 'ovabrw_pickup_date_real', $values['ovabrw_pickup_date_real'], true );

        	// Dropoff date real
        	$item->add_meta_data( 'ovabrw_pickoff_date_real', $values['ovabrw_pickoff_date_real'], true );

        	// Quantity
        	if ( $this->show_quantity() ) {
	            $item->add_meta_data( 'ovabrw_number_vehicle', $values['ovabrw_number_vehicle'], true );
	        } else {
	            $item->add_meta_data( 'ovabrw_number_vehicle', 1, true );
	        }

	        // Vehicle ids
	        if ( $values['id_vehicle'] ) {
	        	$item->add_meta_data( 'id_vehicle', $values['id_vehicle'], true );
	        }

	        // Real Quantity & Price
	        if ( $values['real_quantity'] ) {
	        	$item->add_meta_data( 'ovabrw_total_days', str_replace( '<br>', ', ', $values['real_quantity'] ), true );
	        }
	        
	        if ( $values['real_price'] ) {
	        	$item->add_meta_data( 'ovabrw_price_detail', str_replace( '<br>', ', ', $values['real_price'] ), true );
	        }

	        // Custom Checkout Fields
	        $list_fields = $this->get_custom_checkout_fields();

	        if ( is_array( $list_fields ) && ! empty( $list_fields ) ) {
	            foreach( $list_fields as $key => $field ) {
	                $value = array_key_exists( $key, $values ) ? $values[$key] : '';

	                if ( ! empty( $value ) && $field['enabled'] == 'on' ) {
	                    if ( 'select' === $field['type'] ) {
	                        $options_key = $options_text = array();

	                        if ( ovabrw_check_array( $field, 'ova_options_key' ) ) {
	                            $options_key = $field['ova_options_key'];
	                        }

	                        if ( ovabrw_check_array( $field, 'ova_options_text' ) ) {
	                            $options_text = $field['ova_options_text'];
	                        }

	                        $key_op = array_search( $value, $options_key );

	                        if ( ! is_bool( $key_op ) ) {
	                            if ( ovabrw_check_array( $options_text, $key_op ) ) {
	                                $value = $options_text[$key_op];
	                            }
	                        }
	                    }

	                    $item->add_meta_data( $key, $value, true );
	                }
	            }
	        }

	        if ( isset( $values['custom_ckf'] ) && $values['custom_ckf'] ) {
	            $item->add_meta_data( 'ovabrw_custom_ckf', $values['custom_ckf'], true );
	        }

	        if ( isset( $values['custom_ckf_qty'] ) && $values['custom_ckf_qty'] ) {
	            $item->add_meta_data( 'ovabrw_custom_ckf_qty', $values['custom_ckf_qty'], true );
	        }

	        // Resources
	        if ( ovabrw_array_exists( $values['resources'] ) ) {
	            $resources_name = $values['resources'];

	            if ( isset( $values['resources_qty'] ) && $values['resources_qty'] ) {
	                foreach ( $resources_name as $k => $v ) {
	                    if ( isset( $values['resources_qty'][$k] ) && absint( $values['resources_qty'][$k] ) ) {
	                        $resources_name[$k] = $v.' (x'.absint( $values['resources_qty'][$k] ).')';
	                    }
	                }
	            }

	            if ( count( $values['resources'] ) == 1 ) {
	                $item->add_meta_data( esc_html__( 'Resource', 'ova-brw' ), join( ', ', $resources_name ), true );
	            } else {
	                $item->add_meta_data( esc_html__( 'Resources', 'ova-brw' ), join( ', ', $resources_name ), true );
	            }

	            $item->add_meta_data( 'ovabrw_resources', $values['resources'], true );
	            $item->add_meta_data( 'ovabrw_resources_qty', $values['resources_qty'], true );
	        }

	        // Services
	        if ( ovabrw_array_exists( $values['ovabrw_service'] ) ) {
	        	$services 		= $values['ovabrw_service'];
	        	$services_qty 	= $values['ovabrw_service_qty'];

	        	$item->add_meta_data( 'ovabrw_services', $services, true );
                $item->add_meta_data( 'ovabrw_services_qty', $services_qty, true );

	        	if ( ovabrw_array_exists( $services ) ) {
	        		$serv_labels 	= $this->get_value( 'label_service', [] );
	        		$serv_ids 		= $this->get_value( 'service_id', [] );
	        		$serv_names 	= $this->get_value( 'service_name', [] );

	        		foreach ( $services as $k ) {
			    		if ( ovabrw_array_exists( $serv_ids ) ) {
			    			$qty = isset( $services_qty[$k] ) ? $services_qty[$k] : '';

			    			foreach ( $serv_ids as $i => $ids ) {
			    				$option_index = array_search( $k, $ids );

			        			if ( is_bool( $option_index ) ) continue;

			        			$name   = isset( $serv_names[$i][$option_index] ) ? $serv_names[$i][$option_index] : '';
                                $label  = isset( $serv_labels[$i] ) ? $serv_labels[$i] : '';

                                if ( $qty ) {
                                    $name .= ' (x'.absint( $qty ).')';
                                }

                                $item->add_meta_data( $label, $name, true );
			    			}
			    		}
			    	}
	        	}
	        }

	        // Insurance
	        $insurance_amount = $values['data']->get_meta('insurance_amount');
	        if ( $insurance_amount ) {
	        	$item->add_meta_data( 'ovabrw_insurance_amount', ovabrw_convert_price( $insurance_amount ), true );

	        	// Insurance tax
	        	$insurance_tax = $values['data']->get_meta('insurance_tax');
	        	if ( $insurance_tax ) {
	        		$item->add_meta_data( 'ovabrw_insurance_tax', ovabrw_convert_price( $insurance_tax ), true );
	        	}

	        	// Remaining insurance
	        	$remaining_insurance = $values['data']->get_meta('remaining_insurance');
	        	if ( $remaining_insurance ) {
	        		$item->add_meta_data( 'ovabrw_remaining_insurance', ovabrw_convert_price( $remaining_insurance ), true );
	        	}

	        	// Remaining insurance tax
	        	$remaining_insurance_tax = $values['data']->get_meta('remaining_insurance_tax');
	        	if ( $remaining_insurance_tax ) {
	        		$item->add_meta_data( 'ovabrw_remaining_insurance_tax', ovabrw_convert_price( $remaining_insurance_tax ), true );
	        	}
	        }

	        // Deposit
	        if ( isset( WC()->cart->deposit_info[ 'has_deposit' ] ) && WC()->cart->deposit_info[ 'has_deposit' ] ) {
	        	$deposit_type 		= $values['data']->get_meta('deposit_type');
	        	$deposit_value 		= $values['data']->get_meta('deposit_value');
	        	$deposit_amount 	= $values['data']->get_meta('deposit_amount');
				$remaining_amount 	= $values['data']->get_meta('remaining_amount');
				$remaining_tax 		= $values['data']->get_meta('remaining_tax');
				$total_payable 		= $values['data']->get_meta('total_payable');

				if ( $deposit_type ) {
					$item->add_meta_data( 'ovabrw_deposit_type', $deposit_type, true );
				}
				if ( $deposit_value ) {
					$item->add_meta_data( 'ovabrw_deposit_value', $deposit_value, true );
				}
				if ( $deposit_amount ) {
					$item->add_meta_data( 'ovabrw_deposit_amount', ovabrw_convert_price( $deposit_amount ), true );
				}
				if ( $remaining_amount ) {
					$item->add_meta_data( 'ovabrw_remaining_amount', ovabrw_convert_price( $remaining_amount ), true );
				}
				if ( $remaining_tax ) {
					$item->add_meta_data( 'ovabrw_remaining_tax', $remaining_tax, true );
				}
				if ( $total_payable ) {
					$item->add_meta_data( 'ovabrw_total_payable', ovabrw_convert_price( $total_payable ), true );
				}
	        }

	        do_action( 'ovabrw_after_save_order_line_item', $item, $values, $this );
		}
		
		public function get_total( $cart_item = [] ) {
			$pickup_date 	= isset( $cart_item['ovabrw_checkin'] ) ? $cart_item['ovabrw_checkin'] : '';
			$dropoff_date 	= isset( $cart_item['ovabrw_checkout'] ) ? $cart_item['ovabrw_checkout'] : '';

			if ( ! $this->ID || ! $pickup_date || ! $dropoff_date ) return 0;

			$total_day = $total_hour = 0;

			// Quantity Rent Day
			$qty_rent_day = $this->get_number_rental_days( $pickup_date, $dropoff_date );

			if ( $qty_rent_day ) {
				$checkin_day 	= $pickup_date;
				$checkout_day 	= $pickup_date + $qty_rent_day*86400;

				$total_day = $this->get_total_day( $checkin_day, $checkout_day, $qty_rent_day );
			}

			// Quantity Rent Hour
			$qty_rent_hour = $this->get_number_rental_hours( $pickup_date, $dropoff_date );

			if ( $qty_rent_hour ) {
				$checkin_hour 	= $dropoff_date - $qty_rent_hour*3600;
				$checkout_hour 	= $dropoff_date;

				$total_hour = $this->get_total_hour( $checkin_hour, $checkout_hour, $qty_rent_hour );
			}

			$total = floatval( $total_day ) + floatval( $total_hour );

			// Resource Prices
			$resources      	= isset( $cart_item['resources'] ) ? $cart_item['resources'] : [];
        	$resources_qty  	= isset( $cart_item['resources_qty'] ) ? $cart_item['resources_qty'] : [];
			$resource_prices 	= $this->get_resource_prices( $pickup_date, $dropoff_date, $resources, $resources_qty );
			$total 				+= $resource_prices;

			// Service Prices
			$services 		= isset( $cart_item['ovabrw_service'] ) ? $cart_item['ovabrw_service'] : [];
        	$services_qty   = isset( $cart_item['ovabrw_service_qty'] ) ? $cart_item['ovabrw_service_qty'] : [];
        	$service_prices = $this->get_service_prices( $pickup_date, $dropoff_date, $services, $services_qty );
        	$total 			+= $service_prices;

        	// Custom Checkout Fields
        	$custom_ckf 	= isset( $cart_item['custom_ckf'] ) ? $cart_item['custom_ckf'] : [];
        	$custom_ckf_qty = isset( $cart_item['custom_ckf_qty'] ) ? $cart_item['custom_ckf_qty'] : [];
        	$ckf_prices 	= $this->get_ckf_prices( $custom_ckf, $custom_ckf_qty );
        	$total 			+= $ckf_prices;

        	// Quantity
        	$quantity 	= isset( $cart_item['ovabrw_number_vehicle'] ) ? absint( $cart_item['ovabrw_number_vehicle'] ) : 1;
			$total 		*= $quantity;

			return apply_filters( 'ovabrw_get_total', $total, $cart_item, $this );
		}

		public function get_total_day( $pickup_date = '', $dropoff_date = '', $qty_rent_day = 0 ) {
			if ( ! $pickup_date || ! $dropoff_date || ! $qty_rent_day ) return 0;

			$total = 0;

			// Regular Price
			$regular_price = floatval( $this->get_value( 'regular_price_day' ) );

			if ( ! $regular_price ) {
				$regular_price = ! empty( get_post_meta( $this->ID, '_regular_price', true ) ) ? floatval( get_post_meta( $this->ID, '_regular_price', true ) ) : 0;
			}

			if ( ! $regular_price ) return $total;

			// Week price
			$monday_price 		= floatval( $this->get_value( 'daily_monday', $regular_price ) );
			$tuesday_price 		= floatval( $this->get_value( 'daily_tuesday', $regular_price ) );
			$wednesday_price 	= floatval( $this->get_value( 'daily_wednesday', $regular_price ) );
			$thursday_price 	= floatval( $this->get_value( 'daily_thursday', $regular_price ) );
			$friday_price 		= floatval( $this->get_value( 'daily_friday', $regular_price ) );
			$saturday_price 	= floatval( $this->get_value( 'daily_saturday', $regular_price ) );
			$sunday_price 		= floatval( $this->get_value( 'daily_sunday', $regular_price ) );

			// Special Day
			$arr_special_day 	= $this->get_data_special_day( $pickup_date, $dropoff_date );
			$total_special 		= floatval( $arr_special_day['total'] );
			$special_qty 		= absint( $arr_special_day['qty'] );

			// Discount Price
			$discount_price = $this->get_global_price_day( $qty_rent_day, $special_qty );

			if ( $discount_price ) {
				$monday_price = $tuesday_price = $wednesday_price = $thursday_price = $friday_price = $saturday_price = $sunday_price = $discount_price;
			}

			$arr_week_price = [ $monday_price, $tuesday_price, $wednesday_price, $thursday_price, $friday_price, $saturday_price, $sunday_price ];

			// Total week day
			$weekstart  	= date( 'N', $pickup_date );
			$total_week_day = $this->get_price_by_weekday_start( $weekstart, $qty_rent_day, $arr_week_price );

			// Get Total Price not Special
			$total_not_special = 0;

			if ( $special_qty ) {
				$total_not_special = $this->get_price_not_special_day( $pickup_date, $dropoff_date, $arr_week_price );
			}

			// Total
			$total = floatval( $total_week_day + $total_special - $total_not_special );

			return apply_filters( 'ovabrw_get_total_day', $total, $pickup_date, $dropoff_date, $qty_rent_day, $this );
		}

		public function get_total_hour( $pickup_date = '', $dropoff_date = '', $qty_rent_hour = 0 ) {
			if ( ! $pickup_date || ! $dropoff_date || ! $qty_rent_hour ) return 0;

			$total = 0;

			// Regular Price
			$regular_price = $this->get_value( 'regul_price_hour' );
			
			if ( ! $regular_price ) return $total;

			// Special Hour
			$arr_special_hour 	= $this->get_data_special_hour( $pickup_date, $dropoff_date );
			$total_special 		= floatval( $arr_special_hour['total'] );
			$special_qty 		= absint( $arr_special_hour['qty'] );

			// Discount Price
			$discount_price = $this->get_global_price_hour( $qty_rent_hour, $special_qty );

			if ( $discount_price ) $regular_price = $discount_price;

			// Get Total Price not Special
			$total_not_special = $regular_price * ( $qty_rent_hour - $special_qty );
			
			// Total
			$total = floatval( $total_not_special + $total_special );

			return apply_filters( 'ovabrw_get_total_hour', $total, $pickup_date, $dropoff_date, $qty_rent_hour, $this );
		}

		public function get_global_price_day( $qty_day = 0, $special_qty = 0 ) {
			$global_price = 0;

			if ( ! $this->ID || ! $qty_day ) return $global_price;

			$qty_day -= absint( $special_qty );

			$discount_price = $this->get_value( 'global_discount_price', [] );

			if ( ovabrw_array_exists( $discount_price ) ) {
				$discount_min 		= $this->get_value( 'global_discount_duration_val_min', [] );
				$discount_max 		= $this->get_value( 'global_discount_duration_val_max', [] );
				$discount_duration 	= $this->get_value( 'global_discount_duration_type', [] );

				foreach ( $discount_price as $i => $price ) {
					$min 		= isset( $discount_min[$i] ) ? $discount_min[$i] : '';
					$max 		= isset( $discount_max[$i] ) ? $discount_max[$i] : '';
					$duration 	= isset( $discount_duration[$i] ) ? $discount_duration[$i] : '';

					if ( $min != '' && $max != '' && floatval( $min ) <= $qty_day && $qty_day <= floatval( $max ) && $duration === 'days' ) {
						return floatval( $price );
					}
				}
			}

			return apply_filters( 'ovabrw_get_global_price_day', $global_price, $qty_day, $special_qty, $this );
		}

		public function get_global_price_hour( $qty_hour = 0, $special_qty = 0 ) {
			$global_price = 0;

			if ( ! $this->ID || ! $qty_hour ) return $global_price;

			$qty_hour -= absint( $special_qty );

			$discount_price = $this->get_value( 'global_discount_price', [] );

			if ( ovabrw_array_exists( $discount_price ) ) {
				$discount_min 		= $this->get_value( 'global_discount_duration_val_min', [] );
				$discount_max 		= $this->get_value( 'global_discount_duration_val_max', [] );
				$discount_duration 	= $this->get_value( 'global_discount_duration_type', [] );

				foreach ( $discount_price as $i => $price ) {
					$min 		= isset( $discount_min[$i] ) ? $discount_min[$i] : '';
					$max 		= isset( $discount_max[$i] ) ? $discount_max[$i] : '';
					$duration 	= isset( $discount_duration[$i] ) ? $discount_duration[$i] : '';

					if ( $min != '' && $max != '' && floatval( $min ) <= $qty_hour && $qty_hour <= floatval( $max ) && $duration === 'hours' ) {
						return floatval( $price );
					}
				}
			}

			return apply_filters( 'ovabrw_get_global_price_hour', $global_price, $qty_hour, $special_qty, $this );
		}

		public function get_data_special_day( $pickup_date = '', $dropoff_date = '' ) {
			$special_day = [
				'total' => 0,
				'qty' 	=> 0
			];

			if ( ! $this->ID || ! $pickup_date || ! $dropoff_date ) return $special_day;

			$special_price = $this->get_value( 'rt_price' );

			if ( ovabrw_array_exists( $special_price ) ) {
				$special_startdate 	= $this->get_value( 'rt_startdate', [] );
				$special_starttime 	= $this->get_value( 'rt_starttime', [] );
				$special_enddate 	= $this->get_value( 'rt_enddate', [] );
				$special_endtime 	= $this->get_value( 'rt_endtime', [] );
				$special_discount 	= $this->get_value( 'rt_discount', [] );

				foreach ( $special_price as $i => $price ) {
					$start_date = isset( $special_startdate[$i] ) ? $special_startdate[$i] : '';
					$start_time = isset( $special_starttime[$i] ) ? $special_starttime[$i] : '';
					$end_date 	= isset( $special_enddate[$i] ) ? $special_enddate[$i] : '';
					$end_time 	= isset( $special_endtime[$i] ) ? $special_endtime[$i] : '';
					$discount 	= isset( $special_discount[$i] ) ? $special_discount[$i] : '';

					if ( strtotime( $start_date ) & strtotime( $end_date ) ) {
						$from = strtotime( $start_date );
						if ( $start_time ) $from = strtotime( $start_date.' '.$start_time );

						$to = strtotime( $end_date );
						if ( $end_time ) $to = strtotime( $end_date.' '.$end_time );

						$qty_day = $discount_price = 0;

						// Get special price
						if ( $pickup_date >= $from && $dropoff_date <= $to ) {
							$qty_day = $this->get_number_rental_days( $pickup_date, $dropoff_date );
						} elseif ( $pickup_date < $from && $dropoff_date <= $to && $dropoff_date >= $from ) {
							$qty_day = $this->get_number_rental_days( $from, $dropoff_date );
						} elseif ( $pickup_date >= $from && $pickup_date <= $to && $dropoff_date >= $to ) {
							$qty_day = $this->get_number_rental_days( $pickup_date, $to );
						} elseif ( $pickup_date < $from && $dropoff_date > $to ) {
							$qty_day = $this->get_number_rental_days( $from, $to );
						} else {
							continue;
						}

						$discount_price 		= $this->get_price_special_discount_day( $discount, $price, $qty_day );
						$special_day['total'] 	+= floatval( $discount_price ) * $qty_day;
						$special_day['qty'] 	+= $qty_day;
					}
				}
			}

			return apply_filters( 'ovabrw_get_data_special_day', $special_day, $pickup_date, $dropoff_date, $this );
		}

		public function get_data_special_hour( $pickup_date = '', $dropoff_date = '' ) {
			$special_day = [
				'total' => 0,
				'qty' 	=> 0
			];

			if ( ! $this->ID || ! $pickup_date || ! $dropoff_date ) return $special_day;

			// Special Hours
			$special_price = $this->get_value( 'rt_price_hour' );

			if ( ovabrw_array_exists( $special_price ) ) {
				$special_startdate 	= $this->get_value( 'rt_startdate', [] );
				$special_starttime 	= $this->get_value( 'rt_starttime', [] );
				$special_enddate 	= $this->get_value( 'rt_enddate', [] );
				$special_endtime 	= $this->get_value( 'rt_endtime', [] );
				$special_discount 	= $this->get_value( 'rt_discount', [] );

				foreach ( $special_price as $i => $price ) {
					$start_date = isset( $special_startdate[$i] ) ? $special_startdate[$i] : '';
					$start_time = isset( $special_starttime[$i] ) ? $special_starttime[$i] : '';
					$end_date 	= isset( $special_enddate[$i] ) ? $special_enddate[$i] : '';
					$end_time 	= isset( $special_endtime[$i] ) ? $special_endtime[$i] : '';
					$discount 	= isset( $special_discount[$i] ) ? $special_discount[$i] : '';

					if ( strtotime( $start_date ) & strtotime( $end_date ) ) {
						$from = strtotime( $start_date );
						if ( $start_time ) $from = strtotime( $start_date.' '.$start_time );

						$to = strtotime( $end_date );
						if ( $end_time ) $to = strtotime( $end_date.' '.$end_time );

						$qty_hour = $discount_price = 0;

						// Get special price
						if ( $pickup_date >= $from && $dropoff_date <= $to ) {
							$qty_hour = $this->get_number_rental_hours( $pickup_date, $dropoff_date );
						} elseif ( $pickup_date < $from && $dropoff_date <= $to && $dropoff_date >= $from ) {
							$qty_hour = $this->get_number_rental_hours( $from, $dropoff_date );
						} elseif ( $pickup_date >= $from && $pickup_date <= $to && $dropoff_date >= $to ) {
							$qty_hour = $this->get_number_rental_hours( $pickup_date, $to );
						} elseif ( $pickup_date < $from && $dropoff_date > $to ) {
							$qty_hour = $this->get_number_rental_hours( $from, $to );
						} else {
							continue;
						}

						$discount_price 		= $this->get_price_special_discount_hour( $discount, $price, $qty_hour );
						$special_day['total'] 	+= floatval( $discount_price ) * $qty_hour;
						$special_day['qty'] 	+= $qty_hour;
					}
				}
			}

			return apply_filters( 'ovabrw_get_data_special_hour', $special_day, $pickup_date, $dropoff_date, $this );
		}

		public function get_price_special_discount_day( $discount = [], $price = 0, $qty_day = 0 ) {
			if ( ! ovabrw_array_exists( $discount ) || ! $qty_day ) return $price;

			$dsc_price 	= isset( $discount['price'] ) ? $discount['price'] : '';
			$dsc_min 	= isset( $discount['min'] ) ? $discount['min'] : '';
			$dsc_max 	= isset( $discount['max'] ) ? $discount['max'] : '';
			$dsc_type 	= isset( $discount['duration_type'] ) ? $discount['duration_type'] : '';

			if ( ovabrw_array_exists( $dsc_price ) ) {
				foreach ( $dsc_price as $i => $p ) {
					$min 		= isset( $dsc_min[$i] ) ? $dsc_min[$i] : '';
					$max 		= isset( $dsc_max[$i] ) ? $dsc_max[$i] : '';
					$duration 	= isset( $dsc_type[$i] ) ? $dsc_type[$i] : '';

					if ( $min != '' && $max != '' && floatval( $min ) <= $qty_day && $qty_day <= floatval( $max ) && $duration === 'days' ) {
						return $p;
					}
				}
			}

			return apply_filters( 'ovabrw_get_price_special_discount_day', $price, $discount, $qty_day, $this );
		}

		public function get_price_special_discount_hour( $discount = [], $price = 0, $qty_hour = 0 ) {
			if ( ! ovabrw_array_exists( $discount ) || ! $qty_hour ) return $price;

			$dsc_price 	= isset( $discount['price'] ) ? $discount['price'] : '';
			$dsc_min 	= isset( $discount['min'] ) ? $discount['min'] : '';
			$dsc_max 	= isset( $discount['max'] ) ? $discount['max'] : '';
			$dsc_type 	= isset( $discount['duration_type'] ) ? $discount['duration_type'] : '';

			if ( ovabrw_array_exists( $dsc_price ) ) {
				foreach ( $dsc_price as $i => $p ) {
					$min 		= isset( $dsc_min[$i] ) ? $dsc_min[$i] : '';
					$max 		= isset( $dsc_max[$i] ) ? $dsc_max[$i] : '';
					$duration 	= isset( $dsc_type[$i] ) ? $dsc_type[$i] : '';

					if ( $min != '' && $max != '' && floatval( $min ) <= $qty_hour && $qty_hour <= floatval( $max ) && $duration === 'hours' ) {
						return $p;
					}
				}
			}

			return apply_filters( 'ovabrw_get_price_special_discount_hour', $price, $discount, $qty_hour, $this );
		}

		public function get_price_not_special_day( $pickup_date = '', $dropoff_date = '', $arr_price = [] ) {
			$total_not_special = 0;

			if ( ! $this->ID || ! $pickup_date || ! $dropoff_date || ! ovabrw_array_exists( $arr_price ) ) return $total_not_special;

			$special_price = $this->get_value( 'rt_price' );

			if ( ovabrw_array_exists( $special_price ) ) {
				$special_startdate 	= $this->get_value( 'rt_startdate', [] );
				$special_starttime 	= $this->get_value( 'rt_starttime', [] );
				$special_enddate 	= $this->get_value( 'rt_enddate', [] );
				$special_endtime 	= $this->get_value( 'rt_endtime', [] );

				foreach ( $special_price as $i => $price ) {
					$start_date = isset( $special_startdate[$i] ) ? $special_startdate[$i] : '';
					$start_time = isset( $special_starttime[$i] ) ? $special_starttime[$i] : '';
					$end_date 	= isset( $special_enddate[$i] ) ? $special_enddate[$i] : '';
					$end_time 	= isset( $special_endtime[$i] ) ? $special_endtime[$i] : '';
					$discount 	= isset( $special_discount[$i] ) ? $special_discount[$i] : '';

					if ( strtotime( $start_date ) & strtotime( $end_date ) ) {
						$from = strtotime( $start_date );
						if ( $start_time ) $from = strtotime( $start_date.' '.$start_time );

						$to = strtotime( $end_date );
						if ( $end_time ) $to = strtotime( $end_date.' '.$end_time );

						$qty_day = $weekstart = '';

						// Get special price
						if ( $pickup_date >= $from && $dropoff_date <= $to ) {
							$qty_day 	= $this->get_number_rental_days( $pickup_date, $dropoff_date );
							$weekstart 	= date( 'N', $pickup_date );
						} elseif ( $pickup_date < $from && $dropoff_date <= $to && $dropoff_date >= $from ) {
							$qty_day 	= $this->get_number_rental_days( $from, $dropoff_date );
							$weekstart 	= date( 'N', $from );
						} elseif ( $pickup_date >= $from && $pickup_date <= $to && $dropoff_date >= $to ) {
							$qty_day 	= $this->get_number_rental_days( $pickup_date, $to );
							$weekstart 	= date( 'N', $pickup_date );
						} elseif ( $pickup_date < $from && $dropoff_date > $to ) {
							$qty_day 	= $this->get_number_rental_days( $from, $to );
							$weekstart 	= date( 'N', $from );
						} else {
							continue;
						}

						// Get total not special
						$total_not_special += $this->get_price_by_weekday_start( $weekstart, $qty_day, $arr_price );
					}
				}
			}

			return apply_filters( 'ovabrw_get_price_not_special_day', $total_not_special, $pickup_date, $dropoff_date, $arr_price, $this );
		}

		public function get_strtotime_input_date( $pickup_date = '', $dropoff_date = '' ) {
			$new_date = [
				'pickup_date_new' 	=> '',
				'dropoff_date_new' 	=> ''
			];

			// Check show drop-off date
			$show_dropoff_date = ovabrw_show_date( $this->ID, 'dropoff' );

			if ( ! $show_dropoff_date && ! $dropoff_date ) {
				$dropoff_date = $pickup_date;
			}

			$new_date['pickup_date_new'] 	= $pickup_date;
			$new_date['dropoff_date_new'] 	= $dropoff_date;

			return apply_filters( 'ovabrw_get_strtotime_input_date', $new_date, $pickup_date, $dropoff_date, $this );
		}

		public function get_real_data( $pickup_date = '', $dropoff_date = '' ) {
			$real_data = [
				'real_quantity' => '',
				'real_price' 	=> ''
			];

			if ( ! $pickup_date || ! $dropoff_date ) return $real_quantity;

			$real_quantity = $real_price = [];

			// Get number rental time by Day
			$number_rental_days = $this->get_number_rental_days( $pickup_date, $dropoff_date );

			if ( $number_rental_days ) {
				$checkin_day 	= $pickup_date;
				$checkout_day 	= $pickup_date + $number_rental_days*86400;

				$special_price_day = $this->get_value( 'rt_price' );

				if ( ovabrw_array_exists( $special_price_day ) ) {
					$special_startdate 	= $this->get_value( 'rt_startdate', [] );
					$special_starttime 	= $this->get_value( 'rt_starttime', [] );
					$special_enddate 	= $this->get_value( 'rt_enddate', [] );
					$special_endtime 	= $this->get_value( 'rt_endtime', [] );
					$special_discount 	= $this->get_value( 'rt_discount', [] );

					foreach ( $special_price_day as $i =>$price ) {
						$start_date = isset( $special_startdate[$i] ) ? $special_startdate[$i] : '';
						$start_time = isset( $special_starttime[$i] ) ? $special_starttime[$i] : '';
						$end_date 	= isset( $special_enddate[$i] ) ? $special_enddate[$i] : '';
						$end_time 	= isset( $special_endtime[$i] ) ? $special_endtime[$i] : '';
						$discount 	= isset( $special_discount[$i] ) ? $special_discount[$i] : '';

						if ( strtotime( $start_date ) & strtotime( $end_date ) ) {
							$from = strtotime( $start_date );
							if ( $start_time ) $from = strtotime( $start_date.' '.$start_time );

							$to = strtotime( $end_date );
							if ( $end_time ) $to = strtotime( $end_date.' '.$end_time );

							$qty_day = $discount_price = 0;

							// Get special price
							if ( $checkin_day >= $from && $checkout_day <= $to ) {
								$qty_day = $this->get_number_rental_days( $pickup_date, $checkout_day );
							} elseif ( $checkin_day < $from && $checkout_day <= $to && $checkout_day >= $from ) {
								$qty_day = $this->get_number_rental_days( $from, $checkout_day );
							} elseif ( $checkin_day >= $from && $checkin_day <= $to && $checkout_day >= $to ) {
								$qty_day = $this->get_number_rental_days( $checkin_day, $to );
							} elseif ( $checkin_day < $from && $checkout_day > $to ) {
								$qty_day = $this->get_number_rental_days( $from, $to );
							} else {
								continue;
							}

							$number_rental_days -= $qty_day;
							$discount_price = $this->get_price_special_discount_day( $discount, $price, $qty_day );

							if ( $qty_day ) {
								array_push( $real_quantity, sprintf( esc_html__( '%s Special Day(s)', 'ova-brw' ), $qty_day ) );
								array_push( $real_price, sprintf( esc_html__( '%s Special Day(s)', 'ova-brw' ), ovabrw_wc_price( OVABRW()->options->get_price_include_tax( $this->ID, $discount_price ) ) ) );
							}
						}
					}
				}

				// Check number rental time days
				if ( $number_rental_days ) {
					// Regular Price
					$regular_price_day = floatval( $this->get_value( 'regular_price_day' ) );

					if ( ! $regular_price_day ) {
						$regular_price_day = ! empty( get_post_meta( $this->ID, '_regular_price', true ) ) ? floatval( get_post_meta( $this->ID, '_regular_price', true ) ) : 0;
					}

					$global_price_day = $this->get_global_price_day( $number_rental_days );

					if ( ! $global_price_day ) {
						$weekstart 			= date( 'N', $pickup_date );
						$global_price_day 	= $this->get_global_price_by_weekday_start( $weekstart, $global_price_day );

						if ( ! $global_price_day ) $global_price_day = $regular_price_day;
					}

					array_push( $real_quantity, sprintf( esc_html__( '%s Day(s)', 'ova-brw' ), $number_rental_days ) );
					array_push( $real_price, sprintf( esc_html__( '%s Day(s)', 'ova-brw' ), ovabrw_wc_price( OVABRW()->options->get_price_include_tax( $this->ID, $global_price_day ) ) ) );
				}
			}

			// Get number rental time by Hour
			$number_rental_hours = $this->get_number_rental_hours( $pickup_date, $dropoff_date );

			// Special Hours
			if ( $number_rental_hours ) {
				$checkin_hour 	= $dropoff_date - $number_rental_hours*3600;
				$checkout_hour 	= $dropoff_date;

				$special_price_hour = $this->get_value( 'rt_price_hour' );

				if ( ovabrw_array_exists( $special_price_hour ) ) {
					$special_startdate 	= $this->get_value( 'rt_startdate', [] );
					$special_starttime 	= $this->get_value( 'rt_starttime', [] );
					$special_enddate 	= $this->get_value( 'rt_enddate', [] );
					$special_endtime 	= $this->get_value( 'rt_endtime', [] );
					$special_discount 	= $this->get_value( 'rt_discount', [] );

					foreach ( $special_price_hour as $i => $price ) {
						$start_date = isset( $special_startdate[$i] ) ? $special_startdate[$i] : '';
						$start_time = isset( $special_starttime[$i] ) ? $special_starttime[$i] : '';
						$end_date 	= isset( $special_enddate[$i] ) ? $special_enddate[$i] : '';
						$end_time 	= isset( $special_endtime[$i] ) ? $special_endtime[$i] : '';
						$discount 	= isset( $special_discount[$i] ) ? $special_discount[$i] : '';

						if ( strtotime( $start_date ) & strtotime( $end_date ) ) {
							$from = strtotime( $start_date );
							if ( $start_time ) $from = strtotime( $start_date.' '.$start_time );

							$to = strtotime( $end_date );
							if ( $end_time ) $to = strtotime( $end_date.' '.$end_time );

							$qty_hour = $discount_price = 0;

							// Get special price
							if ( $checkin_hour >= $from && $checkout_hour <= $to ) {
								$qty_hour = $this->get_number_rental_hours( $checkin_hour, $checkout_hour );
							} elseif ( $checkin_hour < $from && $checkout_hour <= $to && $checkout_hour >= $from ) {
								$qty_hour = $this->get_number_rental_hours( $from, $checkout_hour );
							} elseif ( $checkin_hour >= $from && $checkin_hour <= $to && $checkout_hour >= $to ) {
								$qty_hour = $this->get_number_rental_hours( $checkin_hour, $to );
							} elseif ( $checkin_hour < $from && $checkout_hour > $to ) {
								$qty_hour = $this->get_number_rental_hours( $from, $to );
							} else {
								continue;
							}

							$number_rental_hours -= $qty_hour;
							$discount_price = $this->get_price_special_discount_hour( $discount, $price, $qty_hour );

							if ( $qty_hour ) {
								array_push( $real_quantity, sprintf( esc_html__( '%s Special Hour(s)', 'ova-brw' ), $qty_hour ) );
								array_push( $real_price, sprintf( esc_html__( '%s Special Hour(s)', 'ova-brw' ), ovabrw_wc_price( OVABRW()->options->get_price_include_tax( $this->ID, $discount_price ) ) ) );
							}
						}
					}
				}

				// Check number rental time hours
				if ( $number_rental_hours ) {
					// Regular Price
					$regular_price_hour = $this->get_value( 'regul_price_hour' );
					$global_price_hour 	= $this->get_global_price_hour( $number_rental_hours );

					if ( ! $global_price_hour ) $global_price_hour = $regular_price_hour;

					array_push( $real_quantity, sprintf( esc_html__( '%s Hour(s)', 'ova-brw' ), $number_rental_hours ) );
					array_push( $real_price, sprintf( esc_html__( '%s Hour(s)', 'ova-brw' ), ovabrw_wc_price( OVABRW()->options->get_price_include_tax( $this->ID, $global_price_hour ) ) ) );
				}
			}

			if ( ovabrw_array_exists( $real_quantity ) ) {
				$real_data['real_quantity'] = join( '<br>', $real_quantity );
			}
			if ( ovabrw_array_exists( $real_price ) ) {
				$real_data['real_price'] = join( '<br>', $real_price );
			}

			return apply_filters( 'ovabrw_get_real_data', $real_data, $pickup_date, $dropoff_date, $this );
		}

		public function get_number_rental_days( $pickup_date = '', $dropoff_date = '' ) {
			if ( ! $this->ID || ! $pickup_date || ! $dropoff_date ) return 0;

			$rent_time_day_raw = ( $dropoff_date - $pickup_date ) / 86400;

		    return apply_filters( 'ovabrw_get_number_rental_days', intval(floor( $rent_time_day_raw )), $pickup_date, $dropoff_date, $this );
		}

		public function get_number_rental_hours( $pickup_date = '', $dropoff_date = '' ) {
			if ( ! $this->ID || ! $pickup_date || ! $dropoff_date ) return 0;

			$rent_time_hour_raw 	= ( $dropoff_date - $pickup_date ) / 3600;
			$number_rental_days 	= $this->get_number_rental_days( $pickup_date, $dropoff_date );
		    $number_rental_hours 	= $rent_time_hour_raw - $number_rental_days * 24;

		    if ( ! $number_rental_hours && $pickup_date === $dropoff_date ) {
		    	$number_rental_hours = 1;
		    }

		    return apply_filters( 'ovabrw_get_number_rental_hours', ceil($number_rental_hours), $pickup_date, $dropoff_date, $this );
		}

		public function get_html_price( $product_id = null ) {
			if ( ! $this->ID ) $this->ID = $product_id;

			// Price by day
			$price_by_day 	= $this->get_value( 'regular_price_day' );
			$unit_by_day 	= esc_html__( '/day', 'ova-brw' );

			// Price by hour
			$price_by_hour 	= $this->get_value( 'regul_price_hour' );
			$unit_by_hour 	= esc_html__( '/hour', 'ova-brw' );

			do_action( 'ovabrw_before_get_html_price', $product_id, $this );
			if ( $price_by_day ): ?>
				<span class="amount">
					<?php echo ovabrw_wc_price( $price_by_day, [], false ); ?>
				</span>
				<span class="unit">
					<?php echo esc_html( $unit_by_day ); ?>
				</span><br/>
			<?php endif; ?>
			<?php if ( $price_by_hour ): ?>
				<span class="amount">
					<?php echo ovabrw_wc_price( $price_by_hour, [], false ); ?>
				</span>
				<span class="unit">
					<?php echo esc_html( $unit_by_hour ); ?>
				</span>
			<?php endif;
			do_action( 'ovabrw_after_get_html_price', $product_id, $this );
		}

		// Request Booking
		public function request_booking_get_mail_body( $data = [] ) {
			if ( ! ovabrw_array_exists( $data ) ) return false;

			// Get pick-up and drop-off labels
			$pickup_label 	= OVABRW()->options->get_label_pickup_date( $this->ID );
			$dropoff_label 	= OVABRW()->options->get_label_pickoff_date( $this->ID );

			// Get Data
			$product_name 		= isset( $data['product_name'] ) ? $data['product_name'] : '';
			$customer_name 		= isset( $data['name'] ) ? $data['name'] : '';
			$customer_email 	= isset( $data['email'] ) ? $data['email'] : '';
			$customer_phone 	= isset( $data['number'] ) ? $data['number'] : '';
			$customer_address 	= isset( $data['address'] ) ? $data['address'] : '';
			$customer_note 		= isset( $data['extra'] ) ? $data['extra'] : '';
			$pickup_location 	= isset( $data['ovabrw_pickup_loc'] ) ? sanitize_text_field( $data['ovabrw_pickup_loc'] ) : '';
			$dropoff_location 	= isset( $data['ovabrw_pickoff_loc'] ) ? sanitize_text_field( $data['ovabrw_pickoff_loc'] ) : '';
			$pickup_date 		= isset( $data['pickup_date'] ) ? sanitize_text_field( $data['pickup_date'] ) : '';
			$dropoff_date 		= isset( $data['pickoff_date'] ) ? sanitize_text_field( $data['pickoff_date'] ) : '';
			$qty_input 			= isset( $data['ovabrw_number_vehicle'] ) ? absint( $data['ovabrw_number_vehicle'] ) : '';

			if ( ! $qty_input ) $qty_input = 1;
			if ( ! $dropoff_date ) $dropoff_date = $pickup_date;

	        // Get Order Detail
	        $order_detail = '<h2>'. esc_html__( 'Order details: ', 'ova-brw' ) . '</h2>';
        	$order_detail .= '<table>';

    		// Product
    		if ( $this->ID ) {
    			$order_detail .= '<tr>';
        			$order_detail .= '<td style="width: 15%">'.esc_html__( 'Product: ', 'ova-brw' ).'</td>';
        			$order_detail .= '<td style="width: 85%">';
        				$order_detail .= '<a href="'.get_permalink( $this->ID ).'">'.$product_name.'</a>';
        			$order_detail .= '</td>';
        		$order_detail .= '</tr>';
    		}

    		// Customer name
    		if ( $customer_name ) {
    			$order_detail .= '<tr>';
    				$order_detail .= '<td>'.esc_html__( 'Name: ', 'ova-brw' ).'</td>';
    				$order_detail .= '<td>'.$customer_name.'</td>';
    			$order_detail .= '</tr>';
    		}

    		// Customer email
    		if ( $customer_email ) {
    			$order_detail .= '<tr>';
    				$order_detail .= '<td>'.esc_html__( 'Email: ', 'ova-brw' ).'</td>';
    				$order_detail .= '<td>'.$customer_email.'</td>';
    			$order_detail .= '</tr>';
    		}

    		// Customer phone
    		if ( get_option( 'ova_brw_request_booking_form_show_number', 'yes' ) === 'yes' && $customer_phone ) {
    			$order_detail .= '<tr>';
    				$order_detail .= '<td>'.esc_html__( 'Phone: ', 'ova-brw' ).'</td>';
    				$order_detail .= '<td>'.$customer_phone.'</td>';
    			$order_detail .= '</tr>';
    		}

    		// Customer address
    		if ( get_option( 'ova_brw_request_booking_form_show_address', 'yes' ) === 'yes' && $customer_address ) {
    			$order_detail .= '<tr>';
    				$order_detail .= '<td>'.esc_html__( 'Address: ', 'ova-brw' ).'</td>';
    				$order_detail .= '<td>'.$customer_address.'</td>';
    			$order_detail .= '</tr>';
    		}

    		// Pickup location
    		if ( get_option( 'ova_brw_request_booking_form_show_pickup_location', 'yes' ) === 'yes' && $pickup_location ) {
    			$order_detail .= '<tr>';
    				$order_detail .= '<td>'.esc_html__( 'Pick-up Location: ', 'ova-brw' ).'</td>';
    				$order_detail .= '<td>'.$pickup_location.'</td>';
    			$order_detail .= '</tr>';
    		}

    		// Dropoff location
    		if ( get_option( 'ova_brw_request_booking_form_show_pickoff_location', 'yes' ) === 'yes' && $dropoff_location ) {
    			$order_detail .= '<tr>';
    				$order_detail .= '<td>'.esc_html__( 'Drop-off Location: ', 'ova-brw' ).'</td>';
    				$order_detail .= '<td>'.$dropoff_location.'</td>';
    			$order_detail .= '</tr>';
    		}

    		// Pickup date
			$order_detail .= '<tr>';
				$order_detail .= '<td>'.sprintf( esc_html__( '%s: ', 'ova-brw' ), $pickup_label ).'</td>';
				$order_detail .= '<td>'.$pickup_date.'</td>';
			$order_detail .= '</tr>';

    		// Dropoff date
    		if ( get_option( 'ova_brw_request_booking_form_show_pickoff_date', 'yes' ) === 'yes' && $dropoff_date ) {
    			$order_detail .= '<tr>';
    				$order_detail .= '<td>'.sprintf( esc_html__( '%s: ', 'ova-brw' ), $dropoff_label ).'</td>';
    				$order_detail .= '<td>'.$dropoff_date.'</td>';
    			$order_detail .= '</tr>';
    		}

    		// Quantity Input
    		if ( get_option( 'ova_brw_request_booking_form_show_number_vehicle', 'yes' ) === 'yes' && $qty_input ) {
    			$order_detail .= '<tr>';
    				$order_detail .= '<td>'.esc_html__( 'Quantity: ', 'ova-brw' ).'</td>';
    				$order_detail .= '<td>'.$qty_input.'</td>';
    			$order_detail .= '</tr>';
    		}

    		// Custom Checkout Fields
    		$list_fields = $this->get_custom_checkout_fields();
    		$custom_ckf         = array();
	        $custom_ckf_qty     = [];
	        $custom_ckf_save    = array();

	        if ( ! empty( $list_fields ) && is_array( $list_fields ) ) {
	            foreach ( $list_fields as $key => $field ) {
	                if ( $field['type'] === 'file' ) {
	                    $files = isset( $_FILES[$key] ) ? $_FILES[$key] : '';

	                    if ( ! empty( $files ) ) {
	                        if ( isset( $files['size'] ) && $files['size'] ) {
	                            $mb = absint( $files['size'] ) / 1048576;

	                            if ( $mb > $field['max_file_size'] ) {
	                                continue;
	                            }
	                        }

	                        $overrides = [
	                            'test_form' => false,
	                            'mimes'     => apply_filters( 'ovabrw_ft_file_mimes', [
	                                'jpg'   => 'image/jpeg',
	                                'jpeg'  => 'image/pjpeg',
	                                'png'   => 'image/png',
	                                'pdf'   => 'application/pdf',
	                                'doc'   => 'application/msword',
	                            ]),
	                        ];

	                        require_once( ABSPATH . 'wp-admin/includes/admin.php' );

	                        $upload = wp_handle_upload( $files, $overrides );

	                        if ( isset( $upload['error'] ) ) {
	                            continue;
	                        }

	                        $order_detail .= '<tr>';
	                        	$order_detail .= '<td>'.sprintf( '%s: ', esc_html( $field['label'] ) ).'</td>';
	                        	$order_detail .= '<td>';
	                        		$order_detail .= '<a href="'.esc_url( $upload['url'] ).'" title="'.esc_attr( basename( $upload['file'] ) ).'" target="_blank">'.esc_attr( basename( $upload['file'] ) ).'</a>';
	                        	$order_detail .= '</td>';
	                        $order_detail .= '</tr>';

	                        $custom_ckf_save[$key] = '<a href="'.esc_url( $upload['url'] ).'" title="'.esc_attr( basename( $upload['file'] ) ).'" target="_blank">'.esc_attr( basename( $upload['file'] ) ).'</a>';
	                    }
	                } else {
	                    $value = array_key_exists( $key, $data ) ? $data[$key] : '';

	                    if ( ! empty( $value ) && 'on' === $field['enabled'] ) {
	                        if ( 'select' === $field['type'] ) {
	                            $custom_ckf[$key] = sanitize_text_field( $value );

	                            if ( isset( $data[$key.'_qty'] ) && ! empty( $data[$key.'_qty'] ) ) {
	                                if ( isset( $data[$key.'_qty'][$value] ) && absint( $data[$key.'_qty'][$value] ) ) {
	                                    $custom_ckf_qty[$value] = absint( $data[$key.'_qty'][$value] );
	                                }
	                            }

	                            $options_key = $options_text = array();
	                            if ( ovabrw_check_array( $field, 'ova_options_key' ) ) {
	                                $options_key = $field['ova_options_key'];
	                            }

	                            if ( ovabrw_check_array( $field, 'ova_options_text' ) ) {
	                                $options_text = $field['ova_options_text'];
	                            }

	                            $key_op = array_search( $value, $options_key );

	                            if ( ! is_bool( $key_op ) ) {
	                                if ( ovabrw_check_array( $options_text, $key_op ) ) {
	                                    if ( isset( $custom_ckf_qty[$value] ) && absint( $custom_ckf_qty[$value] ) ) {
	                                        $value = $options_text[$key_op] . ' (x'.absint( $custom_ckf_qty[$value] ).')';
	                                    } else {
	                                        $value = $options_text[$key_op];
	                                    }
	                                }
	                            }
	                        }

	                        if ( 'checkbox' === $field['type'] ) {
	                            $checkbox_val = $checkbox_key = $checkbox_text = array();

	                            $custom_ckf[$key] = $value;

	                            if ( isset( $data[$key.'_qty'] ) && ! empty( $data[$key.'_qty'] ) && is_array( $data[$key.'_qty'] ) ) {
	                                $custom_ckf_qty = $custom_ckf_qty + $data[$key.'_qty'];
	                            }

	                            if ( ovabrw_check_array( $field, 'ova_checkbox_key' ) ) {
	                                $checkbox_key = $field['ova_checkbox_key'];
	                            }

	                            if ( ovabrw_check_array( $field, 'ova_checkbox_text' ) ) {
	                                $checkbox_text = $field['ova_checkbox_text'];
	                            }

	                            foreach ( $value as $val_cb ) {
	                                $key_cb = array_search( $val_cb, $checkbox_key );
	                                $qty    = isset( $custom_ckf_qty[$val_cb] ) && absint( $custom_ckf_qty[$val_cb] ) ? absint( $custom_ckf_qty[$val_cb] ) : '';

	                                if ( ! is_bool( $key_cb ) ) {
	                                    if ( ovabrw_check_array( $checkbox_text, $key_cb ) ) {
	                                        if ( $qty ) {
	                                            array_push( $checkbox_val , $checkbox_text[$key_cb] . ' (x'.$qty.')' );
	                                        } else {
	                                            array_push( $checkbox_val , $checkbox_text[$key_cb] );
	                                        }
	                                    }
	                                }
	                            }

	                            if ( ! empty( $checkbox_val ) && is_array( $checkbox_val ) ) {
	                                $value = join( ", ", $checkbox_val );
	                            }
	                        }

	                        if ( 'radio' === $field['type'] ) {
	                            $custom_ckf[$key] = sanitize_text_field( $value );

	                            if ( isset( $data[$key.'_qty'] ) && ! empty( $data[$key.'_qty'] ) ) {
	                                $qty = isset( $data[$key.'_qty'][$custom_ckf[$key]] ) && absint( $data[$key.'_qty'][$custom_ckf[$key]] ) ? absint( $data[$key.'_qty'][$custom_ckf[$key]] ) : 1;
	                                $custom_ckf_qty[$key] = $qty;

	                                $value .= ' (x'.$qty.')';
	                            }
	                        }

	                        $order_detail .= '<tr>';
	                        	$order_detail .= '<td>'.sprintf( '%s: ', esc_html( $field['label'] ) ).'</td>';
	                        	$order_detail .= '<td>'.esc_html( $value ).'</td>';
	                        $order_detail .= '</tr>';

	                        $custom_ckf_save[$key] = $value;
	                    }
	                }
	            }
	        }

    		// Resources
	        $resources          = array();
	        $resource_names     = array();
	        $resource_checkboxs = isset( $data['ovabrw_resource_checkboxs'] ) ? $data['ovabrw_resource_checkboxs'] : [];
	        $resource_qty       = isset( $data['ovabrw_resource_quantity'] ) ? $data['ovabrw_resource_quantity'] : [];

	        if ( ovabrw_array_exists( $resource_checkboxs ) ) {
	            $resource_ids 	= $this->get_value( 'resource_id', [] );
	            $resource_name 	= $this->get_value( 'resource_name', [] );

	            foreach ( $resource_checkboxs as $rs_id ) {
	                $rs_key = array_search( $rs_id, $resource_ids );
	                
	                if ( ! is_bool( $rs_key ) ) {
	                    $rs_name = isset( $resource_name[$rs_key] ) ? $resource_name[$rs_key] : '';

	                    if ( isset( $resource_qty[$rs_id] ) && absint( $resource_qty[$rs_id] ) ) {
	                        $rs_name .= ' (x'.absint( $resource_qty[$rs_id] ).')';
	                    }

	                    $resources[$rs_id] = $rs_name;
	                    array_push( $resource_names, $rs_name );
	                }
	            }
	        }

    		if ( get_option( 'ova_brw_request_booking_form_show_extra_service', 'yes' ) === 'yes' && ovabrw_array_exists( $resource_names ) ) {
    			$order_detail .= '<tr>';
    				if ( count( $resource_names ) === 1 ) {
    					$order_detail .= '<td>'.esc_html__( 'Resource: ', 'ova-brw' ).'</td>';
    				} else {
    					$order_detail .= '<td>'.esc_html__( 'Resources: ', 'ova-brw' ).'</td>';
    				}
    				$order_detail .= '<td>'.implode( ', ', $resource_names ).'</td>';
    			$order_detail .= '</tr>';
    		}

    		// Services
    		$service_str 	= '';
        	$services_qty 	= [];
        	$services 		= isset( $data['ovabrw_service'] ) ? $data['ovabrw_service'] : [];
	        $ser_qty 		= isset( $data['ovabrw_service_qty'] ) ? $data['ovabrw_service_qty'] : [];

	        if ( ovabrw_array_exists( $services ) ) {
	        	$serv_labels 	= $this->get_value( 'label_service', [] );
	        	$serv_ids 		= $this->get_value( 'service_id', [] );
	        	$serv_names 	= $this->get_value( 'service_name', [] );

	        	foreach ( $services as $ser_id ) {
	        		if ( isset( $ser_qty[$ser_id] ) && absint( $ser_qty[$ser_id] ) ) {
	                    $services_qty[$ser_id] = absint( $ser_qty[$ser_id] );
	                }

	        		if ( ovabrw_array_exists( $serv_ids ) ) {
	        			foreach ( $serv_ids as $i => $ids ) {
	        				$serv_label = isset( $serv_labels[$i] ) ? $serv_labels[$i] : '';

	        				$option_index = array_search( $ser_id, $ids );

	        				if ( is_bool( $option_index ) ) continue;

	        				$serv_name = isset( $serv_names[$i][$option_index] ) ? $serv_names[$i][$option_index] : '';

	        				$service_str .= '<tr>';
                            $service_str .= '<td>'.$serv_label.':</td>';

                            if ( isset( $services_qty[$ser_id] ) && absint( $services_qty[$ser_id] ) ) {
                                $service_str .= '<td>'.$serv_name.' (x'.absint( $services_qty[$ser_id] ).')'.'</td>';
                            } else {
                                $service_str .= '<td>'.$serv_name.'</td>';
                            }

                            $service_str .= '</tr>';
	        			}
	        		}
	        	}
	        }

    		if ( get_option( 'ova_brw_request_booking_form_show_service', 'yes' ) === 'yes' ) {
    			$order_detail .= $service_str;
    		}

	        // Customer note
	        if ( get_option( 'ova_brw_request_booking_form_show_extra_info', 'yes' ) === 'yes' && $customer_note ) {
	        	$order_detail .= '<tr>';
    				$order_detail .= '<td>'.esc_html__( 'Extra: ', 'ova-brw' ).'</td>';
    				$order_detail .= '<td>'.$customer_note.'</td>';
    			$order_detail .= '</tr>';
	        }

        	$order_detail .= '</table>';

        	$body = get_option( 'ova_brw_request_booking_mail_content' );

        	if ( ! $body ) {
        		$body = esc_html__( 'You have hired a vehicle: [ovabrw_vehicle_name] at [ovabrw_order_pickup_date] - [ovabrw_order_pickoff_date]. [ovabrw_order_details]', 'ova-brw' );
        	}

        	// Product link
        	$product_link = '<a href="'.get_permalink($this->ID).'" target="_blank">'.$product_name.'</a>';

        	// Replace body
        	$body = str_replace( '[ovabrw_vehicle_name]', $product_link, $body );
        	$body = str_replace( '[ovabrw_order_pickup_date]', $pickup_date, $body );
        	$body = str_replace( '[ovabrw_order_pickoff_date]', $dropoff_date, $body );
        	$body = str_replace( '[ovabrw_order_details]', $order_detail, $body );

        	// Create Order
        	if ( get_option( 'ova_brw_request_booking_create_order', 'no' ) === 'yes' ) {
        		$order_data = [
        			'customer_name' 		=> $customer_name,
        			'customer_email' 		=> $customer_email,
        			'customer_phone' 		=> $customer_phone,
        			'customer_address' 		=> $customer_address,
        			'customer_note' 		=> $customer_note,
        			'pickup_location' 		=> $pickup_location,
        			'dropoff_location' 		=> $dropoff_location,
        			'pickup_date' 			=> $pickup_date,
        			'dropoff_date' 			=> $dropoff_date,
        			'quantity' 				=> $qty_input,
        			'custom_ckf' 			=> $custom_ckf,
        			'custom_ckf_qty' 		=> $custom_ckf_qty,
        			'custom_ckf_save' 		=> $custom_ckf_save,
        			'resources' 			=> $resources,
        			'resources_qty' 		=> $resource_qty,
        			'ovabrw_service' 		=> $services,
        			'ovabrw_service_qty' 	=> $services_qty,
        		];

	            $order_id = $this->request_booking_create_new_order( $order_data );
	        }

			return apply_filters( 'ovabrw_request_booking_get_mail_body', $body, $data, $this );
		}

		public function request_booking_create_new_order( $data = [] ) {
			if ( ! ovabrw_array_exists( $data ) ) return false;

	        // Validate
	        $new_date = $this->get_strtotime_input_date( strtotime( $data['pickup_date'] ), strtotime( $data['dropoff_date'] ) );

        	// Add Cart item
	        $cart_item = [
	        	'ovabrw_checkin' 			=> $new_date['pickup_date_new'],
	        	'ovabrw_checkout' 			=> $new_date['dropoff_date_new'],
	        	'ovabrw_pickup_loc' 		=> $data['pickup_location'],
	        	'ovabrw_pickoff_loc' 		=> $data['dropoff_location'],
	        	'ovabrw_number_vehicle' 	=> $data['quantity'],
	        	'custom_ckf' 				=> $data['custom_ckf'],
	        	'custom_ckf_qty' 			=> $data['custom_ckf_qty'],
	        	'resources' 				=> $data['resources'],
	        	'resources_qty' 			=> $data['resources_qty'],
	        	'ovabrw_service' 			=> $data['ovabrw_service'],
	        	'ovabrw_service_qty' 		=> $data['ovabrw_service_qty']
	        ];

	        $subtotal 		= ovabrw_convert_price( $this->get_total( $cart_item ) );
	        $order_total 	= $subtotal;
	        $insurance 		= (int)$data['quantity'] * floatval( $this->get_value( 'amount_insurance' ) );
	        if ( $insurance ) {
	        	$insurance = ovabrw_convert_price( $insurance );
	        }

	        // Create Order
	        $args = [
	        	'status'        => '',
	            'customer_note' => $data['customer_note']
	        ];
	        
	        $order      = wc_create_order( $args ); // Create new order
	        $order_id   = $order->get_id(); // Get order id
	        $products   = wc_get_product( $this->ID );

	        // Tax enabled
	        $tax_amount = $tax_rate_id = 0;

	        // Taxable
            $item_taxes = false;

	        if ( wc_tax_enabled() ) {
	        	$tax_rates 	= WC_Tax::get_rates( $products->get_tax_class() );

	        	// Tax rate id
                if ( ! empty( $tax_rates ) ) {
		            $tax_rate_id = key( $tax_rates );
		        }

	        	if ( wc_prices_include_tax() ) {
		        	$taxes 		= WC_Tax::calc_inclusive_tax( $subtotal, $tax_rates );
		        	$tax_amount = WC_Tax::get_tax_total( $taxes );
                    $subtotal 	-= $tax_amount;
	        	} else {
	        		$taxes 		= WC_Tax::calc_exclusive_tax( $subtotal, $tax_rates );
                    $tax_amount = WC_Tax::get_tax_total( $taxes );
                    $order_total += $tax_amount;
	        	}

	        	$item_taxes = [
	        		'total'    => $taxes,
                    'subtotal' => $taxes
	        	];
	        }

	        // Handle items
	        $item_id = $order->add_product( $products, $data['quantity'], [
	        	'totals' => [
	        		'subtotal' 	=> $subtotal,
	                'total' 	=> $subtotal
	        	]
	        ]);

	        // Get order line item
        	$line_item = $order->get_item( $item_id );

	        if ( $line_item ) {
	            $data_item = [];

	            // Rental Type
		        $data_item['rental_type'] 	= $this->type;
		        $data_item['define_day'] 	= $this->get_value( 'define_1_day' );

		        // Pickup & Dropoff locations
		        $data_item['ovabrw_pickup_loc'] 	= $data['pickup_location'];
		        $data_item['ovabrw_pickoff_loc'] 	= $data['dropoff_location'];

		        // Pickup & Dropoff dates
		        $data_item['ovabrw_pickup_date'] 	= $data['pickup_date'];
		        $data_item['ovabrw_pickoff_date'] 	= $data['dropoff_date'];

		        // Pick-up & Drop-off strtotime
		        $data_item['ovabrw_pickup_date_strtotime'] 	= strtotime( $data['pickup_date'] );
		        $data_item['ovabrw_pickoff_date_strtotime'] = strtotime( $data['dropoff_date'] );

		        // Real pickup & dropoff dates
		        $data_item['ovabrw_pickup_date_real'] 	= $data['pickup_date'];
		        $data_item['ovabrw_pickoff_date_real'] 	= $data['dropoff_date'];

		        // Quantity
		        $data_item['ovabrw_number_vehicle'] = $data['quantity'];

		        // Real Quantity & Price
	        	$real_data = $this->get_real_data( strtotime( $data['pickup_date'] ), strtotime( $data['dropoff_date'] ) );
	        	$data_item['ovabrw_total_days'] 	= str_replace( '<br>', ', ', $real_data['real_quantity'] );
	        	$data_item['ovabrw_price_detail'] 	= str_replace( '<br>', ', ', $real_data['real_price'] );

	        	// Custom Checkout Fields
	        	if ( ovabrw_array_exists( $data['custom_ckf'] ) ) {
	                $data_item[ 'ovabrw_custom_ckf' ] = $data['custom_ckf'];

	                if ( ovabrw_array_exists( $data['custom_ckf_qty'] ) ) {
	                	$data_item[ 'ovabrw_custom_ckf_qty' ] = $data['custom_ckf_qty'];
	                }

	                if ( ovabrw_array_exists( $data['custom_ckf_save'] ) ) {
		                foreach ( $data['custom_ckf_save'] as $k => $val ) {
		                    $data_item[$k] = $val;
		                }
		            }
	            }

	            // Resources
		        if ( ovabrw_array_exists( $data['resources'] ) ) {
		            $resources_name = $data['resources'];

		            if ( ovabrw_array_exists( $data['resources_qty'] ) ) {
		                foreach ( $resources_name as $k => $v ) {
		                    if ( isset( $data['resources_qty'][$k] ) && absint( $data['resources_qty'][$k] ) ) {
		                        $resources_name[$k] = $v.' (x'.absint( $data['resources_qty'][$k] ).')';
		                    }
		                }
		            }

		            if ( count( $data['resources'] ) == 1 ) {
		            	$data_item[esc_html__( 'Resource', 'ova-brw' )] = join( ', ', $resources_name );
		            } else {
		            	$data_item[esc_html__( 'Resources', 'ova-brw' )] = join( ', ', $resources_name );
		            }

		            $data_item['ovabrw_resources']      = $data['resources'];
            		$data_item['ovabrw_resources_qty']  = $data['resources_qty'];
		        }

		        // Services
		        if ( ovabrw_array_exists( $data['ovabrw_service'] ) ) {
		        	$services 		= $data['ovabrw_service'];
		        	$services_qty 	= $data['ovabrw_service_qty'];

		        	$data_item['ovabrw_services'] 		= $services;
		        	$data_item['ovabrw_services_qty'] 	= $services_qty;

		        	if ( ovabrw_array_exists( $services ) ) {
		        		$serv_labels 	= $this->get_value( 'label_service', [] );
		        		$serv_ids 		= $this->get_value( 'service_id', [] );
		        		$serv_names 	= $this->get_value( 'service_name', [] );

		        		foreach ( $services as $k ) {
				    		if ( ovabrw_array_exists( $serv_ids ) ) {
				    			$qty = isset( $services_qty[$k] ) ? $services_qty[$k] : '';

				    			foreach ( $serv_ids as $i => $ids ) {
				    				$option_index = array_search( $k, $ids );

				        			if ( is_bool( $option_index ) ) continue;

				        			$name   = isset( $serv_names[$i][$option_index] ) ? $serv_names[$i][$option_index] : '';
	                                $label  = isset( $serv_labels[$i] ) ? $serv_labels[$i] : '';

	                                if ( $qty ) {
	                                    $name .= ' (x'.absint( $qty ).')';
	                                }

	                                $data_item[$label] = $name;
				    			}
				    		}
				    	}
		        	}
		        }

		        // Insurance
		        if ( $insurance ) {
	                $data_item[ 'ovabrw_insurance_amount' ] = $insurance;
	            }

	            // Add item
	            foreach ( $data_item as $meta_key => $meta_value ) {
	                wc_add_order_item_meta( $item_id, $meta_key, $meta_value );
	            }

	            // Update item tax
	            $line_item->set_props([
	            	'taxes' => $item_taxes
	            ]);

	            // Save item
	            $line_item->save();
	        }

	        // Insurace
	        if ( $insurance ) {
	        	// Update order total
        		$order_total += $insurance;

        		// Add insurance amount meta data
	        	$order->add_meta_data( '_ova_insurance_amount', $insurance, true );

	        	// Get insurance name
	        	$insurance_name = OVABRW()->options->get_insurance_name();

	        	// Add item fee
	        	$item_fee = new WC_Order_Item_Fee();
                $item_fee->set_props([
                	'name'      => $insurance_name,
                    'tax_class' => 0,
                    'total'     => $insurance,
                    'order_id'  => $order_id
                ]);

                $item_fee->save();

                $order->add_item( $item_fee );

                $order->add_meta_data( '_ova_insurance_key', sanitize_title( $insurance_name ), true );
	        }

	        // Set order tax
	        if ( wc_tax_enabled() && $tax_amount ) {
	        	// Init order item tax
	            $item_tax = new WC_Order_Item_Tax();

	            $item_tax->set_props([
	            	'rate_id'            => $tax_rate_id,
	                'tax_total'          => $tax_amount,
	                'shipping_tax_total' => 0,
	                'rate_code'          => WC_Tax::get_rate_code( $tax_rate_id ),
	                'label'              => WC_Tax::get_rate_label( $tax_rate_id ),
	                'compound'           => WC_Tax::is_compound( $tax_rate_id ),
	                'rate_percent'       => WC_Tax::get_rate_percent_value( $tax_rate_id )
	            ]);

	            $item_tax->save();
	            $order->add_item( $item_tax );
	            $order->set_cart_tax( $tax_amount );
	        }

	        // Address
	        $billing = [
	        	'first_name' => $data['customer_name'],
                'last_name'  => '',
                'company'    => '',
                'email'      => $data['customer_email'],
                'phone'      => $data['customer_phone'],
                'address_1'  => $data['customer_address'],
                'address_2'  => '',
                'city'       => '',
                'country'    => '',
	        ];

	        // Set address
	        $order->set_address( $billing, 'billing' );

	        // Set customer
            $user = get_user_by( 'email', $data['customer_email'] );
            if ( $user ) {
                $order->set_customer_id( $user->ID );
            }

	        // Set Order Status
	        $status_order = get_option( 'ova_brw_request_booking_order_status', 'wc-on-hold' );
	        $order->set_status( $status_order );

	        // Set date created
	        $order->set_date_created( date( 'Y-m-d H:i:s', current_time( 'timestamp' ) ) );

	        // Set total
	        $order->set_total( $order_total );

	        // Save
	        $order->save();
	        
	        return apply_filters( 'ovabrw_request_booking_create_new_order', $order_id, $data, $this );
		}
		// End

		public static function instance() {
			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self();
			}

			return self::$_instance;
		}
	}
}