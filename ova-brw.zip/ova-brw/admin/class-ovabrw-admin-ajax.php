<?php defined( 'ABSPATH' ) || exit();

if ( ! class_exists( 'OVABRW_Admin_Ajax' ) ) {
	class OVABRW_Admin_Ajax {
		public function __construct() {
			$this->init();
		}

		public function init() {
			// Define All Ajax function
			$arr_ajax = [
				'update_order_status_woo',
				'get_custom_tax_in_cat',
				'update_cckf',
				'update_custom_taxonomies',
				'change_rental_type',
				'load_data_product_create_order',
				'get_total_price_and_quantity',
				'get_packages',
				'add_specification',
				'edit_specification',
				'delete_specification',
				'sort_specifications',
				'enable_specification',
				'disable_specification',
				'change_type_specification',
				'update_insurance'
			];

			foreach ( $arr_ajax as $name ) {
				add_action( 'wp_ajax_'.OVABRW_PREFIX.$name, array( $this, OVABRW_PREFIX.$name ) );
				add_action( 'wp_ajax_nopriv_'.OVABRW_PREFIX.$name, array( $this, OVABRW_PREFIX.$name ) );
			}
		}

		/**
		 * Schedule Ajax
		 */
		public function ovabrw_update_order_status_woo() {
			// Check security
            check_admin_referer( 'ovabrw-security-ajax', 'security' );

			$order_id 		= sanitize_text_field( ovabrw_get_meta_data( 'order_id', $_POST ) );
			$order_status 	= sanitize_text_field( ovabrw_get_meta_data( 'new_order_status', $_POST ) );

			if ( $order_id && $order_status ) {
				$order = wc_get_order( $order_id );

				if ( !current_user_can( apply_filters( 'ovabrw_update_order_status' ,'publish_posts' ) ) ) {
					echo 'error_permission';	
				} elseif ( $order->update_status( $order_status ) ) {
					echo 'true';
				} else {
					echo 'false';
				}
			} else {
				echo 'false';
			}
			
			wp_die();
		}

		/**
		 * Get Custom Taxonomy choosed in Category
		 */
		public function ovabrw_get_custom_tax_in_cat() {
			// Check security
            check_admin_referer( 'ovabrw-security-ajax', 'security' );

			$term_ids 	= ovabrw_get_meta_data( 'term_ids', $_POST );
			$taxonomies = [];
			
			if ( ovabrw_array_exists( $term_ids ) ) {
				foreach ( $term_ids as $term_id ) {
					$custom_tax = get_term_meta( $term_id, 'ovabrw_custom_tax', true );
					
					if ( $custom_tax ) {
						foreach ( $custom_tax as $slug ) {
							if ( $slug && !in_array( $slug, $taxonomies ) ) {
								array_push( $taxonomies, $slug );
							}
						}
					}
				}
			}
			
			echo implode(",", $taxonomies ); 
			wp_die();
		}

		/**
		 * Update custom checkout fields when sortable
		 */
		public function ovabrw_update_cckf() {
			// Check security
            check_admin_referer( 'ovabrw-security-ajax', 'security' );

            // Get fields
			$fields = ovabrw_get_meta_data( 'fields', $_POST );

			if ( ovabrw_array_exists( $fields ) ) {
				$new_fields 	= [];
				$list_fields 	= ovabrw_recursive_replace( '\\', '', get_option( 'ovabrw_booking_form', array() ) );

				foreach ( $fields as $field ) {
                    if ( !empty( $field ) && array_key_exists( $field, $list_fields ) ) {
                        $new_fields[$field] = $list_fields[$field];
                    }
                }

                if ( ovabrw_array_exists( $new_fields ) ) {
                    $list_fields = $new_fields;
                }

                update_option( 'ovabrw_booking_form', $list_fields );
			}

			wp_die();
		}

		/**
		 * Update custom taxonomies when sortable
		 */
		public function ovabrw_update_custom_taxonomies() {
			// Check security
            check_admin_referer( 'ovabrw-security-ajax', 'security' );

            // Get fields
			$fields = ovabrw_get_meta_data( 'fields', $_POST );

			if ( ovabrw_array_exists( $fields ) ) {
				$new_fields 	= [];
				$list_fields 	= ovabrw_recursive_replace( '\\', '', get_option( 'ovabrw_custom_taxonomy', array() ) );

				foreach ( $fields as $field ) {
                    if ( !empty( $field ) && array_key_exists( $field, $list_fields ) ) {
                        $new_fields[$field] = $list_fields[$field];
                    }
                }

                if ( ovabrw_array_exists( $new_fields ) ) {
                    $list_fields = $new_fields;
                }

                update_option( 'ovabrw_custom_taxonomy', $list_fields );
			}

			wp_die();
		}

		// Change Rental Type
		public function ovabrw_change_rental_type() {
			// Check security
            check_admin_referer( 'ovabrw-security-ajax', 'security' );

            // Product ID
			$product_id = ovabrw_get_meta_data( 'product_id', $_POST );
			if ( !$product_id ) wp_die();

			// Rental type
			$type = ovabrw_get_meta_data( 'rental_type', $_POST );

			// Get rental object
			$rental_object 	= isset( OVABRW_Admin_Meta_Boxes::instance()->rental_types[$type] ) ? OVABRW_Admin_Meta_Boxes::instance()->rental_types[$type] : '';

			if ( $rental_object && is_object( $rental_object ) ) {
				$rental_object->set_ID( $product_id );
				echo $rental_object->get_html();
			}

			wp_die();
		}

		public function ovabrw_load_data_product_create_order() {
			// Check security
            check_admin_referer( 'ovabrw-security-ajax', 'security' );

            // Product ID
			$product_id = trim( sanitize_text_field( ovabrw_get_meta_data( 'product_id', $_POST ) ) );
			if ( !$product_id ) wp_die();

			// Currency
			$currency = sanitize_text_field( ovabrw_get_meta_data( 'currency', $_POST ) );

			// Rental type
			$type 		= ovabrw_get_post_meta( $product_id, 'price_type' );
			$rental_obj = isset( OVABRW_Admin_Meta_Boxes::instance()->rental_types[$type] ) ? OVABRW_Admin_Meta_Boxes::instance()->rental_types[$type] : '';

			if ( $rental_obj && is_object( $rental_obj ) ) {
				$rental_obj->set_ID( $product_id );
				$order_time = OVABRW()->options->get_booked_dates( $product_id );

				echo $rental_obj->create_order_get_meta_boxes_html([
					'currency' 		=> $currency,
					'order_time' 	=> json_encode( $order_time )
				]);
			}

			wp_die();
		}

		public function ovabrw_get_total_price_and_quantity() {
			// Check security
            check_admin_referer( 'ovabrw-security-ajax', 'security' );

			// Set data
			$data = $_POST;
			if ( !ovabrw_array_exists( $data ) ) wp_die();

			// Product ID
			$product_id = ovabrw_get_meta_data( 'product_id', $data );

			// Currency
			$currency = sanitize_text_field( ovabrw_get_meta_data( 'currency', $data ) );

			// Pick-up location
			$pickup_location = sanitize_text_field( ovabrw_get_meta_data( 'pickup_location', $data ) );

			// Drop-off location
			$dropoff_location = sanitize_text_field( ovabrw_get_meta_data( 'dropoff_location', $data ) );

			// Taxi pick-up location
			$pickup_taxi_location = sanitize_text_field( ovabrw_get_meta_data( 'pickup_taxi_location', $data ) );
			if ( $pickup_taxi_location ) {
				$data['pickup_loc'] = $pickup_taxi_location;
			}

			// Taxi drop-off location
			$dropoff_taxi_location = sanitize_text_field( ovabrw_get_meta_data( 'dropoff_taxi_location', $data ) );
			if ( $dropoff_taxi_location ) {
				$data['dropoff_loc'] = $dropoff_taxi_location;
			}

			// Pick-up date
			$pickup_date = sanitize_text_field( ovabrw_get_meta_data( 'pickup_date', $data ) );

			// Drop-off date
			$dropoff_date = sanitize_text_field( ovabrw_get_meta_data( 'dropoff_date', $data ) );

			// Package ID
			$package_id = sanitize_text_field( ovabrw_get_meta_data( 'package_id', $data ) );

			// Quantity
			$quantity = (int)ovabrw_get_meta_data( 'quantity', $data, 1 );

			// Vehicle ID
			$vehicle_id = sanitize_text_field( ovabrw_get_meta_data( 'vehicle_id', $data ) );

			// Extra time
			$extra_time = sanitize_text_field( ovabrw_get_meta_data( 'extra_time', $data ) );

			// Duration map
			$duration_map = sanitize_text_field( ovabrw_get_meta_data( 'duration_map', $data ) );

			// Duration
			$duration = sanitize_text_field( ovabrw_get_meta_data( 'duration', $data ) );

			// Distance
			$distance = sanitize_text_field( ovabrw_get_meta_data( 'distance', $data ) );

			// Custom Checkout Fields
			$custom_ckf 	= isset( $data['custom_ckf'] ) ? str_replace( '\\', '', $data['custom_ckf'] ) : '';
			$custom_ckf 	= (array) json_decode( $custom_ckf );
			$custom_ckf_qty = isset( $data['custom_ckf_qty'] ) ? str_replace( '\\', '', $data['custom_ckf_qty'] ) : '';
			$custom_ckf_qty = (array) json_decode( $custom_ckf_qty );

			// Resources
			$resources 		= isset( $data['resources'] ) ? str_replace( '\\', '', $data['resources'] ) : '';
			$resources 		= (array)json_decode( $resources );
			$resources_qty 	= isset( $data['resources_qty'] ) ? str_replace( '\\', '', $data['resources_qty'] ) : [];
			$resources_qty 	= (array)json_decode( $resources_qty );

			// Services
			$services 		= isset( $data['services'] ) ? str_replace( '\\', '', $data['services'] ) : '';
			$services 		= (array)json_decode( $services );
			$services_qty 	= isset( $data['services_qty'] ) ? str_replace( '\\', '', $data['services_qty'] ) : '';
			$services_qty 	= (array)json_decode( $services_qty );

			// Get rental type product
			$type = get_post_meta( $product_id, 'ovabrw_price_type', true );

			// Object Rental Types
        	$rental_object = isset( OVABRW_Rental_Types::instance()->rental_types[$type] ) ? OVABRW_Rental_Types::instance()->rental_types[$type] : '';

        	if ( empty( $rental_object ) || ! is_object( $rental_object ) ) {
        		echo 0;
				wp_die();
        	}

        	// Set Product ID
        	$rental_object->set_ID( $product_id );

        	$new_date = [
        		'pickup_date_new' 	=> '',
        		'dropoff_date_new' 	=> '',
        	];

        	switch ( $type ) {
        		case 'day':
        			$new_date = $rental_object->get_strtotime_input_date( strtotime( $pickup_date ), strtotime( $dropoff_date ) );
        			break;
        		case 'hour':
        			$new_date = $rental_object->get_strtotime_input_date( strtotime( $pickup_date ), strtotime( $dropoff_date ) );
        			break;
        		case 'mixed':
        			$new_date = $rental_object->get_strtotime_input_date( strtotime( $pickup_date ), strtotime( $dropoff_date ) );
        			break;
        		case 'period_time':
        			$new_date = $rental_object->get_strtotime_input_date( strtotime( $pickup_date ), $package_id );
        			break;
        		case 'transportation':
        			$new_date = $rental_object->get_strtotime_input_date( strtotime( $pickup_date ), strtotime( $dropoff_date ), $pickup_location, $dropoff_location );
        			break;
        		case 'taxi':
        			$pickup_location 	= $pickup_taxi_location;
        			$dropoff_location 	= $dropoff_taxi_location;

        			$new_date = $rental_object->get_strtotime_input_date( $pickup_date, $duration );
        			break;
        		case 'hotel':
        			$new_date = $rental_object->get_strtotime_input_date( strtotime( $pickup_date ), strtotime( $dropoff_date ) );
        		case 'appointment':
        			$new_date = $rental_object->get_strtotime_input_date( strtotime( $pickup_date ), strtotime( $dropoff_date ) );
        			break;
        		default:
        			break;
        	}

			// Ajax Validation Booking
			$validation_booking = $rental_object->ovabrw_ajax_validation_booking( $new_date['pickup_date_new'], $new_date['dropoff_date_new'], $data );

			if ( $validation_booking ) {
				$total['error'] = $validation_booking;
				echo json_encode( $total ); wp_die();
			}

			// Check available quantity
			if ( $vehicle_id ) {
				$vehicle_available = $rental_object->get_vehicle_available( $new_date['pickup_date_new'], $new_date['dropoff_date_new'], $pickup_location, $dropoff_location, 'check' );
				
				if ( ovabrw_array_exists( $vehicle_available ) ) {
					if ( ! in_array( $vehicle_id, $vehicle_available ) ) {
						$total['error'] = sprintf( esc_html__( 'Vehicle ID: %s is not available!', 'ova-brw' ), $vehicle_id );
						echo json_encode( $total ); wp_die();
					}

					$qty_available = count( $vehicle_available );
				} else {
					$total['error'] = esc_html__( 'Out stock!', 'ova-brw' );
					echo json_encode( $total ); wp_die();
				}
			} else {
				$data_available = $rental_object->get_qty_available( $new_date['pickup_date_new'], $new_date['dropoff_date_new'], $pickup_location, $dropoff_location, 'check' );
		        $qty_available 	= $data_available['qty_available'];

		        if ( $quantity > $qty_available ) {
		        	if ( $qty_available > 0 ) {
		        		$total['error'] = sprintf( esc_html__( 'Available vehicle is %s', 'ova-brw'  ), $qty_available );
		        	} else {
		        		$total['error'] = esc_html__( 'Out stock!', 'ova-brw' );
		        	}

	                echo json_encode( $total ); wp_die();
		        }
			}

	        // Qty available
		    $total['number_vehicle_available'] = $qty_available;

	        // Add Cart item
	        $cart_item = [
	        	'ovabrw_checkin' 			=> $new_date['pickup_date_new'],
	        	'ovabrw_checkout' 			=> $new_date['dropoff_date_new'],
	        	'ovabrw_pickup_loc' 		=> $pickup_location,
	        	'ovabrw_pickoff_loc' 		=> $dropoff_location,
	        	'package_id' 				=> $package_id,
	        	'ovabrw_number_vehicle' 	=> $quantity,
	        	'custom_ckf' 				=> $custom_ckf,
	        	'custom_ckf_qty' 			=> $custom_ckf_qty,
	        	'resources' 				=> $resources,
	        	'resources_qty' 			=> $resources_qty,
	        	'ovabrw_service' 			=> $services,
	        	'ovabrw_service_qty' 		=> $services_qty,
	        	'duration_map' 				=> $duration_map,
	        	'duration' 					=> $duration,
	        	'distance' 					=> $distance,
	        	'extra_time' 				=> $extra_time,
	        ];

			$line_total = $rental_object->get_total( $cart_item );
			$insurance 	= floatval( $rental_object->get_value( 'amount_insurance' ) ) * $quantity;

			// Multi Currency
        	if ( is_plugin_active( 'woocommerce-multilingual/wpml-woocommerce.php' ) ) {
                $line_total = ovabrw_convert_price( $line_total );
                $insurance 	= ovabrw_convert_price( $insurance );
            }

            // Insurance Amount
            $total['amount_insurance'] = $insurance;
            $line_total += $insurance;
			
			if ( $line_total < 0 ) {
				echo 0;	
			} else {
				$total['line_total'] = round( ovabrw_convert_price( $line_total, [ 'currency' => $currency ] ), wc_get_price_decimals() );
			}

			echo json_encode( $total );
			wp_die();
		}

		public function ovabrw_get_packages() {
			// Check security
			check_admin_referer( 'ovabrw-security-ajax', 'security' );

			// Product ID
			$product_id = sanitize_text_field( ovabrw_get_meta_data( 'product_id', $_POST ) );

			// Pick-up date
			$pickup_date = strtotime( ovabrw_get_meta_data( 'pickup_date', $_POST ) );

			// Pick-up location
			$pickup_location = sanitize_text_field( ovabrw_get_meta_data( 'pickup_location', $_POST ) );

			// Drop-off location
			$dropoff_location = sanitize_text_field( ovabrw_get_meta_data( 'dropoff_location', $_POST ) );
			

			if ( !$product_id || !$pickup_date ) {
				wp_die();
			}

			$rental_type 	= get_post_meta( $product_id, 'ovabrw_price_type', true );
			$rental_object 	= isset( OVABRW_Rental_Types::instance()->rental_types[$rental_type] ) ? OVABRW_Rental_Types::instance()->rental_types[$rental_type] : '';

        	if ( empty( $rental_object ) || !is_object( $rental_object ) ) {
				wp_die();
        	}

        	// Set Product ID
        	$rental_object->set_ID( $product_id );

        	$packages = [];

        	// Get Data
        	$package_ids 	= $rental_object->get_value( 'petime_id', [] );
			$package_labels = $rental_object->get_value( 'petime_label', [] );

			if ( ovabrw_array_exists( $package_ids ) ) {
				foreach ( $package_ids as $k => $package_id ) {
					$label 		= ovabrw_get_meta_data( $k, $package_labels );
					$new_date 	= $rental_object->get_strtotime_input_date( $pickup_date, $package_id );

					if ( !$new_date['pickup_date_new'] || !$new_date['dropoff_date_new'] ) continue;

					// Check available quantity
			        $data_available = $rental_object->get_qty_available( $new_date['pickup_date_new'], $new_date['dropoff_date_new'], $pickup_location, $dropoff_location, 'seach' );
			        $qty_available 	= $data_available['qty_available'];

			        if ( $qty_available > 0 ) {
			        	$packages[$package_id] = $label;
			        }
				}
			}

			if ( empty( $packages ) || count( $packages ) < 1 ) {
				$packages = array( esc_html__( 'There are no packages', 'ova-brw' ) );
			}
			
			echo json_encode( $packages );
			wp_die();
		}

		// Add new specification
		public function ovabrw_add_specification() {
			// Check security
            check_admin_referer( 'ovabrw-security-ajax', 'security' );

			ob_start();

			// include html add new
			OVABRW_Admin_Specifications::instance()->ovavbrw_popup_specification_field();
			$html = ob_get_contents();

			ob_clean();

			echo $html;

			wp_die();
		}

		// Edit specification
		public function ovabrw_edit_specification() {
			// Check security
            check_admin_referer( 'ovabrw-security-ajax', 'security' );

			$name = ovabrw_get_meta_data( 'name', $_POST );
			$type = ovabrw_get_meta_data( 'type', $_POST );

			if ( !$name || !$type ) wp_die();

			ob_start();

			// include html add new
			OVABRW_Admin_Specifications::instance()->ovavbrw_popup_specification_field( 'edit', $type, $name );
			$html = ob_get_contents();

			ob_clean();

			echo $html;

			wp_die();
		}

		// Delete specification
		public function ovabrw_delete_specification() {
			// Check security
            check_admin_referer( 'ovabrw-security-ajax', 'security' );

			$name = ovabrw_get_meta_data( 'name', $_POST );

			if ( !$name ) wp_die();

			$post['fields'] = [ $name ];

			OVABRW_Admin_Specifications::instance()->delete( $post );

			echo 1;
			wp_die();
		}

		// Sort specifications
		public function ovabrw_sort_specifications() {
			// Check security
            check_admin_referer( 'ovabrw-security-ajax', 'security' );

			OVABRW_Admin_Specifications::instance()->sort( $_POST ); wp_die();
		}

		// Enable specification
		public function ovabrw_enable_specification() {
			// Check security
            check_admin_referer( 'ovabrw-security-ajax', 'security' );

			$name = ovabrw_get_meta_data( 'name', $_POST );

			if ( !$name ) wp_die();

			OVABRW_Admin_Specifications::instance()->enable([
				'fields' => [ $name ]
			]);

			echo 1;
			wp_die();
		}

		// Disable specification
		public function ovabrw_disable_specification() {
			// Check security
            check_admin_referer( 'ovabrw-security-ajax', 'security' );

			$name = ovabrw_get_meta_data( 'name', $_POST );

			if ( !$name ) wp_die();

			OVABRW_Admin_Specifications::instance()->disable([
				'fields' => [ $name ]
			]);

			echo 1;
			wp_die();
		}

		// Change type specification
		public function ovabrw_change_type_specification() {
			// Check security
            check_admin_referer( 'ovabrw-security-ajax', 'security' );

            // Get type
			$type = ovabrw_get_meta_data( 'type', $_POST );

			if ( !$type ) wp_die();

			ob_start();

			// include html add new
			OVABRW_Admin_Specifications::instance()->ovavbrw_popup_specification_field( 'new', $type );
			$html = ob_get_contents();

			ob_clean();

			echo $html;

			wp_die();
		}

		// Update insurance amount
		public function ovabrw_update_insurance() {
			// Check security
            check_admin_referer( 'ovabrw-security-ajax', 'security' );

			$order_id 	= (int)ovabrw_get_meta_data( 'order_id', $_POST );
			$item_id 	= (int)ovabrw_get_meta_data( 'item_id', $_POST );
			$amount 	= floatval( ovabrw_get_meta_data( 'amount', $_POST ) );
			$tax 		= floatval( ovabrw_get_meta_data( 'tax', $_POST ) );

			if ( !$order_id || !$item_id || $amount < 0 || $tax < 0 ) wp_die();

			$order = wc_get_order( $order_id );
            if ( !$order ) wp_die();

			$item = WC_Order_Factory::get_order_item( absint( $item_id ) );
            if ( !$item ) wp_die();

            // Insurance key
           	$insurance_key = $order->get_meta( '_ova_insurance_key' );

            // Total insurance
            $order_insurance 		= floatval( $order->get_meta( '_ova_insurance_amount' ) );
            $order_insurance_tax 	= floatval( $order->get_meta( '_ova_insurance_tax' ) );

            // Item insurance
            $item_insurance = floatval( $item->get_meta( 'ovabrw_insurance_amount' ) );

            // Item insurance tax
            $item_insurance_tax = floatval( $item->get_meta( 'ovabrw_insurance_tax' ) );

            // Original order and item
            $original_order 	= $original_item = false;
            $original_item_id 	= $order->get_meta( '_ova_original_item_id' );

            if ( absint( $original_item_id ) ) {
            	$original_item = WC_Order_Factory::get_order_item( absint( $original_item_id ) );

            	if ( $original_item ) {
            		$original_order = $original_item->get_order();
            	}
            }

            // Get fees
            $fees = $order->get_fees();
            
            // Update order insurance amount
            if ( ! empty( $fees ) && is_array( $fees ) ) {
            	foreach ( $fees as $item_fee_id => $item_fee ) {
            		$fee_key = sanitize_title( $item_fee->get_name() );

            		if ( $fee_key === $insurance_key ) {
            			$order_insurance -= $item_insurance;
            			$order_insurance += $amount;

            			$order_insurance_tax -= $item_insurance_tax;
            			$order_insurance_tax += $tax;

            			if ( $order_insurance < 0 ) $order_insurance = 0;
            			if ( $order_insurance_tax < 0 ) $order_insurance_tax = 0;

            			// Update item fee
            			if ( wc_tax_enabled() ) {
                            $order_taxes = $order->get_taxes();
                            $tax_item_id = 0;

                            foreach ( $order_taxes as $tax_item ) {
                                $tax_item_id = $tax_item->get_rate_id();

                                if ( $tax_item_id ) break;
                            }

                            $item_fee->set_props(
								array(
									'total'     => $order_insurance,
									'subtotal'  => $order_insurance,
									'total_tax' => $order_insurance_tax,
									'taxes'     => array(
										'total' => array( $tax_item_id => $order_insurance_tax ),
									),
								)
							);

                            // Update original item
                            if ( $original_item ) {
                            	// Get original item remaining insurance amount
                            	$item_remaining_insurance = floatval( $original_item->get_meta( 'ovabrw_remaining_insurance' ) );

                            	// Get original item remaining insurance tax amount
                            	$item_remaining_insurance_tax = floatval( $original_item->get_meta( 'ovabrw_remaining_insurance_tax' ) );

                            	// Update original item meta data
                            	$original_item->update_meta_data( 'ovabrw_remaining_insurance', $order_insurance );
                            	$original_item->update_meta_data( 'ovabrw_remaining_insurance_tax', $order_insurance_tax );
                            	$original_item->save();

                            	// Update original order
	                            if ( $original_order ) {
	                            	// Get original order remaining insurance amount
	                            	$order_remaining_insurance = floatval( $original_order->get_meta( '_ova_remaining_insurance' ) );
	                            	$order_remaining_insurance -= $item_remaining_insurance;
	                            	$order_remaining_insurance += $order_insurance;

	                            	// Get original order remaining insurance tax amount
	                            	$order_remaining_insurance_tax = floatval( $original_order->get_meta( '_ova_remaining_insurance_tax' ) );
	                            	$order_remaining_insurance_tax -= $item_remaining_insurance_tax;
	                            	$order_remaining_insurance_tax += $order_insurance_tax;

	                            	// Update original order meta data
	                            	$original_order->update_meta_data( '_ova_remaining_insurance', $order_remaining_insurance );
	                            	$original_order->update_meta_data( '_ova_remaining_insurance_tax', $order_remaining_insurance_tax );
	                            	$original_order->save();
	                            }
                            }
            			} else {
            				$item_fee->set_props(
								array(
									'total'     => $order_insurance,
									'subtotal'  => $order_insurance
								)
							);

							// Update original order and item
                            if ( $original_item ) {
                            	// Get original item remaining insurance amount
                            	$item_remaining_insurance = floatval( $original_item->get_meta( 'ovabrw_remaining_insurance' ) );

                            	// Update original item meta data
                            	$original_item->update_meta_data( 'ovabrw_remaining_insurance', $order_insurance );
                            	$original_item->save();

                            	// Update original order
	                            if ( $original_order ) {
	                            	// Get original order remaining insurance amount
	                            	$order_remaining_insurance = floatval( $original_order->get_meta( '_ova_remaining_insurance' ) );
	                            	$order_remaining_insurance -= $item_remaining_insurance;
	                            	$order_remaining_insurance += $order_insurance;

	                            	// Update original order meta data
	                            	$original_order->update_meta_data( '_ova_remaining_insurance', $order_remaining_insurance );
	                            	$original_order->save();
	                            }
                            }
            			}

            			$item_fee->set_amount( $order_insurance );
            			$item_fee->save();

            			// Update item insurance
        				$item->update_meta_data( 'ovabrw_insurance_amount', $amount );
        				$item->update_meta_data( 'ovabrw_insurance_tax', $tax );
        				$item->save();

        				// Update order insurance
        				$order->update_meta_data( '_ova_insurance_amount', $order_insurance );
        				$order->update_meta_data( '_ova_insurance_tax', $order_insurance_tax );
        				$order->update_taxes();
        				$order->calculate_totals( false );
            		}
            	}
            }

            wp_die();
		}
	}

	new OVABRW_Admin_Ajax();
}