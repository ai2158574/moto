<?php if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'OVABRW_Admin_Meta_Boxes', false ) ) {
	class OVABRW_Admin_Meta_Boxes {
		protected static $_instance = null;
		public $rental_types = [];

		public function __construct() {
			// Add product type: Rental
			add_filter( 'product_type_selector', array( $this, 'ovabrw_product_type_selector' ) );

			// Add new product - default tour product
			add_filter( 'woocommerce_product_type_query', array( $this, 'ovabrw_product_type_query' ), 10, 2 );

			// Load rental types files
			ovabrw_autoload( OVABRW_PLUGIN_PATH .'admin/meta-boxes/rental-types/class-ovabrw-admin-rental-by-*.php' );

			// Init rental types
			$this->init();
		}

		/**
		 * Add tour product type to the dropdown
		 * @param  array $product_types
		 * @return array $product_types
		 */
		public function ovabrw_product_type_selector( $product_types ) {
			$product_types[OVABRW_RENTAL] = esc_html__( 'Rental', 'ova-brw' );

	        return $product_types;
		}

		/**
		 * @param  string $product_type
		 * @param  int $product_id
		 * @return string
		 */
		public function ovabrw_product_type_query( $product_type, $product_id ) {
			global $pagenow, $post_type;

		    if ( $pagenow == 'post-new.php' && $post_type == 'product' ) {
		        return OVABRW_RENTAL;
		    }

		    return $product_type;
		}

		/**
		 * Init rental types
		 */
		public function init() {
			$this->rental_types['day'] 				= new OVABRW_Admin_Rental_By_Day();
			$this->rental_types['hour'] 			= new OVABRW_Admin_Rental_By_Hour();
			$this->rental_types['mixed'] 			= new OVABRW_Admin_Rental_By_Mixed();
			$this->rental_types['period_time'] 		= new OVABRW_Admin_Rental_By_Period_Time();
			$this->rental_types['transportation'] 	= new OVABRW_Admin_Rental_By_Transportation();
			$this->rental_types['taxi'] 			= new OVABRW_Admin_Rental_By_Taxi();
			$this->rental_types['hotel'] 			= new OVABRW_Admin_Rental_By_Hotel();
			$this->rental_types['appointment'] 		= new OVABRW_Admin_Rental_By_Appointment();
		}

		/**
		 * Get rental product IDs
		 */
		public function get_rental_product_ids() {
			$args = array(
	            'post_type'         => 'product',
	            'post_status' 		=> 'publish',
	            'posts_per_page' 	=> '-1',
	            'fields'            => 'ids',
	            'tax_query' 		=> array(
	                array(
	                    'taxonomy' => 'product_type',
	                    'field'    => 'slug',
	                    'terms'    => 'ovabrw_car_rental', 
	                ),
	            ),
	        );

	        $product_ids = get_posts( $args );

	        return apply_filters( 'ovabrw_get_rental_product_ids', $product_ids );
		}

		public static function instance() {
			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self();
			}

			return self::$_instance;
		}
	}

	new OVABRW_Admin_Meta_Boxes();
}