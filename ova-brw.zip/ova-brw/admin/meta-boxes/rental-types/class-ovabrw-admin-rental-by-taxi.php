<?php if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'OVABRW_Admin_Rental_By_Taxi', false ) ) {
	class OVABRW_Admin_Rental_By_Taxi extends OVABRW_Abstract_Admin_Rental_Types {
		protected static $_instance = null;

		/**
		 * Construct
		 */
		public function __construct() {
			$this->ID 		= '';
			$this->type 	= 'taxi';
			$this->title 	= esc_html__( 'Taxi', 'ova-brw' );
			$this->prefix 	= OVABRW_PREFIX;

			parent::__construct();
		}

		/**
		 * Get fields
		 */
		public function get_fields() {
			return apply_filters( "ovabrw_rental_by_{$this->type}_get_fields", array(
				'rental-type',
				'regular-price',
				'amount-insurance',
				'taxi-guests',
				'deposit',
				'inventory',
				'setup-map',
				'specifications',
				'features',
				'resources',
				'services',
				'unavailable-time',
				'advanced-options',
				'custom-checkout-fields',
				'show-quantity',
				'pickup-date',
				'extra-tab',
				'frontend-order',
				'map'
			));
		}

		/**
		 * Output fields - Create order
		 */
		public function create_order_get_meta_boxes_html( $args = [] ) {
			ob_start();
			include( OVABRW_PLUGIN_PATH.'admin/orders/views/html-create-order-rental-taxi.php' );
			return ob_get_clean();
		}

		/**
		 * Get price HTML
		 */
		public function get_price_html( $currency = '' ) {
			$price 		= $this->get_value( 'regul_price_taxi' );
			$price_by 	= $this->get_value( 'map_price_by' );

			if ( ! $price_by ) $price_by = 'km';

			if ( $price_by === 'km' ) {
				return sprintf( esc_html__( '%s / Km', 'ova-brw' ), ovabrw_wc_price( $price, ['currency' => $currency] ) );
			} else {
				return sprintf( esc_html__( '%s / Mi', 'ova-brw' ), ovabrw_wc_price( $price, ['currency' => $currency] ) );
			}
		}

		/**
		 * instance
		 */
		public static function instance() {
			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self();
			}

			return self::$_instance;
		}
	}
}