<?php if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'OVABRW_Admin_Rental_By_Day', false ) ) {
	class OVABRW_Admin_Rental_By_Day extends OVABRW_Abstract_Admin_Rental_Types {
		protected static $_instance = null;

		/**
		 * Construct
		 */
		public function __construct() {
			$this->ID 		= '';
			$this->type 	= 'day';
			$this->title 	= esc_html__( 'Day', 'ova-brw' );
			$this->prefix 	= OVABRW_PREFIX;

			parent::__construct();
		}

		/**
		 * Get fields
		 */
		public function get_fields() {
			return apply_filters( "ovabrw_rental_by_{$this->type}_get_fields", array(
				'rental-type',
				'regular-price',
				'define-day',
				'amount-insurance',
				'deposit',
				'inventory',
				'daily-price',
				'choose-location',
				'specifications',
				'features',
				'global-discount',
				'special-time',
				'resources',
				'services',
				'unavailable-time',
				'advanced-options',
				'custom-checkout-fields',
				'show-quantity',
				'pickup-date',
				'dropoff-date',
				'pickup-location',
				'dropoff-location',
				'extra-tab',
				'frontend-order',
				'map'
			));
		}

		/**
		 * Output fields - Create order
		 */
		public function create_order_get_meta_boxes_html( $args = [] ) {
			ob_start();
			include( OVABRW_PLUGIN_PATH.'admin/orders/views/html-create-order-rental-day.php' );
			return ob_get_clean();
		}

		/**
		 * Get price HTML
		 */
		public function get_price_html( $currency = '' ) {
			$price = floatval( $this->get_value( 'regular_price_day' ) );
			if ( ! $price ) $price = floatval( get_post_meta( $this->get_id(), '_regular_price', true ) );

			return sprintf( esc_html__( '%s / Day', 'ova-brw' ), ovabrw_wc_price( $price, ['currency' => $currency] ) );
		}

		/**
		 * instance
		 */
		public static function instance() {
			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self();
			}

			return self::$_instance;
		}
	}
}