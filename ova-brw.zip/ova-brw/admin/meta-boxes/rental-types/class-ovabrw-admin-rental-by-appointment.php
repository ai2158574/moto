<?php if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'OVABRW_Admin_Rental_By_Appointment', false ) ) {
	class OVABRW_Admin_Rental_By_Appointment extends OVABRW_Abstract_Admin_Rental_Types {
		protected static $_instance = null;

		/**
		 * Construct
		 */
		public function __construct() {
			$this->ID 		= '';
			$this->type 	= 'appointment';
			$this->title 	= esc_html__( 'Appointment', 'ova-brw' );
			$this->prefix 	= OVABRW_PREFIX;

			parent::__construct();
		}

		/**
		 * Get fields
		 */
		public function get_fields() {
			return apply_filters( "ovabrw_rental_by_{$this->type}_get_fields", array(
				'rental-type',
				'regular-price',
				'amount-insurance',
				'time-slots',
				'deposit',
				'specifications',
				'features',
				'appointment-special-time',
				'resources',
				'services',
				'unavailable-time',
				'advanced-options',
				'custom-checkout-fields',
				'show-quantity',
				'pickup-date',
				'dropoff-date',
				'extra-tab',
				'frontend-order',
				'map'
			));
		}

		/**
		 * Output fields - Create order
		 */
		public function create_order_get_meta_boxes_html( $args = [] ) {
			ob_start();
			include( OVABRW_PLUGIN_PATH.'admin/orders/views/html-create-order-rental-appointment.php' );
			return ob_get_clean();
		}

		/**
		 * Get price HTML
		 */
		public function get_price_html( $currency = '' ) {
			$min = $max = '';

			// Get timeslot prices
			$timeslost_prices = $this->get_value( 'time_slots_price', [] );

			if ( ovabrw_array_exists( $timeslost_prices ) ) {
			    foreach ( $timeslost_prices as $prices ) {
			    	// Min price
			    	$min_price = (float)min( $prices );
			    	if ( '' == $min ) $min = $min_price;
			    	if ( $min > $min_price ) $min = $min_price;

			    	$max_price = (float)max( $prices );
			    	if ( '' == $max ) $max = $max_price;
			    	if ( $max < $max_price ) $max = $max_price;
			    }
			}

			if ( $min && $max && $min == $max ) {
				return sprintf( esc_html__( 'From %s', 'ova-brw' ), ovabrw_wc_price( $min, ['currency' => $currency] ) );
			} elseif ( $min && $max ) {
				return sprintf( esc_html__( '%s - %s', 'ova-brw' ), ovabrw_wc_price( $min, ['currency' => $currency] ), ovabrw_wc_price( $max, ['currency' => $currency] ) );
			} else {
				return esc_html__( 'Option Price' );
			}
		}

		/**
		 * instance
		 */
		public static function instance() {
			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self();
			}

			return self::$_instance;
		}
	}
}