<?php if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'OVABRW_Admin_Rental_By_Period_Time', false ) ) {
	class OVABRW_Admin_Rental_By_Period_Time extends OVABRW_Abstract_Admin_Rental_Types {
		protected static $_instance = null;

		/**
		 * Construct
		 */
		public function __construct() {
			$this->ID 		= '';
			$this->type 	= 'period_time';
			$this->title 	= esc_html__( 'Period Time', 'ova-brw' );
			$this->prefix 	= OVABRW_PREFIX;

			parent::__construct();
		}

		/**
		 * Get fields
		 */
		public function get_fields() {
			return apply_filters( "ovabrw_rental_by_{$this->type}_get_fields", array(
				'rental-type',
				'amount-insurance',
				'packages',
				'deposit',
				'inventory',
				'choose-location',
				'specifications',
				'features',
				'resources',
				'services',
				'unavailable-time',
				'advanced-options',
				'custom-checkout-fields',
				'show-quantity',
				'pickup-date',
				'pickup-location',
				'dropoff-location',
				'extra-tab',
				'frontend-order',
				'map'
			));
		}

		/**
		 * Output fields - Create order
		 */
		public function create_order_get_meta_boxes_html( $args = [] ) {
			ob_start();
			include( OVABRW_PLUGIN_PATH.'admin/orders/views/html-create-order-rental-period-time.php' );
			return ob_get_clean();
		}

		/**
		 * Get price HTML
		 */
		public function get_price_html( $currency = '' ) {
			$min = $max = 0;
			$petime_price = $this->get_value( 'petime_price', [] );

			if ( ! empty( $petime_price ) && is_array( $petime_price ) ) {
			    $min = min( $petime_price );
			    $max = max( $petime_price );
			}

			if ( $min && $max && $min == $max ) {
				return sprintf( esc_html__( 'From %s', 'ova-brw' ), ovabrw_wc_price( $min, ['currency' => $currency] ) );
			} elseif ( $min && $max ) {
				return sprintf( esc_html__( '%s - %s', 'ova-brw' ), ovabrw_wc_price( $min, ['currency' => $currency] ), ovabrw_wc_price( $max, ['currency' => $currency] ) );
			} else {
				return esc_html__( 'Option Price' );
			}
		}

		/**
		 * instance
		 */
		public static function instance() {
			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self();
			}

			return self::$_instance;
		}
	}
}