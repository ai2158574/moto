<?php defined( 'ABSPATH' ) || exit; ?>

<!-- Before advanced settings -->
<div class="ovabrw-advanced-settings">
	<div class="advanced-header">
		<h3 class="advanced-label"><?php esc_html_e( 'Advanced options', 'ova-brw' ); ?></h3>
		<span aria-hidden="true" class="dashicons dashicons-arrow-up"></span>
		<span aria-hidden="true" class="dashicons dashicons-arrow-down"></span>
	</div>
	<div class="advanced-content">
		<div class="ovabrw-product-template">
		<?php
			$templates = [
				'global' 	=> esc_html__( 'Category Setting', 'ova-brw' ),
                'default' 	=> esc_html__( 'Classic', 'ova-brw' )
			];

            if ( ovabrw_global_typography() ) {
                $templates['modern'] = esc_html__( 'Modern', 'ova-brw' );
            }

            // Get templates from elementor
            $elementor_templates = get_posts([
            	'post_type'     => 'elementor_library', 
                'meta_key'      => '_elementor_template_type', 
                'meta_value'    => 'page',
                'numberposts'   => -1
            ]);

            if ( ovabrw_array_exists( $elementor_templates ) ) {
                foreach ( $elementor_templates as $template ) {
                    $template_id    = $template->ID;
                    $template_title = $template->post_title;

                    $templates[$template_id] = $template_title;
                }
            }

            woocommerce_wp_select([
            	'id' 				=> $this->get_name( 'product_template' ),
				'label' 			=> esc_html__( 'Product Template', 'ova-brw' ),
				'options' 			=> $templates,
				'value' 			=> $this->get_value( 'product_template', 'global' ),
				'desc_tip'			=> true,
				'description' 		=> esc_html__( 'Classic/Modern or Other (made in Templates of Elementor )', 'ova-brw' ),
				'custom_attributes' => [
					'data-placeholder' => esc_html__( 'Select a template...', 'ova-brw' )
				]
            ]);
		?>
		</div>
		<div class="ovabrw_rent_time_min_wrap">
			<p class=" form-field ovabrw_product_disable_week_day_field">
				<label for="ovabrw_product_disable_week_day">
					<?php esc_html_e( 'Disable Weekdays', 'ova-brw' ); ?>
				</label>
				<?php
					// Disable Week Days
					$disable_weekdays = $this->get_value( 'product_disable_week_day' );

					if ( ovabrw_array_exists( $disable_weekdays ) ) {
						$disable_weekdays = str_replace( '0', '7', $disable_weekdays );
						$disable_weekdays = array_map( 'trim', $disable_weekdays );
					} else {
						$disable_weekdays = '' != $disable_weekdays ? explode( ',', $disable_weekdays ) : [];
					}
				?>
				<select
					id="<?php echo esc_attr( $this->get_name('product_disable_week_day') ); ?>"
					name="<?php echo esc_attr( $this->get_name('product_disable_week_day[]') ); ?>"
					class="ovabrw-select2"
					data-placeholder="<?php esc_html_e( 'Select day of the week', 'ova-brw' ); ?>"
					multiple>
					<option value="1"<?php echo wc_selected( 1, $disable_weekdays ); ?>>
						<?php esc_html_e( 'Monday', 'ova-brw' ); ?>
					</option>
					<option value="2"<?php echo wc_selected( 2, $disable_weekdays ); ?>>
						<?php esc_html_e( 'Tuesday', 'ova-brw' ); ?>
					</option>
					<option value="3"<?php echo wc_selected( 3, $disable_weekdays ); ?>>
						<?php esc_html_e( 'Wednesday', 'ova-brw' ); ?>
					</option>
					<option value="4"<?php echo wc_selected( 4, $disable_weekdays ); ?>>
						<?php esc_html_e( 'Thursday', 'ova-brw' ); ?>
					</option>
					<option value="5"<?php echo wc_selected( 5, $disable_weekdays ); ?>>
						<?php esc_html_e( 'Friday', 'ova-brw' ); ?>
					</option>
					<option value="6"<?php echo wc_selected( 6, $disable_weekdays ); ?>>
						<?php esc_html_e( 'Saturday', 'ova-brw' ); ?>
					</option>
					<option value="7"<?php echo wc_selected( 7, $disable_weekdays ); ?>>
						<?php esc_html_e( 'Sunday', 'ova-brw' ); ?>
					</option>
				</select>
			</p>
			<?php
				if ( 'day' == $this->type ) {
					// Rent Day min
					woocommerce_wp_text_input([
						'id'            => $this->get_name('rent_day_min'),
					    'class'         => 'short ',
					    'label'         => esc_html__( 'Minimum Booking Days', 'ova-brw' ),
					    'placeholder'   => esc_html__( '1', 'ova-brw' ),
					    'desc_tip'      => 'true',
					    'value' 		=> $this->get_value('rent_day_min'),
					    'data_type' 	=> 'price'
					]);

					// Rent Day max
					woocommerce_wp_text_input([
						'id'            => $this->get_name('rent_day_max'),
					    'class'         => 'short ',
					    'label'         => esc_html__( 'Maximum Booking Days', 'ova-brw' ),
					    'placeholder'   => esc_html__( '1', 'ova-brw' ),
					    'desc_tip'      => 'true',
					    'value' 		=> $this->get_value('rent_day_max'),
					    'data_type' 	=> 'price'
					]);
				} elseif ( 'hotel' == $this->type ) {
					// Rent hotel min
					woocommerce_wp_text_input([
						'id'            => $this->get_name('rent_day_min'),
					    'class'         => 'short ',
					    'label'         => esc_html__( 'Minimum Booking Nights', 'ova-brw' ),
					    'placeholder'   => esc_html__( '1', 'ova-brw' ),
					    'desc_tip'      => 'true',
					    'value' 		=> $this->get_value('rent_day_min'),
					    'data_type' 	=> 'price'
					]);

					// Rent hotel max
					woocommerce_wp_text_input([
						'id'            => $this->get_name('rent_day_max'),
					    'class'         => 'short ',
					    'label'         => esc_html__( 'Maximum Booking Nights', 'ova-brw' ),
					    'placeholder'   => esc_html__( '1', 'ova-brw' ),
					    'desc_tip'      => 'true',
					    'value' 		=> $this->get_value('rent_day_max'),
					    'data_type' 	=> 'price'
					]);
				} elseif ( 'hour' == $this->type || 'mixed' == $this->type ) {
					// Rent Hour min
					woocommerce_wp_text_input([
						'id'            => $this->get_name('rent_hour_min'),
					    'class'         => 'short ',
					    'label'         => esc_html__( 'Minimum Booking Hours', 'ova-brw' ),
					    'placeholder'   => esc_html__( '1', 'ova-brw' ),
					    'desc_tip'      => 'true',
					    'value' 		=> $this->get_value('rent_hour_min'),
					    'data_type' 	=> 'price'
					]);

					// Rent Hour max
					woocommerce_wp_text_input([
						'id'            => $this->get_name('rent_hour_max'),
					    'class'         => 'short ',
					    'label'         => esc_html__( 'Maximum Booking Hours', 'ova-brw' ),
					    'placeholder'   => esc_html__( '1', 'ova-brw' ),
					    'desc_tip'      => 'true',
					    'value' 		=> $this->get_value('rent_hour_max'),
					    'data_type' 	=> 'price'
					]);
				}

				if ( $this->type == 'day' || $this->type == 'transportation' ) {
					woocommerce_wp_text_input([
						'id' 			=> $this->get_name('prepare_vehicle_day'),
						'class' 		=> 'short',
						'label' 		=> esc_html__( 'Time between 2 leases (Day)', 'ova-brw' ),
						'desc_tip' 		=> 'true',
						'description' 	=> esc_html__( 'For example: if the car is delivered on 01/01/2024, I set 1 day to prepare the car so the car is available again to book on 03/01/2024', 'ova-brw' ),
						'placeholder' 	=> '0',
						'value' 		=> $this->get_value( 'prepare_vehicle_day' ),
						'data_type' 	=> 'price'
					]);
				} elseif ( $this->type == 'hour' || $this->type == 'mixed' || $this->type == 'period_time' || $this->type == 'taxi' ) {
					woocommerce_wp_text_input([
						'id' 			=> $this->get_name('prepare_vehicle'),
						'class' 		=> 'short',
						'label' 		=> esc_html__( 'Time between 2 leases (Minutes)', 'ova-brw' ),
						'desc_tip' 		=> 'true',
						'description' 	=> esc_html__( 'For example: if the car is delivered at 9:00, I set 60 minutes to prepare the car so the car is available again to book at 10:00', 'ova-brw' ),
						'placeholder' 	=> '60',
						'value' 		=> $this->get_value('prepare_vehicle'),
						'data_type' 	=> 'price'
					]);
				}

				woocommerce_wp_text_input([
					'id' 			=> $this->get_name('preparation_time'),
					'class' 		=> 'short',
					'label' 		=> esc_html__( 'Preparation Time', 'ova-brw' ),
					'desc_tip' 		=> 'true',
					'description' 	=> esc_html__( 'Book in advance X days from the current date', 'ova-brw' ),
					'placeholder' 	=> esc_html__( 'Number of days', 'ova-brw' ),
					'value' 		=> $this->get_value( 'preparation_time' ),
					'custom_attributes' => [
						'min' => 0
					],
					'data_type' 	=> 'price'
				]);
			?>
		</div>
		