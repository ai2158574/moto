<?php defined( 'ABSPATH' ) || exit;
	// Get locations
	$locations = OVABRW()->options->get_data_location();
?>
<div class="ovabrw-advanced-settings">
	<div class="advanced-header">
		<h3 class="advanced-label">
			<?php esc_html_e( 'Locations', 'ova-brw' ); ?>
		</h3>
		<span aria-hidden="true" class="dashicons dashicons-arrow-up"></span>
		<span aria-hidden="true" class="dashicons dashicons-arrow-down"></span>
	</div>
	<div class="advanced-content">
		<div class="ovabrw-form-field ovabrw-locations">
			<table class="widefat">
				<thead>
					<tr>
						<th class="ovabrw-required">
							<?php esc_html_e( 'Pick-up Location', 'ova-brw' ); ?>
						</th>
						<th class="ovabrw-required">
							<?php esc_html_e( 'Drop-off Location', 'ova-brw' ); ?>
						</th>
						<th></th>
					</tr>
				</thead>
				<tbody>
				<?php if ( ovabrw_array_exists( $locations ) ):
					$pickup_locations 	= $this->get_value( 'st_pickup_loc' );
					$dropoff_locations 	= $this->get_value( 'st_dropoff_loc' );

					if ( ovabrw_array_exists( $pickup_locations ) ):
						foreach ( $pickup_locations as $i => $pickup_location ):
							$dropoff_location = ovabrw_get_meta_data( $i, $dropoff_locations );
				?>
							<tr>
								<td width="50%">
									<?php ovabrw_wp_select_input([
										'class' 		=> 'ovabrw-input-required',
										'name' 			=> $this->get_name( 'st_pickup_loc[]' ),
										'value' 		=> $pickup_location,
										'placeholder' 	=> esc_html__( 'Select Location', 'ova-brw' ),
										'options' 		=> $locations
									]); ?>
							    </td>
							    <td width="50%">
							    	<?php ovabrw_wp_select_input([
							    		'class' 		=> 'ovabrw-input-required',
										'name' 			=> $this->get_name( 'st_dropoff_loc[]' ),
										'value' 		=> $dropoff_location,
										'placeholder' 	=> esc_html__( 'Select Location', 'ova-brw' ),
										'options' 		=> $locations
									]); ?>
							    </td>
							    <td width="1%">
							    	<button class="button ovabrw-remove-location">x</button>
							    </td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				<?php endif; ?>
				</tbody>
				<tfoot>
					<tr>
						<th colspan="3">
							<button class="button ovabrw-add-location" data-add-new="<?php
								ob_start();
								include( OVABRW_PLUGIN_PATH.'admin/meta-boxes/fields/ovabrw-choose-location-field.php' );
								echo esc_attr( ob_get_clean() );
							?>">
								<?php esc_html_e( 'Add Location', 'ova-brw' ); ?>
							</button>
						</th>
					</tr>
				</tfoot>
			</table>
		</div>
	</div>
</div>