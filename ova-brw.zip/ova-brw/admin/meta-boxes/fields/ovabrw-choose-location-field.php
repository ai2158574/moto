<?php defined( 'ABSPATH' ) || exit;

// Get locations
$locations = OVABRW()->options->get_data_location();
if ( !ovabrw_array_exists( $locations ) ) $locations = [];

?>
<tr>
    <td width="50%">
        <?php ovabrw_wp_select_input([
            'class'         => 'ovabrw-input-required',
            'name'          => $this->get_name( 'st_pickup_loc[]' ),
            'placeholder'   => esc_html__( 'Select Location', 'ova-brw' ),
            'options'       => $locations
        ]); ?>
    </td>
    <td width="50%">
        <?php ovabrw_wp_select_input([
            'class'         => 'ovabrw-input-required',
            'name'          => $this->get_name( 'st_dropoff_loc[]' ),
            'placeholder'   => esc_html__( 'Select Location', 'ova-brw' ),
            'options'       => $locations
        ]); ?>
    </td>
    <td width="1%">
        <button class="button ovabrw-remove-location">x</button>
    </td>
</tr>