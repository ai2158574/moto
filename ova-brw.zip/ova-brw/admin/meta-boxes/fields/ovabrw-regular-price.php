<?php defined( 'ABSPATH' ) || exit;

// Rental Types: Day & Mixed
if ( 'day' == $this->type || 'mixed' == $this->type ) {
	$regular_price = get_post_meta( $this->ID, '_regular_price', true );

	woocommerce_wp_text_input([
		'id' 			=> $this->get_name( 'regular_price_day' ),
		'class' 		=> 'ovabrw-input-required',
		'wrapper_class' => 'ovabrw-required',
		'label' 		=> esc_html__( 'Regular price / Day', 'ova-brw' ),
		'placeholder' 	=> '',
		'desc_tip'    	=> true,
		'description' 	=> esc_html__( 'Regular price by day', 'ova-brw' ),
		'data_type' 	=> 'price',
		'value' 		=> $this->get_value( 'regular_price_day', $regular_price )
	]);
}

// Rental Types: Hour & Mixed
if ( 'hour' == $this->type || 'mixed' == $this->type ) {
	woocommerce_wp_text_input([
		'id' 			=> $this->get_name('regul_price_hour'),
		'class' 		=> 'ovabrw-input-required',
		'wrapper_class' => 'ovabrw-required',
		'label' 		=> esc_html__( 'Regular price / Hour', 'ova-brw' ),
		'placeholder' 	=> '',
		'desc_tip'    	=> 'true',
		'description' 	=> esc_html__( 'Regular price by hour', 'ova-brw' ),
		'data_type' 	=> 'price',
		'value' 		=> $this->get_value('regul_price_hour')
	]);
}

// Rental Type: Taxi
if ( 'taxi' == $this->type ) {
	woocommerce_wp_text_input([
		'id' 			=> $this->get_name('regul_price_taxi'),
		'class' 		=> 'ovabrw-input-required',
		'wrapper_class' => 'ovabrw-required',
		'label' 		=> esc_html__( 'Price Per Kilometer', 'ova-brw' ),
		'placeholder' 	=> '',
		'desc_tip'    	=> 'true',
		'description' 	=> esc_html__( 'Price Per Kilometer', 'ova-brw' ),
		'data_type' 	=> 'price',
		'value' 		=> $this->get_value('regul_price_taxi')
	]);
}

// Rental Type: Hotel
if ( 'hotel' == $this->type ) {
	woocommerce_wp_text_input([
		'id' 			=> $this->get_name('regular_price_hotel'),
		'class' 		=> 'ovabrw-input-required',
		'wrapper_class' => 'ovabrw-required',
		'label' 		=> esc_html__( 'Price / Night', 'ova-brw' ),
		'placeholder' 	=> '',
		'desc_tip'    	=> 'true',
		'description' 	=> esc_html__( 'Regular price by night', 'ova-brw' ),
		'data_type' 	=> 'price',
		'value' 		=> $this->get_value('regular_price_hotel')
	]);
}