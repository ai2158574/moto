<?php defined( 'ABSPATH' ) || exit;

woocommerce_wp_select([
	'id' 			=> $this->get_name('unfixed_time'),
	'label' 		=> esc_html__( 'Package', 'ova-brw' ),
	'placeholder' 	=> '',
	'options' 		=> [
		'no' 	=> esc_html__( 'Fixed Hour', 'ova-brw' ),
		'yes' 	=> esc_html__( 'UnFixed Hour', 'ova-brw' )
	],
	'desc_tip'		=> true,
	'description'	=> esc_html__( 'Fixed Hour: you cannot choose hour in booking form. UnFixed Hour: You can choose hour in booking form', 'ova-brw' ),
	'value' 		=> $this->get_value( 'unfixed_time', 'no' )
]);