<?php if ( ! defined( 'ABSPATH' ) ) exit();

if ( ! class_exists( 'OVABRW_Admin_CKF' ) ) {
	class OVABRW_Admin_CKF {
		public function __construct() {
            // Admin Menu
            add_action('admin_menu', array( $this, 'ovabrw_add_menu' ) );
        }

        public function ovabrw_add_menu() {
        	add_submenu_page(
                'edit.php?post_type=product',
                __( 'Custom Checkout Field', 'ova-brw' ),
                __( 'Custom Checkout Field', 'ova-brw' ),
                apply_filters( 'ovabrw_add_checkout_field_cap' ,'edit_posts' ),
                'ovabrw-custom-checkout-field',
                array( $this, 'ovabrw_custom_checkout_field' )
            );
        }

        public function ovabrw_custom_checkout_field() {
        	include( OVABRW_PLUGIN_PATH.'admin/products/views/html-custom-checkout-fields.php' );
        }

        public function ova_output_popup_form_fields( $form_type = '', $list_fields = [] ) {
            include( OVABRW_PLUGIN_PATH.'admin/products/views/html-popup-custom-checkout-field.php' );
        }

        public function ovabrw_sanitize_keys( $args = [], $default = [] ) {
            if ( empty( $args ) || ! is_array( $args ) ) return $args;

            foreach ( $args as $k => $v ) {
                if ( ! $v && isset( $default[$k] ) && $default[$k] ) {
                    $v = $default[$k];
                }

                $args[$k] = sanitize_text_field( sanitize_title( $v ) );
            }

            return $args;
        }
	}

	new OVABRW_Admin_CKF();
}