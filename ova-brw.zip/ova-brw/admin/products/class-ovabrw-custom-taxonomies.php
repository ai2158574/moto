<?php if ( ! defined( 'ABSPATH' ) ) exit();

if ( ! class_exists( 'OVABRW_Admin_Custom_Taxonomies' ) ) {
	class OVABRW_Admin_Custom_Taxonomies {
		public function __construct() {
            // Admin Menu
            add_action('admin_menu', array( $this, 'ovabrw_add_menu' ) );
        }

        public function ovabrw_add_menu() {
        	add_submenu_page(
                'edit.php?post_type=product',
                __( 'Custom Taxonomy', 'ova-brw' ),
                __( 'Custom Taxonomy', 'ova-brw' ),
                apply_filters( 'ovabrw_add_custom_taxonomy_field_cap' ,'edit_posts' ),
                'ovabrw-custom-taxonomy',
                array( $this, 'ovabrw_custom_taxonomy' )
            );
        }

        public function ovabrw_custom_taxonomy() {
        	include( OVABRW_PLUGIN_PATH.'admin/products/views/html-custom-taxonomies.php' );
        }

        public function ova_output_popup_custom_tax_form( $form_type = '', $list_fields = [] ) {
            include( OVABRW_PLUGIN_PATH.'admin/products/views/html-popup-custom-taxonomy.php' );
        }
	}

	new OVABRW_Admin_Custom_Taxonomies();
}