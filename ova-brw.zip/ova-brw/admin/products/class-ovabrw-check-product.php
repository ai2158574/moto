<?php if ( ! defined( 'ABSPATH' ) ) exit();

if ( ! class_exists( 'OVABRW_Admin_Check_Product' ) ) {
	class OVABRW_Admin_Check_Product {
		public function __construct() {
            // Admin Menu
            add_action('admin_menu', array( $this, 'ovabrw_add_menu' ) );
        }

        public function ovabrw_add_menu() {
        	add_submenu_page(
                'edit.php?post_type=product',
                __( 'Check Product', 'ova-brw' ),
                __( 'Check Product', 'ova-brw' ),
                apply_filters( 'ovabrw_check_product_cap' ,'edit_posts' ),
                'ovabrw-check-product',
                array( $this, 'ovabrw_check_product' )
            );
        }

        public function ovabrw_check_product() {
        	include( OVABRW_PLUGIN_PATH.'admin/products/views/html-check-product.php' );
        }
	}

	new OVABRW_Admin_Check_Product();
}