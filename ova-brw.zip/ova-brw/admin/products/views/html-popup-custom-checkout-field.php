<?php if ( ! defined( 'ABSPATH' ) ) exit(); ?>

<form method="post" id="ova_popup_field_form" action="" autocomplete="off">
    <input
        type="hidden"
        name="ova_action"
        value="<?php echo isset( $form_type ) ? esc_attr( $form_type ) : ''; ?>"
    />
    <input type="hidden" name="ova_old_name" value="">
    <table width="100%">
        <tr class="ova-row-type">
            <td class="ovabrw-required label"><?php esc_html_e( 'Type', 'ova-brw' ); ?></td>
            <td>
                <select name="type" id="ova_type" required>
                    <option value="text"><?php esc_html_e('Text', 'ova-brw'); ?></option>
                    <option value="password"><?php esc_html_e('Password', 'ova-brw'); ?></option>
                    <option value="email"><?php esc_html_e('Email', 'ova-brw'); ?></option>
                    <option value="tel"><?php esc_html_e('Phone', 'ova-brw'); ?></option>
                    <option value="textarea"><?php esc_html_e('Textarea', 'ova-brw'); ?></option>
                    <option value="radio"><?php esc_html_e('Radio', 'ova-brw'); ?></option>
                    <option value="checkbox"><?php esc_html_e('Checkbox', 'ova-brw'); ?></option>
                    <option value="file"><?php esc_html_e('File', 'ova-brw'); ?></option>
                    <option value="select"><?php esc_html_e('Select', 'ova-brw'); ?></option>
                    <option value="number"><?php esc_html_e('Number', 'ova-brw'); ?></option>
                    <option value="date"><?php esc_html_e('Date', 'ova-brw'); ?></option>
                </select>
                <span class="formats-file-size">
                    <em>
                        <?php esc_html_e( 'Formats: .jpg, .jpeg, .png, .pdf, .doc', 'ova-brw' ); ?>
                    </em>
                </span>
            </td>
        </tr>
        <tr class="row-options">
            <td width="30%" class="label" valign="top">
                <?php esc_html_e('Options', 'ova-brw'); ?>
            </td>
            <td>
                <table width="100%" border="0" cellpadding="0" cellspacing="0" class="ova-sub-table">
                    <thead>
                        <tr>
                            <th class="ovabrw-required">
                                <?php esc_html_e( 'Value(unique)', 'ova-brw' ); ?>
                            </th>
                            <th class="ovabrw-required">
                                <?php esc_html_e( 'Text', 'ova-brw' ); ?>
                            </th>
                            <th><?php esc_html_e( 'Price', 'ova-brw' ); ?></th>
                            <th><?php esc_html_e( 'Quantity', 'ova-brw' ); ?></th>
                            <th><?php esc_html_e( 'Actions', 'ova-brw' ); ?></th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody class="ovabrw-sortable">
                        <tr>
                            <td>
                                <input
                                    type="text"
                                    name="ova_options_key[]"
                                    placeholder="text"
                                    required
                                />
                            </td>
                            <td>
                                <input
                                    type="text"
                                    name="ova_options_text[]"
                                    placeholder="text"
                                    required
                                />
                            </td>
                            <td>
                                <input
                                    type="text"
                                    name="ova_options_price[]"
                                    placeholder="number"
                                />
                            </td>
                            <td>
                                <input
                                    type="number"
                                    name="ova_options_qty[]"
                                    placeholder="number"
                                    min="0"
                                />
                            </td>
                            <td class="ova-box">
                                <a href="javascript:void(0)" class="ovabrw_addfield btn btn-blue" title="Add new option">+</a>
                            </td>
                            <td class="ova-box">
                                <a href="javascript:void(0)" class="ovabrw_remove_row btn btn-red" title="Remove option">x</a>
                            </td>
                            <td class="ova-box sort">
                                <span class="dashicons dashicons-menu" title="Drag & Drop"></span>
                            </td>
                        </tr>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td>
                                <span>
                                    <em>
                                        <?php esc_html_e( 'Quantity: maximum per booking', 'ova-brw' ); ?>
                                    </em>
                                </span>
                            </td>
                        </tr>
                    </tfoot>
                </table>                
            </td>
        </tr>
        <tr class="row-values">
            <td width="30%" class="label" valign="top">
                <?php esc_html_e( 'Values', 'ova-brw' ); ?>
            </td>
            <td>
                <table width="100%" border="0" cellpadding="0" cellspacing="0" class="ova-sub-table">
                    <thead>
                        <tr>
                            <th class="ovabrw-required">
                                <?php esc_html_e( 'Value(unique)', 'ova-brw' ); ?>
                            </th>
                            <th><?php esc_html_e( 'Price', 'ova-brw' ); ?></th>
                            <th><?php esc_html_e( 'Quantity', 'ova-brw' ); ?></th>
                            <th><?php esc_html_e( 'Actions', 'ova-brw' ); ?></th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody class="ovabrw-sortable">
                        <tr>
                            <td>
                                <input
                                    type="text"
                                    name="ova_values[]"
                                    placeholder="text"
                                    required
                                />
                            </td>
                            <td>
                                <input
                                    type="text"
                                    name="ova_prices[]"
                                    placeholder="number"
                                />
                            </td>
                            <td>
                                <input
                                    type="number"
                                    name="ova_qtys[]"
                                    placeholder="number"
                                    min="0"
                                />
                            </td>
                            <td class="ova-box">
                                <a href="javascript:void(0)" class="ovabrw_add_value btn btn-blue" title="Add">+</a>
                            </td>
                            <td class="ova-box">
                                <a href="javascript:void(0)" class="ovabrw_remove_value btn btn-red" title="Remove">x</a>
                            </td>
                            <td class="ova-box sort">
                                <span class="dashicons dashicons-menu" title="Drag & Drop"></span>
                            </td>
                        </tr>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td>
                                <span>
                                    <em>
                                        <?php esc_html_e( 'Quantity: maximum per booking', 'ova-brw' ); ?>
                                    </em>
                                </span>
                            </td>
                        </tr>
                    </tfoot>
                </table>                
            </td>
        </tr>
        <tr class="row-checkbox-options">
            <td width="30%" class="label" valign="top">
                <?php esc_html_e( 'Options', 'ova-brw' ); ?>
            </td>
            <td>
                <table width="100%" border="0" cellpadding="0" cellspacing="0" class="ova-sub-table">
                    <thead>
                        <tr>
                            <th class="ovabrw-required">
                                <?php esc_html_e( 'Value(unique)', 'ova-brw' ); ?>
                            </th>
                            <th class="ovabrw-required">
                                <?php esc_html_e( 'Text', 'ova-brw' ); ?>
                            </th>
                            <th><?php esc_html_e( 'Price', 'ova-brw' ); ?></th>
                            <th><?php esc_html_e( 'Quantity', 'ova-brw' ); ?></th>
                            <th><?php esc_html_e( 'Actions', 'ova-brw' ); ?></th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody class="ovabrw-sortable">
                        <tr>
                            <td>
                                <input
                                    type="text"
                                    name="ova_checkbox_key[]"
                                    placeholder="text"
                                    required
                                />
                            </td>
                            <td>
                                <input
                                    type="text"
                                    name="ova_checkbox_text[]"
                                    placeholder="text"
                                    required
                                />
                            </td>
                            <td>
                                <input
                                    type="text"
                                    name="ova_checkbox_price[]"
                                    placeholder="number"
                                />
                            </td>
                            <td>
                                <input
                                    type="number"
                                    name="ova_checkbox_qty[]"
                                    placeholder="number"
                                />
                            </td>
                            <td class="ova-box">
                                <a href="javascript:void(0)" class="ovabrw_add_checkbox_option btn btn-blue" title="Add new option">+</a>
                            </td>
                            <td class="ova-box">
                                <a href="javascript:void(0)" class="ovabrw_remove_checkbox_option btn btn-red" title="Remove option">x</a>
                            </td>
                            <td class="ova-box sort">
                                <span class="dashicons dashicons-menu" title="Drag & Drop"></span>
                            </td>
                        </tr>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td>
                                <span>
                                    <em>
                                        <?php esc_html_e( 'Quantity: maximum per booking', 'ova-brw' ); ?>
                                    </em>
                                </span>
                            </td>
                        </tr>
                    </tfoot>
                </table>                
            </td>
        </tr>
        <tr class="ova-row-file-size">
            <td class="label"><?php esc_html_e( 'Max Size', 'ova-brw' ); ?></td>
            <td>
                <input type="text" name="max_file_size" value="20">
                <span><?php esc_html_e( 'Default: 20MB', 'ova-brw' ); ?></span>
            </td>
        </tr>
        <tr class="ova-row-name">
            <td class="ovabrw-required label"><?php esc_html_e( 'Name', 'ova-brw' ); ?></td>
            <td>
                <input type="text" name="name" required>
                <span>
                    <em>
                        <?php esc_html_e( 'Unique, only lowercase, not space', 'ova-brw' ); ?>
                    </em>
                </span>
            </td>
        </tr>
        <tr class="ova-row-label">
            <td class="ovabrw-required label"><?php esc_html_e( 'Label', 'ova-brw' ); ?></td>
            <td>
                <input type="text" name="label" required>
            </td>
        </tr>
        <tr class="ova-row-description">
            <td class="label"><?php esc_html_e( 'Description', 'ova-brw' ); ?></td>
            <td>
                <textarea name="description"></textarea>
            </td>
        </tr>
        <tr class="ova-row-placeholder">
            <td class="label"><?php esc_html_e( 'Placeholder', 'ova-brw' ); ?></td>
            <td>
                <input type="text" name="placeholder">
            </td>
        </tr>
        <tr class="ova-row-default">
            <td class="label"><?php esc_html_e( 'Default value', 'ova-brw' ); ?></td>
            <td>
                <input type="text" name="default">
            </td>
        </tr>
        <tr class="ova-row-min">
            <td class="label"><?php esc_html_e( 'Min', 'ova-brw' ); ?></td>
            <td>
                <input type="number" name="min" autocomplete="off" min="0">
            </td>
        </tr>
        <tr class="ova-row-max">
            <td class="label"><?php esc_html_e( 'Max', 'ova-brw' ); ?></td>
            <td>
                <input type="number" name="max" autocomplete="off" min="0">
            </td>
        </tr>
        <tr class="ova-row-default-date">
            <td class="label"><?php esc_html_e( 'Default', 'ova-brw' ); ?></td>
            <td>
                <input
                    type="text"
                    id="<?php echo esc_attr( ovabrw_unique_id( 'cckf_default_date' ) ); ?>"
                    class="ovabrw-datepicker"
                    name="default_date"
                    autocomplete="off"
                />
            </td>
        </tr>
        <tr class="ova-row-min-date">
            <td class="label"><?php esc_html_e( 'Min', 'ova-brw' ); ?></td>
            <td>
                <input
                    type="text"
                    id="<?php echo esc_attr( ovabrw_unique_id( 'cckf_min_date' ) ); ?>"
                    class="ovabrw-datepicker"
                    name="min_date"
                    autocomplete="off"
                />
            </td>
        </tr>
        <tr class="ova-row-max-date">
            <td class="label"><?php esc_html_e( 'Max', 'ova-brw' ); ?></td>
            <td>
                <input
                    type="text"
                    id="<?php echo esc_attr( ovabrw_unique_id( 'cckf_max_date' ) ); ?>"
                    class="ovabrw-datepicker"
                    name="max_date"
                    autocomplete="off"
                />
            </td>
        </tr>
        <tr class="ova-row-class">
            <td class="label"><?php esc_html_e( 'Class', 'ova-brw' ); ?></td>
            <td>
                <input type="text" name="class" value="">
            </td>
        </tr>
        <tr class="row-required">
            <td>&nbsp;</td>
            <td class="check-box">
                <input
                    id="ova_required"
                    type="checkbox"
                    name="required"
                    checked
                />
                <label for="ova_required">
                    <?php esc_html_e( 'Required', 'ova-brw' ); ?>
                </label>
                <br/>
                <input
                    id="ova_enable"
                    type="checkbox"
                    name="enabled"
                    checked
                />
                <label for="ova_enable">
                    <?php esc_html_e( 'Enable', 'ova-brw' ); ?>
                </label>
                <br/>
            </td>                     
            <td class="label"></td>
        </tr>
    </table>
    <button type='submit' class="button button-primary">
        <?php esc_html_e( 'save', 'ova-brw' ); ?>
    </button>
</form>