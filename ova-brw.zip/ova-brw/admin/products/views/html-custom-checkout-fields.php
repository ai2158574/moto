<?php if ( ! defined( 'ABSPATH' ) ) exit();

/* Jquery ui */
wp_enqueue_script('jquery-ui', OVABRW_PLUGIN_URI.'assets/libs/jquery-ui/jquery-ui.min.js', array('jquery'), false, true);
wp_enqueue_style('jquery-ui', OVABRW_PLUGIN_URI.'assets/libs/jquery-ui/jquery-ui.min.css', array(), null);

$list_fields = ovabrw_recursive_replace( '\\', '', get_option( 'ovabrw_booking_form', array() ) );

if ( isset( $_POST ) && $_POST ) {
    $_POST = ovabrw_recursive_replace( '\\', '', $_POST );
}

$action_popup   = isset( $_POST['ova_action'] ) ? sanitize_text_field( $_POST['ova_action'] ) : '';
$name           = isset( $_POST['name'] ) ? sanitize_text_field( sanitize_title( $_POST['name'] ) ) : '';

// Update popup
if ( isset( $_POST ) && ! empty( $_POST ) ) {
    if ( current_user_can('publish_posts') ) {
        if ( array_key_exists( 'name', $_POST ) && ! empty( $_POST['name'] ) ) {
            $list_fields[$name] = array(
                'type'          => isset( $_POST['type'] ) ? sanitize_text_field( $_POST['type'] ) : '',
                'label'         => isset( $_POST['label'] ) ? sanitize_text_field( $_POST['label'] ) : '',
                'description'   => isset( $_POST['description'] ) ? sanitize_text_field( $_POST['description'] ) : '',
                'default'       => isset( $_POST['default'] ) ? sanitize_text_field( $_POST['default'] ) : '',
                'placeholder'   => isset( $_POST['placeholder'] ) ? sanitize_text_field( $_POST['placeholder'] ) : '',
                'class'         => isset( $_POST['class'] ) ? sanitize_text_field( $_POST['class'] ) : '',
                'required'      => isset( $_POST['required'] ) ? sanitize_text_field( $_POST['required'] ) : '',
                'enabled'       => isset( $_POST['enabled'] ) ? sanitize_text_field( $_POST['enabled'] ) : '',
                'show_in_email' => isset( $_POST['show_in_email'] ) ? sanitize_text_field( $_POST['show_in_email'] ) : '',
                'show_in_order' => isset( $_POST['show_in_order'] ) ? sanitize_text_field( $_POST['show_in_order'] ) : '',
            );
        }

        if ( isset( $_POST['type'] ) && $_POST['type'] == 'select' ) {
            $list_fields[$name]['ova_options_key']      = $this->ovabrw_sanitize_keys( $_POST['ova_options_key'], $_POST['ova_options_text'] );
            $list_fields[$name]['ova_options_text']     = $_POST['ova_options_text'];
            $list_fields[$name]['ova_options_price']    = $_POST['ova_options_price'];
            $list_fields[$name]['ova_options_qty']      = $_POST['ova_options_qty'];
            $list_fields[$name]['placeholder']          = '';
        }

        if ( isset( $_POST['type'] ) && $_POST['type'] == 'radio' ) {
            $list_fields[$name]['ova_values']   = $_POST['ova_values'];
            $list_fields[$name]['ova_prices']   = $_POST['ova_prices'];
            $list_fields[$name]['ova_qtys']     = $_POST['ova_qtys'];
            $list_fields[$name]['placeholder']  = '';
        }

        if ( isset( $_POST['type'] ) && $_POST['type'] == 'checkbox' ) {
            $list_fields[$name]['placeholder']          = '';
            $list_fields[$name]['ova_checkbox_key']     = $this->ovabrw_sanitize_keys( $_POST['ova_checkbox_key'], $_POST['ova_checkbox_text'] );
            $list_fields[$name]['ova_checkbox_text']    = $_POST['ova_checkbox_text'];
            $list_fields[$name]['ova_checkbox_price']   = $_POST['ova_checkbox_price'];
            $list_fields[$name]['ova_checkbox_qty']     = $_POST['ova_checkbox_qty'];
        }

        if ( isset( $_POST['type'] ) && $_POST['type'] == 'file' ) {
            $list_fields[$name]['placeholder']      = '';
            $list_fields[$name]['default']          = '';
            $list_fields[$name]['max_file_size']    = $_POST['max_file_size'];
        }

        if ( isset( $_POST['type'] ) && $_POST['type'] == 'number' ) {
            $list_fields[$name]['min'] = $_POST['min'];
            $list_fields[$name]['max'] = $_POST['max'];
        }

        if ( isset( $_POST['type'] ) && $_POST['type'] == 'date' ) {
            $list_fields[$name]['default_date'] = $_POST['default_date'];
            $list_fields[$name]['min_date']     = $_POST['min_date'];
            $list_fields[$name]['max_date']     = $_POST['max_date'];
        }

        if ( $action_popup == 'new' ) {
            update_option( 'ovabrw_booking_form', $list_fields );
        } elseif ( $action_popup == 'edit' ) {
            $old_name = isset( $_POST['ova_old_name'] ) ? $_POST['ova_old_name'] : '';

            if ( ! empty( $old_name ) && array_key_exists( $old_name, $list_fields ) && $old_name != $name  ) {
                unset($list_fields[$old_name]);
            }

            if ( ! $name ) {
                unset($list_fields[$name]);
            }

            update_option('ovabrw_booking_form', $list_fields);
        }

        //end popup
        $action_update = isset( $_POST['ovabrw_update_table'] ) ? sanitize_text_field( $_POST['ovabrw_update_table'] ) : '';

        if ( $action_update === 'update_table' ) {
            if ( isset( $_POST['remove'] ) && $_POST['remove'] == 'remove' ) {
                $select_field = isset( $_POST['select_field'] ) ? $_POST['select_field'] : [];

                if ( is_array( $select_field ) && ! empty( $select_field ) ) {
                    foreach ( $select_field as $field ) {
                        if ( array_key_exists( $field, $list_fields ) ) {
                            unset( $list_fields[$field] );
                        }
                    }
                }
            }

            if ( isset( $_POST['enable'] ) && $_POST['enable'] == 'enable' ) {
                $select_field = isset( $_POST['select_field'] ) ? $_POST['select_field'] : [];

                if ( is_array( $select_field ) && ! empty( $select_field ) ) {
                    foreach ( $select_field as $field ) {
                        if ( ! empty( $field ) && array_key_exists( $field, $list_fields ) ) {
                            $list_fields[$field]['enabled'] = 'on';
                        }
                    }
                }
            }

            if ( isset( $_POST['disable'] ) && $_POST['disable'] == 'disable' ) {
                $select_field = isset( $_POST['select_field'] ) ? $_POST['select_field'] : [];

                if ( is_array( $select_field ) && ! empty( $select_field ) ) {
                    foreach ( $select_field as $field ) {
                        if ( ! empty( $field ) && array_key_exists( $field, $list_fields ) ) {
                            $list_fields[$field]['enabled'] = '';
                        }
                    }
                }
            }

            update_option( 'ovabrw_booking_form', $list_fields );
        }
    } else {
        if ( ! array_key_exists( $name, $list_fields ) && $name && $action_popup == 'new' ) {
            $list_fields[$name] = array(
                'type'          => isset( $_POST['type'] ) ? sanitize_text_field( $_POST['type'] ) : '',
                'label'         => isset( $_POST['label'] ) ? sanitize_text_field( $_POST['label'] ) : '',
                'description'   => isset( $_POST['description'] ) ? sanitize_text_field( $_POST['description'] ) : '',
                'default'       => isset( $_POST['default'] ) ? sanitize_text_field( $_POST['default'] ) : '',
                'placeholder'   => isset( $_POST['placeholder'] ) ? sanitize_text_field( $_POST['placeholder'] ) : '',
                'class'         => isset( $_POST['class'] ) ? sanitize_text_field( $_POST['class'] ) : '',
                'required'      => isset( $_POST['required'] ) ? sanitize_text_field( $_POST['required'] ) : '',
                'enabled'       => '',
                'show_in_email' => isset( $_POST['show_in_email'] ) ? sanitize_text_field( $_POST['show_in_email'] ) : '',
                'show_in_order' => isset( $_POST['show_in_order'] ) ? sanitize_text_field( $_POST['show_in_order'] ) : '',
            );

            if ( isset( $_POST['type'] ) && $_POST['type'] == 'select' ) {
                $list_fields[$name]['ova_options_key']      = $this->ovabrw_sanitize_keys( $_POST['ova_options_key'], $_POST['ova_options_text'] );
                $list_fields[$name]['ova_options_text']     = $_POST['ova_options_text'];
                $list_fields[$name]['ova_options_price']    = $_POST['ova_options_price'];
                $list_fields[$name]['ova_options_qty']      = $_POST['ova_options_qty'];
                $list_fields[$name]['placeholder']          = '';
            }

            if ( isset( $_POST['type'] ) && $_POST['type'] == 'radio' ) {
                $list_fields[$name]['ova_values']   = $_POST['ova_values'];
                $list_fields[$name]['ova_prices']   = $_POST['ova_prices'];
                $list_fields[$name]['ova_qtys']     = $_POST['ova_qtys'];
                $list_fields[$name]['placeholder']  = '';
            }

            if ( isset( $_POST['type'] ) && $_POST['type'] == 'checkbox' ) {
                $list_fields[$name]['placeholder']          = '';
                $list_fields[$name]['ova_checkbox_key']     = $this->ovabrw_sanitize_keys( $_POST['ova_checkbox_key'], $_POST['ova_checkbox_text'] );
                $list_fields[$name]['ova_checkbox_text']    = $_POST['ova_checkbox_text'];
                $list_fields[$name]['ova_checkbox_price']   = $_POST['ova_checkbox_price'];
                $list_fields[$name]['ova_checkbox_qty']     = $_POST['ova_checkbox_qty'];
            }

            if ( isset( $_POST['type'] ) && $_POST['type'] == 'file' ) {
                $list_fields[$name]['placeholder']      = '';
                $list_fields[$name]['default']          = '';
                $list_fields[$name]['max_file_size']    = $_POST['max_file_size'];
            }

            update_option( 'ovabrw_booking_form', $list_fields );
        }
    }
}
?>
<div class="wrap">
    <div class="ova-list-checkout-field">
        <form method="post" id="ova_update_form" action="">
            <input type="hidden" name="ovabrw_update_table" value="update_table" >
            <table cellspacing="0" cellpadding="10px">
                <thead>
                    <th colspan="6">
                        <button type="button" class="button button-primary" id="ovabrw_openform">
                            + <?php esc_html_e( 'Add field', 'ova-brw' ); ?>
                        </button>
                        <input type="submit" class="button" name="remove" value="remove" />
                        <input type="submit" class="button" name="enable" value="enable" />
                        <input type="submit" class="button" name="disable" value="disable" />
                        <div class="ovabrw-loading">
                            <span class="dashicons dashicons-update-alt"></span>
                        </div>
                    </th>
                    <tr>
                        <th class="check-column">
                            <input 
                                type="checkbox" 
                                style="margin:0px 4px -1px -1px;" 
                                id="ovabrw_select_all_field" />
                        </th>
                        <th class="name"><?php esc_html_e( 'Name', 'ova-brw' ); ?></th>
                        <th class="id"><?php esc_html_e( 'Type', 'ova-brw' ); ?></th>
                        <th><?php esc_html_e( 'Label', 'ova-brw' ); ?></th>
                        <th><?php esc_html_e( 'Placeholder', 'ova-brw' ); ?></th>
                        <th class="status"><?php esc_html_e( 'Required', 'ova-brw' ); ?></th>
                        <th class="status"><?php esc_html_e( 'Enabled', 'ova-brw' ); ?></th>    
                        <th class="action"><?php esc_html_e( 'Edit', 'ova-brw' ); ?></th> 
                    </tr>
                </thead>
                <tbody class="ovabrw-sortable-ajax">
                    <?php if ( ! empty( $list_fields ) ): 
                        foreach ( $list_fields as $key => $field ):
                            $name               = $key;
                            $type               = array_key_exists( 'type', $field ) ? $field['type'] : '';
                            $max_file_size      = array_key_exists( 'max_file_size', $field ) ? $field['max_file_size'] : '';
                            $label              = array_key_exists( 'label', $field ) ? $field['label'] : '';
                            $description        = array_key_exists( 'description', $field ) ? $field['description'] : '';
                            $placeholder        = array_key_exists( 'placeholder', $field ) ? $field['placeholder'] : '';
                            $default            = array_key_exists( 'default', $field ) ? $field['default'] : '';
                            $min                = array_key_exists( 'min', $field ) ? $field['min'] : '';
                            $max                = array_key_exists( 'max', $field ) ? $field['max'] : '';
                            $default_date       = array_key_exists( 'default_date', $field ) ? $field['default_date'] : '';
                            $min_date           = array_key_exists( 'min_date', $field ) ? $field['min_date'] : '';
                            $max_date           = array_key_exists( 'max_date', $field ) ? $field['max_date'] : '';
                            $class              = array_key_exists( 'class', $field ) ? $field['class'] : '';
                            $required           = array_key_exists( 'required', $field ) ? $field['required'] : '';
                            $enabled            = array_key_exists( 'enabled', $field ) ? $field['enabled'] : '';
                            $ova_options_key    = array_key_exists( 'ova_options_key', $field ) ? $field['ova_options_key'] : [];
                            $ova_options_text   = array_key_exists( 'ova_options_text', $field ) ? $field['ova_options_text'] : [];
                            $ova_options_price  = array_key_exists( 'ova_options_price', $field ) ? $field['ova_options_price'] : [];
                            $ova_options_qty  = array_key_exists( 'ova_options_qty', $field ) ? $field['ova_options_qty'] : [];
                            $ova_values         = array_key_exists( 'ova_values', $field ) ? $field['ova_values'] : [];
                            $ova_prices         = array_key_exists( 'ova_prices', $field ) ? $field['ova_prices'] : [];
                            $ova_qtys           = array_key_exists( 'ova_qtys', $field ) ? $field['ova_qtys'] : [];
                            $ova_checkbox_key   = array_key_exists( 'ova_checkbox_key', $field ) ? $field['ova_checkbox_key'] : [];
                            $ova_checkbox_text  = array_key_exists( 'ova_checkbox_text', $field ) ? $field['ova_checkbox_text'] : [];
                            $ova_checkbox_price = array_key_exists( 'ova_checkbox_price', $field ) ? $field['ova_checkbox_price'] : [];
                            $ova_checkbox_qty   = array_key_exists( 'ova_checkbox_qty', $field ) ? $field['ova_checkbox_qty'] : [];
                            $required_status    = $required ? '<span class="dashicons dashicons-yes tips" data-tip="Yes"></span>' : '-';
                            $enabled_status     = $enabled ? '<span class="dashicons dashicons-yes tips" data-tip="Yes"></span>' : '-';
                            $class_disable  = ! $enabled ? 'class="ova-disable"' : '';
                            $disable_button = ! $enabled ? 'disabled' : '';
                            $value_enabled  = $enabled == 'on' ? $name : '';
                            
                            $data_edit = [
                                'name'                  => $name,
                                'type'                  => $type,
                                'max_file_size'         => $max_file_size,
                                'label'                 => $label,
                                'description'           => $description,
                                'placeholder'           => $placeholder,
                                'default'               => $default,
                                'min'                   => $min,
                                'max'                   => $max,
                                'default_date'          => $default_date,
                                'min_date'              => $min_date,
                                'max_date'              => $max_date,
                                'class'                 => $class,
                                'ova_options_key'       => $ova_options_key,
                                'ova_options_text'      => $ova_options_text,
                                'ova_options_price'     => $ova_options_price,
                                'ova_options_qty'       => $ova_options_qty,
                                'ova_values'            => $ova_values,
                                'ova_prices'            => $ova_prices,
                                'ova_qtys'              => $ova_qtys,
                                'ova_checkbox_key'      => $ova_checkbox_key,
                                'ova_checkbox_text'     => $ova_checkbox_text,
                                'ova_checkbox_price'    => $ova_checkbox_price,
                                'ova_checkbox_qty'      => $ova_checkbox_qty,
                                'required'              => $required,
                                'enabled'               => $enabled
                            ];

                            $data_edit = json_encode( $data_edit );
                    ?>
                    <tr <?php echo $class_disable; ?>>
                        <input type="hidden" name="ovabrw_fields[]" value="<?php echo esc_attr( $name ); ?>">
                        <input type="hidden" name="remove_field[]" value="">
                        <input type="hidden" name="enable_field[]" value="<?php echo esc_attr( $value_enabled ); ?>">
                        <td class="ova-checkbox">
                            <input type="checkbox" name="select_field[]" value="<?php echo $name; ?>" />
                        </td>
                        <td class="ova-name"><?php echo esc_html( $key ); ?></td>
                        <td class="ova-type"><?php echo esc_html( $type ); ?></td>
                        <td class="ova-label"><?php echo esc_html( $label ); ?></td>
                        <td class="ova-placeholder"><?php echo esc_html( $placeholder ); ?></td>
                        <td class="ova-require status"><?php echo $required_status; ?></td>
                        <td class="ova-enable status"><?php echo $enabled_status; ?></td>
                        <td class="ova-edit edit">
                            <button type="button" <?php echo esc_attr( $disable_button ); ?> class="button ova-button ovabrw_edit_field_form" data-data_edit="<?php echo esc_attr( $data_edit ); ?>">
                                <?php esc_html_e( 'Edit', 'ova-brw' ); ?>
                            </button>
                        </td>
                    </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </form>
    </div>
    <div class="ova-wrap-popup-ckf">
        <div id="ova_new_field_form" title="<?php esc_html_e( 'New Checkout Field', 'ova-brw' ); ?>" class="ova-popup-wrapper">
            <a href="javascript:void(0)" class="close_popup" id="ovabrw_close_popup">X</a>
            <?php $this->ova_output_popup_form_fields( 'new', $list_fields ); ?>
        </div>
    </div>
    <input
        type="hidden"
        name="ovabrw-datepicker-options"
        value="<?php echo esc_attr( wp_json_encode( ovabrw_admin_datepicker_options() ) ); ?>"
    />
</div>