<?php defined( 'ABSPATH' ) || exit();

// Date format
$date_format = ovabrw_get_date_format();

// Time format
$time_format = ovabrw_get_time_format();

// Get all rental type
$product_ids = OVABRW()->options->get_product_ids_by_rental_type();

// Current product ID
$product_id = sanitize_text_field( ovabrw_get_meta_data( 'product_id', $_GET ) );

// Disable weekdays
$disable_weekdays = get_post_meta( $product_id, 'ovabrw_product_disable_week_day' );
if ( !$disable_weekdays ) {
    $disable_weekdays = get_option( 'ova_brw_calendar_disable_week_day', [] );
}
if ( ovabrw_array_exists( $disable_weekdays ) ) {
    $key = array_search( '7', $disable_weekdays );
    if ( $key !== false ) $disable_weekdays[$key] = '0';
} else {
    if ( $disable_weekdays && !is_array( $disable_weekdays ) ) {
        $disable_weekdays = explode( ',', $disable_weekdays );
        $disable_weekdays = array_map( 'trim', $disable_weekdays );
    }
}
// End

// Background disable date
$background_disable = get_option( 'ova_brw_bg_calendar', '#c4c4c4' );

?>
<div class="wrap">
    <div class="booking_filter">
        <form id="booking-filter" method="GET" action="<?php echo admin_url('/edit.php?post_type=product&page=ovabrw-check-product'); ?>">
            <h2><?php esc_html_e( 'Check Product', 'ova-brw' ); ?></h2>
    		<select name="product_id" required>
    			<option value="">
                    <?php esc_html_e( '-- Choose Product --', 'ova-brw' ); ?>
                </option>
                <?php if ( ovabrw_array_exists( $product_ids ) ):
                    foreach ( $product_ids as $p_id ):
                ?>
                    <option value="<?php echo esc_attr( $p_id ); ?>"<?php selected( $p_id, $product_id ); ?>>
                        <?php echo get_the_title( $p_id ); ?>
                    </option>
                <?php endforeach;
                endif; ?>
    		</select>
			<button type="submit" class="button">
                <?php esc_html_e( 'Display Schedule', 'ova-brw' ); ?>
            </button>
            <div class="total_vehicle">
                <?php esc_html_e( 'Total Vehicle','ova-brw' ); ?>:
                <?php echo get_post_meta( $product_id, 'ovabrw_car_count', true ); ?>
            </div>
            <input type="hidden" name="post_type" value="product">
            <input type="hidden" name="page" value="<?php echo esc_attr( $_REQUEST['page'] ); ?>">

            <?php if ( $product_id ):
                $booked_dates = OVABRW()->options->get_booked_dates( $product_id );
                if ( $booked_dates ) {
                    wp_localize_script( 'ovabrw-calendar-booking', 'ovaBookedDates', $booked_dates );
                }

                $toolbar_nav[]  = 'yes' == get_option( 'ova_brw_calendar_show_nav_month', 'yes' ) ? 'dayGridMonth' : '';
                $toolbar_nav[]  = 'yes' == get_option( 'ova_brw_calendar_show_nav_week', 'yes' ) ? 'timeGridWeek' : '';
                $toolbar_nav[]  = 'yes' == get_option( 'ova_brw_calendar_show_nav_day', 'yes' ) ? 'timeGridDay' : '';
                $toolbar_nav[]  = 'yes' == get_option( 'ova_brw_calendar_show_nav_list', 'yes' ) ? 'listWeek' : '';
                $show_time      = 'yes' == get_option( 'ova_brw_template_show_time_in_calendar', 'yes' ) ? '' : 'ova-hide-time-calendar';

                $nav    =  implode(',', array_filter( $toolbar_nav ) );
                $lang   = get_option( 'ova_brw_calendar_language_general', 'en-GB' );
                
                // WPML
                $current_lang = apply_filters( 'wpml_current_language', NULL );
                if ( $current_lang ) $lang = $current_lang;

                // Polylang
                if ( function_exists('pll_current_language') ) $lang = pll_current_language();

                // Default view
                $default_view = ( '' != get_option( 'ova_brw_calendar_default_view', 'dayGridMonth' ) ) ? get_option( 'ova_brw_calendar_default_view', 'dayGridMonth' ) : 'dayGridMonth';

                // First day
                $first_day = get_option( 'ova_brw_calendar_first_day', 1 );

                // Time step
                $time_step = get_option( 'ova_brw_booking_form_step_time', 30 );

                ?>
                <div class="ovabrw-wrap-calendar">
                    <div id="<?php echo esc_attr( 'calendar'.$product_id ); ?>" 
                        data-id="<?php echo esc_attr( 'calendar'.$product_id ); ?>"
                        class="ovabrw__product_calendar <?php echo esc_attr( $show_time ); ?>"  
                        data-lang="<?php echo esc_attr( $lang ); ?>" 
                        data-nav="<?php echo esc_attr( $nav ); ?>" 
                        data-default-view="<?php echo esc_attr( $default_view ); ?>" 
                        data-event-rows="<?php echo apply_filters( 'ovabrw_event_number_cell', 2 ); ?>"
                        data-disable-weekdays="<?php echo esc_attr( json_encode( $disable_weekdays ) ); ?>"
                        data-first-day="<?php echo esc_attr( $first_day ); ?>"
                        data-time-step="<?php echo esc_attr( $time_step ); ?>"
                        data-background-disable="<?php echo esc_attr( $background_disable ); ?>">
                        <ul class="intruction">
                            <li>
                                <span class="pink"></span>
                                <span class="white"></span>
                                <span>
                                    <?php esc_html_e( 'Available','ova-brw' ); ?>
                                </span>     
                            </li>
                            <li>
                                <span class="yellow" style="background: <?php echo esc_attr( $background_disable ); ?>" ></span>
                                <span><?php esc_html_e( 'Unavailable', 'ova-brw' ); ?></span>   
                            </li>
                        </ul>
                    </div>
                </div>
            <?php endif; ?>
        </form>
        <div style="clear:both;"></div><br>
        <!-- Find Vehicle ID -->
        <form id="available-vehicle" method="GET" action="<?php echo admin_url('/edit.php?post_type=product&page=check-product'); ?>">
            <?php 
                $all_locations      = OVABRW()->options->get_all_location_ids();
                $from_day           = sanitize_text_field( ovabrw_get_meta_data( 'from_day', $_GET ) );
                $to_day             = sanitize_text_field( ovabrw_get_meta_data( 'to_day', $_GET ) );
                $pickup_location    = sanitize_text_field( ovabrw_get_meta_data( 'pickup_loc', $_GET ) );
                $from_day_new       = $from_day ? strtotime( $from_day ) : '';
                $to_day_new         = $to_day ? strtotime( $to_day ) : '';
                $number_vehicles    = 1;

                // Vehicles available
                $vehicles_available = [];

                if ( $product_id ) {
                    // Get Manage Vehicles
                    $manage_vehicles = get_post_meta( $product_id, 'ovabrw_manage_store', true );

                     // Set Pick-up, Drop-off Date again
                    $new_input_date   = ovabrw_new_input_date( $product_id, $from_day_new, $to_day_new, '', $pickup_location, '' );
                    $pickup_date_new  = $new_input_date['pickup_date_new'];
                    $pickoff_date_new = $new_input_date['pickoff_date_new'];

                    // Check Count Product in Order
                    $store_vehicle_rented  = ovabrw_vehicle_rented_in_order( $product_id, $from_day_new, $to_day_new );

                    if ( $manage_vehicles == 'store' ) {
                        $total_vehicle      = get_post_meta( $product_id, 'ovabrw_car_count', true );
                        $number_vehicles    = $total_vehicle - $store_vehicle_rented;
                    } else {
                        $ids_vehicle_available = ovabrw_get_ids_vehicle_available( $product_id, $store_vehicle_rented, array() );
                        $number_vehicles       = count( $ids_vehicle_available );
                    }

                    $ova_validate_manage_store = ova_validate_manage_store( $product_id, $pickup_date_new, $pickoff_date_new, $pickup_location, '', $passed = false, $validate = 'search', $number_vehicles ) ;

                    if ( $ova_validate_manage_store && $ova_validate_manage_store['status'] == true ) {
                        if ( 'store' == $manage_vehicles ) {
                            $vehicles_available = $ova_validate_manage_store['number_vehicle_available'];
                        } else {
                            $vehicles_available = array_unique( $ova_validate_manage_store['vehicle_availables'] );
                        }
                    }
                }
            ?>
            <h3><?php esc_html_e( 'Check Available','ova-brw' ); ?></h3>
            <select name="pickup_loc">
                <option value="" <?php selected( '', $pickup_location, 'selected'); ?>>
                    <?php esc_html_e( '-- Pick-up Location --', 'ova-brw' ); ?>
                </option>
                <?php if ( ovabrw_array_exists( $all_locations ) ):
                    foreach ( $all_locations as $location_id ): ?>
                        <option value="<?php echo esc_attr( get_the_title( $location_id ) ); ?>"<?php selected( get_the_title( $location_id ), $pickup_location ); ?>>
                            <?php echo esc_html( get_the_title( $location_id ) ); ?>
                        </option>
                    <?php endforeach;
                endif; ?>
            </select>
            <?php ovabrw_wp_text_input([
                'type'      => 'text',
                'id'        => ovabrw_unique_id( 'from_day' ),
                'class'     => 'start-date',
                'name'      => 'from_day',
                'value'     => $from_day,
                'data_type' => 'datetimepicker',
                'attrs'     => [
                    'data-date' => strtotime( $from_day ) ? date( $date_format, strtotime( $from_day ) ) : '',
                    'data-time' => strtotime( $from_day ) ? date( $time_format, strtotime( $from_day ) ) : ''
                ]
            ]); ?>
            <?php esc_html_e('to','ova-brw'); ?>
            <?php ovabrw_wp_text_input([
                'type'      => 'text',
                'id'        => ovabrw_unique_id( 'to_day' ),
                'class'     => 'end-date',
                'name'      => 'to_day',
                'value'     => $to_day,
                'data_type' => 'datetimepicker',
                'attrs'     => [
                    'data-date' => strtotime( $to_day ) ? date( $date_format, strtotime( $to_day ) ) : '',
                    'data-time' => strtotime( $to_day ) ? date( $time_format, strtotime( $to_day ) ) : ''
                ]
            ]); ?>
            <select name="product_id">
                <option value="">
                    <?php esc_html_e( '-- Choose Product --', 'ova-brw' ); ?>
                </option>
                <?php if ( ovabrw_array_exists( $product_ids ) ):
                    foreach ( $product_ids as $p_id ): ?>
                        <option value="<?php echo esc_attr( $p_id ); ?>"<?php selected( $p_id, $product_id ); ?>>
                            <?php echo get_the_title( $p_id ); ?>
                        </option>
                    <?php endforeach;
                endif; ?>
            </select>
            <button type="submit" class="button">
                <?php esc_html_e( 'Find Vehicle', 'ova-brw' ); ?>
            </button>
            <?php if ( $vehicles_available ): ?>
            <table class="vehicle_id_available">
                <thead>
                    <tr>
                        <td>
                            <strong>
                                <?php esc_html_e( 'Available Items', 'ova-brw' ); ?>
                            </strong>
                        </td>
                    </tr>
                </thead>
                <tbody>
                    <?php if ( 'store' == $manage_vehicles ): ?>
                        <tr>
                            <td>
                                <?php echo esc_html( $vehicles_available ); ?>
                            </td>
                        </tr>
                    <?php else:
                        foreach ( $vehicles_available as $value ): ?>
                            <tr>
                                <td><?php echo esc_html( $value ); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
            <?php else:
                esc_html_e( 'Not Found Vehicle','ova-brw' );
            endif; ?>
            <input
                type="hidden"
                name="ovabrw-datetimepicker-options"
                value="<?php echo esc_attr( wp_json_encode( ovabrw_admin_datetimepicker_options() ) ); ?>"
            />
            <input type="hidden" name="post_type" value="product">
            <input type="hidden" name="page" value="<?php echo esc_attr( $_REQUEST['page'] ); ?>">
        </form>
    </div>
</div>