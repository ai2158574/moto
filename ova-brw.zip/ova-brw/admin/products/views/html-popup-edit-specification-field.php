<?php defined( 'ABSPATH' ) || exit();
	// Get specifications
    $specifications = ovabrw_recursive_replace( '\\', '', get_option( 'ovabrw_specifications', [] ) );

    // Get data
    $label 		= isset( $specifications[$name]['label'] ) ? $specifications[$name]['label'] : '';
    $icon_font 	= isset( $specifications[$name]['icon-font'] ) ? $specifications[$name]['icon-font'] : '';
    $default 	= isset( $specifications[$name]['default'] ) ? $specifications[$name]['default'] : '';
    $class 		= isset( $specifications[$name]['class'] ) ? $specifications[$name]['class'] : '';
    $options 	= isset( $specifications[$name]['options'] ) ? $specifications[$name]['options'] : '';
    $enable 	= isset( $specifications[$name]['enable'] ) ? $specifications[$name]['enable'] : '';
    $show_label = isset( $specifications[$name]['show_label'] ) ? $specifications[$name]['show_label'] : '';
    $show_in_card = isset( $specifications[$name]['show_in_card'] ) ? $specifications[$name]['show_in_card'] : '';
?>

<form action="" method="post" id="ovabrw-popup-specification-form" enctype="multipart/form-data" autocomplete="off">
	<input
		type="hidden"
		name="ovabrw-specificaiton-action"
		value="<?php echo esc_attr( $action ); ?>"
	/>
	<button class="popup-specification-close">X</button>
	<table width="100%">
		<tbody>
			<?php add_action( 'ovabrw_before_popup_edit_specification', $action, $type, $name ); ?>
			<tr class="type">
				<td class="ovabrw-required label">
					<?php esc_html_e( 'Select type', 'ova-brw' ); ?>
				</td>
				<td>
					<select name="type" id="type" required>
						<?php foreach ( $this->get_types() as $t => $v ): ?>
							<option value="<?php echo esc_attr( $t ); ?>"<?php selected( $t, $type ); ?>>
								<?php echo esc_html( $v ); ?>
							</option>
						<?php endforeach; ?>
					</select>
				</td>
			</tr>
			<tr class="name">
				<td class="ovabrw-required label">
					<?php esc_html_e( 'Name', 'ova-brw' ); ?>
				</td>
				<td>
					<input
						type="text"
						name="name"
						value="<?php echo esc_attr( $name ); ?>"
						autocomplete="off"
						required
					/>
					<input
						type="hidden"
						name="old_name"
						value="<?php echo esc_attr( $name ); ?>"
						autocomplete="off"
						required
					/>
					<span>
						<em>
							<?php esc_html_e( 'Unique, only lowercase, not space', 'ova-brw' ); ?>
						</em>
					</span>
				</td>
			</tr>
			<tr class="label">
				<td class="ovabrw-required label">
					<?php esc_html_e( 'Label', 'ova-brw' ); ?>
				</td>
				<td>
					<input
						type="text"
						name="label"
						value="<?php echo esc_attr( $label ); ?>"
						autocomplete="off"
						required
					>
				</td>
			</tr>
			<?php if ( in_array( $type, ['radio', 'checkbox', 'select'] ) ): // Radio ?>
				<tr class="radio-options specification-options">
					<td class="label"><?php esc_html_e( 'Options(*)', 'ova-brw' ); ?></td>
					<td>
						<table class="widefat" width="100%">
							<thead>
								<tr>
									<th class="ovabrw-required">
										<?php esc_html_e( 'Options', 'ova-brw' ); ?>
									</th>
									<th><?php esc_html_e( 'Actions', 'ova-brw' ); ?></th>
								</tr>
							</thead>
							<tbody class="option-sortable">
							<?php if ( ! empty( $options ) && is_array( $options ) ): ?>
								<?php foreach ( $options as $v ): ?>
									<tr>
										<td>
											<input
												type="text"
												name="options[]"
												value="<?php echo esc_attr( $v ); ?>"
												autocomplete="off"
												required
											/>
										</td>
										<td>
											<span class="btn btn-add-new">+</span>
											<span class="btn btn-add-remove">x</span>
											<span class="dashicons dashicons-menu-alt3"></span>
										</td>
									</tr>
								<?php endforeach; ?>
							<?php else: ?>
								<tr>
									<td>
										<input type="text" name="options[]" autocomplete="off" required>
									</td>
									<td>
										<span class="btn btn-add-new">+</span>
										<span class="btn btn-add-remove">x</span>
										<span class="dashicons dashicons-menu-alt3"></span>
									</td>
								</tr>
							<?php endif; ?>
							</tbody>
						</table>
					</td>
				</tr>
			<?php endif; // End radio ?>
			<tr class="icon-font">
				<td class="label"><?php esc_html_e( 'Icon font', 'ova-brw' ); ?></td>
				<td>
					<input
						type="text"
						name="icon-font"
						value="<?php echo esc_attr( $icon_font ); ?>"
						autocomplete="off"
					>
					<span>
						<em>
							<?php esc_html_e( 'Please enter an icon font class (e.g: flaticon-users)', 'ova-brw' ); ?>
						</em>
					</span>
				</td>
			</tr>
			<tr class="default">
				<td class="label"><?php esc_html_e( 'Default', 'ova-brw' ); ?></td>
				<td>
					<?php if ( $type === 'date' ): ?>
						<input
							type="text"
							id="<?php echo esc_attr( ovabrw_unique_id( 'specification_date' ) ); ?>"
							class="ovabrw-datepicker"
							name="default"
							autocomplete="off"
							value="<?php echo esc_attr( $default ); ?>"
						/>
					<?php elseif ( $type === 'link' ): ?>
						<input
							type="url"
							name="default"
							autocomplete="off"
							value="<?php echo esc_url( $default ); ?>"
						/>
					<?php elseif ( $type === 'number' ): ?>
						<input
							type="number"
							name="default"
							autocomplete="off"
							value="<?php echo esc_attr( $default ); ?>"
						/>
					<?php elseif ( $type === 'email' ): ?>
						<input
							type="email"
							name="default"
							autocomplete="off"
							value="<?php echo esc_attr( $default ); ?>"
						/>
					<?php elseif ( $type === 'color' ): ?>
						<input
							type="color"
							name="default"
							value="<?php echo esc_attr( $default ); ?>"
						/>
					<?php elseif ( $type === 'file' ):
						$attachment_title = $attachment_url = '';

						if ( $default ) {
							$attachment_title 	= get_the_title( $default );
							$attachment_url 	= get_edit_post_link( $default );
						}
					?>
						<button class="button button-primary specification-add-file">
							<?php esc_html_e( 'Add file', 'ova-brw' ); ?>
						</button>
						<p class="file-default" style="<?php echo $default ? 'display: block;' : ''; ?>">
							<a href="<?php echo esc_url( $attachment_url ); ?>" target="_blank">
								<?php echo esc_html( $attachment_title ); ?>
							</a>
							<button class="btn">X</button>
						</p>
						<input
							type="hidden"
							name="default"
							value="<?php echo esc_attr( $default ); ?>"
						/>
					<?php else: ?>
						<input
							type="text"
							autocomplete="off"
							name="default"
							value="<?php echo esc_attr( $default ); ?>"
						/>
					<?php endif; ?>
				</td>
			</tr>
			<tr class="class">
				<td class="label"><?php esc_html_e( 'Class', 'ova-brw' ); ?></td>
				<td>
					<input
						type="text"
						name="class"
						value="<?php echo esc_attr( $class ); ?>"
					>
				</td>
			</tr>
			<?php add_action( 'ovabrw_after_popup_edit_specification', $action, $type, $name ); ?>
			<tr class="status">
				<td class="label"></td>
				<td>
					<?php if ( $type === 'select' ):
						$multiple = isset( $specifications[$name]['multiple'] ) ? $specifications[$name]['multiple'] : '';
					?>
						<label>
							<input type="checkbox" name="multiple"<?php checked( 'on', $multiple ); ?>>
							<?php esc_html_e( 'Multiple', 'ova-brw' ); ?>
						</label>
					<?php endif; ?>
					<label>
						<input type="checkbox" name="enable"<?php checked( 'on', $enable ); ?>>
						<?php esc_html_e( 'Enable', 'ova-brw' ); ?>
					</label>
					<label>
						<input type="checkbox" name="show_label"<?php checked( 'on', $show_label ); ?>>
						<?php esc_html_e( 'Show label', 'ova-brw' ); ?>
					</label>
					<label>
						<input type="checkbox" name="show_in_card" <?php checked( 'on', $show_in_card ); ?>>
						<?php esc_html_e( 'Show in Card template', 'ova-brw' ); ?>
					</label>
				</td>
			</tr>
		</tbody>
	</table>
	<button type="submit" class="button button-primary"><?php esc_html_e( 'Save', 'ova-brw' ); ?></button>
</form>