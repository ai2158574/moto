<?php if ( ! defined( 'ABSPATH' ) ) exit(); ?>

<form method="post" id="ova_popup_field_form" action="" autocomplete="off">
    <input
        type="hidden"
        name="ova_action"
        value="<?php echo isset( $form_type ) ? esc_attr( $form_type ) : ''; ?>"
    />
    <input type="hidden" name="ova_old_name">
    <input type="hidden" name="ova_old_slug">
    <table width="100%">
        <tr><td colspan="2" class="err_msgs"></td></tr>
        <tr class="ova-row-slug">
            <td class="ovabrw-required label">
                <?php esc_html_e( 'Slug', 'ova-brw' ); ?>
            </td>
            <td>
                <input
                    type="text"
                    name="slug"
                    placeholder="<?php esc_html_e( 'taxonomy_1', 'ova-brw' ); ?>"
                    required
                />
                <br>
                <span>
                    <?php esc_html_e( 'Taxonomy key, must not exceed 32 characters', 'ova-brw' ); ?>
                </span>
            </td>
        </tr>
        <tr class="ova-row-name">
            <td class="ovabrw-required label">
                <?php esc_html_e( 'Name', 'ova-brw' ); ?>
            </td>
            <td>
                <input
                    type="text"
                    name="name"
                    placeholder="<?php esc_html_e( 'Taxonomys 1', 'ova-brw' ); ?>"
                    required
                />
            </td>
        </tr>
        <tr class="ova-row-sigular-name">
            <td class="label">
                <?php esc_html_e( 'Singular name', 'ova-brw' ); ?>
            </td>
            <td>
                <input
                    type="text"
                    name="singular_name"
                    placeholder="<?php esc_html_e( 'Taxonomy 1', 'ova-brw' ); ?>"
                />
            </td>
        </tr>
        <tr class="ova-row-label-frontend">
            <td class="label">
                <?php esc_html_e( 'Label frontend', 'ova-brw' ); ?>
            </td>
            <td>
                <input
                    type="text"
                    name="label_frontend"
                    placeholder="<?php esc_html_e( 'Label', 'ova-brw' ); ?>"
                />
            </td>
        </tr>
        <tr class="row-required">
            <td>&nbsp;</td>
            <td class="check-box">
                <input
                    id="ova_enable"
                    type="checkbox"
                    name="enabled"
                    value="on"
                    checked
                />
                <label for="ova_enable">
                    <?php esc_html_e( 'Enable', 'ova-brw' ); ?>
                </label>
                <br/>
            </td>                     
            <td class="label"></td>
        </tr>
        <tr class="row-show-listing">
            <td>&nbsp;</td>
            <td class="check-box">
                <input
                    id="show_listing"
                    type="checkbox"
                    name="show_listing"
                    value="on"
                    checked
                />
                <label>
                    <?php esc_html_e( 'Show in Listing', 'ova-brw' ); ?>
                </label>
                <br/>
            </td>                     
            <td class="label"></td>
        </tr>
    </table>
    <button type='submit' class="button button-primary">
        <?php esc_html_e( 'Save', 'ova-brw' ); ?>
    </button>
</form>