<?php defined( 'ABSPATH' ) || exit();

if ( ! class_exists( 'OVABRW_Admin_Specifications' ) ) {
	class OVABRW_Admin_Specifications {
        protected static $_instance = null;

		public function __construct() {
            // Admin Menu
            add_action('admin_menu', array( $this, 'ovabrw_add_menu' ) );
        }

        public function ovabrw_add_menu() {
        	add_submenu_page(
                'edit.php?post_type=product',
                __( 'Specifications', 'ova-brw' ),
                __( 'Specifications', 'ova-brw' ),
                apply_filters( 'ovabrw_add_specification_capability' ,'edit_posts' ),
                'ovabrw-specifications',
                array( $this, 'ovabrw_html_specification' )
            );
        }

        public function ovabrw_html_specification() {
        	include( OVABRW_PLUGIN_PATH.'admin/products/views/html-specifications.php' );
        }

        public function ovavbrw_popup_specification_field( $action = 'new', $type = 'text', $name = '' ) {
            if ( $action === 'edit' ) {
                include( OVABRW_PLUGIN_PATH.'admin/products/views/html-popup-edit-specification-field.php' );
            } else {
                include( OVABRW_PLUGIN_PATH.'admin/products/views/html-popup-add-specification-field.php' );
            }
        }

        public function ovabrw_sanitize_keys( $args = [], $default = [] ) {
            if ( empty( $args ) || ! is_array( $args ) ) return $args;

            foreach ( $args as $k => $v ) {
                if ( ! $v && isset( $default[$k] ) && $default[$k] ) {
                    $v = $default[$k];
                }

                $args[$k] = sanitize_text_field( sanitize_title( $v ) );
            }

            return $args;
        }

        public function get_types() {
            $types = array(
                'text'      => esc_html__( 'Text', 'ova-brw' ),
                'link'      => esc_html__( 'Link', 'ova-brw' ),
                'number'    => esc_html__( 'Number', 'ova-brw' ),
                'tel'       => esc_html__( 'Tel', 'ova-brw' ),
                'email'     => esc_html__( 'Email', 'ova-brw' ),
                'radio'     => esc_html__( 'Radio', 'ova-brw' ),
                'checkbox'  => esc_html__( 'Checkbox', 'ova-brw' ),
                'select'    => esc_html__( 'Select', 'ova-brw' ),
                'date'      => esc_html__( 'Date', 'ova-brw' ),
                'color'     => esc_html__( 'Color', 'ova-brw' ),
                'file'      => esc_html__( 'File', 'ova-brw' )
            );

            return apply_filters( 'ovabrw_specification_get_types', $types );
        }

        // Add
        public function add( $post = [] ) {
            if ( ! empty( $post ) && current_user_can('publish_posts') ) {
                // Get specifications
                $specifications = ovabrw_recursive_replace( '\\', '', get_option( 'ovabrw_specifications', [] ) );

                // Get name
                $name = isset( $post['name'] ) ? sanitize_text_field( sanitize_title( $post['name'] ) ) : '';

                if ( $name ) {
                    // Basic
                    $specifications[$name] = array(
                        'type'          => isset( $post['type'] ) ? $post['type'] : '',
                        'label'         => isset( $post['label'] ) ? $post['label'] : '',
                        'icon-font'     => isset( $post['icon-font'] ) ? $post['icon-font'] : '',
                        'default'       => isset( $post['default'] ) ? $post['default'] : '',
                        'class'         => isset( $post['class'] ) ? $post['class'] : '',
                        'enable'        => isset( $post['enable'] ) ? $post['enable'] : '',
                        'show_label'    => isset( $post['show_label'] ) ? $post['show_label'] : '',
                        'show_in_card'  => isset( $post['show_in_card'] ) ? $post['show_in_card'] : '',
                    );

                    // Options
                    if ( isset( $post['options'] ) && $post['options'] ) {
                        $specifications[$name]['options'] = $post['options'];
                    }

                    // Multiple
                    if ( isset( $post['multiple'] ) && $post['multiple'] ) {
                        $specifications[$name]['multiple'] = $post['multiple'];
                    }
                }

                update_option( 'ovabrw_specifications', $specifications );
            }

            // Refresh
            wp_safe_redirect( $_SERVER['HTTP_REFERER'] );
        }

        // Edit
        public function edit( $post = [] ) {
            if ( ! empty( $post ) && current_user_can('publish_posts') ) {
                // Get specifications
                $specifications = ovabrw_recursive_replace( '\\', '', get_option( 'ovabrw_specifications', [] ) );

                // Get name
                $new_name = isset( $post['name'] ) ? sanitize_text_field( sanitize_title( $post['name'] ) ) : '';
                $old_name = isset( $post['old_name'] ) ? sanitize_text_field( $post['old_name'] ) : '';

                if ( $new_name && $old_name ) {
                    $data = array(
                        'type'          => isset( $post['type'] ) ? $post['type'] : '',
                        'label'         => isset( $post['label'] ) ? $post['label'] : '',
                        'icon-font'     => isset( $post['icon-font'] ) ? $post['icon-font'] : '',
                        'default'       => isset( $post['default'] ) ? $post['default'] : '',
                        'class'         => isset( $post['class'] ) ? $post['class'] : '',
                        'enable'        => isset( $post['enable'] ) ? $post['enable'] : '',
                        'show_label'    => isset( $post['show_label'] ) ? $post['show_label'] : '',
                        'show_in_card'  => isset( $post['show_in_card'] ) ? $post['show_in_card'] : '',
                    );

                    // Options
                    if ( isset( $post['options'] ) && $post['options'] ) {
                        $data['options'] = $post['options'];
                    }

                    // Multiple
                    if ( isset( $post['multiple'] ) && $post['multiple'] ) {
                        $data['multiple'] = $post['multiple'];
                    }

                    // Change name
                    if ( $new_name != $old_name ) {
                        $specifications = array_map(function ($key, $value) use ($old_name, $new_name) {
                            if ( $key === $old_name ) {
                                return [$new_name => $value];
                            }

                            return [$key => $value];
                        }, array_keys($specifications), $specifications);

                        $specifications = call_user_func_array('array_merge', $specifications);

                        $specifications[$new_name] = $data;
                    } else {
                        $specifications[$old_name] = $data;
                    }
                }

                update_option( 'ovabrw_specifications', $specifications );
            }

            // Refresh
            wp_safe_redirect( $_SERVER['HTTP_REFERER'] );
        }

        // Delete
        public function delete( $post = [] ) {
            if ( ! empty( $post ) && current_user_can('publish_posts') ) {
                // Get specifications
                $specifications = ovabrw_recursive_replace( '\\', '', get_option( 'ovabrw_specifications', [] ) );

                $fields = isset( $post['fields'] ) ? $post['fields'] : '';

                if ( ! empty( $fields ) && is_array( $fields ) ) {
                    foreach ( $fields as $name ) {
                        // remove field from specifications
                        if ( isset( $specifications[$name] ) ) unset($specifications[$name]);
                    }
                }

                update_option( 'ovabrw_specifications', $specifications );
            }

            // Refresh
            if ( ! wp_doing_ajax() ) wp_safe_redirect( $_SERVER['HTTP_REFERER'] );
        }

        // Enable
        public function enable( $post = [] ) {
            if ( ! empty( $post ) && current_user_can('publish_posts') ) {
                // Get specifications
                $specifications = ovabrw_recursive_replace( '\\', '', get_option( 'ovabrw_specifications', [] ) );

                $fields = isset( $post['fields'] ) ? $post['fields'] : '';

                if ( ! empty( $fields ) && is_array( $fields ) ) {
                    foreach ( $fields as $name ) {
                        // remove field from specifications
                        if ( isset( $specifications[$name]['enable'] ) ) {
                            $specifications[$name]['enable'] = 'on';
                        }
                    }
                }

                update_option( 'ovabrw_specifications', $specifications );
            }

            // Refresh
            if ( ! wp_doing_ajax() ) wp_safe_redirect( $_SERVER['HTTP_REFERER'] );
        }

        // Disable
        public function disable( $post = [] ) {
            if ( ! empty( $post ) && current_user_can('publish_posts') ) {
                // Get specifications
                $specifications = ovabrw_recursive_replace( '\\', '', get_option( 'ovabrw_specifications', [] ) );

                $fields = isset( $post['fields'] ) ? $post['fields'] : '';

                if ( ! empty( $fields ) && is_array( $fields ) ) {
                    foreach ( $fields as $name ) {
                        // remove field from specifications
                        if ( isset( $specifications[$name]['enable'] ) ) {
                            $specifications[$name]['enable'] = '';
                        }
                    }
                }

                update_option( 'ovabrw_specifications', $specifications );
            }

            // Refresh
            if ( ! wp_doing_ajax() ) wp_safe_redirect( $_SERVER['HTTP_REFERER'] );
        }

        // Sort
        public function sort( $args = [] ) {
            $fields = isset( $args['fields'] ) ? $args['fields'] : [];

            if ( ! empty( $fields ) && current_user_can('publish_posts') ) {
                // Get specifications
                $specifications = ovabrw_recursive_replace( '\\', '', get_option( 'ovabrw_specifications', [] ) );

                // New data
                $new_data = [];

                foreach ( $fields as $name ) {
                    if ( $name && array_key_exists( $name, $specifications ) ) {
                        $new_data[$name] = $specifications[$name];
                    }
                }

                if ( ! empty( $new_data ) && is_array( $new_data ) ) {
                    update_option( 'ovabrw_specifications', $new_data );
                }
            }
        }

        public static function instance() {
            if ( is_null( self::$_instance ) ) {
                self::$_instance = new self();
            }

            return self::$_instance;
        }
	}

	new OVABRW_Admin_Specifications();
}