<?php defined( 'ABSPATH' ) || exit;

/**
 * Output a text input box.
 *
 * @param array $field field data.
 */
if ( !function_exists( 'ovabrw_wp_text_input' ) ) {
	function ovabrw_wp_text_input( $field ) {
		$field['type'] 			= ovabrw_get_meta_data( 'type', $field );
		$field['id'] 			= ovabrw_get_meta_data( 'id', $field );
		$field['class'] 		= ovabrw_get_meta_data( 'class', $field );
		$field['name'] 			= ovabrw_get_meta_data( 'name', $field );
		$field['value'] 		= ovabrw_get_meta_data( 'value', $field );
		$field['placeholder']   = ovabrw_get_meta_data( 'placeholder', $field );
		$field['required'] 		= ovabrw_get_meta_data( 'required', $field );
		$field['readonly'] 		= ovabrw_get_meta_data( 'readonly', $field );
		
		// Data type
		$data_type = ovabrw_get_meta_data( 'data_type', $field );

		switch ( $data_type ) {
			case 'price':
				// Add class
				$field['class'] .= ' wc_input_price';

				// Convert value
				$field['value'] = wc_format_localized_price( $field['value'] );

				// Placeholder
				if ( ! $field['placeholder'] ) {
					$field['placeholder'] = esc_html__( 'price', 'ova-brw' );
				}
				break;
			case 'decimal':
				// Add class
				$field['class'] .= ' wc_input_decimal';

				// Convert value
				$field['value'] = wc_format_localized_decimal( $field['value'] );

				// Placeholder
				if ( ! $field['placeholder'] ) {
					$field['placeholder'] = esc_html__( 'price', 'ova-brw' );
				}
				break;
			case 'timepicker':
				// Add class
				$field['class'] .= ' ovabrw-timepicker';

				// Time format
				$time_format = ovabrw_get_time_format();

				// Convert value
				$field['value'] = strtotime( $field['value'] ) ? date( $time_format, strtotime( $field['value'] ) ) : '';

				// Placeholder
				if ( ! $field['placeholder'] ) {
					$field['placeholder'] = ovabrw_get_time_placeholder();
				}
				break;
			case 'datepicker':
				// Add class
				$field['class'] .= ' ovabrw-datepicker';

				// Date format
				$date_format = ovabrw_get_date_format();

				// Convert valie
				$field['value'] = strtotime( $field['value'] ) ? date( $date_format, strtotime( $field['value'] ) ) : '';

				// Placeholder
				if ( ! $field['placeholder'] ) {
					$field['placeholder'] = ovabrw_get_date_placeholder();
				}
				break;
			case 'datetimepicker':
				// Add class
				$field['class'] .= ' ovabrw-datetimepicker';

				// Get date time format
				$datetime_format = ovabrw_get_date_format() . ' ' . ovabrw_get_time_format();

				// Convert value
				$field['value'] = strtotime( $field['value'] ) ? date( $datetime_format, strtotime( $field['value'] ) ) : '';

				// Placeholder
				if ( ! $field['placeholder'] ) {
					$field['placeholder'] = ovabrw_get_date_placeholder() . ' ' . ovabrw_get_time_placeholder();
				}
				break;
			case 'number':
				// Convert value
				$field['value'] = '' !== $field['value'] ? (int)$field['value'] : '';

				// Placeholder
				if ( ! $field['placeholder'] ) {
					$field['placeholder'] = esc_html__( 'number', 'ova-brw' );
				}
			default:
				break;
		}

		// Custom attribute handling
		$attrs = array();

		if ( ! empty( $field['attrs'] ) && is_array( $field['attrs'] ) ) {
			foreach ( $field['attrs'] as $attr => $value ) {
				if ( $value === '' ) continue;
				$attrs[] = esc_attr( $attr ) . '="' . esc_attr( $value ) . '"';
			}
		}

		// Required
		if ( $field['required'] ) {
			$attrs[] = 'required';
		}

		// Read only
		if ( $field['readonly'] ) {
			$attrs[] = 'readonly';
		}

		do_action( 'ovabrw_before_wp_text_input', $field );

		echo '<input type="' . esc_attr( $field['type'] ) . '" id="' . esc_attr( $field['id'] ) . '" class="' . esc_attr( $field['class'] ) . '" name="' . esc_attr( $field['name'] ) . '" value="' . esc_attr( $field['value'] ) . '" placeholder="' . esc_attr( $field['placeholder'] ) . '" ' . wp_kses_post( implode( ' ', $attrs ) ) . ' /> ';

		do_action( 'ovabrw_after_wp_text_input', $field );
	}
}

/**
 * Output a selext input box.
 *
 * @param array $field field data.
 */
if ( !function_exists( 'ovabrw_wp_select_input' ) ) {
	function ovabrw_wp_select_input( $field ) {
		$field['id'] 			= ovabrw_get_meta_data( 'id', $field );
		$field['class'] 		= ovabrw_get_meta_data( 'class', $field );
		$field['name'] 			= ovabrw_get_meta_data( 'name', $field );
		$field['value'] 		= ovabrw_get_meta_data( 'value', $field );
		$field['placeholder'] 	= ovabrw_get_meta_data( 'placeholder', $field );
		$field['options'] 		= ovabrw_get_meta_data( 'options', $field );
		$field['attrs'] 		= ovabrw_get_meta_data( 'attrs', $field );

		// Custom attribute handling
		$attrs = array();

		if ( ovabrw_array_exists( $field['attrs'] ) ) {
			foreach ( $field['attrs'] as $attr => $value ) {
				$attrs[] = esc_attr( $attr ) . '="' . esc_attr( $value ) . '"';
			}
		}

		do_action( 'ovabrw_before_wp_select_input', $field );
		?>
		<select
			name="<?php echo esc_attr( $field['name'] ); ?>"
			id="<?php echo esc_attr( $field['id'] ); ?>"
			class="<?php echo esc_attr( $field['class'] ); ?>"
			<?php echo wp_kses_post( implode( ' ', $attrs ) ); ?>>
			<?php if ( $field['placeholder'] ): ?>
				<option value="">
					<?php echo esc_html( $field['placeholder'] ); ?>
				</option>
			<?php endif; ?>
			<?php foreach ( $field['options'] as $key => $value ): ?>
				<option value="<?php echo esc_attr( $key ); ?>"<?php ovabrw_selected( $key, $field['value'] ); ?>>
					<?php echo esc_html( $value ); ?>
				</option>
			<?php endforeach; ?>
		</select>
		<?php
		do_action( 'ovabrw_before_wp_select_input', $field );
	}
}

/**
 * Get timepicker options
 * @return array
 */
if ( !function_exists( 'ovabrw_admin_timepicker_options' ) ) {
	function ovabrw_admin_timepicker_options() {
		return apply_filters( 'ovabrw_admin_timepicker_options', array(
			'timeFormat' 		=> ovabrw_get_time_format(),
			'step'				=> ovabrw_get_time_step(),
			'scrollDefault' 	=> '07:00',
	        'forceRoundTime' 	=> true,
	        'disableTextInput' 	=> true,
	        'autoPickTime' 		=> true,
	        'defaultStartTime' 	=> ovabrw_get_default_pickup_time(),
	        'defaultEndTime' 	=> ovabrw_get_default_dropoff_time(),
	        'allowTimes' 		=> [],
	        'allowStartTimes' 	=> ovabrw_get_pickup_group_time(),
	        'allowEndTimes' 	=> ovabrw_get_dropoff_group_time(),
	        'lang' 				=> apply_filters( 'ovabrw_admin_timepicker_options_lang', array(
	        	'am' 		=> 'am',
	        	'pm' 		=> 'pm',
	        	'AM' 		=> 'AM',
	        	'PM' 		=> 'PM',
	        	'decimal' 	=> '.',
	        	'mins' 		=> 'mins',
	        	'hr' 		=> 'hr',
	        	'hrs' 		=> 'hrs',
	        	'pickUp' 	=> esc_html__( 'Pick-up', 'ova-brw' ),
	        	'dropOff' 	=> esc_html__( 'Drop-off', 'ova-brw' )
	        ))
		));
	}
}

/**
 * Get datepicker options
 * @return array
 */
if ( !function_exists( 'ovabrw_admin_datepicker_options' ) ) {
	function ovabrw_admin_datepicker_options() {
		// Date format
		$date_format = ovabrw_get_date_format();

		// Min year, Max year
		$min_year = (int)get_option( 'ova_brw_booking_form_year_start', date('Y') );
		$max_year = (int)get_option( 'ova_brw_booking_form_year_end', date('Y')+3 );

		// Min date, Max date
		$min_date = $max_date = '';

		if ( $min_year ) {
			$min_date = date( $date_format, strtotime( "$min_year-01-01" ) );
		}
		if ( $max_year ) {
			$december_date = new DateTime("$max_year-12-01");
			$december_date->modify('last day of this month');

			// Get max date
			$max_date = $december_date->format($date_format);
		}

		// Start date when calendar show
		$start_date = '';

		if ( $min_date && strtotime( $min_date ) > current_time( 'timestamp' ) ) {
			$start_date = $min_date;
		}

		// Language
		$language = apply_filters( 'ovabrw_admin_datepicker_language', get_option( 'ova_brw_calendar_language_general', 'en-GB' ) );
		if ( apply_filters( 'wpml_current_language', NULL ) ) { // WPML
            $language = apply_filters( 'wpml_current_language', NULL );
        } elseif ( function_exists('pll_current_language') ) { // Polylang
            $language = pll_current_language();
        }

		// Disable weekdays
		$disable_weekdays = array();

		if ( apply_filters( 'ovabrw_admin_use_disable_weekdays', true ) ) {
			$disable_weekdays = get_option( 'ova_brw_calendar_disable_week_day', [] );

			if ( ovabrw_array_exists( $disable_weekdays ) ) {
	        	$key = array_search( '0', $disable_weekdays );
				if ( $key !== false ) $disable_weekdays[$key] = '7';
	        } else {
	        	if ( $disable_weekdays && !is_array( $disable_weekdays ) ) {
	        		$disable_weekdays = explode( ',', $disable_weekdays );
	        		$disable_weekdays = array_map( 'trim', $disable_weekdays );
	        	}
	        }
		}

		// Datepicker CSS
		$datepciker_css = array(
			OVABRW_PLUGIN_URI.'assets/libs/easepick/easepick.min.css',
			OVABRW_PLUGIN_URI.'assets/css/datepicker/datepicker.css'
		);

		// Get customize calendar
		$customize_calendar = get_option( OVABRW_PREFIX.'customize_calendar' );
		if ( 'yes' == $customize_calendar ) {
			$css_path = OVABRW_PLUGIN_PATH.'assets/css/datepicker/customize.css';

			if ( file_exists( $css_path ) ) {
				$datepciker_css[] = OVABRW_PLUGIN_URI.'assets/css/datepicker/customize.css';
			} else {
				$additional_css = get_option( OVABRW_PREFIX.'additional_css' );
				$numberof_byte 	= file_put_contents( OVABRW_PLUGIN_PATH.'assets/css/datepicker/customize.css', (string)$additional_css );

				if ( $numberof_byte ) {
					$datepciker_css[] = OVABRW_PLUGIN_URI.'assets/css/datepicker/customize.css';
				}
			}
		}

		return apply_filters( 'ovabrw_admin_datepicker_options', [
			'css' 			=> apply_filters( 'ovabrw_admin_datepicker_css', $datepciker_css ),
			'firstDay' 		=> (int)get_option( 'ova_brw_calendar_first_day', 1 ),
			'lang' 			=> $language,
			'format' 		=> $date_format,
			'grid' 			=> 2,
			'calendars' 	=> 2,
			'zIndex' 		=> 999999999,
			'inline' 		=> false,
			'readonly' 		=> true,
			'header' 		=> apply_filters( 'ovabrw_admin_datepicker_header', '' ),			
			'autoApply' 	=> true,
			'locale' 		=> apply_filters( 'ovabrw_admin_datepicker_locale', [
				'cancel' 	=> esc_html__( 'Cancel', 'ova-brw' ),
	        	'apply' 	=> esc_html__( 'Apply', 'ova-brw' )
			]),
			'AmpPlugin' 	=> apply_filters( 'ovabrw_admin_datepicker_amp_plugin', [
				'dropdown' 	=> [
					'months' 	=> true,
					'years' 	=> true,
					'minYear' 	=> $min_year ? $min_year : date('Y'),
					'maxYear' 	=> $max_year ? $max_year : date('Y')+3
				],
				'resetButton' 	=> true,
				'darkMode' 		=> false
			]),
			'RangePlugin' 	=> apply_filters( 'ovabrw_admin_datepicker_range_plugin', [
				'repick' 	=> false,
				'strict' 	=> true,
				'tooltip' 	=> true,
				'locale' 	=> [
					'zero' 	=> '',
					'one' 	=> esc_html__( 'day', 'ova-brw' ),
					'two' 	=> '',
					'many' 	=> '',
					'few' 	=> '',
					'other' => esc_html__( 'days', 'ova-brw' )
				]
			]),
			'LockPlugin' 	=> apply_filters( 'ovabrw_admin_datepicker_lock_plugin', [
				'minDate' 			=> $min_date,
				'maxDate' 			=> $max_date,
				'minDays' 			=> '',
				'maxDays' 			=> '',
				'selectForward' 	=> false,
				'selectBackward' 	=> false,
				'presets' 			=> false,
				'inseparable' 		=> false
			]),
			'PresetPlugin' 	=> apply_filters( 'ovabrw_admin_datepicker_preset_plugin', [
				'position' 		=> 'left',
				'customLabels' 	=> [
					'Today',
					'Yesterday',
					'Last 7 Days',
					'Last 30 Days',
					'This Month',
					'Last Month'
				],
				'customPreset' 	=> ovabrw_get_predefined_ranges()
			]),
			'plugins' => apply_filters( 'ovabrw_admin_datepicker_plugins', [
				'AmpPlugin',
				'RangePlugin',
				'LockPlugin',
				'PresetPlugin'
			]),
			'disableWeekDays' 	=> apply_filters( 'ovabrw_admin_datepicker_disable_weekdays', $disable_weekdays ),
			'disableDates' 		=> apply_filters( 'ovabrw_admin_datepicker_disable_dates', array() ),
			'bookedDates' 		=> apply_filters( 'ovabrw_admin_datepicker_booked_dates', array() ),
			'allowedDates' 		=> apply_filters( 'ovabrw_admin_datepicker_allowed_dates', array() ),
			'startDate' 		=> apply_filters( 'ovabrw_admin_datepicker_start_date', $start_date )
		]);
	}
}

/**
 * Get datetimepicker options
 * @return array
 */
if ( !function_exists( 'ovabrw_admin_datetimepicker_options' ) ) {
	function ovabrw_admin_datetimepicker_options() {
		// Date format
		$date_format = ovabrw_get_date_format();

		// Min year, Max year
		$min_year = (int)get_option( 'ova_brw_booking_form_year_start', date('Y') );
		$max_year = (int)get_option( 'ova_brw_booking_form_year_end', date('Y')+3 );

		// Min date, Max date
		$min_date = $max_date = '';

		if ( $min_year ) {
			$min_date = date( $date_format, strtotime( "$min_year-01-01" ) );
		}
		if ( $max_year ) {
			$december_date = new DateTime("$max_year-12-01");
			$december_date->modify('last day of this month');

			// Get max date
			$max_date = $december_date->format($date_format);
		}

		// Start date when calendar show
		$start_date = '';

		if ( $min_date && strtotime( $min_date ) > current_time( 'timestamp' ) ) {
			$start_date = $min_date;
		}

		// Language
		$language = apply_filters( 'ovabrw_admin_datepicker_language', get_option( 'ova_brw_calendar_language_general', 'en-GB' ) );
		if ( apply_filters( 'wpml_current_language', NULL ) ) { // WPML
            $language = apply_filters( 'wpml_current_language', NULL );
        } elseif ( function_exists('pll_current_language') ) { // Polylang
            $language = pll_current_language();
        }

		// Disable weekdays
		$disable_weekdays = array();

		if ( apply_filters( 'ovabrw_admin_use_disable_weekdays', true ) ) {
			$disable_weekdays = get_option( 'ova_brw_calendar_first_day', [] );
		}

		// Datepicker CSS
		$datepciker_css = array(
			OVABRW_PLUGIN_URI.'assets/libs/easepick/easepick.min.css',
			OVABRW_PLUGIN_URI.'assets/css/datepicker/datepicker.css'
		);

		// Get customize calendar
		$customize_calendar = get_option( OVABRW_PREFIX.'customize_calendar' );
		if ( 'yes' == $customize_calendar ) {
			$css_path = OVABRW_PLUGIN_PATH.'assets/css/datepicker/customize.css';

			if ( file_exists( $css_path ) ) {
				$datepciker_css[] = OVABRW_PLUGIN_URI.'assets/css/datepicker/customize.css';
			} else {
				$additional_css = get_option( OVABRW_PREFIX.'additional_css' );
				$numberof_byte 	= file_put_contents( OVABRW_PLUGIN_PATH.'assets/css/datepicker/customize.css', (string)$additional_css );

				if ( $numberof_byte ) {
					$datepciker_css[] = OVABRW_PLUGIN_URI.'assets/css/datepicker/customize.css';
				}
			}
		}

		return apply_filters( 'ovabrw_admin_datetimepicker_options', [
			'datepicker' => [
				'css' 			=> apply_filters( 'ovabrw_admin_datepicker_css', $datepciker_css ),
				'firstDay' 		=> (int)get_option( 'ova_brw_calendar_first_day', 1 ),
				'lang' 			=> $language,
				'format' 		=> $date_format,
				'grid' 			=> 2,
				'calendars' 	=> 2,
				'zIndex' 		=> 999999999,
				'inline' 		=> false,
				'readonly' 		=> true,
				'header' 		=> apply_filters( 'ovabrw_admin_datepicker_header', '' ),			
				'autoApply' 	=> false,
				'locale' 		=> apply_filters( 'ovabrw_admin_datepicker_locale', [
					'cancel' 	=> esc_html__( 'Cancel', 'ova-brw' ),
		        	'apply' 	=> esc_html__( 'Apply', 'ova-brw' )
				]),
				'AmpPlugin' 	=> apply_filters( 'ovabrw_admin_datepicker_amp_plugin', [
					'dropdown' 	=> [
						'months' 	=> true,
						'years' 	=> true,
						'minYear' 	=> $min_year ? $min_year : date('Y'),
						'maxYear' 	=> $max_year ? $max_year : date('Y')+3,
					],
					'resetButton' 	=> true,
					'darkMode' 		=> false
				]),
				'RangePlugin' 	=> apply_filters( 'ovabrw_admin_datepicker_range_plugin', [
					'repick' 	=> false,
					'strict' 	=> true,
					'tooltip' 	=> true,
					'locale' 	=> [
						'zero' 	=> '',
						'one' 	=> esc_html__( 'day', 'ova-brw' ),
						'two' 	=> '',
						'many' 	=> '',
						'few' 	=> '',
						'other' => esc_html__( 'days', 'ova-brw' )
					]
				]),
				'LockPlugin' 	=> apply_filters( 'ovabrw_admin_datepicker_lock_plugin', [
					'minDate' 			=> $min_date,
					'maxDate' 			=> $max_date,
					'minDays' 			=> '',
					'maxDays' 			=> '',
					'selectForward' 	=> false,
					'selectBackward' 	=> false,
					'presets' 			=> false,
					'inseparable' 		=> false
				]),
				'PresetPlugin' 	=> apply_filters( 'ovabrw_admin_datepicker_preset_plugin', [
					'position' 		=> 'left',
					'customLabels' 	=> [
						'Today',
						'Yesterday',
						'Last 7 Days',
						'Last 30 Days',
						'This Month',
						'Last Month'
					],
					'customPreset' 	=> ovabrw_get_predefined_ranges()
				]),
				'plugins' => apply_filters( 'ovabrw_admin_datepicker_plugins', [
					'AmpPlugin',
					'RangePlugin',
					'LockPlugin',
					'PresetPlugin',
					'TimePlugin'
				]),
				'disableWeekDays' 	=> apply_filters( 'ovabrw_admin_datepicker_disable_weekdays', $disable_weekdays ),
				'disableDates' 		=> apply_filters( 'ovabrw_admin_datepicker_disable_dates', array() ),
				'bookedDates' 		=> apply_filters( 'ovabrw_admin_datepicker_booked_dates', array() ),
				'allowedDates' 		=> apply_filters( 'ovabrw_admin_datepicker_allowed_dates', array() ),
				'startDate' 		=> apply_filters( 'ovabrw_admin_datepicker_start_date', $start_date )
			],
			'timepicker' => [
				'timeFormat' 		=> ovabrw_get_time_format(),
				'step'				=> ovabrw_get_time_step(),
				'scrollDefault' 	=> '07:00',
		        'forceRoundTime' 	=> true,
		        'disableTextInput' 	=> true,
		        'autoPickTime' 		=> true,
		        'useSelect' 		=> true,
		        'scrollSelect' 		=> '07:00',
		        'defaultStartTime' 	=> ovabrw_get_default_pickup_time(),
		        'defaultEndTime' 	=> ovabrw_get_default_dropoff_time(),
		        'allowTimes' 		=> [],
		        'allowStartTimes' 	=> ovabrw_get_pickup_group_time(),
		        'allowEndTimes' 	=> ovabrw_get_dropoff_group_time(),
		        'lang' 				=> apply_filters( 'ovabrw_admin_timepicker_options_lang', [
		        	'am' 		=> 'am',
		        	'pm' 		=> 'pm',
		        	'AM' 		=> 'AM',
		        	'PM' 		=> 'PM',
		        	'decimal' 	=> '.',
		        	'mins' 		=> 'mins',
		        	'hr' 		=> 'hr',
		        	'hrs' 		=> 'hrs',
		        	'pickUp' 	=> esc_html__( 'Pick-up', 'ova-brw' ),
		        	'dropOff' 	=> esc_html__( 'Drop-off', 'ova-brw' )
		        ])
			]
		]);
	}
}