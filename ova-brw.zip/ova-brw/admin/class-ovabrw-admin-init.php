<?php if ( ! defined( 'ABSPATH' ) ) exit();

if ( ! class_exists( 'OVABRW_Admin_Init' ) ) {
    class OVABRW_Admin_Init {
        public function __construct() {
            // Functions
            require_once ( OVABRW_PLUGIN_PATH . 'admin/class-ovabrw-admin-core-functions.php' );

            // Assets
            require_once( OVABRW_PLUGIN_PATH.'admin/class-ovabrw-admin-assets.php' );

            // Create Menu in Admin Woo
            if ( current_user_can( 'administrator' ) || current_user_can('edit_posts') ) {
                // Settings
                require_once( OVABRW_PLUGIN_PATH.'admin/settings/class-ovabrw-settings.php' );

                // Abstract
                require_once( OVABRW_PLUGIN_PATH.'admin/abstracts/abstract-ovabrw-admin-rental-types.php' );

                // Admin Ajax
                require_once( OVABRW_PLUGIN_PATH.'admin/class-ovabrw-admin-ajax.php' );
                
                // Orders
                require_once( OVABRW_PLUGIN_PATH.'admin/orders/class-ovabrw-list-orders.php' );
                require_once( OVABRW_PLUGIN_PATH.'admin/orders/class-ovabrw-orders.php' );

                // Check Product
                require_once( OVABRW_PLUGIN_PATH.'admin/products/class-ovabrw-check-product.php' );

                // Custom Checkout Fields
                require_once( OVABRW_PLUGIN_PATH.'admin/products/class-ovabrw-custom-checkout-fields.php' );

                // Specifications
                require_once( OVABRW_PLUGIN_PATH.'admin/products/class-ovabrw-specifications.php' );

                // Custom Taxonomies
                require_once( OVABRW_PLUGIN_PATH.'admin/products/class-ovabrw-custom-taxonomies.php' );

                // Import Locations
                require_once( OVABRW_PLUGIN_PATH.'admin/imports/class-ovabrw-import-locations.php' );

                // Categories
                require_once( OVABRW_PLUGIN_PATH.'admin/categories/class-ovabrw-category-fields.php' );

                // Add meta-boxes
                require_once( OVABRW_PLUGIN_PATH.'admin/class-ovabrw-admin-meta-boxes.php' );
            }
        }
    }

    new OVABRW_Admin_Init();
}