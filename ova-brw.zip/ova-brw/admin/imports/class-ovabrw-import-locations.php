<?php if ( ! defined( 'ABSPATH' ) ) exit();

if ( ! class_exists( 'OVABRW_Admin_Import_Locations' ) ) {
	class OVABRW_Admin_Import_Locations {
		public function __construct() {
			// Admin Menu
            add_action('admin_menu', array( $this, 'ovabrw_add_menu' ) );

            // Create new order manually
            add_action( 'admin_init', array( $this, 'ovabrw_import_locations_manully' ) );
		}

		public function ovabrw_add_menu() {
			add_submenu_page(
                'edit.php?post_type=product',
                __( 'Import Locations', 'ova-brw' ),
                __( 'Import Locations', 'ova-brw' ),
                apply_filters( 'ovabrw_import_locations_cap' ,'edit_posts' ),
                'ovabrw-import-location',
                array( $this, 'ovabrw_import_locations' )
            );
		}

		public function ovabrw_import_locations_manully() {
            $action = isset( $_POST['action_import'] ) && $_POST['action_import'] ? sanitize_text_field( $_POST['action_import'] ) : '';

            if ( $action === 'import_locations' ) {
                $product_id = isset( $_POST['product_id'] ) && $_POST['product_id'] ? absint( $_POST['product_id'] ) : '';

                // Check Permission
                if( !current_user_can( apply_filters( 'ovabrw_import_locations' ,'publish_posts' ) ) ){

                    echo    '<div class="notice notice-error is-dismissible" style="margin-left:200px;">
                                <h2>'.esc_html__( 'You don\'t have permission to import locations', 'ova-brw' ).'</h2>
                            </div>';
                    return;
                }

                if ( !$product_id ) {
                    $_POST['error'] = esc_html__( 'Please select a product', 'ova-brw' );
                    add_action( 'admin_notices', array( $this, 'ovabrw_show_admin_notice_error' ) );
                    return;
                }

                $file = isset( $_FILES['location_file'] ) && $_FILES['location_file'] ? $_FILES['location_file'] : '';
                    $upload_overrides = array(
                    'test_form' => false,
                    'mimes'     => array(
                        'csv' => 'text/csv',
                        'txt' => 'text/plain',
                    ),
                );

                try {
                    $upload = wp_handle_upload( $file, $upload_overrides );
                } catch ( Exception $e ) {
                    $_POST['error'] = $e->getMessage();
                    add_action( 'admin_notices', array( $this, 'ovabrw_show_admin_notice_error' ) );
                    return;
                }
                
                if ( isset( $upload['error'] ) && $upload['error'] ) {
                    $_POST['error'] = $upload['error'];
                    add_action( 'admin_notices', array( $this, 'ovabrw_show_admin_notice_error' ) );
                    return;
                } else {
                    // Construct the object array.
                    $object = array(
                        'post_title'     => basename( $upload['file'] ),
                        'post_content'   => $upload['url'],
                        'post_mime_type' => $upload['type'],
                        'guid'           => $upload['url'],
                        'context'        => 'import',
                        'post_status'    => 'private',
                    );

                    // Save the data.
                    $id = wp_insert_attachment( $object, $upload['file'] );
                    wp_schedule_single_event( time() + DAY_IN_SECONDS, 'importer_scheduled_cleanup', array( $id ) );

                    $file_url = $upload['file'];
                    $handle = fopen($file_url,"r");

                    while (!feof($handle) ) {
                        $data[] = fgetcsv($handle);
                    }
                    fclose($handle);

                    if ( !empty( $data ) && is_array( $data ) ) {
                        if ( count( $data ) === 1 ) {
                            $_POST['error'] = esc_html__( 'File empty!', 'ova-brw' );
                            add_action( 'admin_notices', array( $this, 'ovabrw_show_admin_notice_error' ) );
                            return;
                        } else {
                            array_shift($data);

                            $pickup_location    = array();
                            $dropoff_location   = array();
                            $location_time      = array();
                            $price_location     = array();

                            foreach( $data as $items ) {
                                $pickup_loc = isset( $items[0] ) && $items[0] ? $items[0] : '';
                                if ( !$pickup_loc ) {
                                    continue;
                                }
                                
                                $dropoff_loc = isset( $items[1] ) && $items[1] ? $items[1] : '';
                                if ( !$dropoff_loc ) {
                                    continue;
                                }
                                
                                $time_loc = isset( $items[2] ) && $items[2] ? floatval( $items[2] ) : '';
                                if ( !$time_loc ) {
                                    continue;
                                }

                                $price_loc = isset( $items[3] ) && $items[3] ? floatval( $items[3] ) : '';
                                if ( !$price_loc ) {
                                    continue;
                                }

                                array_push( $pickup_location , $pickup_loc );
                                array_push( $dropoff_location , $dropoff_loc );
                                array_push( $location_time , $time_loc );
                                array_push( $price_location , $price_loc );
                            }

                            if ( !empty( $pickup_location ) && !empty( $dropoff_location ) && !empty( $location_time ) && !empty( $price_location ) ) {
                                $update_pickup_location     = array();
                                $update_dropoff_location    = array();
                                $update_location_time       = array();
                                $update_price_location      = array();

                                $current_pickup_location    = get_post_meta( $product_id, 'ovabrw_pickup_location', true );
                                if ( !empty( $current_pickup_location ) && is_array( $current_pickup_location ) ) {
                                    $update_pickup_location = array_merge( $current_pickup_location, $pickup_location );
                                } else {
                                    $update_pickup_location = $pickup_location;
                                }

                                $current_dropoff_location = get_post_meta( $product_id, 'ovabrw_dropoff_location', true );
                                if ( !empty( $current_dropoff_location ) && is_array( $current_dropoff_location ) ) {
                                    $update_dropoff_location = array_merge( $current_dropoff_location, $dropoff_location );
                                } else {
                                    $update_dropoff_location = $dropoff_location;
                                }
                                
                                $current_location_time = get_post_meta( $product_id, 'ovabrw_location_time', true );
                                if ( !empty( $current_location_time ) && is_array( $current_location_time ) ) {
                                    $update_location_time = array_merge( $current_location_time, $location_time );
                                } else {
                                    $update_location_time = $location_time;
                                }

                                $current_price_location = get_post_meta( $product_id, 'ovabrw_price_location', true );
                                if ( !empty( $current_price_location ) && is_array( $current_price_location ) ) {
                                    $update_price_location = array_merge( $current_price_location, $price_location );
                                } else {
                                    $update_price_location = $price_location;
                                }

                                update_post_meta( $product_id, 'ovabrw_pickup_location', $update_pickup_location );
                                update_post_meta( $product_id, 'ovabrw_dropoff_location', $update_dropoff_location );
                                update_post_meta( $product_id, 'ovabrw_location_time', $update_location_time );
                                update_post_meta( $product_id, 'ovabrw_price_location', $update_price_location );

                                $_POST['success'] = esc_html__( 'Imported locations success!', 'ova-brw' );
                                add_action( 'admin_notices', array( $this, 'ovabrw_show_admin_notice_success' ) );
                                return;
                            } else {
                                $_POST['error'] = esc_html__( 'Imported locations fails!', 'ova-brw' );
                                add_action( 'admin_notices', array( $this, 'ovabrw_show_admin_notice_error' ) );
                                return;
                            }
                        }
                    } else {
                        $_POST['error'] = esc_html__( 'File empty!', 'ova-brw' );
                        add_action( 'admin_notices', array( $this, 'ovabrw_show_admin_notice_error' ) );
                        return;
                    }
                }
            }

            if ( $action === 'import_setup_locations' ) {

                $product_id = isset( $_POST['product_id'] ) && $_POST['product_id'] ? absint( $_POST['product_id'] ) : '';
                
                // Check Permission
                if( !current_user_can( apply_filters( 'ovabrw_import_locations' ,'publish_posts' ) ) ){

                    echo    '<div class="notice notice-error is-dismissible" style="margin-left:200px;">
                                <h2>'.esc_html__( 'You don\'t have permission to import locations', 'ova-brw' ).'</h2>
                            </div>';
                    return;
                }

                if ( !$product_id ) {
                    $_POST['error'] = esc_html__( 'Please select a product', 'ova-brw' );
                    add_action( 'admin_notices', array( $this, 'ovabrw_show_admin_notice_error' ) );
                    return;
                }

                $file = isset( $_FILES['location_file'] ) && $_FILES['location_file'] ? $_FILES['location_file'] : '';
                    $upload_overrides = array(
                    'test_form' => false,
                    'mimes'     => array(
                        'csv' => 'text/csv',
                        'txt' => 'text/plain',
                    ),
                );

                try {
                    $upload = wp_handle_upload( $file, $upload_overrides );
                } catch ( Exception $e ) {
                    $_POST['error'] = $e->getMessage();
                    add_action( 'admin_notices', array( $this, 'ovabrw_show_admin_notice_error' ) );
                    return;
                }
                
                if ( isset( $upload['error'] ) && $upload['error'] ) {
                    $_POST['error'] = $upload['error'];
                    add_action( 'admin_notices', array( $this, 'ovabrw_show_admin_notice_error' ) );
                    return;
                } else {
                    // Construct the object array.
                    $object = array(
                        'post_title'     => basename( $upload['file'] ),
                        'post_content'   => $upload['url'],
                        'post_mime_type' => $upload['type'],
                        'guid'           => $upload['url'],
                        'context'        => 'import',
                        'post_status'    => 'private',
                    );

                    // Save the data.
                    $id = wp_insert_attachment( $object, $upload['file'] );
                    wp_schedule_single_event( time() + DAY_IN_SECONDS, 'importer_scheduled_cleanup', array( $id ) );

                    $file_url = $upload['file'];
                    $handle = fopen($file_url,"r");

                    while (!feof($handle) ) {
                        $data[] = fgetcsv($handle);
                    }
                    fclose($handle);

                    if ( !empty( $data ) && is_array( $data ) ) {
                        if ( count( $data ) === 1 ) {
                            $_POST['error'] = esc_html__( 'File empty!', 'ova-brw' );
                            add_action( 'admin_notices', array( $this, 'ovabrw_show_admin_notice_error' ) );
                            return;
                        } else {
                            array_shift($data);

                            $st_pickup_loc  = array();
                            $st_dropoff_loc = array();

                            foreach( $data as $items ) {
                                $pickup_loc = isset( $items[0] ) && $items[0] ? $items[0] : '';
                                if ( !$pickup_loc ) {
                                    continue;
                                }
                                
                                $dropoff_loc = isset( $items[1] ) && $items[1] ? $items[1] : '';
                                if ( !$dropoff_loc ) {
                                    continue;
                                }

                                array_push( $st_pickup_loc , $pickup_loc );
                                array_push( $st_dropoff_loc , $dropoff_loc );
                            }

                            if ( !empty( $st_pickup_loc ) && !empty( $st_dropoff_loc ) ) {
                                $update_pickup_location     = array();
                                $update_dropoff_location    = array();

                                $current_pickup_location    = get_post_meta( $product_id, 'ovabrw_st_pickup_loc', true );
                                if ( !empty( $current_pickup_location ) && is_array( $current_pickup_location ) ) {
                                    $update_pickup_location = array_merge( $current_pickup_location, $st_pickup_loc );
                                } else {
                                    $update_pickup_location = $st_pickup_loc;
                                }

                                $current_dropoff_location = get_post_meta( $product_id, 'ovabrw_st_dropoff_loc', true );
                                if ( !empty( $current_dropoff_location ) && is_array( $current_dropoff_location ) ) {
                                    $update_dropoff_location = array_merge( $current_dropoff_location, $st_dropoff_loc );
                                } else {
                                    $update_dropoff_location = $st_dropoff_loc;
                                }
                                
                                update_post_meta( $product_id, 'ovabrw_st_pickup_loc', $update_pickup_location );
                                update_post_meta( $product_id, 'ovabrw_st_dropoff_loc', $update_dropoff_location );
                                
                                $_POST['success'] = esc_html__( 'Imported locations success!', 'ova-brw' );
                                add_action( 'admin_notices', array( $this, 'ovabrw_show_admin_notice_success' ) );
                                return;
                            } else {
                                $_POST['error'] = esc_html__( 'Imported locations fails!', 'ova-brw' );
                                add_action( 'admin_notices', array( $this, 'ovabrw_show_admin_notice_error' ) );
                                return;
                            }
                        }
                    } else {
                        $_POST['error'] = esc_html__( 'File empty!', 'ova-brw' );
                        add_action( 'admin_notices', array( $this, 'ovabrw_show_admin_notice_error' ) );
                        return;
                    }
                }
            }

            if ( $action === 'remove_locations' ) {

                // Check Permission
                if( !current_user_can( apply_filters( 'ovabrw_import_locations' ,'publish_posts' ) ) ){

                    echo    '<div class="notice notice-error is-dismissible" style="margin-left:200px;">
                                <h2>'.esc_html__( 'You don\'t have permission to remove locations', 'ova-brw' ).'</h2>
                            </div>';
                    return;
                }

                $product_id = isset( $_POST['product_id'] ) && $_POST['product_id'] ? absint( $_POST['product_id'] ) : '';
                if ( !$product_id ) {
                    $_POST['error'] = esc_html__( 'Please select a product', 'ova-brw' );
                    add_action( 'admin_notices', array( $this, 'ovabrw_show_admin_notice_error' ) );
                    return;
                }

                $product_type = get_post_meta( $product_id, 'ovabrw_price_type', true );

                if ( $product_type != 'transportation' ) {
                    update_post_meta( $product_id, 'ovabrw_st_pickup_loc', '' );
                    update_post_meta( $product_id, 'ovabrw_st_dropoff_loc', '' );
                } else {
                    update_post_meta( $product_id, 'ovabrw_pickup_location', '' );
                    update_post_meta( $product_id, 'ovabrw_dropoff_location', '' );
                    update_post_meta( $product_id, 'ovabrw_location_time', '' );
                    update_post_meta( $product_id, 'ovabrw_price_location', '' );
                }

                $_POST['success'] = esc_html__( 'Removed locations success!', 'ova-brw' );
                add_action( 'admin_notices', array( $this, 'ovabrw_show_admin_notice_success' ) );
                return;
            }
        }

		public function ovabrw_import_locations() {
			$all_rooms 		= OVABRW()->options->get_product_ids_by_rental_type();
			$all_locations 	= OVABRW()->options->get_product_ids_by_rental_type( 'transportation' );
			$all_products 	= OVABRW()->options->get_product_ids_by_rental_type( 'transportation', true );
			$bytes      	= wp_max_upload_size();
			$size       	= size_format( $bytes );
			$upload_dir 	= wp_upload_dir();

			?>
			<div class="ova-import-locations">
				<form class="import-locations" enctype="multipart/form-data" method="post">
					<h2 class="heading"><?php esc_html_e( 'Import locations from a CSV file', 'ova-brw' ); ?></h2>
	        		<select name="product_id">
	        			<option value="">
	                        <?php esc_html_e( '-- Choose Product --', 'ova-brw' ); ?>
	                    </option>
                        <?php
                            if ( ! empty( $all_locations ) && is_array( $all_locations ) ) {
                                foreach ( $all_locations as $p_id ) { ?>
                                    <option value="<?php echo esc_attr( $p_id ); ?>">
                                        <?php echo get_the_title( $p_id ); ?>
                                    </option>
                                <?php }
                            }
                        ?>
	        		</select>
					<p class="note"><?php esc_html_e( 'Only applicable for Rental: Transportation', 'ova-brw' ); ?></p>
					<div class="import-locations-fields">
						<h4 for="upload">
							<?php esc_html_e( 'Choose a CSV file from your computer:', 'ova-brw' ); ?>
						</h4>
						<input type="file" id="upload" name="location_file" size="25">
						<input type="hidden" name="action_import" value="import_locations">
						<input type="hidden" name="max_file_size" value="<?php echo esc_attr( $bytes ); ?>" />
						<br/>
						<span class="max-size">
							<?php
							printf(
								esc_html__( 'Maximum size: %s', 'ova-brw' ),
								esc_html( $size )
							);
							?>
						</span>
						<a href="<?php echo esc_url( OVABRW_PLUGIN_URI.'/admin/imports/demo.csv' ); ?>" class="demo" download>
							<?php esc_html_e( 'Demo file.csv', 'ova-brw' ); ?>
						</a>
					</div>
					<div class="import-locations-submit">
						<button type="submit" class="button">
							<?php esc_html_e( 'Import', 'ova-brw' ); ?>
						</button>
					</div>
				</form>
				<form class="import-setup-locations" enctype="multipart/form-data" method="post">
	        		<select name="product_id">
	        			<option value="">
	                        <?php esc_html_e( '-- Choose Product --', 'ova-brw' ); ?>
	                    </option>
                        <?php
                            if ( ! empty( $all_products ) && is_array( $all_products ) ) {
                                foreach ( $all_products as $p_id ) { ?>
                                    <option value="<?php echo esc_attr( $p_id ); ?>">
                                        <?php echo get_the_title( $p_id ); ?>
                                    </option>
                                <?php }
                            }
                        ?>
	        		</select>
					<p class="note"><?php esc_html_e( 'Only applicable for Rental: Day, Hour, Mixed, Period of Time', 'ova-brw' ); ?></p>
					<div class="import-locations-fields">
						<h4 for="upload">
							<?php esc_html_e( 'Choose a CSV file from your computer:', 'ova-brw' ); ?>
						</h4>
						<input type="file" id="upload" name="location_file" size="25">
						<input type="hidden" name="action_import" value="import_setup_locations">
						<input type="hidden" name="max_file_size" value="<?php echo esc_attr( $bytes ); ?>" />
						<br/>
						<span class="max-size">
							<?php
							printf(
								esc_html__( 'Maximum size: %s', 'ova-brw' ),
								esc_html( $size )
							);
							?>
						</span>
						<a href="<?php echo esc_url( OVABRW_PLUGIN_URI.'/admin/imports/demo2.csv' ); ?>" class="demo" download>
							<?php esc_html_e( 'Demo file.csv', 'ova-brw' ); ?>
						</a>
					</div>
					<div class="import-locations-submit">
						<button type="submit" class="button">
							<?php esc_html_e( 'Import', 'ova-brw' ); ?>
						</button>
					</div>
				</form>
				<form class="remove-locations" enctype="multipart/form-data" method="post">
					<h2 class="heading"><?php esc_html_e( 'Remove Locations', 'ova-brw' ); ?></h2>
	        		<select name="product_id">
	        			<option value="">
	                        <?php esc_html_e( '-- Choose Product --', 'ova-brw' ); ?>
	                    </option>
                        <?php
                            if ( ! empty( $all_rooms ) && is_array( $all_rooms ) ) {
                                foreach ( $all_rooms as $p_id ) { ?>
                                    <option value="<?php echo esc_attr( $p_id ); ?>">
                                        <?php echo get_the_title( $p_id ); ?>
                                    </option>
                                <?php }
                            }
                        ?>
	        		</select>
					<input type="hidden" name="action_import" value="remove_locations">
					<div class="remove-locations-submit">
						<button type="submit" class="button">
							<?php esc_html_e( 'Remove', 'ova-brw' ); ?>
						</button>
					</div>
				</form>
			</div>
			<?php
		}

		public function ovabrw_show_admin_notice_success() {
            if ( isset( $_POST['success'] ) && $_POST['success'] ) {
                ?>
                <div class="notice notice-success is-dismissible">
                    <p><?php esc_html_e( $_POST['success'] ); ?></p>
                </div>
                <?php
            }
        }

        public function ovabrw_show_admin_notice_error() {
            if ( isset( $_POST['error'] ) && $_POST['error'] ) {
                ?>
                <div class="notice notice-error is-dismissible">
                    <p><?php esc_html_e( $_POST['error'] ); ?></p>
                </div>
                <?php
            }
        }
	}

	new OVABRW_Admin_Import_Locations();
}