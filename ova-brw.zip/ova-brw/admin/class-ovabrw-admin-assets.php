<?php defined( 'ABSPATH' ) || exit;

if ( !class_exists( 'OVABRW_Admin_Assets', false ) ) {
	/**
	 * OVABRW_Admin_Assets class.
	 */
	class OVABRW_Admin_Assets {
		/**
		 * Constructor.
		 */
		public function __construct() {
			// Admin head
			add_action( 'admin_head', array( $this, 'admin_head' ) );

			// Admin styles
			add_action( 'admin_enqueue_scripts', array( $this, 'admin_styles' ) );

			// Admin scripts
			add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ) );
		}

		/**
		 * Admin head
		 */
		public function admin_head() {
			$screen    	= get_current_screen();
			$screen_id 	= $screen ? $screen->id : '';

			// Product edit page
			if ( 'product' === $screen_id ) {
				// Custom taxonomies
				$taxonomies = array();

				// Get custom taxonomies
				$custom_taxonomies = ovabrw_create_type_taxonomies();

				if ( ovabrw_array_exists( $custom_taxonomies ) ) {
					foreach ( $custom_taxonomies as $taxonomy ) {
						array_push( $taxonomies, $taxonomy['slug'] );
					}
				}

				// Taxonomies depend category
				$taxonomies_depend = get_option( 'ova_brw_search_show_tax_depend_cat', 'yes' );
				if ( 'yes' !== $taxonomies_depend ) {
					$taxonomies = array();
				}

				echo '<script type="text/javascript">
					var ovabrwTaxonomies = "'.implode( ',', $taxonomies ).'";
				</script>';
			}
		}

		/**
		 * Enqueue styles
		 */
		public function admin_styles() {
			$version 	= OVABRW()->version;
			$screen    	= get_current_screen();
			$screen_id 	= $screen ? $screen->id : '';

			// Admin styles
			wp_register_style( 'ovabrw-admin', OVABRW_PLUGIN_URI.'assets/css/admin/admin.css', array(), $version );

			// Tippy scale stype
			wp_register_style( 'ovabrw-tippy-scale', OVABRW_PLUGIN_URI.'assets/libs/tippy/scale.css', array(), $version );

			// Register timepicker style
			wp_register_style( 'ovabrw-admin-timepicker', OVABRW_PLUGIN_URI.'assets/libs/timepicker/timepicker.min.css', array(), $version );

			// CodeMirror CSS
			wp_register_style( 'ovabrw-codemirror', OVABRW_PLUGIN_URI.'assets/libs/codemirror/codemirror.min.css', array(), $version );
			wp_register_style( 'ovabrw-codemirror-dracula', OVABRW_PLUGIN_URI.'assets/libs/codemirror/theme/dracula.min.css', array(), $version );
			wp_register_style( 'ovabrw-show-hint', OVABRW_PLUGIN_URI.'assets/libs/codemirror/hint/show-hint.min.css', array(), $version );

			// Calendar
			wp_register_style( 'ovabrw-calendar', OVABRW_PLUGIN_URI.'assets/libs/fullcalendar/main.min.css', array(), $version );
			
			// Select2
			wp_register_style( 'ovabrw-select2', OVABRW_PLUGIN_URI.'assets/libs/select2/select2.min.css', array(), $version );

			// Flaticon
			wp_register_style( 'ovabrw-flaticon', OVABRW_PLUGIN_URI.'assets/libs/flaticons/essential_set/flaticon.css', array(), $version );

			// Brwicon 2
			wp_register_style( 'ovabrw-flaticon2', OVABRW_PLUGIN_URI.'assets/libs/flaticons/brwicon2/font/brwicon2.css', array(), $version );

			// Create order
			wp_register_style( 'ovabrw-create-order', OVABRW_PLUGIN_URI.'assets/css/admin/create-order.css', array(), $version );

			// Specifications
			wp_register_style( 'ovabrw-specifications', OVABRW_PLUGIN_URI.'assets/css/admin/specifications.css', array(), $version );

			// Settings
			wp_register_style( 'ovabrw-settings', OVABRW_PLUGIN_URI.'assets/css/admin/settings.css', array(), $version );

			// Import location
			wp_register_style( 'ovabrw-import-locations', OVABRW_PLUGIN_URI.'assets/css/admin/import-locations.css', array(), $version );

			// Manage orders
			wp_register_style( 'ovabrw-manage-orders', OVABRW_PLUGIN_URI.'assets/css/admin/manage-orders.css', array(), $version );

			// Custom checkout fields
			wp_register_style( 'ovabrw-custom-checkout-fields', OVABRW_PLUGIN_URI.'assets/css/admin/custom-checkout-fields.css', array(), $version );

			// Product Category
			wp_register_style( 'ovabrw-product-category', OVABRW_PLUGIN_URI.'assets/css/admin/product-category.css', array(), $version );

			// Check booking
			wp_register_style( 'ovabrw-check-booking', OVABRW_PLUGIN_URI.'assets/css/admin/check-booking.css', array(), $version );

			// Edit order
			wp_register_style( 'ovabrw-wc-orders', OVABRW_PLUGIN_URI.'assets/css/admin/edit-order.css', array(), $version );

			// Product editor
			wp_register_style( 'ovabrw-product-editor', OVABRW_PLUGIN_URI.'assets/css/admin/product-editor.css', array(), $version );

			// Vehicle ID
			wp_register_style( 'ovabrw-vehicle', OVABRW_PLUGIN_URI.'assets/css/admin/vehicle.css', array(), $version );

			// Global CSS
	        $css    = OVABRW()->options->datepicker_global_css();
	        $root   = ":root{{$css}}";
	        wp_add_inline_style( 'ovabrw-admin', $root );

			// Product edit page
			if ( 'product' == $screen_id ) {
				// Tippy scale stype
				wp_enqueue_style( 'ovabrw-tippy-scale' );

				// Timepicker
				wp_enqueue_style( 'ovabrw-admin-timepicker' );

				// Product editor
				wp_enqueue_style( 'ovabrw-product-editor' );
			} elseif ( 'product_page_ovabrw-create-order' == $screen_id ) { // Add new order
				// Select2
				wp_enqueue_style( 'ovabrw-select2' );

				// Flaticon
				wp_enqueue_style( 'ovabrw-flaticon' );
				wp_enqueue_style( 'ovabrw-flaticon2' );

				// Tippy scale stype
				wp_enqueue_style( 'ovabrw-tippy-scale' );

				// Timepicker
				wp_enqueue_style( 'ovabrw-admin-timepicker' );

				wp_enqueue_style( 'ovabrw-create-order' );
			} elseif ( 'vehicle' == $screen_id ) {
				// Timepicker
				wp_enqueue_style( 'ovabrw-admin-timepicker' );

				// Vehicle ID
				wp_enqueue_style( 'ovabrw-vehicle' );
			} elseif ( 'product_page_ovabrw-import-location' == $screen_id ) { // Import location
				wp_enqueue_style( 'ovabrw-select2' );
				wp_enqueue_style( 'ovabrw-import-locations' );
			} elseif ( 'product_page_ovabrw-specifications' == $screen_id ) { // Specifications
				wp_enqueue_style( 'ovabrw-specifications' );
			} elseif ( 'product_page_ovabrw-manage-order' == $screen_id ) { // Manage Orders
				// Timepicker
				wp_enqueue_style( 'ovabrw-admin-timepicker' );

				wp_enqueue_style( 'ovabrw-manage-orders' );
			} elseif ( 'product_page_ovabrw-custom-checkout-field' == $screen_id ) { // Custom checkout fields
				wp_enqueue_style( 'ovabrw-custom-checkout-fields' );
			} elseif ( 'product_page_ovabrw-check-product' == $screen_id ) { // Check booking
				// Select2
				wp_enqueue_style( 'ovabrw-select2' );

				// Calendar
				wp_enqueue_style( 'ovabrw-calendar' );

				// Check booking
				wp_enqueue_style( 'ovabrw-check-booking' );
			} elseif ( 'product_page_ovabrw-custom-taxonomy' == $screen_id ) {
				wp_enqueue_style( 'ovabrw-custom-checkout-fields' );
			} elseif ( 'woocommerce_page_wc-settings' == $screen_id ) { // Rental settings
				// CodeMirror
				wp_enqueue_style( 'ovabrw-codemirror' );
				wp_enqueue_style( 'ovabrw-codemirror-dracula' );
				wp_enqueue_style( 'ovabrw-show-hint' );

				// Settings
				wp_enqueue_style( 'ovabrw-settings' );
			} elseif ( 'edit-product_cat' == $screen_id ) { // Product category
				wp_enqueue_style( 'ovabrw-product-category' );
			} elseif ( 'woocommerce_page_wc-orders' == $screen_id || 'edit-shop_order' == $screen_id ) { // Shop order page
				wp_enqueue_style( 'ovabrw-wc-orders' );
			}

			// Admin styles
			wp_enqueue_style( 'ovabrw-admin' );
		}

		/**
		 * Enqueue scripts
		 */
		public function admin_scripts() {
			$version 	= OVABRW()->version;
			$screen    	= get_current_screen();
			$screen_id 	= $screen ? $screen->id : '';

			// Admin scripts
			wp_register_script( 'ovabrw-admin-scripts', OVABRW_PLUGIN_URI.'assets/js/admin/admin_script.min.js', array('jquery'), $version, true );

			// Tippy
			wp_register_script( 'ovabrw-popper', OVABRW_PLUGIN_URI.'assets/libs/tippy/popper.min.js', array('jquery'), $version, true );
			wp_register_script( 'ovabrw-tippy-bundle', OVABRW_PLUGIN_URI.'assets/libs/tippy/tippy-bundle.min.js', array('jquery'), $version, true );

			// Register timepicker script
			wp_register_script( 'ovabrw-admin-timepicker', OVABRW_PLUGIN_URI.'assets/libs/timepicker/timepicker.min.js', array('jquery'), $version, true );

			// Register easepick script
			wp_register_script( 'ovabrw-admin-easepick', OVABRW_PLUGIN_URI.'assets/libs/easepick/easepick.min.js', array('jquery'), $version, true );

			// CodeMirror
			wp_register_script( 'ovabrw-codemirror', OVABRW_PLUGIN_URI.'assets/libs/codemirror/codemirror.min.js', array('jquery'), $version, true );
			wp_register_script( 'ovabrw-css-codemirror', OVABRW_PLUGIN_URI.'assets/libs/codemirror/css.min.js', array('jquery'), $version, true );
			wp_register_script( 'ovabrw-closebrackets', OVABRW_PLUGIN_URI.'assets/libs/codemirror/edit/closebrackets.js', array('jquery'), $version, true );
			wp_register_script( 'ovabrw-matchbrackets', OVABRW_PLUGIN_URI.'assets/libs/codemirror/edit/matchbrackets.js', array('jquery'), $version, true );
			wp_register_script( 'ovabrw-comment', OVABRW_PLUGIN_URI.'assets/libs/codemirror/comment/comment.js', array('jquery'), $version, true );
			wp_register_script( 'ovabrw-continuecomment', OVABRW_PLUGIN_URI.'assets/libs/codemirror/comment/continuecomment.js', array('jquery'), $version, true );
			wp_register_script( 'ovabrw-show-hint', OVABRW_PLUGIN_URI.'assets/libs/codemirror/hint/show-hint.min.js', array('jquery'), $version, true );
			wp_register_script( 'ovabrw-css-show-hint', OVABRW_PLUGIN_URI.'assets/libs/codemirror/hint/css-hint.min.js', array('jquery'), $version, true );

			// Calendar
			wp_register_script( 'ovabrw-moment', OVABRW_PLUGIN_URI.'assets/libs/fullcalendar/moment.min.js', array('jquery'), $version, true );
		    wp_register_script( 'ovabrw-calendar', OVABRW_PLUGIN_URI.'assets/libs/fullcalendar/main.js', array('jquery'), $version, true );
		    wp_register_script( 'ovabrw-locale-all', OVABRW_PLUGIN_URI.'assets/libs/fullcalendar/locales-all.js', array('jquery'), $version, true );
		    wp_register_script( 'ovabrw-calendar-booking', OVABRW_PLUGIN_URI.'assets/js/admin/calendar.min.js', array('jquery'), $version, true );

		    // Select2
		    wp_register_script( 'ovabrw-select2', OVABRW_PLUGIN_URI.'assets/libs/select2/select2.min.js', array('jquery'), $version, true );

		    // Custom checkout fields
		   	wp_register_script( 'ovabrw-custom-checkout-fields', OVABRW_PLUGIN_URI.'assets/js/admin/custom-checkout-fields.min.js', array('jquery'), $version, true );

		   	// Check booking
		   	wp_register_script( 'ovabrw-check-booking', OVABRW_PLUGIN_URI.'assets/js/admin/check-booking.min.js', array('jquery'), $version, true );

		   	// Manage orders
		   	wp_register_script( 'ovabrw-manage-orders', OVABRW_PLUGIN_URI.'assets/js/admin/manage-orders.min.js', array('jquery'), $version, true );

		   	// Specifications
		   	wp_register_script( 'ovabrw-specifications', OVABRW_PLUGIN_URI.'assets/js/admin/specifications.min.js', array('jquery'), $version, true );

		   	// Create new order
		   	wp_register_script( 'ovabrw-create-order', OVABRW_PLUGIN_URI.'assets/js/admin/create-new-order.min.js', array('jquery'), $version, true );

		   	// Settings
		   	wp_register_script( 'ovabrw-settings', OVABRW_PLUGIN_URI.'assets/js/admin/settings.min.js', array('jquery'), $version, true );

		   	// Edit order
		   	wp_register_script( 'ovabrw-wc-orders', OVABRW_PLUGIN_URI.'assets/js/admin/edit-order.min.js', array('jquery'), $version, true );

		   	// Product editor
		   	wp_register_script( 'ovabrw-product-editor', OVABRW_PLUGIN_URI.'assets/js/admin/product-editor.min.js', array('jquery'), $version, true );

		   	// Vehicle ID
		   	wp_register_script( 'ovabrw-vehicle', OVABRW_PLUGIN_URI.'assets/js/admin/vehicle.min.js', array('jquery'), $version, true );

			// Product edit page
			if ( 'product' == $screen_id ) {
				// Google API Key Maps
				if ( get_option( 'ova_brw_google_key_map', false ) ) {
					wp_enqueue_script( 'ovabrw-google-maps','https://maps.googleapis.com/maps/api/js?key='.get_option( 'ova_brw_google_key_map' ).'&loading=async&callback=Function.prototype&libraries=places', $version, true );
				} else {
					wp_enqueue_script( 'ovabrw-google-maps','https://maps.googleapis.com/maps/api/js?sensor=false&loading=async&callback=Function.prototype&libraries=places', array('jquery'), $version, true );
				}

				// Tippy
		        wp_enqueue_script( 'ovabrw-popper' );
		        wp_enqueue_script( 'ovabrw-tippy-bundle' );

		        // Timepicker
				wp_enqueue_script( 'ovabrw-admin-timepicker' );

				// Easepick - Datepicker
				wp_enqueue_script( 'ovabrw-admin-easepick' );

				// Product editor
				wp_enqueue_script( 'ovabrw-product-editor' );
				wp_localize_script( 'ovabrw-product-editor', 'ovabrwErrorMessages', ovabrw_get_validation_messages() );
			} elseif ( 'product_page_ovabrw-create-order' == $screen_id ) { // Add new order
				// Google API Key Maps
				if ( get_option( 'ova_brw_google_key_map', false ) ) {
					wp_enqueue_script( 'ovabrw-google-maps','https://maps.googleapis.com/maps/api/js?key='.get_option( 'ova_brw_google_key_map' ).'&loading=async&callback=Function.prototype&libraries=places', $version, true );
				} else {
					wp_enqueue_script( 'ovabrw-google-maps','https://maps.googleapis.com/maps/api/js?sensor=false&loading=async&callback=Function.prototype&libraries=places', array('jquery'), $version, true );
				}
				
				// Select2
				wp_enqueue_script( 'ovabrw-select2' );

				// Tippy
		        wp_enqueue_script( 'ovabrw-popper' );
		        wp_enqueue_script( 'ovabrw-tippy-bundle' );

		        // Timepicker
				wp_enqueue_script( 'ovabrw-admin-timepicker' );

				// Easepick - Datepicker
				wp_enqueue_script( 'ovabrw-admin-easepick' );

				// Create new order
				wp_enqueue_script( 'ovabrw-create-order' );
			} elseif ( 'vehicle' == $screen_id ) {
				// Timepicker
				wp_enqueue_script( 'ovabrw-admin-timepicker' );

				// Easepick - Datepicker
				wp_enqueue_script( 'ovabrw-admin-easepick' );

				// Vehicle
				wp_enqueue_script( 'ovabrw-vehicle' );
			} elseif ( 'product_page_ovabrw-import-location' == $screen_id ) { // Import location
				// Select2
				wp_enqueue_script( 'ovabrw-select2' );
			} elseif ( 'product_page_ovabrw-custom-checkout-field' == $screen_id ) {
				// Easepick - Datepicker
				wp_enqueue_script( 'ovabrw-admin-easepick' );

				// Custom checkout fields
				wp_enqueue_script( 'ovabrw-custom-checkout-fields' );
			} elseif ( 'product_page_ovabrw-check-product' == $screen_id ) { // Check booking
				// Select2
				wp_enqueue_script( 'ovabrw-select2' );

				// Timepicker
				wp_enqueue_script( 'ovabrw-admin-timepicker' );

				// Easepick - Datepicker
				wp_enqueue_script( 'ovabrw-admin-easepick' );

				// Calendar
				wp_enqueue_script( 'ovabrw-calendar' );
				wp_enqueue_script( 'ovabrw-locale-all' );
				wp_enqueue_script( 'ovabrw-calendar-booking' );
				wp_enqueue_script( 'ovabrw-check-booking' );
			} elseif ( 'product_page_ovabrw-manage-order' == $screen_id ) { // Manage orders
				// Timepicker
				wp_enqueue_script( 'ovabrw-admin-timepicker' );

				// Easepick - Datepicker
				wp_enqueue_script( 'ovabrw-admin-easepick' );

				// Manage orders
				wp_enqueue_script( 'ovabrw-manage-orders' );
			} elseif ( 'product_page_ovabrw-specifications' == $screen_id ) {
				// Easepick - Datepicker
				wp_enqueue_script( 'ovabrw-admin-easepick' );
				
				// Specifications
				wp_enqueue_script( 'ovabrw-specifications' );
			} elseif ( 'product_page_ovabrw-custom-taxonomy' == $screen_id ) { // Custom taxonomies
				wp_enqueue_script( 'ovabrw-custom-checkout-fields' );
			} elseif ( 'woocommerce_page_wc-settings' == $screen_id ) {
				// CodeMirror
				wp_enqueue_script( 'ovabrw-codemirror' );
				wp_enqueue_script( 'ovabrw-css-codemirror' );
				wp_enqueue_script( 'ovabrw-closebrackets' );
				wp_enqueue_script( 'ovabrw-matchbrackets' );
				wp_enqueue_script( 'ovabrw-comment' );
				wp_enqueue_script( 'ovabrw-continuecomment' );
				wp_enqueue_script( 'ovabrw-show-hint' );
				wp_enqueue_script( 'ovabrw-css-show-hint' );
				
				// Settings
				wp_enqueue_script( 'ovabrw-settings' );
			} elseif ( 'woocommerce_page_wc-orders' == $screen_id || 'edit-shop_order' == $screen_id ) { // Shop order
				wp_enqueue_script( 'ovabrw-wc-orders' );
			}

			// Ajax object
			wp_localize_script( 'ovabrw-admin-scripts', 'ajax_object', array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'security' => wp_create_nonce( 'ovabrw-security-ajax' )
			));

			// Admin scripts
			wp_enqueue_script( 'ovabrw-admin-scripts' );

			// Error messages
			wp_localize_script( 'ovabrw-admin-scripts', 'ovabrwErrorMessages', ovabrw_get_validation_messages() );

			// Timepicker options
			wp_localize_script( 'ovabrw-admin-scripts', 'timePickerOptions', OVABRW()->options->get_timepicker_options() );

			// Datepicker options
			wp_localize_script( 'ovabrw-admin-scripts', 'datePickerOptions', OVABRW()->options->get_datepicker_options() );
		}
	}

	return new OVABRW_Admin_Assets();
}