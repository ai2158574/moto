<?php if ( ! defined( 'ABSPATH' ) ) exit();

if ( ! class_exists( 'OVABRW_Admin_Category_Fields' ) ) {
	class OVABRW_Admin_Category_Fields {
		public $card_templates = [];

		public function __construct() {
			// Set card templates
			$this->card_templates = ovabrw_get_all_card_templates();
			if ( ! is_array( $this->card_templates ) ) $this->card_templates = [];

			// Add product category fields
            add_action( 'product_cat_add_form_fields', array( $this, 'add_form_fields' ) );

            // Save product category fields
            add_action( 'product_cat_edit_form_fields', array( $this, 'edit_form_fields' ) );

            // Edit product category
            add_action( 'edited_product_cat', array( $this, 'save_fields' ) );

            // Create product category
			add_action( 'create_product_cat', array( $this, 'save_fields' ) );
        }

        /**
         * Add product category fields
         */
        public function add_form_fields() {
        	// Get all custom taxonomies
        	$taxonomies = ovabrw_recursive_replace( '\\', '', get_option( 'ovabrw_custom_taxonomy', [] ) );

        	// Get all custom checkout fields
        	$cckf = ovabrw_recursive_replace( '\\', '', get_option( 'ovabrw_booking_form', [] ) );

        	// Get all specifications
        	$specifications = ovabrw_recursive_replace( '\\', '', get_option( 'ovabrw_specifications', [] ) );

        	// Get templates from elementor
            $global_template    = get_option( 'ova_brw_template_elementor_template', 'default' );
            $templates          = get_posts([
            	'post_type' 	=> 'elementor_library',
            	'meta_key' 		=> '_elementor_template_type',
            	'meta_value' 	=> 'page',
            	'numberposts'   => -1
            ]);
        ?>
        	<!-- Display category -->
	        <div class="form-field">
	            <label for="Display">
	            	<?php esc_html_e( 'Display', 'ova-brw' ); ?>
	            </label>
	            <select name="ovabrw_cat_dis">
	                <option value="rental"><?php esc_html_e( 'Rental', 'ova-brw' ); ?></option>
	                <option value="shop"><?php esc_html_e( 'Shop', 'ova-brw' ); ?></option>
	            </select>
	        </div>

        	<!-- Display Price In Format -->
	        <div class="form-field">
	            <div class="ovabrw-single-price-format">
	                <label>
	                    <?php esc_html_e( 'Display Price In Format (product template)', 'ova-brw' ); ?>
	                    <span>
		                	<?php echo wc_help_tip( __( 'For example: [regular_price] / [unit]<br>
	                        You can insert text or HTML<br>
	                        Use shortcodes:<br>
	                        <em>[unit]</em>: Display Day or Night or Hour or Km or Mi<br>
	                        <em>[regular_price]</em>: Display regular price by day<br>
	                        <em>[hour_price]</em>: Display regular price by hour<br>
	                        <em>[min_daily_price]</em>: Display minimum daily price<br>
	                        <em>[max_daily_price]</em>: Display maximum daily price<br>
	                        <em>[min_package_price]</em>: Display minimum package price (rental type: Period)<br>
	                        <em>[max_package_price]</em>: Display maximum package price (rental type: Period)<br>
	                        <em>[min_location_price]</em>: Display minimum location price (rental type: Transportation)<br>
	                        <em>[max_location_price]</em>: Display maximum location price (rental type: Transportation)<br>
	                        <em>[min_price]</em>: Display minimum timeslot price (rental type: Appointment)<br>
	                        <em>[max_price]</em>: Display maximum timeslot price (rental type: Appointment)', 'ova-brw' ), true ); ?>
		                </span>
	                </label>
	                <select name="ovabrw_select_single_price_format">
	                    <option value="global">
	                    	<?php esc_html_e( 'Global Setting', 'ova-brw' ); ?>
	                    </option>
	                    <option value="new">
	                    	<?php esc_html_e( 'New format', 'ova-brw' ); ?>
	                    </option>
	                </select>
	            </div>
	            <div class="form-field single-price-format-wrap" style="display: none;">
	                <textarea name="ovabrw_single_new_price_format" rows="5" cols="40" placeholder="<?php esc_html_e( 'Add new format', 'ova-brw' ); ?>"></textarea>
	            </div>
	        </div>
	        <div class="form-field">
	            <div class="ovabrw-archive-price-format">
	                <label>
	                    <?php esc_html_e( 'Display Price In Format (card template)', 'ova-brw' ); ?>
	                    <span>
		                	<?php echo wc_help_tip( __( 'For example: [regular_price] / [unit]<br>
	                        You can insert text or HTML<br>
	                        Use shortcodes:<br>
	                        <em>[unit]</em>: Display Day or Night or Hour or Km or Mi<br>
	                        <em>[regular_price]</em>: Display regular price by day<br>
	                        <em>[hour_price]</em>: Display regular price by hour<br>
	                        <em>[min_daily_price]</em>: Display minimum daily price<br>
	                        <em>[max_daily_price]</em>: Display maximum daily price<br>
	                        <em>[min_package_price]</em>: Display minimum package price (rental type: Period)<br>
	                        <em>[max_package_price]</em>: Display maximum package price (rental type: Period)<br>
	                        <em>[min_location_price]</em>: Display minimum location price (rental type: Transportation)<br>
	                        <em>[max_location_price]</em>: Display maximum location price (rental type: Transportation)<br>
	                        <em>[min_price]</em>: Display minimum timeslot price (rental type: Appointment)<br>
	                        <em>[max_price]</em>: Display maximum timeslot price (rental type: Appointment)', 'ova-brw' ), true ); ?>
		                </span>
	                </label>
	                <select name="ovabrw_select_archive_price_format">
	                    <option value="global">
	                    	<?php esc_html_e( 'Global Setting', 'ova-brw' ); ?>
	                    </option>
	                    <option value="new">
	                    	<?php esc_html_e( 'New format', 'ova-brw' ); ?>
	                    </option>
	                </select>
	            </div>
	            <div class="form-field archive-price-format-wrap" style="display: none;">
	                <textarea name="ovabrw_archive_new_price_format" rows="5" cols="40" placeholder="<?php esc_html_e( 'Add new format', 'ova-brw' ); ?>"></textarea>
	            </div>
	        </div>

	        <!-- Custom Taxonomies -->
	        <?php if ( 'yes' == get_option( 'ova_brw_search_show_tax_depend_cat', 'yes' ) ): ?>
		        <div class="form-field">
		            <label>
		                <?php esc_html_e( 'Choose custom taxonomies', 'ova-brw' ); ?>
		            </label>
		            <select name="ovabrw_custom_tax[]" multiple="multiple" class="ovabrw_custom_tax_with_cat">
	                <?php if ( !empty( $taxonomies ) ):
	                    foreach ( $taxonomies as $slug => $field ):
	                        $name = array_key_exists( 'name', $field ) ? $field['name'] : '';
					?>
	                        <option value="<?php echo esc_attr( $slug ); ?>">
	                            <?php echo esc_html( $name.' ('.$slug.')' ); ?>
	                        </option>
	                <?php endforeach;
	            	endif; ?>
		            </select>
		        </div>
	    	<?php endif; ?>

	        <!-- Custom Checkout Fields -->
	        <div class="form-field">
	            <div class="choose_custom_checkout_field">
	                <label>
	                    <?php esc_html_e( 'Choose custom checkout fields', 'ova-brw' ); ?>
	                    <span>
		                	<?php echo wc_help_tip( esc_html__( 'All: The all custom checkout fields will display', 'ova-brw' ), true ); ?>
		                </span>
	                </label>
	                <select name="ovabrw_choose_custom_checkout_field" id="">
	                    <option value="all">
	                    	<?php esc_html_e( 'All', 'ova-brw' ); ?>
	                    </option>
	                    <option value="special">
	                    	<?php esc_html_e( 'Choose other fields', 'ova-brw' ); ?>
	                    </option>
	                </select>
	            </div>
	            <div id="special_cus_fields" class="show_special_checkout_field">
	                <br>
	                <label>
	                    <?php esc_html_e( 'Choose other custom checkout fields', 'ova-brw' ); ?>
	                </label>
	                <select name="ovabrw_custom_checkout_field[]" multiple="multiple" class="ovabrw_custom_tax_with_cat">
                    <?php if ( ! empty( $cckf ) ):
                        foreach ( $cckf as $slug => $field ):
                            $label = array_key_exists( 'label', $field ) ? $field['label'] : '';
                    ?>
                            <option value="<?php echo esc_attr( $slug ); ?>">
                                <?php echo esc_html( $label.' ('.$slug.')' ); ?>
                            </option>
                    <?php endforeach; endif; ?>
	                </select>
	            </div>
	        </div>

	        <!-- Specifications -->
	        <div class="form-field">
	            <div class="choose_specifications">
	                <label>
	                    <?php esc_html_e( 'Choose Specifications', 'ova-brw' ); ?>
	                    <span>
		                	<?php echo wc_help_tip( esc_html__( 'All: The all specifications will display', 'ova-brw' ), true ); ?>
		                </span>
	                </label>
	                <select name="ovabrw_choose_specifications">
	                    <option value="all">
	                    	<?php esc_html_e( 'All', 'ova-brw' ); ?>
	                    </option>
	                    <option value="special">
	                    	<?php esc_html_e( 'Choose other specifications', 'ova-brw' ); ?>
	                    </option>
	                </select>
	            </div>
	            <div id="show_special_specifications" class="show_special_specifications">
	                <br>
	                <label>
	                    <?php esc_html_e('Choose other specifications', 'ova-brw'); ?>
	                </label>
	                <select
	                	name="ovabrw_specifications[]"
	                	class="ovabrw_custom_tax_with_cat"
	                	multiple="multiple">
                    <?php if ( ! empty( $specifications ) && is_array( $specifications ) ):
	                        foreach ( $specifications as $name => $field ):
	                        	if ( !isset( $field['enable'] ) || !$field['enable'] ) continue;

	                            $label = isset( $field['label'] ) ? $field['label'] : '';
	                        ?>
	                            <option value="<?php echo esc_attr( $name ); ?>">
	                                <?php echo esc_html( $label ); ?>
	                            </option>
                    <?php endforeach;
                	endif; ?>
	                </select>
	            </div>
	        </div>

	        <!-- Show Location in booking form -->
	        <div class="form-field">
	            <label>
	                <?php esc_html_e( 'Show Location in form', 'ova-brw' ); ?>
	                <span>
	                	<?php echo wc_help_tip( esc_html__( 'If Empty field will get value in WooCommerce >> Settings >> Booking & Rental >> Booking Details', 'ova-brw' ), true ) ?>	
	                </span>
	            </label>
	            <select
	            	name="ovabrw_show_loc_booking_form[]"
	            	class="ovabrw_custom_tax_with_cat"
	            	multiple="multiple">
	            	<option value="pickup_loc">
                        <?php esc_html_e( 'Pick-up Location', 'ova-brw' ); ?>
                    </option>
                    <option value="dropoff_loc">
                        <?php esc_html_e( 'Drop-off Location', 'ova-brw' ); ?>
                    </option>
	            </select>
	        </div>

	        <!-- Label Pick-up Date -->
	        <div class="form-field">
	            <label>
	            	<?php esc_html_e( 'Rename "Pick-up Date" title', 'ova-brw' ); ?>
	            	<span>
		            	<?php echo wc_help_tip( esc_html__( 'Example: Check-in', 'ova-brw' ), true ); ?>
		            </span>
	            </label>
	            <input
	            	type="text"
	            	name="ovabrw_lable_pickup_date"
	            	id="ovabrw_lable_pickup_date"
	            	size="40"
	            />
	        </div>

	        <!-- Label Drop-off Date -->
	        <div class="form-field">
	            <label>
	            	<?php esc_html_e( 'Rename "Drop-off Date" Title', 'ova-brw' ); ?>
	            	<span>
		            	<?php echo wc_help_tip( esc_html__( 'Example: Check-out', 'ova-brw' ), true ); ?>
		            </span>
	            </label>
	            <input
	            	type="text"
	            	name="ovabrw_lable_dropoff_date"
	            	id="ovabrw_lable_dropoff_date"
	            	size="40"
	            />
	        </div>

	        <!-- Product Templates -->
	        <div class="form-field">
	            <label>
	            	<?php esc_html_e( 'Product template', 'ova-brw' ); ?>
	            	<span>
	            	 	<?php echo wc_help_tip( esc_html__( '- Global Setting: WooCommerce >> Settings >> Booking & Rental >> Product Details >> Product Template. <br/> - Other: Made in Templates of Elementor', 'ova-brw' ), true ); ?>
	            	</span>
	            </label>
	            <select id="ovabrw_product_templates" name="ovabrw_product_templates">
	                <?php if ( !empty( $templates ) && is_array( $templates ) ):
	                	foreach ( $templates as $template ):
	                		if ( $template->ID == $global_template ) continue;
	                ?>
	                	<option value="<?php echo esc_attr( $template->ID ); ?>">
	                		<?php echo esc_html( $template->post_title ); ?>
	                	</option>
	            	<?php endforeach;
	            	endif; ?>
	            </select>
	        </div>

	        <!-- Card Template -->
	        <?php if ( ovabrw_global_typography() ): ?>
	            <div class="form-field">
	                <label>
	                	<?php esc_html_e( 'Card Template', 'ova-brw' ); ?>
	                	<span>
		                	<?php echo wc_help_tip( esc_html__( '- Card template is product template that display in listing product page. <br/> - Global Setting: WooCommerce >> Settings >> Booking & Rental >> Typography & Color >> Card', 'ova-brw' ), true );
		                	?>
		                </span>
	                </label>
	                <select name="ovabrw_card_template">
	                    <option value="">
	                        <?php esc_html_e( 'Global Setting', 'ova-brw' ); ?>
	                    </option>
	                <?php foreach ( $this->card_templates as $card => $label ): ?>
	                	<option value="<?php echo esc_attr( $card ); ?>">
	                        <?php echo esc_html( $label ); ?>
	                    </option>
	                <?php endforeach; ?>
	                </select>
	                <br>
	            </div>
	        <?php endif;
        }

        /**
         * Edit product category fields
         */
        public function edit_form_fields( $term ) {
        	// Get term ID
	        $term_id = $term->term_id;

	        // Price format for single page
	        $single_price_format_type 	= get_term_meta( $term_id, 'ovabrw_select_single_price_format', true );
	        $single_price_format_new 	= get_term_meta( $term_id, 'ovabrw_single_new_price_format', true );

	        // Price format for archive page
	        $archive_price_format_type 	= get_term_meta( $term_id, 'ovabrw_select_archive_price_format', true );
	        $archive_price_format_new 	= get_term_meta( $term_id, 'ovabrw_archive_new_price_format', true );

	        // Display rental
	        $display_rental = get_term_meta( $term_id, 'ovabrw_cat_dis', true );

	        // All custom taxonomies
	        $taxonomies = ovabrw_recursive_replace( '\\', '', get_option( 'ovabrw_custom_taxonomy', [] ) );

	        // Get custom taxonomies
	        $custom_taxonomies = get_term_meta( $term_id, 'ovabrw_custom_tax', true );
	        if ( !ovabrw_array_exists( $custom_taxonomies ) ) $custom_taxonomies = [];

	        // Sort custom taxonomies
	        $sort_taxonomies = [];

	        if ( ovabrw_array_exists( $custom_taxonomies ) ) {
	        	foreach ( $custom_taxonomies as $tax_slug ) {
	        		if ( array_key_exists( $tax_slug, $taxonomies ) ) {
	        			$sort_taxonomies[$tax_slug] = $taxonomies[$tax_slug];

	        			// Remove slug in taxonomies
	        			unset( $taxonomies[$tax_slug] );
	        		}
	        	}
	        }

	        // Merge taxonomies
	       	$sort_taxonomies = array_merge( $sort_taxonomies, $taxonomies );
	       	// End sort custom taxonomies

	        // All custom checkout fields
	        $cckf = ovabrw_recursive_replace( '\\', '', get_option( 'ovabrw_booking_form', [] ) );

	        // Custom checkout fields type
	        $cckf_type = get_term_meta( $term_id, 'ovabrw_choose_custom_checkout_field', true );

	        // Get custom checkout fields
	        $cckf_term = get_term_meta( $term_id, 'ovabrw_custom_checkout_field', true );
	        if ( !ovabrw_array_exists( $cckf_term ) ) $cckf_term = [];

	        // Sort custom checkout fields
	        $sort_cckf = [];

	        if ( ovabrw_array_exists( $cckf_term ) ) {
	        	foreach ( $cckf_term as $cckf_slug ) {
	        		if ( array_key_exists( $cckf_slug, $cckf ) ) {
	        			$sort_cckf[$cckf_slug] = $cckf[$cckf_slug];

	        			// Remove slug in custom checkout fields
	        			unset( $cckf[$cckf_slug] );
	        		}
	        	}
	        }

	        // Merge taxonomies
	       	$sort_cckf = array_merge( $sort_cckf, $cckf );
	       	// End sort custom checkout fields
	       	
	       	// Get all specifications
	       	$specifications = ovabrw_recursive_replace( '\\', '', get_option( 'ovabrw_specifications', [] ) );

	        // Specification type
	        $specification_type = get_term_meta( $term_id, 'ovabrw_choose_specifications', true );

	        // Get specification for term
	        $specification_term = get_term_meta( $term_id, 'ovabrw_specifications', true );
	        if ( !ovabrw_array_exists( $specification_term ) ) $specification_term = [];

	        // Sort specifications
	        $sort_specifications = [];

	        if ( ovabrw_array_exists( $specification_term ) ) {
	        	foreach ( $specification_term as $specification_slug ) {
	        		if ( array_key_exists( $specification_slug, $specifications ) ) {
	        			$sort_specifications[$specification_slug] = $specifications[$specification_slug];

	        			// Remove slug in specifications
	        			unset( $specifications[$specification_slug] );
	        		}
	        	}
	        }

	        // Merge specifications
	       	$sort_specifications = array_merge( $sort_specifications, $specifications );
	        // End sort specifications

	       	// Show locations
	        $show_locations = get_term_meta( $term_id, 'ovabrw_show_loc_booking_form', true );
	        if ( !ovabrw_array_exists( $show_locations ) ) $show_locations = [];

	        // Get label pick-up, drop-off dates
	        $label_pickup_date   = get_term_meta( $term_id, 'ovabrw_lable_pickup_date', true );
	        $lable_dropoff_date  = get_term_meta( $term_id, 'ovabrw_lable_dropoff_date', true );

	        // Get product template
	        $global_template 	= get_option( 'ova_brw_template_elementor_template', 'default' );
	        $product_template 	= get_term_meta( $term_id, 'ovabrw_product_templates', true );
	        $templates 			= get_posts( array(
	        	'post_type' 	=> 'elementor_library',
	        	'meta_key' 		=> '_elementor_template_type',
	        	'meta_value' 	=> 'page',
	        	'numberposts'   => -1
	        ));

	        $list_templates             = [];
	        $list_templates['global']  	= esc_html__( 'Global Setting', 'ova-brw' );

	        if ( ! empty( $templates ) ) {
	            foreach ( $templates as $template ) {
	                if ( $template->ID == $global_template ) continue;
	                $list_templates[$template->ID] = $template->post_title;
	            }
	        } // End product template

	        // Card
	        $card_template = get_term_meta( $term_id, 'ovabrw_card_template', true );
	    ?>
	        <!-- Display category -->
	        <tr class="form-field">
	            <th scope="row" valign="top">
	                <label for="ovabrw_cat_dis">
	                    <?php esc_html_e('Display', 'ova-brw'); ?>
	                </label>
	            </th>
	            <td>
	                <select name="ovabrw_cat_dis">
	                    <option value="rental"<?php selected( $display_rental, 'rental' ); ?>>
	                        <?php esc_html_e( 'Rental', 'ova-brw' ); ?>
	                    </option>
	                    <option value="shop"<?php selected( $display_rental, 'shop' ); ?>>
	                        <?php esc_html_e( 'Shop', 'ova-brw' ); ?>
	                    </option>
	                </select>
	            </td>
	        </tr>
	        
	        <!-- Price Format -->
	        <tr class="form-field ovabrw-single-price-format">
	        	<th scope="row" valign="top">
	              	<label>
	                	<?php esc_html_e( 'Display Price In Format (product template)', 'ova-brw' ); ?>
		                <span>
		                	<?php echo wc_help_tip( __( 'For example: [regular_price] / [unit]<br>
	                        You can insert text or HTML<br>
	                        Use shortcodes:<br>
	                        <em>[unit]</em>: Display Day or Night or Hour or Km or Mi<br>
	                        <em>[regular_price]</em>: Display regular price by day<br>
	                        <em>[hour_price]</em>: Display regular price by hour<br>
	                        <em>[min_daily_price]</em>: Display minimum daily price<br>
	                        <em>[max_daily_price]</em>: Display maximum daily price<br>
	                        <em>[min_package_price]</em>: Display minimum package price (rental type: Period)<br>
	                        <em>[max_package_price]</em>: Display maximum package price (rental type: Period)<br>
	                        <em>[min_location_price]</em>: Display minimum location price (rental type: Transportation)<br>
	                        <em>[max_location_price]</em>: Display maximum location price (rental type: Transportation)<br>
	                        <em>[min_price]</em>: Display minimum timeslot price (rental type: Appointment)<br>
	                        <em>[max_price]</em>: Display maximum timeslot price (rental type: Appointment)', 'ova-brw' ), true ); ?>
		                </span>
	            	</label>
	            </th>
	            <td>
	            	<select name="ovabrw_select_single_price_format">
	                    <option value="global"<?php selected( $single_price_format_type, 'global' ); ?>>
	                    	<?php esc_html_e( 'Global Setting', 'ova-brw' ); ?>
	                    </option>
	                    <option value="new"<?php selected( $single_price_format_type, 'new' ); ?>>
	                    	<?php esc_html_e( 'New format', 'ova-brw' ); ?>
	                    </option>
	                </select>
	            </td>
	        </tr>
	        <tr class="form-field single-price-format-wrap">
	        	<th scope="row" valign="top"></th>
	            <td>
	            	<textarea name="ovabrw_single_new_price_format" rows="5" cols="40" placeholder="<?php esc_html_e( 'Add new format', 'ova-brw' ); ?>"><?php echo esc_html( $single_price_format_new ); ?></textarea>
	            </td>
	        </tr>
	        <tr class="form-field ovabrw-archive-price-format">
	        	<th scope="row" valign="top">
	              	<label>
	                	<?php esc_html_e( 'Display Price In Format (card template)', 'ova-brw' ); ?>
		                <span>
		                	<?php echo wc_help_tip( __( 'For example: [regular_price] / [unit]<br>
	                        You can insert text or HTML<br>
	                        Use shortcodes:<br>
	                        <em>[unit]</em>: Display Day or Night or Hour or Km or Mi<br>
	                        <em>[regular_price]</em>: Display regular price by day<br>
	                        <em>[hour_price]</em>: Display regular price by hour<br>
	                        <em>[min_daily_price]</em>: Display minimum daily price<br>
	                        <em>[max_daily_price]</em>: Display maximum daily price<br>
	                        <em>[min_package_price]</em>: Display minimum package price (rental type: Period)<br>
	                        <em>[max_package_price]</em>: Display maximum package price (rental type: Period)<br>
	                        <em>[min_location_price]</em>: Display minimum location price (rental type: Transportation)<br>
	                        <em>[max_location_price]</em>: Display maximum location price (rental type: Transportation)<br>
	                        <em>[min_price]</em>: Display minimum timeslot price (rental type: Appointment)<br>
	                        <em>[max_price]</em>: Display maximum timeslot price (rental type: Appointment)', 'ova-brw' ), true ); ?>
		                </span>
	            	</label>
	            </th>
	            <td>
	            	<select name="ovabrw_select_archive_price_format">
	                    <option value="global"<?php selected( $archive_price_format_type, 'global' ); ?>>
	                    	<?php esc_html_e( 'Global Setting', 'ova-brw' ); ?>
	                    </option>
	                    <option value="new"<?php selected( $archive_price_format_type, 'new' ); ?>>
	                    	<?php esc_html_e( 'New format', 'ova-brw' ); ?>
	                    </option>
	                </select>
	            </td>
	        </tr>
	        <tr class="form-field archive-price-format-wrap">
	        	<th scope="row" valign="top"></th>
	            <td>
	            	<textarea name="ovabrw_archive_new_price_format" rows="5" cols="40" placeholder="<?php esc_html_e( 'Add new format', 'ova-brw' ); ?>"><?php echo esc_html( $archive_price_format_new ); ?></textarea>
	            </td>
	        </tr>

	        <!-- Custom Taxonomies -->
	        <?php if ( 'yes' == get_option( 'ova_brw_search_show_tax_depend_cat', 'yes' ) ): ?>
		        <tr class="form-field">
		            <th scope="row" valign="top">
		                <label>
		                    <?php esc_html_e('Choose custom taxonomies', 'ova-brw'); ?>
		                </label>
		            </th>
		            <td>
		                <select
		                	name="ovabrw_custom_tax[]"
		                	class="ovabrw_custom_tax_with_cat"
		                	multiple="multiple">
	                    <?php foreach ( $sort_taxonomies as $slug => $field ):
	                    	if ( !isset( $field['enabled'] ) || !$field['enabled'] ) continue;

                            $name 		= array_key_exists( 'name', $field ) ? $field['name'] : '';
                            $selected 	= in_array( $slug, $custom_taxonomies ) ? ' selected' : '';
                        ?>
                            <option value="<?php echo esc_attr( $slug ); ?>"<?php echo esc_attr( $selected ); ?>>
                                <?php echo esc_html( $name.' ('.$slug.')' ); ?>
                            </option>
	                    <?php endforeach; ?>
		                </select>
		            </td>
		        </tr>
	    	<?php endif; ?>

	        <!-- Custom Checkout Field -->
	        <tr class="form-field choose_custom_checkout_field">
	            <th scope="row" valign="top">
	              <label>
	                <?php esc_html_e('Choose custom checkout fields', 'ova-brw'); ?>
	                 <span>
	                	<?php echo wc_help_tip( esc_html__( 'All: The all custom checkout fields will display', 'ova-brw' ), true ); ?>
	                </span>
	            </label>
	            </th>
	            <td>
	                <select name="ovabrw_choose_custom_checkout_field" id="">
	                    <option value="all"<?php selected( $cckf_type, 'all' ); ?>>
	                    	<?php esc_html_e( 'All', 'ova-brw' ); ?>
	                    </option>
	                    <option value="special"<?php selected( $cckf_type, 'special' ); ?>>
	                    	<?php esc_html_e( 'Choose other fields', 'ova-brw' ); ?>
	                    </option>
	                </select>
	                
	            </td>
	        </tr>
	        <tr class="form-field show_special_checkout_field">
	            <th scope="row" valign="top"></th>
	            <td>
	                <select
	                	name="ovabrw_custom_checkout_field[]"
	                	class="ovabrw_custom_tax_with_cat"
	                	multiple="multiple">
                    <?php foreach ( $sort_cckf as $slug => $field ):
                    	if ( !isset( $field['enabled'] ) || !$field['enabled'] ) continue;

                        $label 		= array_key_exists( 'label', $field ) ? $field['label'] : '';
                        $selected   = in_array( $slug, $cckf_term ) ? ' selected' : '';
                    ?>
                        <option value="<?php echo esc_attr( $slug ); ?>"<?php echo esc_attr( $selected ); ?>>
                            <?php echo esc_html( $label.' ('.$slug.')' ); ?>
                        </option>
                    <?php endforeach; ?>
	                </select>
	                <span>
	                    <?php esc_html_e('Choose other custom checkout fields', 'ova-brw'); ?>
	                </span>
	            </td>
	        </tr>

	        <!-- Specifications -->
	        <tr class="form-field choose_specifications">
	            <th scope="row" valign="top">
	              <label>
	                <?php esc_html_e( 'Choose Specifications', 'ova-brw' ); ?>
	                <span>
	                	<?php echo wc_help_tip( esc_html__( 'All: The all specifications will display', 'ova-brw' ), true ); ?>
	                </span>
	            </label>
	            </th>
	            <td>
	            	<select name="ovabrw_choose_specifications">
	                    <option value="all"<?php selected( $specification_type , 'all' ); ?>>
	                    	<?php esc_html_e( 'All', 'ova-brw' ); ?>
	                    </option>
	                    <option value="special"<?php selected( $specification_type , 'special' ); ?>>
	                    	<?php esc_html_e( 'Choose other specifications', 'ova-brw' ); ?>
	                    </option>
	                </select>
	            </td>
	        </tr>
	        <tr class="form-field show_special_specifications">
	            <th scope="row" valign="top"></th>
	            <td>
	                <select
	                	name="ovabrw_specifications[]"
	                	class="ovabrw_custom_tax_with_cat"
	                	multiple="multiple">
                    	<?php foreach ( $sort_specifications as $slug => $field ):
                        	if ( !isset( $field['enable'] ) || !$field['enable'] ) continue;

                            $label 		= isset( $field['label'] ) ? $field['label'] : '';
                            $selected 	= in_array( $slug, $specification_term ) ? ' selected' : '';
                        ?>
                            <option value="<?php echo esc_attr( $slug ); ?>"<?php echo esc_attr( $selected ); ?>>
                                <?php echo esc_html( $label.' ('.$slug.')' ); ?>
                            </option>
                    	<?php endforeach; ?>
	                </select>
	                <span>
	                    <?php esc_html_e( 'Choose other specifications', 'ova-brw' ); ?>
	                <span>
	            </td>
	        </tr>
	        
	        <!-- Show Location in booking form -->
	        <tr class="form-field">
	            <th scope="row" valign="top">
	                <label>
	                    <?php esc_html_e( 'Show Location in form', 'ova-brw' ); ?>
	                    <span>
		                	<?php echo wc_help_tip( esc_html__( 'If Empty field will get value in WooCommerce >> Settings >> Booking & Rental >> Booking Details', 'ova-brw' ), true ); ?>	
		                </span>
	                </label>
	            </th>
	            <td>
	                <select
	                	name="ovabrw_show_loc_booking_form[]"
	                	class="ovabrw_custom_tax_with_cat"
	                	multiple="multiple"
	                />
	                	<option value="pickup_loc"<?php echo in_array( 'pickup_loc', $show_locations ) ? ' selected' : ''; ?>>
                            <?php esc_html_e( 'Pick-up Location', 'ova-brw' ); ?>
                        </option>
                        <option value="dropoff_loc"<?php echo in_array( 'dropoff_loc', $show_locations ) ? ' selected' : ''; ?>>
                            <?php esc_html_e( 'Drop-off Location', 'ova-brw' ); ?>
                        </option>
	                </select>
	            </td>
	        </tr>

	        <!-- Label Pick-up Date -->
	        <tr class="form-field ovabrw_lable_pickup_date">
	            <th>
	                <label>
	                	<?php esc_html_e( 'Rename "Pick-up Date" title', 'ova-brw' ); ?>
	                	<span>
			            	<?php echo wc_help_tip( esc_html__( 'Example: Check-in', 'ova-brw' ), true ); ?>
			            </span>		
	                </label>
	            </th>
	            <td>
	                <input
	                	type="text"
	                	name="ovabrw_lable_pickup_date"
	                	id="ovabrw_lable_pickup_date"
	                	value="<?php esc_html_e( $label_pickup_date, 'ova-brw' ); ?>"
	                	size="40"
	                />
	            </td>
	        </tr>

	        <!-- Label Drop-off Date -->
	        <tr class="form-field ovabrw_lable_dropoff_date">
	            <th>
	                <label>
	                	<?php esc_html_e( 'Rename "Drop-off Date" title', 'ova-brw' ); ?>
	                	<span>
			            	<?php echo wc_help_tip( esc_html__( 'Example: Check-out', 'ova-brw' ), true ); ?>
			            </span>		
	                </label>
	            </th>
	            <td>
	                <input
	                	type="text"
	                	name="ovabrw_lable_dropoff_date"
	                	id="ovabrw_lable_dropoff_date"
	                	value="<?php esc_html_e( $lable_dropoff_date, 'ova-brw' ); ?>"
	                	size="40"
	                />
	            </td>
	        </tr>

	        <!-- Product template -->
	        <tr class="form-field ovabrw_product_templates">
	            <th>
	                <label>
	                	<?php esc_html_e( 'Product template', 'ova-brw' ); ?>
	                	<span>
		            	 	<?php echo wc_help_tip( esc_html__( '- Global Setting: WooCommerce >> Settings >> Booking & Rental >> Product Details >> Product Template. <br/> - Other: Made in Templates of Elementor', 'ova-brw' ), true ); ?>
		            	 </span>		
	                </label>
	            </th>
	            <td>
	                <select id="ovabrw_product_templates" name="ovabrw_product_templates">
	                    <?php foreach ( $list_templates as $template_id => $template_title ): ?>
	                    	<option value="<?php echo esc_attr( $template_id ); ?>"<?php selected( $template_id, $product_template ); ?>>
	                    		<?php echo esc_html( $template_title ); ?>
	                    	</option>
	                    <?php endforeach; ?>
	                </select>
	            </td>
	        </tr>

	        <!-- Card template -->
	        <?php if ( ovabrw_global_typography() ): ?>
	           	<tr class="form-field ovabrw_card_template">
	                <th>
	                    <label>
	                    	<?php esc_html_e( 'Card template', 'ova-brw' ); ?>
	                    </label>
	                    <span>
		                	<?php 
		                	echo wc_help_tip( esc_html__( '- Card template is product template that display in listing product page. <br/> - Global Setting: WooCommerce >> Settings >> Booking & Rental >> Typography & Color >> Card', 'ova-brw' ), true );
		                	?>
		                </span>
	                </th>
	                <td>
	                    <select name="ovabrw_card_template">
	                        <option value="">
	                            <?php esc_html_e( 'Global Setting', 'ova-brw' ); ?>
	                        </option>
		                    <?php foreach ( $this->card_templates as $card => $label ): ?>
		                    	<option value="<?php echo esc_attr( $card ); ?>"<?php selected( $card_template, $card ); ?>>
		                            <?php echo esc_html( $label ); ?>
		                        </option>
			                <?php endforeach; ?>
	                    </select>
	                </td>
	            </tr>
	        <?php endif;
	    }

	    /**
	     * Save product category fields
	     */
	    public function save_fields( $term_id ) {
	    	// Single price format
	    	$single_price_format_type = ovabrw_get_meta_data( 'ovabrw_select_single_price_format', $_REQUEST );
	    	update_term_meta( $term_id, 'ovabrw_select_single_price_format', $single_price_format_type );
	    	$single_price_format = wp_kses_post( trim( ovabrw_get_meta_data( 'ovabrw_single_new_price_format', $_REQUEST ) ) );
	    	update_term_meta( $term_id, 'ovabrw_single_new_price_format', $single_price_format );
	    	// End single price format

	    	// Archive price format
	    	$archive_price_format_type = ovabrw_get_meta_data( 'ovabrw_select_archive_price_format', $_REQUEST );
	    	update_term_meta( $term_id, 'ovabrw_select_archive_price_format', $archive_price_format_type );
	    	$archive_price_format = wp_kses_post( trim( ovabrw_get_meta_data( 'ovabrw_archive_new_price_format', $_REQUEST ) ) );
	    	update_term_meta( $term_id, 'ovabrw_archive_new_price_format', $archive_price_format );
	    	// End archive price format

	    	// Display rental
	    	$display_rental = ovabrw_get_meta_data( 'ovabrw_cat_dis', $_REQUEST );
	    	update_term_meta( $term_id, 'ovabrw_cat_dis', $display_rental );

	    	// Custom taxonomies
	        $custom_taxonomies  = ovabrw_get_meta_data( 'ovabrw_custom_tax', $_REQUEST );
	        update_term_meta( $term_id, 'ovabrw_custom_tax', $custom_taxonomies );

	        // Custom checkout fields type
	        $cckf_type = ovabrw_get_meta_data( 'ovabrw_choose_custom_checkout_field', $_REQUEST );
	        update_term_meta( $term_id, 'ovabrw_choose_custom_checkout_field', $cckf_type );

	        // Custom checkout field
	        $cckf = ovabrw_get_meta_data( 'ovabrw_custom_checkout_field', $_REQUEST );
	        update_term_meta( $term_id, 'ovabrw_custom_checkout_field', $cckf );

	        // Specification type
	        $specification_type = ovabrw_get_meta_data( 'ovabrw_choose_specifications', $_REQUEST );
	        update_term_meta( $term_id, 'ovabrw_choose_specifications', $specification_type );

	        // Specifications
	        $specifications = ovabrw_get_meta_data( 'ovabrw_specifications', $_REQUEST );
	        update_term_meta( $term_id, 'ovabrw_specifications', $specifications );

	        // Show locations
	        $show_locations = ovabrw_get_meta_data( 'ovabrw_show_loc_booking_form', $_REQUEST );
	        update_term_meta( $term_id, 'ovabrw_show_loc_booking_form', $show_locations );

	        // Label pick-up date
	        $lable_pickup_date = ovabrw_get_meta_data( 'ovabrw_lable_pickup_date', $_REQUEST );
	        update_term_meta( $term_id, 'ovabrw_lable_pickup_date', $lable_pickup_date );

	        // Label drop-off date
	        $lable_dropoff_date = ovabrw_get_meta_data( 'ovabrw_lable_dropoff_date', $_REQUEST );
	        update_term_meta( $term_id, 'ovabrw_lable_dropoff_date', $lable_dropoff_date );

	        // Get product template
	        $product_template = ovabrw_get_meta_data( 'ovabrw_product_templates', $_REQUEST );
	        update_term_meta( $term_id, 'ovabrw_product_templates', $product_template );

	        // Card
	        $card_template = ovabrw_get_meta_data( 'ovabrw_card_template', $_REQUEST );
	        update_term_meta( $term_id, 'ovabrw_card_template', $card_template );
	    }
	}

	new OVABRW_Admin_Category_Fields();
}