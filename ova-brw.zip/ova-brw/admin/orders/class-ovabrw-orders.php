<?php if ( ! defined( 'ABSPATH' ) ) exit();

if ( ! class_exists( 'OVABRW_Admin_Orders' ) ) {
    class OVABRW_Admin_Orders {
        public function __construct() {
            // Admin Menu
            add_action('admin_menu', array( $this, 'ovabrw_add_menu' ) );

            // Create new order manually
            add_action( 'admin_init', array( $this, 'ovabrw_create_new_order_manully' ) );
        }

        public function ovabrw_add_menu() {
            add_submenu_page(
                'edit.php?post_type=product',
                __( 'Create Order', 'ova-brw' ),
                __( 'Create Order', 'ova-brw' ),
                apply_filters( 'ovabrw_create_order_cap' ,'edit_posts' ),
                'ovabrw-create-order',
                array( $this, 'ovabrw_create_order' )
            );
            
            add_submenu_page(
                'edit.php?post_type=product',
                __( 'Manage Order', 'ova-brw' ),
                __( 'Manage Order', 'ova-brw' ),
                apply_filters( 'ovabrw_manage_order_cap' ,'edit_posts' ),
                'ovabrw-manage-order',
                array( $this, 'ovabrw_display_order' )
            );
        }

        public function ovabrw_create_order() {
            include( OVABRW_PLUGIN_PATH.'admin/orders/views/html-create-order.php' );
        }

        public function ovabrw_display_order() {
            include( OVABRW_PLUGIN_PATH.'admin/orders/views/html-list-orders.php' );
        }

        public function ovabrw_get_address() {
            $data_address = array();

            $first_name         = isset( $_POST['ovabrw_first_name'] )  ? sanitize_text_field( $_POST['ovabrw_first_name'] )    : '';
            $last_name          = isset( $_POST['ovabrw_last_name'] )   ? sanitize_text_field( $_POST['ovabrw_last_name'] )     : '';
            $company            = isset( $_POST['ovabrw_company'] )     ? sanitize_text_field( $_POST['ovabrw_company'] )       : '';
            $email              = isset( $_POST['ovabrw_email'] )       ? sanitize_text_field( $_POST['ovabrw_email'] )         : '';
            $phone              = isset( $_POST['ovabrw_phone'] )       ? sanitize_text_field( $_POST['ovabrw_phone'] )         : '';
            $address_1          = isset( $_POST['ovabrw_address_1'] )   ? sanitize_text_field( $_POST['ovabrw_address_1'] )     : '';
            $address_2          = isset( $_POST['ovabrw_address_2'] )   ? sanitize_text_field( $_POST['ovabrw_address_2'] )     : '';
            $city               = isset( $_POST['ovabrw_city'] )        ? sanitize_text_field( $_POST['ovabrw_city'] )          : '';
            $country_setting    = isset( $_POST['ovabrw_country'] )     ? sanitize_text_field( $_POST['ovabrw_country'] )       : 'US';

            if ( strstr( $country_setting, ':' ) ) {
                $country_setting = explode( ':', $country_setting );
                $country         = current( $country_setting );
                $state           = end( $country_setting );
            } else {
                $country = $country_setting;
                $state   = '*';
            }

            $data_address = array(
                'billing' => array(
                    'first_name' => $first_name,
                    'last_name'  => $last_name,
                    'company'    => $company,
                    'email'      => $email,
                    'phone'      => $phone,
                    'address_1'  => $address_1,
                    'address_2'  => $address_2,
                    'city'       => $city,
                    'country'    => $country,
                ),
                'shipping' => array(),
            );

            $ship_to_different_address = isset( $_POST['ship_to_different_address'] ) ? sanitize_text_field( $_POST['ship_to_different_address'] ) : '';

            if ( $ship_to_different_address ) {
                $ship_first_name        = isset( $_POST['ship_ovabrw_first_name'] ) ? sanitize_text_field( $_POST['ship_ovabrw_first_name'] ) : '';
                $ship_last_name         = isset( $_POST['ship_ovabrw_last_name'] ) ? sanitize_text_field( $_POST['ship_ovabrw_last_name'] ) : '';
                $ship_company           = isset( $_POST['ship_ovabrw_company'] ) ? sanitize_text_field( $_POST['ship_ovabrw_company'] ) : '';
                $ship_phone             = isset( $_POST['ship_ovabrw_phone'] ) ? sanitize_text_field( $_POST['ship_ovabrw_phone'] ) : '';
                $ship_address_1         = isset( $_POST['ship_ovabrw_address_1'] ) ? sanitize_text_field( $_POST['ship_ovabrw_address_1'] ) : '';
                $ship_address_2         = isset( $_POST['ship_ovabrw_address_2'] ) ? sanitize_text_field( $_POST['ship_ovabrw_address_2'] ) : '';
                $ship_city              = isset( $_POST['ship_ovabrw_city'] ) ? sanitize_text_field( $_POST['ship_ovabrw_city'] ) : '';
                $ship_country_setting   = isset( $_POST['ship_ovabrw_country'] ) ? sanitize_text_field( $_POST['ship_ovabrw_country'] ) : 'US';

                if ( strstr( $ship_country_setting, ':' ) ) {
                    $ship_country_setting = explode( ':', $ship_country_setting );
                    $ship_country         = current( $ship_country_setting );
                    $ship_state           = end( $ship_country_setting );
                } else {
                    $ship_country = $ship_country_setting;
                    $ship_state   = '*';
                }

                $data_address['shipping'] = array(
                    'first_name' => $ship_first_name,
                    'last_name'  => $ship_last_name,
                    'company'    => $ship_company,
                    'email'      => $email,
                    'phone'      => $ship_phone,
                    'address_1'  => $ship_address_1,
                    'address_2'  => $ship_address_2,
                    'city'       => $ship_city,
                    'country'    => $ship_country,
                );
            }

            return apply_filters( 'ovabrw_ft_get_address', $data_address );
        }

        public function ovabrw_add_order_item( $order_id ) {
            // Order data
            $data_order = array();

            if ( ! $order_id ) {
                return $data_order;
            }

            $order = wc_get_order( $order_id ); // Get order

            // Get order items
            $order_items    = $order->get_items(); 
            $order_total    = $total_deposit = $total_remaining = $remaining_tax = $total_insurance = $insurance_tax = 0;
            $date_format    = ovabrw_get_date_format();
            $time_format    = ovabrw_get_time_format();
            $tax_rate_id    = '';
            $tax_amount     = 0;

            // Init $i
            $i = 0;

            // Loop order items
            foreach ( $order_items as $item_id => $item ) {
                $data_item = array();

                $product_id = $item->get_product_id();
                $product    = $item->get_product();

                // Rental type
                $rental_type = get_post_meta( $product_id, 'ovabrw_price_type', true );
                $charged_by  = get_post_meta( $product_id, 'ovabrw_define_1_day', true );

                // Pick-up location
                $pickup_location = isset( $_POST['ovabrw_pickup_loc'][$i] ) ? sanitize_text_field( $_POST['ovabrw_pickup_loc'][$i] ) : '';
                if ( $pickup_location === 'other_location' && isset( $_POST['ovabrw_other_pickup_loc'][$i] ) ) {
                    $pickup_location = $_POST['ovabrw_other_pickup_loc'][$i];
                }

                // Drop-off location
                $dropoff_location = isset( $_POST['ovabrw_pickoff_loc'][$i] ) ? sanitize_text_field( $_POST['ovabrw_pickoff_loc'][$i] ) : '';
                if ( $dropoff_location === 'other_location' && isset( $_POST['ovabrw_other_pickoff_loc'][$i] ) ) {
                    $dropoff_location = $_POST['ovabrw_other_pickoff_loc'][$i];
                }

                // Pick-up date
                $pickup_date = isset( $_POST['ovabrw_pickup_date'][$i] ) ? sanitize_text_field( $_POST['ovabrw_pickup_date'][$i] ) : '';

                // Location
                $location = isset( $_POST['ovabrw_location'][$i] ) ? sanitize_text_field( $_POST['ovabrw_location'][$i] ) : '';

                // Start time
                $start_time = isset( $_POST['ovabrw_start_time'][$i] ) ? sanitize_text_field( $_POST['ovabrw_start_time'][$i] ) : '';
                if ( strtotime( $start_time ) ) $pickup_date .= ' ' . $start_time;

                // Drop-off date
                $dropoff_date = isset( $_POST['ovabrw_pickoff_date'][$i] ) ? sanitize_text_field( $_POST['ovabrw_pickoff_date'][$i] ) : '';

                // Adults
                $number_adults = isset( $_POST['ovabrw_adults'][$i] ) ? intval( $_POST['ovabrw_adults'][$i] ) : 0;

                // Children
                $number_children = isset( $_POST['ovabrw_children'][$i] ) ? intval( $_POST['ovabrw_children'][$i] ) : 0;

                // Babies
                $number_babies = isset( $_POST['ovabrw_babies'][$i] ) ? intval( $_POST['ovabrw_babies'][$i] ) : 0;

                // Quantity
                $quantity = isset( $_POST['ovabrw_number_vehicle'][$i] ) ? sanitize_text_field( $_POST['ovabrw_number_vehicle'][$i] ) : 1;

                // Vehicle ID
                $vehilce_ids = isset( $_POST['ovabrw_id_vehicle'][$i] ) ? sanitize_text_field( $_POST['ovabrw_id_vehicle'][$i] ) : '';

                // Resources
                $resources = isset( $_POST['ovabrw_resource_checkboxs'][$product_id] ) ? $_POST['ovabrw_resource_checkboxs'][$product_id] : [];
                $res_qty   = isset( $_POST['ovabrw_resource_quantity'][$product_id] ) ? $_POST['ovabrw_resource_quantity'][$product_id] : [];

                // Services
                $services = isset( $_POST['ovabrw_service'][$product_id] ) ? $_POST['ovabrw_service'][$product_id] : [];
                $serv_qty = isset( $_POST['ovabrw_service_qty'][$product_id] ) ? $_POST['ovabrw_service_qty'][$product_id] : [];

                // Custom Checkout Fields
                $list_fields = get_option( 'ovabrw_booking_form', array() );

                // Total time
                $total_time = isset( $_POST['ovabrw_total_time'][$i] ) ? sanitize_text_field( $_POST['ovabrw_total_time'][$i] ) : '';

                // Price detail
                $price_detail = isset( $_POST['ovabrw_price_detail'][$i] ) ? sanitize_text_field( $_POST['ovabrw_price_detail'][$i] ) : 0;

                // Get packages
                $packages = isset( $_POST['ovabrw_package'][$i] ) ? sanitize_text_field( $_POST['ovabrw_package'][$i] ) : '';

                // Get item insurance amount
                $item_insurance = isset( $_POST['ovabrw_amount_insurance'][$i] ) ? floatval( $_POST['ovabrw_amount_insurance'][$i] ) : 0;

                // Get item deposit amount
                $item_deposit = isset( $_POST['ovabrw_amount_deposite'][$i] ) ? floatval( $_POST['ovabrw_amount_deposite'][$i] ) : 0;

                // Get item remaining amount
                $item_remaining = isset( $_POST['ovabrw_amount_remaining'][$i] ) ? floatval( $_POST['ovabrw_amount_remaining'][$i] ) : 0;

                // Item subtotal
                $item_subtotal = isset( $_POST['ovabrw_total_product'][$i] ) ? floatval( $_POST['ovabrw_total_product'][$i] ) : 0;

                if ( $item_insurance ) $item_subtotal -= $item_insurance;

                $ovabrw_waypoints = [];
                $distance = $extra_time = $duration = '';

                if ( 'taxi' === $rental_type ) {
                    $pickup_location  = isset( $_POST['ovabrw_pickup_location'][$i] ) ? trim( sanitize_text_field( $_POST['ovabrw_pickup_location'][$i] ) ) : '';
                    $dropoff_location = isset( $_POST['ovabrw_dropoff_location'][$i] ) ? trim( sanitize_text_field( $_POST['ovabrw_dropoff_location'][$i] ) ) : '';

                    // Get waypoints
                    $waypoints = isset( $_POST['ovabrw_waypoint_address'][$product_id] ) ? $_POST['ovabrw_waypoint_address'][$product_id] : [];

                    // Get duration map
                    $duration_map = isset( $_POST['ovabrw-duration-map'][$i] ) ? sanitize_text_field( $_POST['ovabrw-duration-map'][$i] ) : '';

                    // Get duration
                    $duration = isset( $_POST['ovabrw-duration'][$i] ) ? sanitize_text_field( $_POST['ovabrw-duration'][$i] ) : '';

                    // Get distance
                    $distance = isset( $_POST['ovabrw-distance'][$i] ) ? sanitize_text_field( $_POST['ovabrw-distance'][$i] ) : '';

                    // Get extra time
                    $extra_time = isset( $_POST['ovabrw_extra_time'][$i] ) ? sanitize_text_field( $_POST['ovabrw_extra_time'][$i] ) : '';

                    // Get new input date
                    $new_input_date = ovabrw_taxi_input_date( $pickup_date, $duration );

                    if ( $new_input_date['pickup_date_new'] ) {
                        $pickup_date = date( $date_format.' '.$time_format, $new_input_date['pickup_date_new'] );
                    }
                    if ( $new_input_date['pickoff_date_new'] ) {
                        $dropoff_date = date( $date_format.' '.$time_format, $new_input_date['pickoff_date_new'] );
                    }
                }

                // Check drop-off date
                if ( ! $dropoff_date ) {
                    $dropoff_date = $pickup_date;
                }

                // Date real
                $pickup_date_real   = $pickup_date;
                $dropoff_date_real  = $dropoff_date;
                $period_label       = '';

                if ( 'day' === $rental_type ) {
                    if ( 'day' === $charged_by ) {
                        $pickup_date_real   = date( $date_format, strtotime( $pickup_date ) ) . ' 00:00';
                        $dropoff_date_real  = date( $date_format, strtotime( $dropoff_date ) ) . ' 24:00';
                    } elseif ( 'hotel' === $charged_by ) {
                        $pickup_date_real   = date( $date_format, strtotime( $pickup_date ) ) . ' ' .apply_filters( 'brw_real_pickup_time_hotel', '14:00' );
                        $dropoff_date_real  = date( $date_format, strtotime( $dropoff_date ) ) . ' ' .apply_filters( 'brw_real_dropoff_time_hotel', '11:00' );
                    }
                } elseif ( 'period_time' === $rental_type ) {
                    // Get info preiod
                    $info_period = OVABRW()->options->get_rental_info_period( $product_id, strtotime( $pickup_date ), $rental_type, $packages );
                    $pickup_date    = date( $date_format.' '.$time_format, $info_period['start_time'] );
                    $dropoff_date   = date( $date_format.' '.$time_format, $info_period['end_time'] );

                    // Date real
                    $pickup_date_real   = $pickup_date;
                    $dropoff_date_real  = $dropoff_date;
                    $period_label       = $info_period['period_label'];
                } elseif ( 'transportation' === $rental_type ) {
                    $pickup_date_real   = date( $date_format, strtotime( $pickup_date ) ) . ' 00:00';;
                    $dropoff_date_real  = date( $date_format, strtotime( $dropoff_date ) ) . ' 00:00';;
                }

                // Rental type
                $data_item[ 'rental_type' ] = $rental_type;

                // Pick-up location
                $data_item[ 'ovabrw_pickup_loc' ] = $pickup_location;

                // Waypoints
                if ( ! empty( $waypoints ) && is_array( $waypoints ) ) {
                    foreach ( $waypoints as $k => $waypoint ) {
                        $data_item[sprintf( esc_html__( 'Waypoint %s', 'ova-brw' ), $k + 1 )] = $waypoint;
                    }
                }

                // Drop-off location
                $data_item[ 'ovabrw_pickoff_loc' ] = $dropoff_location;

                // Location - Appointment
                if ( $location ) {
                    $data_item[ 'ovabrw_location' ] = $location;
                }

                // Dates
                $data_item[ 'ovabrw_pickup_date' ]              = $pickup_date;
                $data_item[ 'ovabrw_pickoff_date' ]             = $dropoff_date;
                $data_item[ 'ovabrw_pickup_date_strtotime' ]    = strtotime( $pickup_date );
                $data_item[ 'ovabrw_pickoff_date_strtotime' ]   = strtotime( $dropoff_date );
                $data_item[ 'ovabrw_pickup_date_real' ]         = $pickup_date_real;
                $data_item[ 'ovabrw_pickoff_date_real' ]        = $dropoff_date_real;

                // Guests
                if ( $number_adults ) $data_item[ 'ovabrw_adults' ]     = $number_adults;
                if ( $number_children ) $data_item[ 'ovabrw_children' ] = $number_children;
                if ( $number_babies ) $data_item[ 'ovabrw_babies' ]     = $number_babies;

                // Package label
                $data_item[ 'period_label' ] = $period_label;

                // Quantity
                $data_item[ 'ovabrw_number_vehicle' ] = $quantity;

                // Vehicle ID
                if ( $vehilce_ids ) $data_item[ 'id_vehicle' ] = $vehilce_ids;

                // Total Days
                $data_item[ 'ovabrw_total_days' ] = $total_time;

                // Price detail
                $data_item[ 'ovabrw_price_detail' ] = $price_detail;
                
                // Define day
                if ( 'day' === $rental_type ) {
                    $data_item[ 'define_day' ] = $charged_by;
                }

                // Distance
                if ( $distance ) {
                    $data_item['ovabrw_distance'] = ovarw_taxi_get_distance_text( $distance, $product_id );
                }

                // Extra time
                if ( $extra_time ) {
                    $data_item['ovabrw_extra_time'] = sprintf( esc_html__( '%s hour(s)', 'ova-brw' ), $extra_time );
                }

                // Duration
                if ( $duration ) {
                    $data_item['ovabrw_duration'] = ovarw_taxi_get_duration_text( $duration );
                }

                // Custom Checkout Fields
                $list_fields    = ovabrw_get_cckf( $product_id );
                $custom_ckf     = array();
                $custom_ckf_qty = [];

                if ( ! empty( $list_fields ) && is_array( $list_fields ) ) {
                    foreach ( $list_fields as $key => $field ) {
                        if ( $field['type'] === 'file' ) {
                            $data_file = isset( $_FILES[$key] ) ? $_FILES[$key] : '';

                            if ( $data_file ) {
                                $files = array();

                                if ( isset( $data_file['name'][$product_id] ) ) {
                                    $files['name'] = $data_file['name'][$product_id];
                                }
                                if ( isset( $data_file['full_path'][$product_id] ) ) {
                                    $files['full_path'] = $data_file['full_path'][$product_id];
                                }
                                if ( isset( $data_file['type'][$product_id] ) ) {
                                    $files['type'] = $data_file['type'][$product_id];
                                }
                                if ( isset( $data_file['tmp_name'][$product_id] ) ) {
                                    $files['tmp_name'] = $data_file['tmp_name'][$product_id];
                                }
                                if ( isset( $data_file['error'][$product_id] ) ) {
                                    $files['error'] = $data_file['error'][$product_id];
                                }
                                if ( isset( $data_file['size'][$product_id] ) ) {
                                    $files['size'] = $data_file['size'][$product_id];
                                }

                                if ( isset( $files['size'] ) && $files['size'] ) {
                                    $mb = absint( $files['size'] ) / 1048576;

                                    if ( $mb > $field['max_file_size'] ) {
                                        continue;
                                    }
                                }

                                $overrides = [
                                    'test_form' => false,
                                    'mimes'     => apply_filters( 'ovabrw_ft_file_mimes', [
                                        'jpg'   => 'image/jpeg',
                                        'jpeg'  => 'image/pjpeg',
                                        'png'   => 'image/png',
                                        'pdf'   => 'application/pdf',
                                        'doc'   => 'application/msword',
                                    ]),
                                ];

                                require_once( ABSPATH . 'wp-admin/includes/admin.php' );

                                $upload = wp_handle_upload( $files, $overrides );

                                if ( isset( $upload['error'] ) ) {
                                    continue;
                                }

                                $data_item[$key] = '<a href="'.esc_url( $upload['url'] ).'" title="'.esc_attr( basename( $upload['file'] ) ).'" target="_blank">'.esc_attr( basename( $upload['file'] ) ).'</a>';
                            }
                        } else {
                            $value = isset( $_POST[$key][$product_id] ) ? $_POST[$key][$product_id] : '';

                            if ( ! empty( $value ) && 'on' === $field['enabled'] ) {
                                if ( 'select' === $field['type'] ) {
                                    $custom_ckf[$key] = sanitize_text_field( $value );

                                    if ( isset( $_POST[$key.'_qty'] ) && ! empty( $_POST[$key.'_qty'] ) ) {
                                        if ( isset( $_POST[$key.'_qty'][$product_id][$value] ) && absint( $_POST[$key.'_qty'][$product_id][$value] ) ) {
                                            $custom_ckf_qty[$value] = absint( $_POST[$key.'_qty'][$product_id][$value] );
                                        }
                                    }

                                    $options_key = $options_text = array();
                                    if ( ovabrw_check_array( $field, 'ova_options_key' ) ) {
                                        $options_key = $field['ova_options_key'];
                                    }

                                    if ( ovabrw_check_array( $field, 'ova_options_text' ) ) {
                                        $options_text = $field['ova_options_text'];
                                    }

                                    $key_op = array_search( $value, $options_key );

                                    if ( ! is_bool( $key_op ) ) {
                                        if ( ovabrw_check_array( $options_text, $key_op ) ) {
                                            if ( isset( $custom_ckf_qty[$value] ) && absint( $custom_ckf_qty[$value] ) ) {
                                                $value = $options_text[$key_op] . ' (x'.absint( $custom_ckf_qty[$value] ).')';
                                            } else {
                                                $value = $options_text[$key_op];
                                            }
                                        }
                                    }
                                }

                                if ( 'checkbox' === $field['type'] ) {
                                    $checkbox_val = $checkbox_key = $checkbox_text = array();

                                    if ( ! empty( $value ) && is_array( $value ) ) {
                                        $custom_ckf[$key] = $value;

                                        if ( isset( $_POST[$key.'_qty'][$product_id] ) && ! empty( $_POST[$key.'_qty'][$product_id] ) && is_array( $_POST[$key.'_qty'][$product_id] ) ) {
                                            $custom_ckf_qty = $custom_ckf_qty + $_POST[$key.'_qty'][$product_id];
                                        }

                                        if ( ovabrw_check_array( $field, 'ova_checkbox_key' ) ) {
                                            $checkbox_key = $field['ova_checkbox_key'];
                                        }

                                        if ( ovabrw_check_array( $field, 'ova_checkbox_text' ) ) {
                                            $checkbox_text = $field['ova_checkbox_text'];
                                        }

                                        foreach ( $value as $val_cb ) {
                                            $key_cb = array_search( $val_cb, $checkbox_key );
                                            $qty    = isset( $custom_ckf_qty[$val_cb] ) && absint( $custom_ckf_qty[$val_cb] ) ? absint( $custom_ckf_qty[$val_cb] ) : '';

                                            if ( ! is_bool( $key_cb ) ) {
                                                if ( ovabrw_check_array( $checkbox_text, $key_cb ) ) {

                                                    if ( $qty ) {
                                                        array_push( $checkbox_val , $checkbox_text[$key_cb] . ' (x'.$qty.')' );
                                                    } else {
                                                        array_push( $checkbox_val , $checkbox_text[$key_cb] );
                                                    }
                                                }
                                            }
                                        }

                                        if ( ! empty( $checkbox_val ) && is_array( $checkbox_val ) ) {
                                            $value = join( ", ", $checkbox_val );
                                        }
                                    }
                                }

                                if ( 'radio' === $field['type'] ) {
                                    $custom_ckf[$key] = sanitize_text_field( $value );

                                    if ( $custom_ckf[$key] && isset( $_POST[$key.'_qty'][$product_id] ) && ! empty( $_POST[$key.'_qty'][$product_id] ) ) {
                                        $qty = isset( $_POST[$key.'_qty'][$product_id][$custom_ckf[$key]] ) && absint( $_POST[$key.'_qty'][$product_id][$custom_ckf[$key]] ) ? absint( $_POST[$key.'_qty'][$product_id][$custom_ckf[$key]] ) : 1;
                                        $custom_ckf_qty[$key] = $qty;

                                        $value .= ' (x'.$qty.')';
                                    }
                                }

                                $data_item[$key] = $value;
                            }
                        }
                    }
                }

                if ( ! empty( $custom_ckf ) ) {
                    $data_item[ 'ovabrw_custom_ckf' ] = $custom_ckf;
                }

                if ( ! empty( $custom_ckf_qty ) ) {
                    $data_item[ 'ovabrw_custom_ckf_qty' ] = $custom_ckf_qty;
                }

                // Add Resources
                if ( ! empty( $resources ) && is_array( $resources ) ) {
                    $data_resources = $name_resources = [];

                    $resource_ids    = get_post_meta( $product_id, 'ovabrw_resource_id', true );
                    $resource_names  = get_post_meta( $product_id, 'ovabrw_resource_name', true );

                    foreach ( $resources as $k => $rs_id ) {
                        $rs_k = array_search( $rs_id, $resource_ids );

                        if ( ! is_bool( $rs_k ) ) {
                            if ( ovabrw_check_array( $resource_names, $rs_k ) ) {
                                $res_name = $resource_names[$rs_k];

                                $data_resources[$rs_id] = $res_name;

                                if ( isset( $res_qty[$rs_id] ) && absint( $res_qty[$rs_id] ) ) {
                                    $res_name .= ' (x'.absint( $res_qty[$rs_id] ).')';
                                }

                                array_push( $name_resources, $res_name );
                            }
                        }
                    }

                    $data_item['ovabrw_resources']      = $data_resources;
                    $data_item['ovabrw_resources_qty']  = $res_qty;

                    if ( count( $name_resources ) == 1 ) {
                        $data_item[ esc_html__( 'Resource', 'ova-brw' ) ] = join( ', ', $name_resources );
                    } else {
                        $data_item[ esc_html__( 'Resources', 'ova-brw' ) ] = join( ', ', $name_resources );
                    } 
                }

                // Add Services
                if ( ! empty( $services ) ) {
                    $data_item['ovabrw_services'] = $services;
                    $services_qty = [];
                    
                    $services_id      = get_post_meta( $product_id, 'ovabrw_service_id', true ); 
                    $services_name    = get_post_meta( $product_id, 'ovabrw_service_name', true );
                    $services_label   = get_post_meta( $product_id, 'ovabrw_label_service', true ); 

                    foreach ( $services as $val_ser ) {
                        if ( isset( $serv_qty[$val_ser] ) && absint( $serv_qty[$val_ser] ) ) {
                            $services_qty[$val_ser] = $serv_qty[$val_ser];
                        }

                        if ( ! empty( $services_id ) && is_array( $services_id ) ) {
                            foreach ( $services_id as $key => $value ) {
                                if ( is_array( $value ) && ! empty( $value ) ) {
                                    foreach ( $value as $k => $val ) {
                                        if ( $val_ser == $val && ! empty( $val ) ) {
                                            $service_name = $services_name[$key][$k];

                                            if ( isset( $services_qty[$val_ser] ) && absint( $services_qty[$val_ser] ) ) {
                                                $service_name .= ' (x'.absint( $services_qty[$val_ser] ).')';
                                            }

                                            $service_label = $services_label[$key];
                                            $data_item[$service_label] = $service_name;
                                        }
                                    }
                                }
                            }
                        }
                    }

                    $data_item['ovabrw_services_qty'] = $services_qty;
                }

                // Amount of insurance
                if ( $item_insurance ) {
                    $data_item[ 'ovabrw_insurance_amount' ] = $item_insurance;

                    $sub_insurance_tax = OVABRW()->options->get_insurance_tax_amount( $item_insurance );

                    if ( $sub_insurance_tax ) {
                        $insurance_tax += $sub_insurance_tax;

                        $data_item[ 'ovabrw_insurance_tax' ] = $sub_insurance_tax;
                    }
                }

                // Deposit
                if ( $item_deposit ) {
                    $data_item[ 'ovabrw_deposit_type' ]     = 'value';
                    $data_item[ 'ovabrw_deposit_value' ]    = $item_deposit;
                    $data_item[ 'ovabrw_deposit_amount' ]   = $item_deposit;
                    $data_item[ 'ovabrw_remaining_amount' ] = $item_remaining;
                    $data_item[ 'ovabrw_total_payable' ]    = $item_subtotal;
                    $item_subtotal = $item_deposit;
                }

                // Order total
                $order_total += $item_subtotal;

                // Taxable
                $item_taxes = false;

                if ( wc_tax_enabled() ) {
                    $tax_rates = WC_Tax::get_rates( $product->get_tax_class() );
                    if ( ! empty( $tax_rates ) ) {
                        $tax_rate_id = key( $tax_rates );
                    }

                    // Remaining tax
                    $item_remaining_tax = OVABRW()->options->get_taxes_by_price( $product, $item_remaining );
                    $remaining_tax      += $item_remaining_tax;

                    // Add item remaining tax
                    $data_item['ovabrw_remaining_tax'] = $item_remaining_tax;

                    if ( wc_prices_include_tax() ) {
                        $taxes          = WC_Tax::calc_inclusive_tax( $item_subtotal, $tax_rates );
                        $item_tax       = WC_Tax::get_tax_total( $taxes );
                        $tax_amount    += $item_tax;
                        $item_subtotal -= $item_tax;
                    } else {
                        $taxes          = WC_Tax::calc_exclusive_tax( $item_subtotal, $tax_rates );
                        $item_tax       = WC_Tax::get_tax_total( $taxes );
                        $tax_amount    += $item_tax;
                        $order_total   += $item_remaining_tax;
                    }

                    $item_taxes = array(
                        'total'    => $taxes,
                        'subtotal' => $taxes,
                    );
                }

                // Update item meta data
                foreach ( $data_item as $meta_key => $meta_value ) {
                    $item->update_meta_data( $meta_key, $meta_value );
                }

                // Update item meta
                $item->set_props(
                    array(
                        'total'     => $item_subtotal,
                        'subtotal'  => $item_subtotal,
                        'taxes'     => $item_taxes
                    )
                );

                $item->save();
                // End update item meta
                
                $total_deposit      += $item_deposit;
                $total_remaining    += $item_remaining;
                $total_insurance    += $item_insurance;

                $i++;
            }

            $data_order = [
                'order_total'       => $order_total,
                'total_insurance'   => $total_insurance,
                'insurance_tax'     => $insurance_tax,
                'total_deposit'     => $total_deposit,
                'total_remaining'   => $total_remaining,
                'remaining_tax'     => $remaining_tax,
                'tax_rate_id'       => $tax_rate_id,
                'tax_amount'        => $tax_amount
            ];

            return apply_filters( 'ovabrw_ft_add_order_item', $data_order, $order_id );
        }

        public function ovabrw_create_new_order_manully() {
            if ( isset( $_POST['ovabrw_create_order'] ) && $_POST['ovabrw_create_order'] == 'create_order' ) {
                do_action( 'ovabrw_before_create_new_order_manully', $_POST );

                // Check Permission
                if ( ! current_user_can( apply_filters( 'ovabrw_create_order' ,'publish_posts' ) ) ) {
                    echo '<div class="notice notice-error is-dismissible">
                            <h2>'.esc_html__( 'You don\'t have permission to create order', 'ova-brw' ).'</h2>
                        </div>';
                    return;
                }

                // Create new order
                $order      = wc_create_order(); 
                $order_id   = $order->get_id();
                $order_meta = array(); // Order meta boxes

                // Get array product ids
                $product_ids    = isset( $_POST['ovabrw_name_product'] ) ? $_POST['ovabrw_name_product'] : [];
                $currency       = isset( $_POST['currency'] ) && $_POST['currency'] ? $_POST['currency'] : '';

                if ( $currency ) $order->set_currency( $currency );

                // Has deposit
                $has_deposit = false;

                // Create order item
                if ( ovabrw_array_exists( $product_ids ) ) {
                    foreach ( $product_ids as $key => $product_id ) {
                        $item_total     = 0;
                        $product_id     = trim( sanitize_text_field( $product_id ) );
                        $product        = wc_get_product( $product_id );
                        $quantity       = isset( $_POST['ovabrw_number_vehicle'][$key] ) ? floatval( $_POST['ovabrw_number_vehicle'][$key] ) : 1;
                        $item_deposit   = isset( $_POST['ovabrw_amount_deposite'][$key] ) ? floatval( $_POST['ovabrw_amount_deposite'][$key] ) : 0;

                        if ( $item_deposit && floatval( $item_deposit ) > 0 ) {
                            $has_deposit = true;
                        }

                        $order->add_product( $product, $quantity );
                    }
                }

                // Get order data
                $order_data = $this->ovabrw_add_order_item( $order_id ); // Get order data

                // Get data total
                $order_total = $order_data['order_total'];

                // Taxable
                $tax_rate_id    = $order_data['tax_rate_id'];
                $tax_amount     = $order_data['tax_amount'];
                
                if ( $has_deposit ) {
                    $order_meta['_ova_has_deposit']        = 1;
                    $order_meta['_ova_deposit_amount']     = $order_data['total_deposit'];
                    $order_meta['_ova_remaining_amount']   = $order_data['total_remaining'];

                    if ( $order_data['remaining_tax'] ) {
                        $order_meta['_ova_remaining_tax'] = $order_data['remaining_tax'];
                    }
                }

                // Insurance
                if ( $order_data['total_insurance'] ) {
                    $insurance_tax  = floatval( $order_data['insurance_tax'] );
                    $insurance_name = OVABRW()->options->get_insurance_name();
                    $order_meta['_ova_insurance_amount'] = $order_data['total_insurance'];

                    if ( $insurance_tax ) {
                        $order_total    += $insurance_tax;
                        $tax_amount     += $insurance_tax;
                        
                        $order_meta['_ova_insurance_tax'] = $insurance_tax;
                    }

                    $item_fee = new WC_Order_Item_Fee();
                    $item_fee->set_props( array(
                        'name'      => $insurance_name,
                        'tax_class' => 0,
                        'amount'    => $order_data['total_insurance'],
                        'total'     => $order_data['total_insurance'],
                        'total_tax' => $insurance_tax,
                        'taxes'     => array(
                            'total' => array( $tax_rate_id => $insurance_tax ),
                        ),
                        'order_id'  => $order_id
                    ));

                    $item_fee->save();

                    $order->add_item( $item_fee );

                    $order_meta['_ova_insurance_key'] = sanitize_title( $insurance_name );
                    $order_total += $order_data['total_insurance'];
                }

                foreach ( $order_meta as $key => $update ) {
                    $order->update_meta_data( $key, $update );
                }

                // Set customer
                $email = isset( $_POST['ovabrw_email'] ) ? sanitize_text_field( $_POST['ovabrw_email'] )         : '';
                $user = get_user_by( 'email', $email );
                if ( $user ) {
                    $order->set_customer_id( $user->ID );
                }

                // Set address
                $data_address = $this->ovabrw_get_address();
                $order->set_address( $data_address['billing'], 'billing' );

                $ship_to_different_address = isset( $_POST['ship_to_different_address'] ) ? sanitize_text_field( $_POST['ship_to_different_address'] ) : '';
                if ( $ship_to_different_address ) {
                    $order->set_address( $data_address['shipping'], 'shipping' );
                } else {
                    $order->set_address( $data_address['billing'], 'shipping' );
                }

                // Taxable
                if ( wc_tax_enabled() ) {
                    $item_tax = new WC_Order_Item_Tax();

                    $item_tax->set_props(
                        array(
                            'rate_id'            => $tax_rate_id,
                            'tax_total'          => $tax_amount,
                            'shipping_tax_total' => 0,
                            'rate_code'          => WC_Tax::get_rate_code( $tax_rate_id ),
                            'label'              => WC_Tax::get_rate_label( $tax_rate_id ),
                            'compound'           => WC_Tax::is_compound( $tax_rate_id ),
                            'rate_percent'       => WC_Tax::get_rate_percent_value( $tax_rate_id ),
                        )
                    );

                    $item_tax->save();

                    $order->add_item( $item_tax );
                    $order->set_cart_tax( $tax_amount );

                    if ( wc_prices_include_tax() ) {
                        $order->update_meta_data( '_ova_prices_include_tax', 1 );
                    }
                }

                // Order status
                $order_status = isset( $_POST['status_order'] ) ? sanitize_text_field( $_POST['status_order'] ) : '';

                if ( $order_status ) {
                    $order->update_status( $order_status );
                }

                // Order set total
                $order->set_total( $order_total );
                $order->save();

                do_action( 'ovabrw_after_create_new_order_manully', $_POST, $order );

                // Redirect to order detail
                if ( $order_id ) {
                    wp_safe_redirect( $order->get_edit_order_url() );
                    exit;
                }
            }
        }

        public function ovabrw_show_admin_notice_success() {
            if ( isset( $_POST['success'] ) && $_POST['success'] ) {
                ?>
                <div class="notice notice-success is-dismissible">
                    <p><?php esc_html_e( $_POST['success'] ); ?></p>
                </div>
                <?php
            }
        }

        public function ovabrw_show_admin_notice_error() {
            if ( isset( $_POST['error'] ) && $_POST['error'] ) {
                ?>
                <div class="notice notice-error is-dismissible">
                    <p><?php esc_html_e( $_POST['error'] ); ?></p>
                </div>
                <?php
            }
        }
    }

    new OVABRW_Admin_Orders();
}