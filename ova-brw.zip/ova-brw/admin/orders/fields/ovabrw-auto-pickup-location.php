<?php defined( 'ABSPATH' ) || exit; ?>

<div class="rental_item ovabrw-location-field">
    <label>
        <?php esc_html_e( 'Pick-up Location', 'ova-brw' ); ?>
    </label>
    <span class="location-field">
        <?php ovabrw_text_input([
            'type'          => 'text',
            'id'            => 'ovabrw_pickup_location_'.$this->get_id(),
            'class'         => 'ovabrw_pickup_location',
            'name'          => 'ovabrw_pickup_location[]',
            'placeholder'   => esc_html__( 'Enter a location', 'ova-brw' ),
            'required'      => true
        ]); ?>
        <?php ovabrw_text_input([
            'type'      => 'hidden',
            'id'        => 'ovabrw_origin',
            'name'      => 'ovabrw_origin',
            'required'  => true
        ]); ?>
        <i class="flaticon-add btn-add-waypoint" aria-hidden="true"></i>
    </span>
</div>