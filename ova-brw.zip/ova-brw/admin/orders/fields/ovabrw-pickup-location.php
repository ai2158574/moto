<?php defined( 'ABSPATH' ) || exit;

if ( $this->show_location( 'pickup' ) ):
    $pickup_location  = $this->get_value( 'st_pickup_loc' );
    $dropoff_location = $this->get_value( 'st_dropoff_loc' );

    if ( 'appointment' == $this->get_type() ):
        // Show other location
        $other_location = $this->get_value( 'show_other_location_pickup_product' );
    ?>
    	<div class="rental_item show_pickup_loc">
            <label>
                <?php esc_html_e( 'Location', 'ova-brw' ); ?>
            </label>
            <?php if ( ovabrw_array_exists( $pickup_location ) ): ?>
                <select name="ovabrw_pickup_loc[]" class="ovabrw-input-required">
                        <option value="">
                            <?php esc_html_e( 'Select Location', 'ova-brw' ); ?>
                        </option>
                        <?php foreach ( $pickup_location as $location ): ?>
                            <option value="<?php echo esc_attr( $location ); ?>">
                                <?php echo esc_html( $location ); ?>
                            </option>
                        <?php endforeach; ?>
                        <?php if ( 'yes' == $other_location ): ?>
                            <option value="other_location">
                                <?php esc_html_e( 'Other Location', 'ova-brw' ); ?>
                            </option>
                        <?php endif; ?>
                    </select>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <div class="rental_item show_pickup_loc">
            <label>
                <?php esc_html_e( 'Pick-up Location', 'ova-brw' ); ?>
            </label>
            <?php if ( 'transportation' == $this->type ) {
                echo OVABRW()->options->get_html_location_transportation( 'ovabrw_pickup_loc[]', 'required', '', $this->ID, 'pickup' );
            } else {
                if ( ovabrw_array_exists( $pickup_location ) && ovabrw_array_exists( $dropoff_location ) ) {
                    echo OVABRW()->options->get_html_couple_location( 'ovabrw_pickup_loc[]', 'required ovabrw_pickup_loc', '', $this->get_id(), 'pickup' );
                } else {
                    echo OVABRW()->options->get_html_location( 'ovabrw_pickup_loc[]', 'required ovabrw_pickup_loc', '', $this->get_id(), 'pickup' );
                }
            } ?>
        </div>
<?php endif;
endif; ?>