<?php defined( 'ABSPATH' ) || exit;

if ( $this->show_location( 'dropoff' ) ):
    $pickup_location  = $this->get_value( 'st_pickup_loc' );
    $dropoff_location = $this->get_value( 'st_dropoff_loc' );
?>
	<div class="rental_item show_pickoff_loc">
        <label>
            <?php esc_html_e( 'Drop-off Location', 'ova-brw' ); ?>
        </label>
        <?php if ( 'transportation' == $this->type ) {
            echo OVABRW()->options->get_html_location_transportation( 'ovabrw_pickoff_loc[]', 'required', '', $this->get_id(), 'dropoff' );
        } else {
            if ( ovabrw_array_exists( $pickup_location ) && ovabrw_array_exists( $dropoff_location ) ) {
                echo OVABRW()->options->get_html_couple_location( 'ovabrw_pickoff_loc[]', 'required', '', $this->ID, 'dropoff' );
            } else {
                echo OVABRW()->options->get_html_location( 'ovabrw_pickoff_loc[]', 'required', '', $this->ID, 'dropoff' );
            }
        } ?>
    </div>
<?php endif;