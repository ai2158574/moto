<?php defined( 'ABSPATH' ) || exit;

$manage_store = $this->get_value( 'manage_store' );

if ( 'store' == $manage_store || 'appointment' == $this->get_type() ):
    if ( $this->show_quantity() ):
        $stock_qty = $this->get_value( 'car_count' );
?>
    <div class="rental_item show_number_vehicle">
        <label for="ovabrw_number_vehicle">
            <?php esc_html_e( 'Quantity', 'ova-brw' ); ?>
        </label>
        <?php ovabrw_text_input([
            'type'      => 'number',
            'class'     => 'ovabrw_number_vehicle',
            'name'      => 'ovabrw_number_vehicle[]',
            'value'     => 1,
            'required'  => true,
            'attrs'     => [
                'min'   => 1,
                'max'   => $stock_qty
            ]
        ]); ?>
    </div>
    <?php endif; ?>
<?php else:
    $vehicle_ids = $this->get_value( 'id_vehicles', [] );
?>
    <div class="rental_item ovabrw-id-vehicle">
        <label for="ovabrw-id-vehicle">
            <?php esc_html_e( 'Vehicle ID', 'ova-brw' ); ?>
        </label>
        <span class="ovabrw-id-vehicle-span">
            <select name="ovabrw_id_vehicle[]" id="ovabrw-id-vehicle" class="ovabrw-input-required select_ovabrw_id_vehicle">
            <?php if ( ovabrw_array_exists( $vehicle_ids ) ):
                foreach ( $vehicle_ids as $vehicle_id ): ?>
                    <option value="<?php echo esc_attr( $vehicle_id ); ?>">
                        <?php echo esc_html( $vehicle_id ); ?>
                    </option>
                <?php endforeach;
                else: ?>
                <option value="">
                    <?php esc_html_e( 'No vehicle', 'ova-brw' ); ?>
                </option>
            <?php endif; ?>
            </select>
        </span>
    </div>
<?php endif;