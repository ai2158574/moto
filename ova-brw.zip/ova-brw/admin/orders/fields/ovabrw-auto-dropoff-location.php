<?php defined( 'ABSPATH' ) || exit; ?>

<div class="rental_item ovabrw-location-field">
    <label>
        <?php esc_html_e( 'Drop-off Location', 'ova-brw' ); ?>
     </label>
    <span class="location-field">
        <?php ovabrw_text_input([
            'type'          => 'text',
            'id'            => 'ovabrw_dropoff_location_'.$this->get_id(),
            'class'         => 'ovabrw_dropoff_location',
            'name'          => 'ovabrw_dropoff_location[]',
            'placeholder'   => esc_html__( 'Enter a location', 'ova-brw' ),
            'required'      => true
        ]); ?>
        <?php ovabrw_text_input([
            'type'      => 'hidden',
            'id'        => 'ovabrw_destination',
            'name'      => 'ovabrw_destination',
            'required'  => true
        ]); ?>
    </span>
</div>