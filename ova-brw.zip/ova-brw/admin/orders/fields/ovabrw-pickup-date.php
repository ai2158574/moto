<?php defined( 'ABSPATH' ) || exit();

if ( $this->show_date() ): ?>
	<div class="rental_item ovabrw-pickup">
	    <label for="ovabrw-pickup-date">
	        <?php echo esc_html( OVABRW()->options->get_label_pickup_date( $this->get_id() ) ); ?>
	    </label>
	    <?php if ( 'appointment' == $this->get_type() ) {
	    	ovabrw_text_input([
				'type' 		=> 'text',
		        'id' 		=> ovabrw_unique_id( 'pickup_date' ),
		        'class' 	=> 'pickup-date',
		        'name' 		=> 'ovabrw_pickup_date[]',
		        'required' 	=> true,
		        'data_type' => 'datepicker'
			]);
	    } elseif ( OVABRW()->options->get_pickup_time_picker( $this->get_id() ) ) {
	    	ovabrw_text_input([
				'type' 		=> 'text',
		        'id' 		=> ovabrw_unique_id( 'pickup_date' ),
		        'class' 	=> 'pickup-date',
		        'name' 		=> 'ovabrw_pickup_date[]',
		        'required' 	=> true,
		        'data_type' => 'datetimepicker'
			]);
	    } else {
	    	ovabrw_text_input([
				'type' 		=> 'text',
		        'id' 		=> ovabrw_unique_id( 'pickup_date' ),
		        'class' 	=> 'pickup-date',
		        'name' 		=> 'ovabrw_pickup_date[]',
		        'required' 	=> true,
		        'data_type' => 'datepicker'
			]);
	    } ?>
	    <span class="ovabrw-loader-date">
	    	<i class="brwicon2-spinner-of-dots" aria-hidden="true"></i>
	    </span>
	</div>
<?php endif;