<?php defined( 'ABSPATH' ) || exit();

if ( $this->show_date( 'dropoff' ) ): ?>
	<div class="rental_item ovabrw-dropoff">
	    <label for="ovabrw-pickup-date">
	        <?php echo esc_html( OVABRW()->options->get_label_pickoff_date( $this->get_id() ) ); ?>
	    </label>
	    <?php if ( 'appointment' == $this->get_type() ) {
	    	ovabrw_text_input([
				'type' 			=> 'text',
		        'class' 		=> 'appointment-dropoff-date',
		        'name' 			=> 'ovabrw_pickoff_date[]',
		        'required' 		=> true,
		        'placeholder' 	=> ovabrw_get_date_placeholder() . ' ' . ovabrw_get_time_placeholder(),
		        'readonly' 		=> true
			]);
	    } elseif ( OVABRW()->options->get_dropoff_time_picker( $this->get_id() ) ) {
			ovabrw_text_input([
				'type' 		=> 'text',
		        'id' 		=> ovabrw_unique_id( 'dropoff_date' ),
		        'class' 	=> 'dropoff-date',
		        'name' 		=> 'ovabrw_pickoff_date[]',
		        'required' 	=> true,
		        'data_type' => 'datetimepicker'
			]);
		} else {
			ovabrw_text_input([
				'type' 		=> 'text',
		        'id' 		=> ovabrw_unique_id( 'dropoff_date' ),
		        'class' 	=> 'dropoff-date',
		        'name' 		=> 'ovabrw_pickoff_date[]',
		        'required' 	=> true,
		        'data_type' => 'datepicker'
			]);
		} ?>
		<span class="ovabrw-loader-date">
	    	<i class="brwicon2-spinner-of-dots" aria-hidden="true"></i>
	    </span>
	</div>
<?php else:
	if ( 'appointment' == $this->get_type() ) {
		ovabrw_text_input([
			'type' => 'hidden',
	        'name' => 'ovabrw_pickoff_date[]',
		]);
	}
endif; ?>