<?php

use Automattic\WooCommerce\Utilities\OrderUtil;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'WP_List_Table' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

if ( ! class_exists( 'OVABRW_Admin_List_Orders' ) ) {
    class OVABRW_Admin_List_Orders extends WP_List_Table {
        function __construct() {
            global $page;

            //Set parent defaults
            parent::__construct( array(
                'singular'  => 'bookings',     //singular name of the listed records
                'plural'    => 'bookings',    //plural name of the listed records
                'ajax'      => false        //does this table support ajax?
            ));
        }

        function column_default( $item, $column_name ) {
            switch ( $column_name ) {
                case 'id':
                case 'customer':
                case 'check-in-check-out':
                case 'pickup-pickoff-loc':
                case 'status-deposit':
                case 'status-insurance':
                case 'room-code':
                case 'room-name':
                case 'order_status':
                case 'order_id':
                    return apply_filters( 'ovabrw_list_orders_column_default', $item[$column_name], $item, $column_name );
                default:
                    return print_r($item,true); //Show the whole array for troubleshooting purposes
            }
        }

        function column_order_status( $item ) {
            switch ( $item['order_status'] ) {
                case 'processing':
                    $order_status_text = esc_html__( 'Processing', 'ova-brw' );
                    break;
                case 'completed':
                    $order_status_text = esc_html__( 'Completed', 'ova-brw' );
                    break;
                case 'pending':
                    $order_status_text = esc_html__( 'Pending payment', 'ova-brw' );
                    break;
                case 'on-hold':
                    $order_status_text = esc_html__( 'On hold', 'ova-brw' );
                    break;
                case 'cancelled':
                    $order_status_text = esc_html__( 'Cancel', 'ova-brw' );
                    break;    
                case 'closed':
                    $order_status_text = esc_html__( 'Closed', 'ova-brw' );
                    break;        
                default:
                    $order_status_text = esc_html__( 'Update Order', 'ova-brw' );
                    break;
            }
            
            //Build row actions
            $selected_action = sprintf( '<select name="update_order_status" class="update_order_status" data-order_id="'.$item['id'].'" data-error-per-msg="'.esc_html__( 'You don\'t have permission to update', 'ova-brw' ).'" data-error-update-msg="'.esc_html__( 'Error Update', 'ova-brw' ).'" >
                <option value="">'.esc_html__( 'Update Status', 'ova-brw' ).'</option>
                <option value="wc-completed">'.esc_html__( 'Completed', 'ova-brw' ).'</option>
                <option value="wc-processing">'.esc_html__( 'Processing', 'ova-brw' ).'</option>
                <option value="wc-pending">'.esc_html__( 'Pending payment', 'ova-brw' ).'</option>
                <option value="wc-on-hold">'.esc_html__( 'On hold', 'ova-brw' ).'</option>
                <option value="wc-cancelled">'.esc_html__( 'Cancel', 'ova-brw' ).'</option>
                <option value="wc-closed">'.esc_html__( 'Closed', 'ova-brw' ).'</option>
            </select>' );

            return sprintf('%1$s%2$s',
                '<mark class="ovabrw-order-status status-'.$item['order_status'].' tips"><span>'.$order_status_text.'</span></mark>',
                $selected_action
            );
        }

        function column_id( $item ) {
        	//Build row actions
            if ( current_user_can( apply_filters( 'ovabrw_edit_order_woo_cap' ,'manage_options' ) ) ) {
                return sprintf('<span>%1$s</span>',
                    '<a target="_blank" href="'.admin_url('/post.php?post='.$item['id'].'&action=edit').'">'.$item['id'].'</a>'
                );
            } else {
                return sprintf( '<span>%1$s</span>', $item['id'] );
            }
        }

        function get_columns() {
            $options = $columns = array();

            $id = get_option( 'admin_manage_order_show_id', 1 );
            if ( $id ) {
                $options['id'] = $id;
            }

            $customer = get_option( 'admin_manage_order_show_customer', 2 );
            if ( $customer ) {
                $options['customer'] = $customer;
            }

            $time = get_option( 'admin_manage_order_show_time', 3 );
            if ( $time ) {
                $options['check-in-check-out'] = $time;
            }

            $location = get_option( 'admin_manage_order_show_location', 4 );
            if ( $location ) {
                $options['pickup-pickoff-loc'] = $location;
            }

            $deposit = get_option( 'admin_manage_order_show_deposit', 5 );
            if ( $deposit ) {
                $options['status-deposit'] = $deposit;
            }

            $insurance = get_option( 'admin_manage_order_show_insurance', 6 );
            if ( $insurance ) {
                $options['status-insurance'] = $insurance;
            }

            $vehicle = get_option( 'admin_manage_order_show_vehicle', 7 );
            if ( $vehicle ) {
                $options['room-code'] = $vehicle;
            }

            $product = get_option( 'admin_manage_order_show_product', 8 );
            if ( $product ) {
                $options['room-name'] = $product;
            }

            $status = get_option( 'admin_manage_order_show_order_status', 9 );
            if ( $status ) {
                $options['order_status'] = $status;
            }

            if ( $options ) {
                asort( $options );
            }

            foreach ( $options as $key => $value ) {
                switch ( $key ) {
                    case 'id':
                        $columns[$key] = esc_html__( 'Order ID','ova-brw' );
                        break;

                    case 'customer':
                        $columns[$key] = esc_html__( 'Customer Name','ova-brw' );
                        break;

                    case 'check-in-check-out':
                        $columns[$key] = esc_html__( 'Check-in - Check-out','ova-brw' );
                        break;
                    case 'pickup-pickoff-loc':
                        $columns[$key] = esc_html__( 'Pick-up, Drop-off Location','ova-brw' );
                        break;

                    case 'status-deposit':
                        $columns[$key] = esc_html__( 'Deposit Status','ova-brw' );
                        break;

                    case 'status-insurance':
                        $columns[$key] = esc_html__( 'Insurance Status','ova-brw' );
                        break;

                    case 'room-code':
                        $columns[$key] = esc_html__( 'Vehicle','ova-brw' );
                        break;

                    case 'room-name':
                        $columns[$key] = esc_html__( 'Product','ova-brw' );
                        break;

                    case 'order_status':
                        $columns[$key] = esc_html__( 'Order Status','ova-brw' );
                        break;
                    
                    default:
                        break;
                }
            }

            return apply_filters( 'ovabrw_list_orders_get_columns', $columns );
        }

        function get_sortable_columns() {
            $sortable_columns = array(
                'id' => array('id',true),
            );

            return apply_filters( 'ovabrw_list_orders_get_sortable_columns', $sortable_columns );
        }

        function prepare_items() {
            global $wpdb; //This is used only if making any database queries

            /**
             * First, lets decide how many records per page to show
             */
            $per_page = '20';
            
            $columns    = $this->get_columns();
            $hidden     = array();
            $sortable   = $this->get_sortable_columns();
            
            $this->_column_headers = array($columns, $hidden, $sortable);
            
            $data = array();

            $room_id                = isset( $_GET['room_id'] ) ? sanitize_text_field( $_GET['room_id'] ) : '';
            $filter_order_status    = isset( $_GET['filter_order_status'] ) ? sanitize_text_field( $_GET['filter_order_status'] ) : '';
            $room_code_filter       = isset( $_GET['room_code'] ) ? sanitize_text_field( $_GET['room_code'] ) : '';

            if ( ! empty( $filter_order_status ) ) {
                $order_status = array( $filter_order_status );
            } else {
                $order_status = array( 'wc-processing','wc-completed', 'wc-half-completed', 'wc-on-hold', 'wc-cancelled', 'wc-closed', 'wc-pending' );    
            }

            $order_number   = isset( $_GET['order_number'] ) ? (int)( $_GET['order_number'] ) : '';
            $name_customer  = isset( $_GET['name_customer'] ) ? sanitize_text_field( $_GET['name_customer'] ) : '';
            $room_query     = $room_id ? 'AND oitem_meta.meta_value = '.$room_id : '';


            if ( OrderUtil::custom_orders_table_usage_is_enabled() ) {
                $result = $wpdb->get_col("
                    SELECT DISTINCT o.id
                    FROM {$wpdb->prefix}wc_orders AS o
                    LEFT JOIN {$wpdb->prefix}woocommerce_order_items AS oitems
                    ON o.id = oitems.order_id
                    LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta AS oitem_meta
                    ON oitems.order_item_id = oitem_meta.order_item_id
                    WHERE o.type = 'shop_order'
                    AND oitems.order_item_type = 'line_item'
                    AND oitem_meta.meta_key = '_product_id'
                    AND o.status IN ( '" . implode( "','", $order_status ) . "' )
                    $room_query
                    ORDER BY o.id DESC
                ");
            } else {
                $result = $wpdb->get_col("
                    SELECT DISTINCT oitems.order_id
                    FROM {$wpdb->prefix}woocommerce_order_items AS oitems
                    LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta AS oitem_meta
                    ON oitems.order_item_id = oitem_meta.order_item_id
                    LEFT JOIN {$wpdb->posts} AS posts ON oitems.order_id = posts.ID
                    WHERE posts.post_type = 'shop_order'
                    AND oitems.order_item_type = 'line_item'
                    AND oitem_meta.meta_key = '_product_id'
                    AND posts.post_status IN ( '" . implode( "','", $order_status ) . "' )
                    $room_query
                    ORDER BY oitems.order_id DESC
                ");
            }

    	    $from_day          = isset( $_GET['from_day'] ) ? strtotime( $_GET['from_day'] ) : '';
        	$to_day            = isset( $_GET['to_day'] ) ? strtotime( $_GET['to_day'] ) : '';
    	    $check_in_out      = isset( $_GET['check_in_out'] ) ? sanitize_text_field( $_GET['check_in_out'] ) : '';
            $check = $check_in_flag = $check_out_flag = $pickup_loc_flag = $pickoff_loc_flag = true;

            $current_pickup_loc     = isset( $_GET['pickup_loc'] ) ? sanitize_text_field( $_GET['pickup_loc'] ) : '';
            $current_pickoff_loc    = isset( $_GET['pickoff_loc'] ) ? sanitize_text_field( $_GET['pickoff_loc'] ) : '';

    	    foreach ( $result as $key => $value ) {
                $order = wc_get_order( $value );
                $buyer = '';

                if ( ( method_exists($order, 'get_billing_first_name') && $order->get_billing_first_name() ) || ( method_exists($order, 'get_billing_last_name') && $order->get_billing_last_name() ) ) {
                    /* translators: 1: first name 2: last name */
                    $buyer = trim( sprintf( _x( '%1$s %2$s', 'full name', 'ova-brw' ), $order->get_billing_first_name(), $order->get_billing_last_name() ) );
                } elseif ( method_exists($order, 'get_billing_company') && $order->get_billing_company() ) {
                    $buyer = trim( $order->get_billing_company() );
                } elseif (  method_exists($order, 'get_customer_id') && $order->get_customer_id() ) {
                    $user  = get_user_by( 'id', $order->get_customer_id() );
                    $buyer = ucwords( $user->display_name );
                }

                if ( ( empty( $order_number ) || ( ! empty( $order_number ) && $order_number == $value  ) ) && ( empty( $name_customer ) || ( strpos( $buyer, $name_customer ) ) !== false ) ) {

        	        // Get Meta Data type line_item of Order
        	        $order_items = $order->get_items( apply_filters('woocommerce_purchase_order_item_types', 'line_item') );

        	        // For Meta Data
        	        foreach ( $order_items as $item_id => $item ) {
        	            $room_check_in = $room_check_out = $room_code = $pickup_loc = $pickoff_loc = '';
                        $product_id = $item->get_product_id();
                        $product    = wc_get_product( $product_id );

                        if ( $product ) {
                            $room_name = '<a href="'.esc_url( get_edit_post_link( $product_id ) ).'" target="_black">';
                                $room_name .= $item->get_name();
                            $room_name .= '</a>';
                        } else {
                            $room_name = $item->get_name();
                        }
                        
                        if ( isset( $_GET['room_id'] ) && $_GET['room_id'] != '' ) {
                            if ( $_GET['room_id'] != $product_id ) {
                                continue;
                            }
                        }

                        // Check item
                        if ( !$item || !is_object( $item ) ) continue;

                        // Vehicle ID
                        $room_code = $item->get_meta('id_vehicle');
                        if ( $room_code_filter && false === stripos( $room_code, $room_code_filter ) ) {
                            continue;
                        }
       	            
                        // Get value of check-in, check-out
                        $room_check_in  = $item->get_meta('ovabrw_pickup_date');
                        $room_check_out = $item->get_meta('ovabrw_pickoff_date');

                        $pickup_loc     = $item->get_meta('ovabrw_pickup_loc');
                        $pickoff_loc    = $item->get_meta('ovabrw_pickoff_loc');

                        $room_check_in_timep    = strtotime( $room_check_in );
                        $room_check_out_timep   = strtotime( $room_check_out );

                        if ( $check_in_out == 'check_in' && $from_day != '' && $to_day != '' ) {
                            $check = ( $from_day <= $room_check_in_timep && $room_check_in_timep <= $to_day ) ? true : false;
                        } elseif ( $check_in_out == 'check_out' ) {
                            $check = ( $from_day <= $room_check_out_timep && $room_check_out_timep <= $to_day ) ? true : false;
                        } elseif ( $from_day != '' && $to_day != '' ) {
                            $check_in_flag = ( $from_day <= $room_check_in_timep && $room_check_in_timep <= $to_day ) ? true : false;
                            $check_out_flag = ( $from_day <= $room_check_out_timep && $room_check_out_timep <= $to_day ) ? true : false;
                        }

                        if ( $current_pickup_loc != '' && $pickup_loc != $current_pickup_loc ) {
                            $pickup_loc_flag = false;
                        } else {
                            $pickup_loc_flag = true;
                        }

                        if ( $current_pickoff_loc != '' && $pickoff_loc != $current_pickoff_loc ) {
                            $pickoff_loc_flag = false;
                        } else {
                            $pickoff_loc_flag = true;
                        }

                        // Insurance status
                        $status_insurance   = '';
                        $insurance_amount   = $item->get_meta( 'ovabrw_insurance_amount' );
                        $order_insurance    = $order->get_meta( '_ova_insurance_amount' );

                        if ( $insurance_amount !== '' ) {
                            $insurance_amount   = floatval( $insurance_amount );
                            $order_insurance    = floatval( $order_insurance );

                            if ( $insurance_amount > 0 && $order_insurance ) {
                                $status_insurance .= '<mark class="ovabrw-order-status status-on-hold">';
                                    $status_insurance .= '<span class="ovabrw-insurance-status">';
                                    $status_insurance .= esc_html__( 'Received', 'ova-brw' );
                                    $status_insurance .= '</span>';
                                $status_insurance .= '</mark>';
                            } else {
                                $status_insurance .= '<mark class="ovabrw-order-status status-processing">';
                                    $status_insurance .= '<span class="ovabrw-insurance-status">';
                                    $status_insurance .= esc_html__( 'Paid for Customers', 'ova-brw' );
                                    $status_insurance .= '</span>';
                                $status_insurance .= '</mark>';
                            }
                        }

                        // Deposit status
                        $status_deposit = '';
                        $is_deposit     = $order->get_meta( '_ova_has_deposit' );

                        if ( $is_deposit ) {
                            $remaining_amount = $item->get_meta( 'ovabrw_remaining_amount' );

                            if ( $remaining_amount ) {
                                $is_remaining_invoice  = false;
                                $remaining_invoice_ids = $order->get_meta( '_ova_remaining_invoice_ids' );

                                // Check remaining invoice ids
                                if ( ! empty( $remaining_invoice_ids ) && is_array( $remaining_invoice_ids ) ) {
                                    foreach ( $remaining_invoice_ids as $remaining_invoice_id ) {
                                        $order_remaining_invoice = wc_get_order( $remaining_invoice_id );

                                        if ( ! $order_remaining_invoice ) continue;

                                        $original_item_id = absint( $order_remaining_invoice->get_meta( '_ova_original_item_id' ) );

                                        if ( $original_item_id === $item_id ) {
                                            $is_remaining_invoice = true;
                                            break;
                                        }
                                    }
                                }

                                if ( $is_remaining_invoice ) {
                                    $status_deposit .= '<mark class="ovabrw-order-status status-processing">';
                                        $status_deposit .= '<span class="ovabrw-deposit-status">';
                                        $status_deposit .= esc_html__( 'Original Payment', 'ova-brw' );
                                        $status_deposit .= '</span>';
                                    $status_deposit .= '</mark>';
                                } else {
                                    $status_deposit .= '<mark class="ovabrw-order-status status-pending">';
                                        $status_deposit .= '<span class="ovabrw-deposit-status">';
                                        $status_deposit .= esc_html__( 'Partial Payment', 'ova-brw' );
                                        $status_deposit .= '</span>';
                                    $status_deposit .= '</mark>';
                                }
                            } else {
                                $status_deposit .= '<mark class="ovabrw-order-status status-processing">';
                                    $status_deposit .= '<span class="ovabrw-deposit-status">';
                                    $status_deposit .= esc_html__( 'Full Payment', 'ova-brw' );
                                    $status_deposit .= '</span>';
                                $status_deposit .= '</mark>';
                            }

                            // Remaining Invoice
                            $remaining_invoice_ids = $order->get_meta( '_ova_remaining_invoice_ids' );

                            if ( ! empty( $remaining_invoice_ids ) && is_array( $remaining_invoice_ids ) ) {
                                foreach ( $remaining_invoice_ids as $order_remaining_id ) {
                                    $order_remaining_invoice = wc_get_order( $order_remaining_id );

                                    if ( $order_remaining_invoice ) {
                                        $original_item_id = absint( $order_remaining_invoice->get_meta( '_ova_original_item_id' ) );

                                        if ( $original_item_id === $item_id ) {
                                            $status_deposit .= '<mark class="ovabrw-order-view">';
                                                $status_deposit .= '<a href="'.esc_url( $order_remaining_invoice->get_edit_order_url() ).'" class="button" target="_blank">';
                                                $status_deposit .= wp_kses_post( sprintf( __( 'Remaining Invoice #%1$s', 'ova-brw' ), $order_remaining_invoice->get_order_number() ) );
                                                $status_deposit .= '</a>';
                                            $status_deposit .= '</mark>';
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                        
                        // Locations
                        $location = '';

                        if ( $pickup_loc && $pickoff_loc ) {
                            $location = $pickup_loc . '<br>@<br>' . $pickoff_loc;
                        } elseif ( $pickup_loc && !$pickoff_loc ) {
                            $location = $pickup_loc;
                        } elseif ( !$pickup_loc && $pickoff_loc ) {
                            $location = $pickoff_loc;
                        }

                        // Check-in, Check-out
                        $date_time = '';

                        if ( $room_check_in && $room_check_out ) {
                            $date_time = $room_check_in . '<br>@<br>' . $room_check_out;
                        } elseif ( $room_check_in && !$room_check_out ) {
                            $date_time = $room_check_in;
                        } elseif ( !$room_check_in && $room_check_out ) {
                            $date_time = $room_check_out;
                        }

                        // Parent Order
                        $parent_order_id = $item->get_meta( 'ovabrw_parent_order_id' );

                        if ( absint( $parent_order_id ) ) {
                            $date_time = '<mark class="ovabrw-order-view">';
                                $date_time .= '<a href="'.esc_url( get_edit_post_link( $parent_order_id ) ).'" class="button" target="_blank">';
                                    $date_time .= sprintf( __( 'Original Order #%1$s', 'ova-brw' ), $parent_order_id );
                                $date_time .= '</a>';
                            $date_time .= '</mark>';
                        }

        	            if ( $check && $check_in_flag && $check_out_flag && $pickup_loc_flag && $pickoff_loc_flag ) {
        	            	$data[] = apply_filters( 'ovabrw_list_orders_data_item', array(
                                'id'                  => $order->get_ID(),
                                'customer'            => $buyer,
                                'check-in-check-out'  => $date_time,
                                'pickup-pickoff-loc'  => $location,
                                'status-deposit'      => $status_deposit,
                                'status-insurance'    => $status_insurance,
                                'room-code'           => $room_code,
                                'room-name'           => $room_name,
                                'order_status'        => $order->get_status(),
                            ), $item );
        	            }
        	        }
        	    }
            }

            function usort_reorder( $a, $b ) {
                // If no sort, default to title
                $orderby    = ! empty( $_REQUEST['orderby'] ) ? sanitize_text_field( $_REQUEST['orderby'] ) : 'id';
                $order      = ! empty( $_REQUEST['order'] ) ? sanitize_text_field( $_REQUEST['order'] ) : 'asc';

                //If no order, default to asc
                $result = strcmp( $a[$orderby], $b[$orderby] ); //Determine sort order
                return $order === 'asc' ? -$result : $result; //Send final sort direction to usort
            }    
            usort( $data, 'usort_reorder' );

            $current_page = $this->get_pagenum();
            $total_items = count($data);
            $data = array_slice($data,(($current_page-1)*$per_page),$per_page);
           
            $this->items = $data;
            $this->set_pagination_args( array(
                'total_items' => $total_items,                  //WE have to calculate the total number of items
                'per_page'    => $per_page,                     //WE have to determine how many items to show on a page
                'total_pages' => ceil($total_items/$per_page)   //WE have to calculate the total number of pages
            ) );
        }
    }
}