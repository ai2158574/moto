<?php defined( 'ABSPATH' ) || exit;

// Get products
$products = OVABRW_Admin_Meta_Boxes::instance()->get_rental_product_ids();

// Defautl country
$country_setting    = get_option( 'woocommerce_default_country', 'US:CA' );

if ( strstr( $country_setting, ':' ) ) {
    $country_setting = explode( ':', $country_setting );
    $country         = current( $country_setting );
    $state           = end( $country_setting );
} else {
    $country = $country_setting;
    $state   = '*';
}

?>
<div class="wrap">
    <form action="<?php echo admin_url('/edit.php?post_type=product&page=ovabrw-create-order'); ?>" id="booking-filter" class="ovabrw-create-order" method="POST" enctype="multipart/form-data">
        <h2>
            <?php esc_html_e( 'Create Order', 'ova-brw' ); ?>
        </h2>
        <div class="ovabrw-wrap">
        <?php
            // Multi currency
            $currencies = [];

            if ( is_plugin_active( 'woo-multi-currency/woo-multi-currency.php' ) || is_plugin_active( 'woocommerce-multi-currency/woocommerce-multi-currency.php' ) ) {
                $setting    = WOOMULTI_CURRENCY_F_Data::get_ins();
                $currencies = $setting->get_list_currencies();
            }

            if ( is_plugin_active( 'woocommerce-multilingual/wpml-woocommerce.php' ) ) {
                // WPML multi currency
                global $woocommerce_wpml;

                if ( $woocommerce_wpml && is_object( $woocommerce_wpml ) ) {
                    if ( wp_doing_ajax() ) add_filter( 'wcml_load_multi_currency_in_ajax', '__return_true' );

                    $currencies     = $woocommerce_wpml->get_setting( 'currency_options' );
                    $current_lang   = apply_filters( 'wpml_current_language', NULL );

                    if ( $current_lang != 'all' && ovabrw_array_exists( $currencies ) ) {
                        foreach ( $currencies as $k => $data ) {
                            if ( isset( $currencies[$k]['languages'][$current_lang] ) && $currencies[$k]['languages'][$current_lang] ) {
                                continue;
                            } else {
                                unset( $currencies[$k] );
                            }
                        }
                    }
                }
            }

            if ( ovabrw_array_exists( $currencies ) ):
                $current_currency = ovabrw_get_meta_data( 'currency', $_GET );

                if ( !$current_currency ) $current_currency = array_key_first( $currencies ); 
            ?>
                <div class="ovabrw-row ovabrw-order-currency">
                    <label for="ovabrw-currency">
                        <?php esc_html_e( 'Currency', 'ova-brw' ); ?>
                    </label>
                    <select name="currency" id="ovabrw-currency">
                        <?php foreach ( $currencies as $currency => $rate ): ?>
                            <option value="<?php echo esc_attr( $currency ); ?>"<?php selected( $currency, $current_currency ); ?>>
                                <?php esc_html_e( $currency ); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <?php ovabrw_text_input([
                        'type'  => 'hidden',
                        'name'  => 'ovabrw-admin-url',
                        'value' => esc_url( get_admin_url() )
                    ]); ?>
                </div>
            <?php endif; ?>
            <div class="ovabrw-row ovabrw-choose-status">
                <label for="stattus-order">
                    <?php esc_html_e( 'Status', 'ova-brw' ); ?>
                </label>
                <select name="status_order" id="stattus-order" class="ovabrw-input-required">
                    <option value="completed" selected>
                        <?php esc_html_e( 'Completed', 'ova-brw' ); ?>
                    </option>
                    <option value="processing">
                        <?php esc_html_e( 'Processing', 'ova-brw' ); ?>
                    </option>
                    <option value="pending">
                        <?php esc_html_e( 'Pending payment', 'ova-brw' ); ?>
                    </option>
                    <option value="on-hold">
                        <?php esc_html_e( 'On hold', 'ova-brw' ); ?>
                    </option>
                    <option value="cancelled">
                        <?php esc_html_e( 'Cancelled', 'ova-brw' ); ?>
                    </option>
                    <option value="refunded">
                        <?php esc_html_e( 'Refunded', 'ova-brw' ); ?>
                    </option>
                    <option value="failed">
                        <?php esc_html_e( 'Failed', 'ova-brw' ); ?>
                    </option>
                </select>
            </div>
            <div class="ovabrw-row ova-column-3 ovabrw-billing">
                <?php do_action( 'ovabrw_before_create_new_order_billing' ); ?>
                <div class="item">
                    <?php ovabrw_text_input([
                        'type'          => 'text',
                        'name'          => 'ovabrw_first_name',
                        'placeholder'   => esc_html__( 'First Name', 'ova-brw' ),
                        'required'      => true
                    ]); ?>
                </div>
                <div class="item">
                    <?php ovabrw_text_input([
                        'type'          => 'text',
                        'name'          => 'ovabrw_last_name',
                        'placeholder'   => esc_html__( 'Last Name', 'ova-brw' ),
                        'required'      => true
                    ]); ?>
                </div>
                <div class="item">
                    <?php ovabrw_text_input([
                        'type'          => 'email',
                        'name'          => 'ovabrw_email',
                        'placeholder'   => esc_html__( 'Email', 'ova-brw' ),
                        'required'      => true
                    ]); ?>
                </div>
                <div class="item">
                    <?php ovabrw_text_input([
                        'type'          => 'tel',
                        'name'          => 'ovabrw_phone',
                        'placeholder'   => esc_html__( 'Phone', 'ova-brw' ),
                        'required'      => true
                    ]); ?>
                </div>
                <div class="item">
                    <?php ovabrw_text_input([
                        'type'          => 'text',
                        'name'          => 'ovabrw_company',
                        'placeholder'   => esc_html__( 'Company', 'ova-brw' )
                    ]); ?>
                </div>
                <div class="item">
                    <?php ovabrw_text_input([
                        'type'          => 'text',
                        'name'          => 'ovabrw_address_1',
                        'placeholder'   => esc_html__( 'Address 1', 'ova-brw' ),
                        'required'      => true
                    ]); ?>
                </div>
                <div class="item">
                    <?php ovabrw_text_input([
                        'type'          => 'text',
                        'name'          => 'ovabrw_address_2',
                        'placeholder'   => esc_html__( 'Address 2', 'ova-brw' )
                    ]); ?>
                </div>
                <div class="item">
                    <?php ovabrw_text_input([
                        'type'          => 'text',
                        'name'          => 'ovabrw_city',
                        'placeholder'   => esc_html__( 'City', 'ova-brw' )
                    ]); ?>
                </div>
                <div class="item">
                    <select name="ovabrw_country" class="ovabrw-input-required ovabrw_country" style="width: 100%;">
                        <?php WC()->countries->country_dropdown_options( $country, $state ); ?>
                    </select>
                </div>
                <?php do_action( 'ovabrw_after_create_new_order_billing' ); ?>
            </div>
            <div class="ship-to-different-address">
                <label class="ship-to-different-address-label">
                    <input
                        id="ship-to-different-address-checkbox"
                        class="ship-to-different-address-checkbox input-checkbox"
                        type="checkbox"
                        name="ship_to_different_address"
                        value="1"
                    />
                    <span>
                        <?php echo esc_html_e( 'Ship to a different address?', 'ova-brw' ); ?>
                    </span>
                </label>
            </div>
            <div class="ovabrw-row ova-column-3 ovabrw-shipping">
                <?php do_action( 'ovabrw_before_create_new_order_shipping' ); ?>
                <div class="item">
                    <?php ovabrw_text_input([
                        'type'          => 'text',
                        'name'          => 'ship_ovabrw_first_name',
                        'placeholder'   => esc_html__( 'First Name', 'ova-brw' )
                    ]); ?>
                </div>
                <div class="item">
                    <?php ovabrw_text_input([
                        'type'          => 'text',
                        'name'          => 'ship_ovabrw_last_name',
                        'placeholder'   => esc_html__( 'Last Name', 'ova-brw' )
                    ]); ?>
                </div>
                <div class="item">
                    <?php ovabrw_text_input([
                        'type'          => 'tel',
                        'name'          => 'ship_ovabrw_phone',
                        'placeholder'   => esc_html__( 'Phone', 'ova-brw' )
                    ]); ?>
                </div>
                <div class="item">
                    <?php ovabrw_text_input([
                        'type'          => 'text',
                        'name'          => 'ship_ovabrw_company',
                        'placeholder'   => esc_html__( 'Company', 'ova-brw' )
                    ]); ?>
                </div>
                <div class="item">
                    <?php ovabrw_text_input([
                        'type'          => 'text',
                        'name'          => 'ship_ovabrw_address_1',
                        'placeholder'   => esc_html__( 'Address 1', 'ova-brw' )
                    ]); ?>
                </div>
                <div class="item">
                    <?php ovabrw_text_input([
                        'type'          => 'text',
                        'name'          => 'ship_ovabrw_address_2',
                        'placeholder'   => esc_html__( 'Address 2', 'ova-brw' )
                    ]); ?>
                </div>
                <div class="item">
                    <?php ovabrw_text_input([
                        'type'          => 'text',
                        'name'          => 'ship_ovabrw_city',
                        'placeholder'   => esc_html__( 'City', 'ova-brw' )
                    ]); ?>
                </div>
                <div class="item">
                    <select name="ship_ovabrw_country" class="ovabrw_country" style="width: 100%;">
                        <?php WC()->countries->country_dropdown_options( $country, $state ); ?>
                    </select>
                </div>
                <?php do_action( 'ovabrw_after_create_new_order_shipping' ); ?>
            </div>
            <div class="wrap_item">
                <div class="ovabrw-order">
                    <div class="item">
                        <div class="sub-item">
                            <h3 class="title"><?php esc_html_e(  'Product', 'ova-brw' ); ?></h3>
                            <div class="rental_item">
                                <label for="ovabrw-name-product">
                                    <?php esc_html_e( 'Product Name', 'ova-brw' ); ?>
                                </label>
                                <select
                                    id="ovabrw-name-product"
                                    class="ovabrw-input-required ovabrw_name_product"
                                    name="ovabrw_name_product[]">
                                    <option value="">
                                        <?php esc_html_e( 'Select Product', 'ova-brw' ); ?>
                                    </option>
                                    <?php foreach ( $products as $product_id ): ?>
                                        <option value="<?php echo esc_attr( $product_id ); ?>">
                                            <?php echo esc_html( get_the_title( $product_id ) ); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <div class="ovabrw-rental-type-loading">
                                    <span class="dashicons-before dashicons-update-alt"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <span class="button ovabrw-remove-order-item">x</span>
                </div>
            </div>
            <div class="ovabrw-row">
                <button class="button ovabrw-add-order-item" data-add-new="<?php
                    ob_start();
                    include( OVABRW_PLUGIN_PATH.'admin/orders/views/html-create-order-field.php' );
                    echo esc_attr( ob_get_clean() );
                ?>">
                    <?php esc_html_e( 'Add Item', 'ova-brw' ); ?>
                </button>
            </div>
            <button type="submit" class="button ovabrw-create-order-submit">
                <?php esc_html_e( 'Create Order', 'ova-brw' ); ?>
            </button>
        </div>
        <input type="hidden" name="post_type" value="product">
        <input type="hidden" name="ovabrw_create_order" value="create_order">
        <input type="hidden" name="page" value="<?php echo esc_attr( $_REQUEST['page'] ); ?>">
    </form>
</div>