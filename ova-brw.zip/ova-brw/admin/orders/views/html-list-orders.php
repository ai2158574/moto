<?php defined( 'ABSPATH' ) || exit();

if ( !class_exists( 'OVABRW_Admin_List_Orders' ) ) return;

// Date format
$date_format = ovabrw_get_date_format();

// Time format
$time_format = ovabrw_get_time_format();

$manage_booking = new OVABRW_Admin_List_Orders();
$manage_booking->prepare_items();

$product_ids            = OVABRW()->options->get_product_ids_by_rental_type();
$order_number           = sanitize_text_field( ovabrw_get_meta_data( 'order_number', $_GET ) );
$customer_name          = sanitize_text_field( ovabrw_get_meta_data( 'name_customer', $_GET ) );
$current_room_id        = sanitize_text_field( ovabrw_get_meta_data( 'room_id', $_GET ) );
$room_code              = sanitize_text_field( ovabrw_get_meta_data( 'room_code', $_GET ) );
$check_in_out           = sanitize_text_field( ovabrw_get_meta_data( 'check_in_out', $_GET ) );
$filter_order_status    = sanitize_text_field( ovabrw_get_meta_data( 'filter_order_status', $_GET ) );
$from_day               = sanitize_text_field( ovabrw_get_meta_data( 'from_day', $_GET ) );
$to_day                 = sanitize_text_field( ovabrw_get_meta_data( 'to_day', $_GET ) );
$all_locations          = OVABRW()->options->get_all_location_ids();
$current_pickup_loc     = sanitize_text_field( ovabrw_get_meta_data( 'pickup_loc', $_GET ) );
$current_pickoff_loc    = sanitize_text_field( ovabrw_get_meta_data( 'pickoff_loc', $_GET ) );
$vehicle_ids            = OVABRW()->options->get_all_vehicle_ids();

$id         = get_option( 'admin_manage_order_show_id', 1 );
$customer   = get_option( 'admin_manage_order_show_customer', 2 );
$time       = get_option( 'admin_manage_order_show_time', 3 );
$location   = get_option( 'admin_manage_order_show_location', 4 );
$deposit    = get_option( 'admin_manage_order_show_deposit', 5 );
$insurance  = get_option( 'admin_manage_order_show_insurance', 6 );
$vehicle    = get_option( 'admin_manage_order_show_vehicle', 7 );
$product    = get_option( 'admin_manage_order_show_product', 8 );
$status     = get_option( 'admin_manage_order_show_order_status', 9 );
?>
<div class="wrap">
    <form id="booking-filter" method="GET" action="<?php echo admin_url('/edit.php?post_type=product&page=ovabrw-manage-order'); ?>">
        <h2><?php esc_html_e( 'Manage Order', 'ova-brw' ); ?></h2>
        <div class="booking_filter">
            <?php if ( $id ): ?>
                <div class="form-field">
                    <?php ovabrw_text_input([
                        'type'          => 'text',
                        'name'          => 'order_number',
                        'value'         => $order_number,
                        'placeholder'   => esc_html__( 'Order ID', 'ova-brw' )
                    ]); ?>
                </div>
            <?php endif; ?>
            <?php if ( $customer ): ?>
                <div class="form-field">
                    <?php ovabrw_text_input([
                        'type'          => 'text',
                        'name'          => 'name_customer',
                        'value'         => $customer_name,
                        'placeholder'   => esc_html__( 'Customer Name', 'ova-brw' )
                    ]); ?>
                </div>
            <?php endif; ?>
            <?php if ( $time ): ?>
                <div class="form-field">
                    <select name="check_in_out">
                        <option value="">
                            <?php esc_html_e( '-- All --', 'ova-brw' ); ?>
                        </option>
                        <option value="check_in"<?php selected( $check_in_out, 'check_in' ); ?>>
                            <?php esc_html_e( 'Check-in date', 'ova-brw' ); ?>
                        </option>
                        <option value="check_out"<?php selected( $check_in_out, 'check_out' ); ?>>
                            <?php esc_html_e( 'Check-out date', 'ova-brw' ); ?>
                        </option>
                    </select>
                </div>
            <?php endif; ?>
            <div class="form-field">
                <?php ovabrw_wp_text_input([
                    'type'          => 'text',
                    'id'            => ovabrw_unique_id( 'from_day' ),
                    'class'         => 'start-date',
                    'name'          => 'from_day',
                    'value'         => $from_day,
                    'placeholder'   => esc_html__( 'From date', 'ova-brw' ),
                    'data_type'     => 'datetimepicker',
                    'attrs'         => [
                        'data-date' => strtotime( $from_day ) ? date( $date_format, strtotime( $from_day ) ) : '',
                        'data-time' => strtotime( $from_day ) ? date( $time_format, strtotime( $from_day ) ) : ''
                    ]
                ]); ?>
            </div>
            <div class="form-field">
                <?php ovabrw_wp_text_input([
                    'type'          => 'text',
                    'id'            => ovabrw_unique_id( 'to_day' ),
                    'class'         => 'end-date',
                    'name'          => 'to_day',
                    'value'         => $to_day,
                    'placeholder'   => esc_html__( 'To date', 'ova-brw' ),
                    'data_type'     => 'datetimepicker',
                    'attrs'         => [
                        'data-date' => strtotime( $to_day ) ? date( $date_format, strtotime( $to_day ) ) : '',
                        'data-time' => strtotime( $to_day ) ? date( $time_format, strtotime( $to_day ) ) : ''
                    ]
                ]); ?>
            </div>
            <?php if ( $vehicle ): ?>
                <div class="form-field">
                    <select name="room_code">
                        <option value="" <?php selected( '', $room_code, 'selected'); ?>>
                            <?php esc_html_e( '-- Vehicle --', 'ova-brw' ); ?>
                        </option>
                        <?php if ( ovabrw_array_exists( $vehicle_ids ) ):
                            foreach ( $vehicle_ids as $v_id ):
                                $vehicle_id = get_post_meta( $v_id, 'ovabrw_id_vehicle', true );
                            ?>
                                <option value="<?php echo esc_attr( $vehicle_id ); ?>"<?php selected( $vehicle_id, $room_code ); ?>>
                                    <?php echo get_the_title( $v_id ); ?>
                                </option>
                        <?php endforeach;
                        endif; ?>
                    </select>
                </div>
            <?php endif; ?>
            <?php if ( $location ): ?>
                <div class="form-field">
                    <select name="pickup_loc">
                        <option value="" <?php selected( '', $current_pickup_loc, 'selected'); ?>>
                            <?php esc_html_e( '-- Pick-up Location --', 'ova-brw' ); ?>
                        </option>
                        <?php if ( ovabrw_array_exists( $all_locations ) ):
                            foreach ( $all_locations as $location_id ): ?>
                                <option value="<?php echo esc_attr( get_the_title( $location_id ) ); ?>"<?php selected( get_the_title( $location_id ), $current_pickup_loc ); ?>>
                                    <?php echo esc_html( get_the_title( $location_id ) ); ?>
                                </option>
                        <?php endforeach;
                        endif; ?>
                    </select>
                </div>
            <?php endif; ?>
            <?php if ( $location ): ?>
                <div class="form-field">
                    <select name="pickoff_loc">
                        <option value="" <?php selected( '', $current_pickoff_loc, 'selected'); ?>>
                            <?php esc_html_e( '-- Drop-off Location --', 'ova-brw' ); ?>
                        </option>
                        <?php if ( ovabrw_array_exists( $all_locations ) ):
                            foreach ( $all_locations as $location_id ): ?>
                                <option value="<?php echo esc_attr( get_the_title( $location_id ) ); ?>"<?php selected( get_the_title( $location_id ), $current_pickup_loc ); ?>>
                                    <?php echo esc_html( get_the_title( $location_id ) ); ?>
                                </option>
                        <?php endforeach;
                        endif; ?>
                    </select>
                </div>
            <?php endif; ?>
            <?php if ( $product ): ?>
                <div class="form-field">
                    <select name="room_id">
                        <option value=""<?php selected( '', $current_room_id ); ?>>
                            <?php esc_html_e( '-- Choose Product --', 'ova-brw' ); ?>
                        </option>
                        <?php if ( ovabrw_array_exists( $product_ids ) ):
                            foreach ( $product_ids as $product_id ): ?>
                                <option value="<?php echo esc_attr( $product_id ); ?>"<?php selected( $product_id, $current_room_id ); ?>>
                                    <?php echo get_the_title( $product_id ); ?>
                                </option>
                        <?php endforeach;
                        endif; ?>
                    </select>
                </div>
            <?php endif; ?>
            <?php if ( $status ): ?>
                <div class="form-field">
                    <select name="filter_order_status" >
                        <option value="">
                            <?php esc_html_e( '--Order Status--', 'ova-brw' ); ?>
                        </option>
                        <option value="wc-completed"<?php selected( $filter_order_status, 'wc-completed' ); ?>>
                            <?php esc_html_e( 'Completed', 'ova-brw' ); ?>
                        </option>
                        <option value="wc-processing"<?php selected( $filter_order_status, 'wc-processing' ); ?>>
                            <?php esc_html_e( 'Processing', 'ova-brw' ); ?>
                        </option>
                        <option value="wc-pending"<?php selected( $filter_order_status, 'wc-pending' ); ?>>
                            <?php esc_html_e( 'Pending payment', 'ova-brw' ); ?>
                        </option>
                        <option value="wc-on-hold"<?php selected( $filter_order_status, 'wc-on-hold' ); ?>>
                            <?php esc_html_e( 'On hold', 'ova-brw' ); ?>
                        </option>
                        <option value="wc-cancelled"<?php selected( $filter_order_status, 'wc-cancelled' ); ?>>
                            <?php esc_html_e( 'Cancel', 'ova-brw' ); ?>
                        </option>
                        <option value="wc-closed"<?php selected( $filter_order_status, 'wc-closed' ); ?>>
                            <?php esc_html_e( 'Closed', 'ova-brw' ); ?>
                        </option>
                    </select>
                </div>
            <?php endif; ?>
            <div class="form-field">
                <button type="submit" class="button">
                    <?php esc_html_e( 'Filter', 'ova-brw' ); ?>
                </button>
            </div>
        </div>
        <input
            type="hidden"
            name="ovabrw-datetimepicker-options"
            value="<?php echo esc_attr( wp_json_encode( ovabrw_admin_datetimepicker_options() ) ); ?>"
        />
        <input type="hidden" name="post_type" value="product">
        <input type="hidden" name="page" value="<?php echo esc_attr( $_REQUEST['page'] ); ?>">
        <?php $manage_booking->display() ?>
    </form>
</div>