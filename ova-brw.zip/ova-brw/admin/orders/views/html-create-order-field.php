<?php defined( 'ABSPATH' ) || exit;

// Get products
$products = OVABRW_Admin_Meta_Boxes::instance()->get_rental_product_ids();

?>
<div class="ovabrw-order">
    <div class="item">
        <div class="sub-item">
            <h3 class="title"><?php esc_html_e('Product', 'ova-brw') ?></h3>
            <div class="rental_item">
                <label for="ovabrw-name-product">
                    <?php esc_html_e( 'Product Name', 'ova-brw' ); ?>
                </label>
                <select
                    id="ovabrw-name-product"
                    class="ovabrw-input-required ovabrw_name_product"
                    name="ovabrw_name_product[]">
                    <option value="">
                        <?php esc_html_e( 'Select Product', 'ova-brw' ); ?>
                    </option>
                    <?php foreach ( $products as $product_id ): ?>
                        <option value="<?php echo esc_attr( $product_id ); ?>">
                            <?php echo esc_html( get_the_title( $product_id ) ); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <div class="ovabrw-rental-type-loading">
                    <span class="dashicons-before dashicons-update-alt"></span>
                </div>
            </div>
        </div>
    </div>
    <span class="button ovabrw-remove-order-item">x</span>
</div>