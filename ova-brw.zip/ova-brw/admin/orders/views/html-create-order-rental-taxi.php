<?php defined( 'ABSPATH' ) || exit();
	$meta_boxed = [
		'price',
		'pickup-date',
		'auto-pickup-location',
		'auto-dropoff-location',
		'extra-time',
		'quantity',
		'custom-checkout-fields',
		'resources',
		'services',
		'insurance',
		'deposit',
		'remaining',
		'total',
        'error'
	];
?>

<div class="sub-item ovabrw-meta">
	<h3 class="title"><?php esc_html_e( 'Add Meta', 'ova-brw' ); ?></h3>
	<?php do_action( 'ovabrw_create_order_before_meta_boxes_rental_taxi' ); ?>
	<?php foreach ( $meta_boxed as $meta ): ?>
		<?php include( OVABRW_PLUGIN_PATH.'admin/orders/fields/ovabrw-'.$meta.'.php' ); ?>
	<?php endforeach; ?>
	<div class="ovabrw-directions">
        <div id="<?php echo esc_attr( 'ovabrw_map_'.$this->ID ); ?>" class="ovabrw_map"></div>
        <div class="directions-info">
            <div class="distance-sum">
                <h3 class="label"><?php esc_html_e( 'Total Distance', 'ova-brw' ); ?></h3>
                <span class="distance-value">0</span>
                <span class="distance-unit"><?php esc_html_e( 'km', 'ova-brw' ); ?></span>
            </div>
            <div class="duration-sum">
                <h3 class="label"><?php esc_html_e( 'Total Time', 'ova-brw' ); ?></h3>
                <span class="hour">0</span>
                <span class="unit"><?php esc_html_e( 'h', 'ova-brw' ); ?></span>
                <span class="minute">0</span>
                <span class="unit"><?php esc_html_e( 'm', 'ova-brw' ); ?></span>
            </div>
        </div>
    </div>
    <?php
        $zoom_map       = $this->get_value( 'zoom_map' );
        $latitude       = $this->get_value( 'latitude' );
        $longitude      = $this->get_value( 'longitude' );
        $price_by       = $this->get_value( 'map_price_by' );
        $map_types      = $this->get_value( 'ovabrw_map_types' );
        $bounds         = $this->get_value( 'ovabrw_bounds' );
        $bounds_lat     = $this->get_value( 'bounds_lat' );
        $bounds_lng     = $this->get_value( 'bounds_lng' );
        $bounds_radius  = $this->get_value( 'bounds_radius' );
        $restrictions   = $this->get_value( 'restrictions' );

        if ( ! $price_by ) $price_by = 'km';
        if ( ! $map_types ) $map_types = [ 'geocode' ];
        if ( ! $restrictions ) $restrictions = [];
    ?>
    <input
        type="hidden"
        name="ovabrw-data-location"
        data-waypoint-text="<?php esc_html_e( 'Waypoint', 'ova-brw' ); ?>"
        data-price-by="<?php echo esc_attr( $price_by ); ?>"
        data-types="<?php echo esc_attr( json_encode( $map_types ) ); ?>"
        data-lat="<?php echo esc_attr( $latitude ); ?>"
        data-lng="<?php echo esc_attr( $longitude ); ?>"
        data-zoom="<?php echo esc_attr( $zoom_map ); ?>"
        data-bounds="<?php echo esc_attr( $bounds ); ?>"
        data-bounds-lat="<?php echo esc_attr( $bounds_lat ); ?>"
        data-bounds-lng="<?php echo esc_attr( $bounds_lng ); ?>"
        data-bounds-radius="<?php echo esc_attr( $bounds_radius ); ?>"
        data-restrictions="<?php echo esc_attr( json_encode( $restrictions ) ); ?>"
    />
    <input
        type="hidden"
        name="ovabrw-duration-map[]"
        value=""
    />
    <input
        type="hidden"
        name="ovabrw-duration[]"
        value=""
    />
    <input
        type="hidden"
        name="ovabrw-distance[]"
        value=""
    />
	<?php do_action( 'ovabrw_create_order_after_meta_boxes_rental_taxi' ); ?>
</div>