<?php defined( 'ABSPATH' ) || exit();
	$meta_boxed = [
		'price',
		'pickup-location',
		'dropoff-location',
		'pickup-date',
		'dropoff-date',
		'quantity',
		'custom-checkout-fields',
		'resources',
		'services',
		'insurance',
		'deposit',
		'remaining',
		'total',
		'error'
	];
?>

<div class="sub-item ovabrw-meta">
	<h3 class="title"><?php esc_html_e( 'Add Meta', 'ova-brw' ); ?></h3>
	<?php do_action( 'ovabrw_create_order_before_meta_boxes_rental_hour' ); ?>
	<?php foreach ( $meta_boxed as $meta ): ?>
		<?php include( OVABRW_PLUGIN_PATH.'admin/orders/fields/ovabrw-'.$meta.'.php' ); ?>
	<?php endforeach; ?>
	<?php do_action( 'ovabrw_create_order_after_meta_boxes_rental_hour' ); ?>
</div>