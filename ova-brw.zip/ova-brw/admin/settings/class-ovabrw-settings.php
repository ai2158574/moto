<?php if ( ! defined( 'ABSPATH' ) ) exit();

if ( ! class_exists( 'OVABRW_Rental_Settings' ) ) {
    class OVABRW_Rental_Settings {
        public function __construct() {
			add_filter( 'woocommerce_get_settings_pages', array( $this, 'ovabrw_add_settings_tab' ), 10, 1 );

			// Global Settings
			add_action( 'woocommerce_settings_ovabrw_global_typography_after', array( $this, 'ovabrw_global_typography_after' ) );

			// Save global settings
			add_action( 'woocommerce_update_option', array( $this, 'ovabrw_wc_update_option' ) );

			// Output admin fields - Textarea
			add_action( 'woocommerce_admin_field_ovabrw_textarea', array( $this, 'ovabrw_admin_field_ovabrw_textarea' ) );

			// Output admin fields - Editor
			add_action( 'woocommerce_admin_field_ovabrw_editor', array( $this, 'ovabrw_admin_field_editor' ) );

			// Save textarea field
			add_filter( 'woocommerce_admin_settings_sanitize_option', array( $this, 'ovabrw_admin_settings_sanitize_option' ), 10, 3 );

			// Before accordion field
			add_action( 'woocommerce_admin_field_ovabrw_before_accordion', array( $this, 'ovabrw_admin_field_before_accordion' ) );

			// After accordion field
			add_action( 'woocommerce_admin_field_ovabrw_after_accordion', array( $this, 'ovabrw_admin_field_after_accordion' ) );

			// Before field
			add_action( 'woocommerce_admin_field_ovabrw_before', array( $this, 'ovabrw_admin_field_before' ) );

			// After field
			add_action( 'woocommerce_admin_field_ovabrw_after', array( $this, 'ovabrw_admin_field_after' ) );
        }

        public function ovabrw_add_settings_tab( $settings ) {
		  	$settings[] = include( OVABRW_PLUGIN_PATH.'admin/settings/class-ovabrw-settings-tab.php' );

		  	return $settings;
		}

		public function ovabrw_global_typography_after() {
			include( OVABRW_PLUGIN_PATH.'admin/settings/views/ovabrw-wcst-global-typography.php' );
		}

		public function ovabrw_wc_update_option( $option ) {
			$data = $_POST;

			if ( empty( $data ) ) {
				return false;
			}

			$update_options = [];

			// Font
			if ( isset( $data['ovabrw_glb_primary_font'] ) ) {
				$update_options['ovabrw_glb_primary_font'] = trim( $data['ovabrw_glb_primary_font'] );
			}
			if ( isset( $data['ovabrw_glb_primary_font_weight'] ) ) {
				$update_options['ovabrw_glb_primary_font_weight'] = $data['ovabrw_glb_primary_font_weight'];
			}
			if ( isset( $data['ovabrw_glb_custom_font'] ) ) {
				$update_options['ovabrw_glb_custom_font'] = trim( $data['ovabrw_glb_custom_font'] );
			}
			// End Font

			// Color
			if ( isset( $data['ovabrw_glb_primary_color'] ) ) {
				$update_options['ovabrw_glb_primary_color'] = trim( $data['ovabrw_glb_primary_color'] );
			}
			if ( isset( $data['ovabrw_glb_light_color'] ) ) {
				$update_options['ovabrw_glb_light_color'] = trim( $data['ovabrw_glb_light_color'] );
			}
			// End Color

			// Heading
			if ( isset( $data['ovabrw_glb_heading_font_size'] ) ) {
				$update_options['ovabrw_glb_heading_font_size'] = trim( $data['ovabrw_glb_heading_font_size'] );
			}
			if ( isset( $data['ovabrw_glb_heading_font_weight'] ) ) {
				$update_options['ovabrw_glb_heading_font_weight'] = trim( $data['ovabrw_glb_heading_font_weight'] );
			}
			if ( isset( $data['ovabrw_glb_heading_line_height'] ) ) {
				$update_options['ovabrw_glb_heading_line_height'] = trim( $data['ovabrw_glb_heading_line_height'] );
			}
			if ( isset( $data['ovabrw_glb_heading_color'] ) ) {
				$update_options['ovabrw_glb_heading_color'] = trim( $data['ovabrw_glb_heading_color'] );
			}
			// End Heading
			
			// Second Heading
			if ( isset( $data['ovabrw_glb_second_heading_font_size'] ) ) {
				$update_options['ovabrw_glb_second_heading_font_size'] = trim( $data['ovabrw_glb_second_heading_font_size'] );
			}
			if ( isset( $data['ovabrw_glb_second_heading_font_weight'] ) ) {
				$update_options['ovabrw_glb_second_heading_font_weight'] = trim( $data['ovabrw_glb_second_heading_font_weight'] );
			}
			if ( isset( $data['ovabrw_glb_second_heading_line_height'] ) ) {
				$update_options['ovabrw_glb_second_heading_line_height'] = trim( $data['ovabrw_glb_second_heading_line_height'] );
			}
			if ( isset( $data['ovabrw_glb_second_heading_color'] ) ) {
				$update_options['ovabrw_glb_second_heading_color'] = trim( $data['ovabrw_glb_second_heading_color'] );
			}
			// End Second Heading
			
			// Label
			if ( isset( $data['ovabrw_glb_label_font_size'] ) ) {
				$update_options['ovabrw_glb_label_font_size'] = trim( $data['ovabrw_glb_label_font_size'] );
			}
			if ( isset( $data['ovabrw_glb_label_font_weight'] ) ) {
				$update_options['ovabrw_glb_label_font_weight'] = trim( $data['ovabrw_glb_label_font_weight'] );
			}
			if ( isset( $data['ovabrw_glb_label_line_height'] ) ) {
				$update_options['ovabrw_glb_label_line_height'] = trim( $data['ovabrw_glb_label_line_height'] );
			}
			if ( isset( $data['ovabrw_glb_label_color'] ) ) {
				$update_options['ovabrw_glb_label_color'] = trim( $data['ovabrw_glb_label_color'] );
			}
			// End Label
			
			// Text
			if ( isset( $data['ovabrw_glb_text_font_size'] ) ) {
				$update_options['ovabrw_glb_text_font_size'] = trim( $data['ovabrw_glb_text_font_size'] );
			}
			if ( isset( $data['ovabrw_glb_text_font_weight'] ) ) {
				$update_options['ovabrw_glb_text_font_weight'] = trim( $data['ovabrw_glb_text_font_weight'] );
			}
			if ( isset( $data['ovabrw_glb_text_line_height'] ) ) {
				$update_options['ovabrw_glb_text_line_height'] = trim( $data['ovabrw_glb_text_line_height'] );
			}
			if ( isset( $data['ovabrw_glb_text_color'] ) ) {
				$update_options['ovabrw_glb_text_color'] = trim( $data['ovabrw_glb_text_color'] );
			}
			// End Text
			
			// Card
			if ( isset( $data['ovabrw_glb_card_template'] ) ) {
				$update_options['ovabrw_glb_card_template'] = trim( $data['ovabrw_glb_card_template'] );
			}
			
			// Get all card templates
			$card_templates = ovabrw_get_all_card_templates();
    		if ( ! is_array( $card_templates ) ) $card_templates = [];

    		// Cart item settings
			$card_prefix = 'ovabrw_glb_';

			foreach ( $card_templates as $card => $label ) {
				// Featured
				if ( isset( $data[$card_prefix.$card.'_featured'] ) ) {
					$update_options[$card_prefix.$card.'_featured'] = $data[$card_prefix.$card.'_featured'];
				}

				// Special
				if ( isset( $data[$card_prefix.$card.'_feature_featured'] ) ) {
					$update_options[$card_prefix.$card.'_feature_featured'] = $data[$card_prefix.$card.'_feature_featured'];
				}

				// Thumbnail type
				if ( isset( $data[$card_prefix.$card.'_thumbnail_type'] ) ) {
					$update_options[$card_prefix.$card.'_thumbnail_type'] = $data[$card_prefix.$card.'_thumbnail_type'];
				}

				// Thumbnail size
				if ( isset( $data[$card_prefix.$card.'_thumbnail_size'] ) ) {
					$update_options[$card_prefix.$card.'_thumbnail_size'] = $data[$card_prefix.$card.'_thumbnail_size'];
				}

				// Thumbnail height
				if ( isset( $data[$card_prefix.$card.'_thumbnail_height'] ) ) {
					$update_options[$card_prefix.$card.'_thumbnail_height'] = $data[$card_prefix.$card.'_thumbnail_height'];
				}

				// Display thumbnail
				if ( isset( $data[$card_prefix.$card.'_display_thumbnail'] ) ) {
					$update_options[$card_prefix.$card.'_display_thumbnail'] = $data[$card_prefix.$card.'_display_thumbnail'];
				}

				// Price
				if ( isset( $data[$card_prefix.$card.'_price'] ) ) {
					$update_options[$card_prefix.$card.'_price'] = $data[$card_prefix.$card.'_price'];
				}

				// Specifications
				if ( isset( $data[$card_prefix.$card.'_specifications'] ) ) {
					$update_options[$card_prefix.$card.'_specifications'] = $data[$card_prefix.$card.'_specifications'];
				}

				// Features
				if ( isset( $data[$card_prefix.$card.'_features'] ) ) {
					$update_options[$card_prefix.$card.'_features'] = $data[$card_prefix.$card.'_features'];
				}

				// Custom Taxonomy
				if ( isset( $data[$card_prefix.$card.'_custom_taxonomy'] ) ) {
					$update_options[$card_prefix.$card.'_custom_taxonomy'] = $data[$card_prefix.$card.'_custom_taxonomy'];
				}

				// Attribute
				if ( isset( $data[$card_prefix.$card.'_attribute'] ) ) {
					$update_options[$card_prefix.$card.'_attribute'] = $data[$card_prefix.$card.'_attribute'];
				}

				// Short description
				if ( isset( $data[$card_prefix.$card.'_short_description'] ) ) {
					$update_options[$card_prefix.$card.'_short_description'] = $data[$card_prefix.$card.'_short_description'];
				}

				// Review
				if ( isset( $data[$card_prefix.$card.'_review'] ) ) {
					$update_options[$card_prefix.$card.'_review'] = $data[$card_prefix.$card.'_review'];
				}

				// Button
				if ( isset( $data[$card_prefix.$card.'_button'] ) ) {
					$update_options[$card_prefix.$card.'_button'] = $data[$card_prefix.$card.'_button'];
				}
			}
			// End Card

			foreach ( $update_options as $name => $value ) {
				update_option( $name, $value );
			}
		}

		/**
		 * OVABRW Textarea field
		 * @param  array $value
		 * @return html
		 */
		public function ovabrw_admin_field_ovabrw_textarea( $value ) {
			$option_value = $value['value'];

			// Custom attribute handling.
			$custom_attributes = array();

			if ( ! empty( $value['custom_attributes'] ) && is_array( $value['custom_attributes'] ) ) {
				foreach ( $value['custom_attributes'] as $attribute => $attribute_value ) {
					$custom_attributes[] = esc_attr( $attribute ) . '="' . esc_attr( $attribute_value ) . '"';
				}
			}

			// Description handling.
			$field_description = \WC_Admin_Settings::get_field_description( $value );
			$description       = $field_description['description'];
			$tooltip_html      = $field_description['tooltip_html'];
			?>
			<tr class="<?php echo esc_attr( $value['row_class'] ); ?>">
				<th scope="row" class="titledesc">
					<label for="<?php echo esc_attr( $value['id'] ); ?>">
						<?php echo esc_html( $value['title'] ); ?>
						<?php echo $tooltip_html; // WPCS: XSS ok. ?>
					</label>
				</th>
				<td class="forminp forminp-<?php echo esc_attr( sanitize_title( $value['type'] ) ); ?>">
					<textarea
						name="<?php echo esc_attr( $value['field_name'] ); ?>"
						id="<?php echo esc_attr( $value['id'] ); ?>"
						style="<?php echo esc_attr( $value['css'] ); ?>"
						class="<?php echo esc_attr( $value['class'] ); ?>"
						placeholder="<?php echo esc_attr( $value['placeholder'] ); ?>"
						<?php echo implode( ' ', $custom_attributes ); // WPCS: XSS ok. ?>
						><?php echo esc_textarea( $option_value ); // WPCS: XSS ok. ?></textarea>
					<?php echo $description; // WPCS: XSS ok. ?>
				</td>
			</tr>
			<?php
		}

		/**
		 * Add text editor field
		 */
		public function ovabrw_admin_field_editor( $value ) {
			// Description handling.
			$field_description = WC_Admin_Settings::get_field_description( $value );
			$description       = $field_description['description'];
			$tooltip_html      = $field_description['tooltip_html'];

			// editor settings
			$editor_settings = array(
				'editor_class' 	=> $value['class'],
				'editor_css' 	=> $value['css'],
				'editor_height' => $value['height'] ? $value['height'] : '',
				'wpautop' 		=> false
			);

			?>
			<tr class="<?php echo esc_attr( $value['row_class'] ); ?>">
				<th scope="row" class="titledesc">
					<label for="<?php echo esc_attr( $value['id'] ); ?>"><?php echo esc_html( $value['title'] ); ?> <?php echo $tooltip_html; ?></label>
					<?php echo $description; ?>
				</th>
				<td class="forminp forminp-<?php echo esc_attr( sanitize_title( $value['type'] ) ); ?>">
					<?php wp_editor( $value['value'], $value['id'], $editor_settings ); ?>
				</td>
			</tr>
			<?php
		}

		/**
		 * OVABRW Save textarea field
		 * @param  array $value
		 * @return html
		 */
		public function ovabrw_admin_settings_sanitize_option( $value, $option, $raw_value ) {
			$type 	= ovabrw_get_meta_data( 'type', $option );
			$id 	= ovabrw_get_meta_data( 'id', $option );

			if ( 'ovabrw_textarea' == $type || 'ovabrw_editor' == $type ) {
				$id 	= isset( $option['id'] ) ? $option['id'] : '';
				$value 	= wp_kses_post( trim( $raw_value ) );

				if ( 'ovabrw_editor' == $type ) {
					$value = apply_filters( 'ovabrw_the_content', $value );
				}
			}

			// Additional CSS
			if ( 'ovabrw_additional_css' == $id ) {
				$value = html_entity_decode( $raw_value, ENT_QUOTES, 'UTF-8' );
				
				$customize_calendar = ovabrw_get_meta_data( OVABRW_PREFIX.'customize_calendar', $_POST );
				if ( $customize_calendar ) {
					// Save file
					file_put_contents( OVABRW_PLUGIN_PATH.'assets/css/datepicker/customize.css', (string)$value );
				}
			}

			return apply_filters( 'ovabrw_admin_settings_sanitize_option', $value, $option, $raw_value );
		}

		/**
		 * Before field
		 * @param  array $value
		 * @return html
		 */
		public function ovabrw_admin_field_before( $value ) {
			do_action( 'ovabrw_admin_field_before', $value );
			?>
			<div id="<?php echo esc_attr( sanitize_title( $value['id'] ) ); ?>" class="<?php echo esc_attr( sanitize_title( $value['class'] ) ); ?>" style="<?php echo esc_attr( $value['css'] ); ?>">
			<?php
		}

		/**
		 * After field
		 * @param  array $value
		 * @return html
		 */
		public function ovabrw_admin_field_after( $value ) {
			?>
			</div>
			<?php
			do_action( 'ovabrw_admin_field_after', $value );
		}

		/**
		 * Before accordion
		 * @param  array $value
		 * @return html
		 */
		public function ovabrw_admin_field_before_accordion( $value ) {
			do_action( 'ovabrw_admin_field_before_accordion', $value );
			?>
			<div id="<?php echo esc_attr( sanitize_title( $value['id'] ) ); ?>" class="ovabrw-accordion">
				<h2 class="ovabrw-accordion-title">
					<?php echo esc_html( $value['title'] ); ?>
				</h2>
				<div class="ovabrw-accordion-content">
			<?php
		}

		/**
		 * After accordion
		 * @param  array $value
		 * @return html
		 */
		public function ovabrw_admin_field_after_accordion( $value ) {
			?>
				</div>
			</div>
			<?php
			do_action( 'ovabrw_admin_field_after_accordion', $value );
		}
    }

	new OVABRW_Rental_Settings();
}