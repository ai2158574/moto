<?php if ( ! defined( 'ABSPATH' ) ) exit();
    // Get all card templates
    $card_templates = ovabrw_get_all_card_templates();

    if ( ! is_array( $card_templates ) ) $card_templates = [];
?>

<div class="wcst-title">
    <h2><?php esc_html_e( 'Card', 'ova-brw' ); ?></h2>
    <span class="dashicons dashicons-plus-alt2 ovabrw-more"></span>
    <span class="dashicons dashicons-minus ovabrw-less"></span>
</div>
<div class="ovabrw-wcst-fields ovabrw-wcst-card">
    <table class="form-table">
        <tbody>
            <tr valign="top">
                <th scope="row" class="titledesc">
                    <label for="ovabrw_glb_card_template">
                        <?php esc_html_e( 'Default Card Template', 'ova-brw' ); ?>
                    </label>
                </th>
                <td class="forminp forminp-select">
                    <select
                        name="ovabrw_glb_card_template"
                        id="ovabrw_glb_card_template"
                        class="ovabrw_select2"
                        data-placeholder="<?php esc_attr_e( 'Select Card Template', 'ova-brw' ); ?>">
                    <?php foreach ( $card_templates as $card => $label ): ?>
                        <option value="<?php echo esc_attr( $card ); ?>"<?php selected( get_option( 'ovabrw_glb_card_template' ), $card ); ?>>
                            <?php echo esc_html( $label ); ?>
                        </option>
                    <?php endforeach; ?>
                    </select>
                    <br>
                    <span>
                        <?php  esc_html_e( 'Product Template in Product Listing Page', 'ova-brw' ); ?>
                    </span>
                </td>
            </tr>
        </tbody>
    </table>
    <div class="ovabrw-wcst-tabs">
        <div class="ovabrw-wcst-tab-nav">
            <?php
            $flag = 1;

            foreach ( $card_templates as $card => $label ):
                $nav_classs = 'ovabrw-wcst-tab-btn';

                if ( $flag === 1 ) $nav_classs = 'ovabrw-wcst-tab-btn active';
            ?>
                <a href="<?php echo esc_attr( '#'.$card ); ?>" data-id="<?php echo esc_attr( $card ); ?>" class="<?php echo esc_attr( $nav_classs ); ?>">
                    <?php echo esc_html( $label ); ?>
                </a>
            <?php $flag++; endforeach; ?>
        </div>
        <div class="ovabrw-wcst-tab-content">
            <?php
                $flag = 1;

                foreach ( $card_templates as $card => $label ):
                    $table_class = 'form-table';

                    if ( $flag === 1 ) $table_class = 'form-table active';
            ?>
                <table class="<?php echo esc_attr( $table_class ); ?>" data-id="<?php echo esc_attr( $card ); ?>">
                    <tbody>
                        <tr valign="top">
                            <th scope="row" class="titledesc">
                                <label for="<?php echo esc_attr( 'ovabrw_glb_'.$card.'_featured' ); ?>">
                                    <?php esc_html_e( 'Show highlight', 'ova-brw' ); ?>
                                </label>
                            </th>
                            <td class="forminp forminp-select">
                                <select
                                    name="<?php echo esc_attr( 'ovabrw_glb_'.$card.'_featured' ); ?>"
                                    id="<?php echo esc_attr( 'ovabrw_glb_'.$card.'_featured' ); ?>">
                                    <option value="yes"<?php selected( get_option( 'ovabrw_glb_'.$card.'_featured', 'yes' ), 'yes' ); ?>>
                                        <?php esc_html_e( 'Yes', 'ova-brw' ); ?>
                                    </option>
                                    <option value="no"<?php selected( get_option( 'ovabrw_glb_'.$card.'_featured', 'yes' ), 'no' ); ?>>
                                        <?php esc_html_e( 'No', 'ova-brw' ); ?>
                                    </option>
                                </select>
                            </td>
                        </tr>
                        <tr valign="top">
                            <th scope="row" class="titledesc">
                                <label for="<?php echo esc_attr( 'ovabrw_glb_'.$card.'_feature_featured' ); ?>">
                                    <?php esc_html_e( 'Show special', 'ova-brw' ); ?>
                                </label>
                            </th>
                            <td class="forminp forminp-select">
                                <select
                                    name="<?php echo esc_attr( 'ovabrw_glb_'.$card.'_feature_featured' ); ?>"
                                    id="<?php echo esc_attr( 'ovabrw_glb_'.$card.'_feature_featured' ); ?>">
                                    <option value="yes"<?php selected( get_option( 'ovabrw_glb_'.$card.'_feature_featured', 'yes' ), 'yes' ); ?>>
                                        <?php esc_html_e( 'Yes', 'ova-brw' ); ?>
                                    </option>
                                    <option value="no"<?php selected( get_option( 'ovabrw_glb_'.$card.'_feature_featured', 'yes' ), 'no' ); ?>>
                                        <?php esc_html_e( 'No', 'ova-brw' ); ?>
                                    </option>
                                </select>
                            </td>
                        </tr>
                        <tr valign="top">
                            <th scope="row" class="titledesc">
                                <label for="<?php echo esc_attr( 'ovabrw_glb_'.$card.'_thumbnail_type' ); ?>">
                                    <?php esc_html_e( 'Thumbnail type', 'ova-brw' ); ?>
                                </label>
                            </th>
                            <td class="forminp forminp-select">
                                <select
                                    name="<?php echo esc_attr( 'ovabrw_glb_'.$card ).'_thumbnail_type'; ?>"
                                    id="<?php echo esc_attr( 'ovabrw_glb_'.$card.'_thumbnail_type' ); ?>">
                                    <option value="slider"<?php selected( get_option( 'ovabrw_glb_'.$card.'_thumbnail_type', 'slider' ), 'slider' ); ?>>
                                        <?php esc_html_e( 'Slider', 'ova-brw' ); ?>
                                    </option>
                                    <option value="image"<?php selected( get_option( 'ovabrw_glb_'.$card.'_thumbnail_type', 'slider' ), 'image' ); ?>>
                                        <?php esc_html_e( 'Image', 'ova-brw' ); ?>
                                    </option>
                                </select>
                            </td>
                        </tr>
                        <tr valign="top">
                            <th scope="row" class="titledesc">
                                <label for="<?php echo esc_attr( 'ovabrw_glb_'.$card.'_thumbnail_size' ); ?>">
                                    <?php esc_html_e( 'Thumbnail size', 'ova-brw' ); ?>
                                </label>
                            </th>
                            <td class="forminp forminp-select">
                                <select
                                    name="<?php echo esc_attr( 'ovabrw_glb_'.$card ).'_thumbnail_size'; ?>"
                                    id="<?php echo esc_attr( 'ovabrw_glb_'.$card.'_thumbnail_size' ); ?>"
                                    class="ovabrw-glb-card-thumbnail-size">
                                    <option value="woocommerce_thumbnail"<?php selected( get_option( 'ovabrw_glb_'.$card.'_thumbnail_size', 'woocommerce_thumbnail' ), 'woocommerce_thumbnail' ); ?>>
                                        <?php esc_html_e( 'Thumbnail', 'ova-brw' ); ?>
                                    </option>
                                    <option value="woocommerce_single"<?php selected( get_option( 'ovabrw_glb_'.$card.'_thumbnail_size', 'woocommerce_thumbnail' ), 'woocommerce_single' ); ?>>
                                        <?php esc_html_e( 'Single', 'ova-brw' ); ?>
                                    </option>
                                    <option value="woocommerce_gallery_thumbnail"<?php selected( get_option( 'ovabrw_glb_'.$card.'_thumbnail_size', 'woocommerce_thumbnail' ), 'woocommerce_gallery_thumbnail' ); ?>>
                                        <?php esc_html_e( 'Gallery Thumbnail', 'ova-brw' ); ?>
                                    </option>
                                    <option value="full"<?php selected( get_option( 'ovabrw_glb_'.$card.'_thumbnail_size', 'woocommerce_thumbnail' ), 'full' ); ?>>
                                        <?php esc_html_e( 'Full', 'ova-brw' ); ?>
                                    </option>
                                    <option value="custom_height"<?php selected( get_option( 'ovabrw_glb_'.$card.'_thumbnail_size', 'woocommerce_thumbnail' ), 'custom_height' ); ?>>
                                        <?php esc_html_e( 'Custom Height', 'ova-brw' ); ?>
                                    </option>
                                </select>
                            </td>
                        </tr>
                        <tr valign="top" class="ovabrw-glb-thumbnail-height">
                            <th scope="row" class="titledesc">
                                <label for="<?php echo esc_attr( 'ovabrw_glb_'.$card.'_thumbnail_height' ); ?>">
                                    <?php esc_html_e( 'Thumbnail height', 'ova-brw' ); ?>
                                </label>
                            </th>
                            <td class="forminp forminp-select">
                                <input
                                    name="<?php echo esc_attr( 'ovabrw_glb_'.$card ).'_thumbnail_height'; ?>"
                                    id="<?php echo esc_attr( 'ovabrw_glb_'.$card.'_thumbnail_height' ); ?>"
                                    value="<?php echo esc_attr( get_option( 'ovabrw_glb_'.$card.'_thumbnail_height', '300px' ) ); ?>"
                                    placeholder="300px or 100%"
                                    autocomplete="off"
                                />
                            </td>
                        </tr>
                        <tr valign="top">
                            <th scope="row" class="titledesc">
                                <label for="<?php echo esc_attr( 'ovabrw_glb_'.$card.'_display_thumbnail' ); ?>">
                                    <?php esc_html_e( 'Display thumbnail', 'ova-brw' ); ?>
                                </label>
                            </th>
                            <td class="forminp forminp-select">
                                <select
                                    name="<?php echo esc_attr( 'ovabrw_glb_'.$card ).'_display_thumbnail'; ?>"
                                    id="<?php echo esc_attr( 'ovabrw_glb_'.$card.'_display_thumbnail' ); ?>">
                                    <option value="fill"<?php selected( get_option( 'ovabrw_glb_'.$card.'_display_thumbnail', 'cover' ), 'fill' ); ?>>
                                        <?php esc_html_e( 'Fill', 'ova-brw' ); ?>
                                    </option>
                                    <option value="contain"<?php selected( get_option( 'ovabrw_glb_'.$card.'_display_thumbnail', 'cover' ), 'contain' ); ?>>
                                        <?php esc_html_e( 'Contain', 'ova-brw' ); ?>
                                    </option>
                                    <option value="cover"<?php selected( get_option( 'ovabrw_glb_'.$card.'_display_thumbnail', 'cover' ), 'cover' ); ?>>
                                        <?php esc_html_e( 'Cover', 'ova-brw' ); ?>
                                    </option>
                                    <option value="none"<?php selected( get_option( 'ovabrw_glb_'.$card.'_display_thumbnail', 'cover' ), 'none' ); ?>>
                                        <?php esc_html_e( 'None', 'ova-brw' ); ?>
                                    </option>
                                    <option value="scale-down"<?php selected( get_option( 'ovabrw_glb_'.$card.'_display_thumbnail', 'cover' ), 'scale-down' ); ?>>
                                        <?php esc_html_e( 'Scale Down', 'ova-brw' ); ?>
                                    </option>
                                </select>
                            </td>
                        </tr>
                        <tr valign="top">
                            <th scope="row" class="titledesc">
                                <label for="<?php echo esc_attr( 'ovabrw_glb_'.$card.'_price' ); ?>">
                                    <?php esc_html_e( 'Show price', 'ova-brw' ); ?>
                                </label>
                            </th>
                            <td class="forminp forminp-select">
                                <select
                                    name="<?php echo esc_attr( 'ovabrw_glb_'.$card.'_price' ); ?>"
                                    id="<?php echo esc_attr( 'ovabrw_glb_'.$card ).'_price'; ?>">
                                    <option value="yes"<?php selected( get_option( 'ovabrw_glb_'.$card.'_price', 'yes' ), 'yes' ); ?>>
                                        <?php esc_html_e( 'Yes', 'ova-brw' ); ?>
                                    </option>
                                    <option value="no"<?php selected( get_option( 'ovabrw_glb_'.$card.'_price', 'yes' ), 'no' ); ?>>
                                        <?php esc_html_e( 'No', 'ova-brw' ); ?>
                                    </option>
                                </select>
                            </td>
                        </tr>
                        <tr valign="top">
                            <th scope="row" class="titledesc">
                                <label for="<?php echo esc_attr( 'ovabrw_glb_'.$card.'_specifications' ); ?>">
                                    <?php esc_html_e( 'Show specifications', 'ova-brw' ); ?>
                                </label>
                            </th>
                            <td class="forminp forminp-select">
                                <select
                                    name="<?php echo esc_attr( 'ovabrw_glb_'.$card.'_specifications' ); ?>"
                                    id="<?php echo esc_attr( 'ovabrw_glb_'.$card.'_specifications' ); ?>">
                                    <option value="yes"<?php selected( get_option( 'ovabrw_glb_'.$card.'_specifications', 'yes' ), 'yes' ); ?>>
                                        <?php esc_html_e( 'Yes', 'ova-brw' ); ?>
                                    </option>
                                    <option value="no"<?php selected( get_option( 'ovabrw_glb_'.$card.'_specifications', 'yes' ), 'no' ); ?>>
                                        <?php esc_html_e( 'No', 'ova-brw' ); ?>
                                    </option>
                                </select>
                            </td>
                        </tr>
                        <tr valign="top">
                            <th scope="row" class="titledesc">
                                <label for="<?php echo esc_attr( 'ovabrw_glb_'.$card.'_features' ); ?>">
                                    <?php esc_html_e( 'Show features', 'ova-brw' ); ?>
                                </label>
                            </th>
                            <td class="forminp forminp-select">
                                <select
                                    name="<?php echo esc_attr( 'ovabrw_glb_'.$card.'_features' ); ?>"
                                    id="<?php echo esc_attr( 'ovabrw_glb_'.$card.'_features' ); ?>">
                                    <option value="yes"<?php selected( get_option( 'ovabrw_glb_'.$card.'_features', 'yes' ), 'yes' ); ?>>
                                        <?php esc_html_e( 'Yes', 'ova-brw' ); ?>
                                    </option>
                                    <option value="no"<?php selected( get_option( 'ovabrw_glb_'.$card.'_features', 'yes' ), 'no' ); ?>>
                                        <?php esc_html_e( 'No', 'ova-brw' ); ?>
                                    </option>
                                </select>
                            </td>
                        </tr>
                        <tr valign="top">
                            <th scope="row" class="titledesc">
                                <label for="<?php echo esc_attr( 'ovabrw_glb_'.$card.'_custom_taxonomy' ); ?>">
                                    <?php esc_html_e( 'Show Custom Taxonomy', 'ova-brw' ); ?>
                                </label>
                            </th>
                            <td class="forminp forminp-select">
                                <select
                                    name="<?php echo esc_attr( 'ovabrw_glb_'.$card.'_custom_taxonomy' ); ?>"
                                    id="<?php echo esc_attr( 'ovabrw_glb_'.$card.'_custom_taxonomy' ); ?>">
                                    <option value="yes"<?php selected( get_option( 'ovabrw_glb_'.$card.'_custom_taxonomy', 'yes' ), 'yes' ); ?>>
                                        <?php esc_html_e( 'Yes', 'ova-brw' ); ?>
                                    </option>
                                    <option value="no"<?php selected( get_option( 'ovabrw_glb_'.$card.'_custom_taxonomy', 'yes' ), 'no' ); ?>>
                                        <?php esc_html_e( 'No', 'ova-brw' ); ?>
                                    </option>
                                </select>
                            </td>
                        </tr>
                        <tr valign="top">
                            <th scope="row" class="titledesc">
                                <label for="<?php echo esc_attr( 'ovabrw_glb_'.$card.'_attribute' ); ?>">
                                    <?php esc_html_e( 'Show attribute', 'ova-brw' ); ?>
                                </label>
                            </th>
                            <td class="forminp forminp-select">
                                <select
                                    name="<?php echo esc_attr( 'ovabrw_glb_'.$card.'_attribute' ); ?>"
                                    id="<?php echo esc_attr( 'ovabrw_glb_'.$card.'_attribute' ); ?>">
                                    <option value="yes"<?php selected( get_option( 'ovabrw_glb_'.$card.'_attribute', 'yes' ), 'yes' ); ?>>
                                        <?php esc_html_e( 'Yes', 'ova-brw' ); ?>
                                    </option>
                                    <option value="no"<?php selected( get_option( 'ovabrw_glb_'.$card.'_attribute', 'yes' ), 'no' ); ?>>
                                        <?php esc_html_e( 'No', 'ova-brw' ); ?>
                                    </option>
                                </select>
                            </td>
                        </tr>
                        <tr valign="top">
                            <th scope="row" class="titledesc">
                                <label for="<?php echo esc_attr( 'ovabrw_glb_'.$card.'_short_description' ); ?>">
                                    <?php esc_html_e( 'Show short description', 'ova-brw' ); ?>
                                </label>
                            </th>
                            <td class="forminp forminp-select">
                                <select
                                    name="<?php echo esc_attr( 'ovabrw_glb_'.$card.'_short_description' ); ?>"
                                    id="<?php echo esc_attr( 'ovabrw_glb_'.$card.'_short_description' ); ?>">
                                    <option value="yes"<?php selected( get_option( 'ovabrw_glb_'.$card.'_short_description', 'yes' ), 'yes' ); ?>>
                                        <?php esc_html_e( 'Yes', 'ova-brw' ); ?>
                                    </option>
                                    <option value="no"<?php selected( get_option( 'ovabrw_glb_'.$card.'_short_description', 'yes' ), 'no' ); ?>>
                                        <?php esc_html_e( 'No', 'ova-brw' ); ?>
                                    </option>
                                </select>
                            </td>
                        </tr>
                        <tr valign="top">
                            <th scope="row" class="titledesc">
                                <label for="<?php echo esc_attr( 'ovabrw_glb_'.$card.'_review' ); ?>">
                                    <?php esc_html_e( 'Show review', 'ova-brw' ); ?>
                                </label>
                            </th>
                            <td class="forminp forminp-select">
                                <select
                                    name="<?php echo esc_attr( 'ovabrw_glb_'.$card.'_review' ); ?>"
                                    id="<?php echo esc_attr( 'ovabrw_glb_'.$card.'_review' ); ?>">
                                    <option value="yes"<?php selected( get_option( 'ovabrw_glb_'.$card.'_review', 'yes' ), 'yes' ); ?>>
                                        <?php esc_html_e( 'Yes', 'ova-brw' ); ?>
                                    </option>
                                    <option value="no"<?php selected( get_option( 'ovabrw_glb_'.$card.'_review', 'yes' ), 'no' ); ?>>
                                        <?php esc_html_e( 'No', 'ova-brw' ); ?>
                                    </option>
                                </select>
                            </td>
                        </tr>
                        <tr valign="top">
                            <th scope="row" class="titledesc">
                                <label for="<?php echo esc_attr( 'ovabrw_glb_'.$card.'_button' ); ?>">
                                    <?php esc_html_e( 'Show button', 'ova-brw' ); ?>
                                </label>
                            </th>
                            <td class="forminp forminp-select">
                                <select
                                    name="<?php echo esc_attr( 'ovabrw_glb_'.$card.'_button' ); ?>"
                                    id="<?php echo esc_attr( 'ovabrw_glb_'.$card.'_button' ); ?>">
                                    <option value="yes"<?php selected( get_option( 'ovabrw_glb_'.$card.'_button', 'yes' ), 'yes' ); ?>>
                                        <?php esc_html_e( 'Yes', 'ova-brw' ); ?>
                                    </option>
                                    <option value="no"<?php selected( get_option( 'ovabrw_glb_'.$card.'_button', 'yes' ), 'no' ); ?>>
                                        <?php esc_html_e( 'No', 'ova-brw' ); ?>
                                    </option>
                                </select>
                            </td>
                        </tr>
                    </tbody>
                </table>
            <?php $flag++; endforeach; ?>
        </div>
    </div>
</div>