<?php defined( 'ABSPATH' ) || exit();

if ( ! class_exists( 'OVABRW_Mail' ) ) {
	class OVABRW_Mail {
		protected static $_instance = null;

		// Reminder Pick-up date email
		public function send_reminder_pickup_date_mail( $args = array() ) {
			// Get data
			$order 			= ovabrw_get_meta_data( 'order', $args );
			$customer_mail 	= ovabrw_get_meta_data( 'customer_mail', $args );
			$product_id 	= ovabrw_get_meta_data( 'product_id', $args );
			$product_name 	= ovabrw_get_meta_data( 'product_name', $args );
			$pickup_date 	= ovabrw_get_meta_data( 'pickup_date', $args );
			$dropoff_date 	= ovabrw_get_meta_data( 'dropoff_date', $args );

			// Subject mail
			$subject = get_option( 'reminder_mail_subject', esc_html__( 'Remind Pick-up date', 'ova-brw' ) );

			// Body mail
			$body = get_option( 'reminder_mail_content', esc_html__( 'You have hired a vehicle: [ovabrw_vehicle_name] at [ovabrw_order_pickup_date]', 'ova-brw' ) );
			$body = str_replace( '[ovabrw_vehicle_name]', '<a href="'.get_permalink( $product_id ).'" target="_blank">'.$product_name.'</a>', $body );
			$body = str_replace( '[ovabrw_order_pickup_date]', $pickup_date, $body );
			$body = apply_filters( 'ovabrw_reminder_content_mail', $body, $args );

			// Headers mail
			$headers = "MIME-Version: 1.0\r\n";
			$headers .= "Content-Type: text/html; charset=".get_bloginfo( 'charset' )."\r\n";

			add_filter( 'wp_mail_from', array( $this, 'mail_reminder_get_mail_from' ) );
			add_filter( 'wp_mail_from_name', array( $this, 'mail_reminder_get_from_name' ) );

			if ( wp_mail( $customer_mail, $subject, $body, $headers ) ) {
				$result = true;
			} else {
				$result = false;
			}

			remove_filter( 'wp_mail_from', array( $this, 'mail_reminder_get_mail_from' ) );
			remove_filter( 'wp_mail_from_name', array( $this, 'mail_reminder_get_from_name' ) );

			return $result;
		}

		public function mail_reminder_get_mail_from() {
			$send_from = get_option( 'reminder_mail_from_email', get_option( 'admin_email' ) );

			if ( ! $send_from ) return get_option( 'admin_email' );

			return apply_filters( 'ovabrw_mail_reminder_get_mail_from', $send_from );
		}

		public function mail_reminder_get_from_name() {
			$from_name = get_option( 'reminder_mail_from_name' );

			if ( ! $from_name ) $from_name = esc_html__( 'Remind Pick-up date', 'ova-brw' );

			return apply_filters( 'ovabrw_mail_reminder_get_from_name', $from_name );
		}
		// End
		
		// Reminder Pick-up date email
		public function send_reminder_dropoff_date_mail( $args = array() ) {
			// Get data
			$order 			= ovabrw_get_meta_data( 'order', $args );
			$customer_mail 	= ovabrw_get_meta_data( 'customer_mail', $args );
			$product_id 	= ovabrw_get_meta_data( 'product_id', $args );
			$product_name 	= ovabrw_get_meta_data( 'product_name', $args );
			$pickup_date 	= ovabrw_get_meta_data( 'pickup_date', $args );
			$dropoff_date 	= ovabrw_get_meta_data( 'dropoff_date', $args );

			// Subject mail
			$subject = get_option( 'reminder_dropoff_date_mail_subject', esc_html__( 'Remind Drop-off date', 'ova-brw' ) );

			// Body mail
			$body = get_option( 'reminder_dropoff_date_mail_content', esc_html__( 'You have hired a vehicle: [ovabrw_vehicle_name] at [ovabrw_order_pickup_date] and returned the vehicle at [ovabrw_order_dropoff_date].', 'ova-brw' ) );
			$body = str_replace( '[ovabrw_vehicle_name]', '<a href="'.get_permalink( $product_id ).'" target="_blank">'.$product_name.'</a>', $body );
			$body = str_replace( '[ovabrw_order_pickup_date]', $pickup_date, $body );
			$body = str_replace( '[ovabrw_order_dropoff_date]', $dropoff_date, $body );
			$body = apply_filters( 'ovabrw_reminder_content_mail', $body, $args );

			// Headers mail
			$headers = "MIME-Version: 1.0\r\n";
			$headers .= "Content-Type: text/html; charset=".get_bloginfo( 'charset' )."\r\n";

			add_filter( 'wp_mail_from', array( $this, 'mail_reminder_dropoff_date_get_mail_from' ) );
			add_filter( 'wp_mail_from_name', array( $this, 'mail_reminder_dropoff_date_get_from_name' ) );

			if ( wp_mail( $customer_mail, $subject, $body, $headers ) ) {
				$result = true;
			} else {
				$result = false;
			}

			remove_filter( 'wp_mail_from', array( $this, 'mail_reminder_dropoff_date_get_mail_from' ) );
			remove_filter( 'wp_mail_from_name', array( $this, 'mail_reminder_dropoff_date_get_from_name' ) );

			return $result;
		}

		public function mail_reminder_dropoff_date_get_mail_from() {
			$send_from = get_option( 'reminder_dropoff_date_mail_from_email', get_option( 'admin_email' ) );

			if ( ! $send_from ) return get_option( 'admin_email' );

			return apply_filters( 'ovabrw_reminder_dropoff_date_mail_from_email', $send_from );
		}

		public function mail_reminder_dropoff_date_get_from_name() {
			$from_name = get_option( 'reminder_dropoff_date_mail_from_name' );

			if ( ! $from_name ) $from_name = esc_html__( 'Remind Drop-off date', 'ova-brw' );

			return apply_filters( 'ovabrw_reminder_dropoff_date_mail_from_name', $from_name );
		}
		// End

		// Request Booking
		public function mail_request_booking( $data = [] ) {
			$product_id = isset( $data['product_id'] ) && $data['product_id'] ? $data['product_id'] : '';

			if ( ! $product_id ) return false;

			$rental_type = get_post_meta( $product_id, 'ovabrw_price_type', true );

			// Object Rental Types
        	$rental_object = isset( OVABRW_Rental_Types::instance()->rental_types[$rental_type] ) ? OVABRW_Rental_Types::instance()->rental_types[$rental_type] : '';

        	if ( empty( $rental_object ) || ! is_object( $rental_object ) ) return false;

        	// Set Product ID
        	$rental_object->set_ID( $product_id );

        	// Get body email
        	$body = $rental_object->request_booking_get_mail_body( $data );

        	if ( ! $body ) return false;

        	// Add filter body
        	$body = apply_filters( 'ovabrw_request_booking_content_mail', $body, $data );

        	// Get subject
        	$subject = get_option( 'ova_brw_request_booking_mail_subject' );

        	if ( ! $subject ) $subject = esc_html__( 'Request For Booking', 'ova-brw' );

        	// Customer email
        	$customer_mail = isset( $data['email'] ) ? $data['email'] : '';

        	// Mail to
        	$mail_to = [];

        	// Send to
        	$send_to = get_option( 'ovabrw_request_booking_send_to', 'both' );

        	if ( 'both' === $send_to ) {
        		$mail_to[] = get_option( 'admin_email' );

        		if ( $customer_mail ) $mail_to[] = $customer_mail;
        	} elseif ( 'admin' === $send_to ) {
        		$mail_to[] = get_option( 'admin_email' );
        	} elseif ( 'customer' === $send_to ) {
        		if ( $customer_mail ) $mail_to[] = $customer_mail;
        	}

        	// Recipient(s)
        	$recipients = get_option( 'ovabrw_request_booking_recipient' );
        	if ( $recipients ) $recipients = explode( ',', str_replace( ' ', '', $recipients ) );
        	if ( ovabrw_array_exists( $recipients ) ) {
        		$mail_to = ovabrw_array_merge_unique( $mail_to, $recipients );
        	}

        	// Add filter mail to
        	$mail_to = apply_filters( 'ovabrw_request_booking_mail_to', $mail_to, $data );

        	return $this->mail_request_booking_send( $mail_to, $subject, $body );
		}

		public function mail_request_booking_send( $mail_to, $subject, $body ) {
			$headers = "MIME-Version: 1.0\r\n";
	        $headers .= "Content-Type: text/html; charset=".get_bloginfo( 'charset' )."\r\n";
	        
	        add_filter( 'wp_mail_from', array( $this, 'mail_request_booking_get_mail_from' ) );
	        add_filter( 'wp_mail_from_name', array( $this, 'mail_request_booking_get_from_name' ) );

	        if ( wp_mail( $mail_to, $subject, $body, $headers ) ) {
	            $result = true;
	        } else {
	            $result = false;
	        }

	        remove_filter( 'wp_mail_from', array( $this, 'mail_request_booking_get_mail_from' ) );
	        remove_filter( 'wp_mail_from_name', array( $this, 'mail_request_booking_get_from_name' ) );

	        return $result;
		}

		public function mail_request_booking_get_mail_from() {
			$send_from = get_option( 'ova_brw_request_booking_mail_from_email' );

			if ( ! $send_from ) return  get_option( 'admin_email' );

			return apply_filters( 'ovabrw_mail_request_booking_get_mail_from', $send_from );
		}

		public function mail_request_booking_get_from_name() {
			$from_name = get_option( 'ova_brw_request_booking_mail_from_name' );

			if ( ! $from_name ) $from_name = esc_html__( 'Request For Booking', 'ova-brw' );

			return apply_filters( 'ovabrw_mail_request_booking_get_from_name', $from_name );
		}
		// End

		// instance
		public static function instance() {
			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self();
			}

			return self::$_instance;
		}
	}

	new OVABRW_Mail();
}