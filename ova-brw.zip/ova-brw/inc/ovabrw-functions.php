<?php
if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Dump & die
 */
if ( !function_exists( 'dd' ) ) {
    function dd( ...$args ) {
        echo '<pre>';
        var_dump( ...$args );
        echo '</pre>';
        die;
    }
}

/**
 * Require once
 */
if ( !function_exists( 'ovabrw_require_once' ) ) {
	function ovabrw_require_once( $files = [] ) {
		if ( ! empty( $files ) && is_array( $files ) ) {
			foreach ( $files as $file ) {
				if ( file_exists( $file ) ) {
					require_once $file;
				}
			}
		}
	}
}

/**
 * Autoload
 */
if ( !function_exists( 'ovabrw_autoload' ) ) {
	function ovabrw_autoload( $pattern = '' ) {
		if ( $pattern ) {
			ovabrw_require_once( glob( $pattern ) );
		}
	}
}

/**
 * Random unique id
 * @param  string $id
 * @return string
 */
if ( !function_exists( 'ovabrw_unique_id' ) ) {
	function ovabrw_unique_id( $id = '' ) {
		$unique_id = OVABRW_PREFIX.$id . '_' . time() . '_' . mt_rand();

		return apply_filters( 'ovabrw_unique_id', $unique_id, $id );
	}
}

/**
 * Selected
 * @param  string $id
 * @return string
 */
if ( !function_exists( 'ovabrw_selected' ) ) {
	function ovabrw_selected( $value = '', $options = array(), $display = true ) {
		$result = '';

		if ( is_array( $options ) ) {
			$options = array_map( 'strval', $options );
			$result  = selected( in_array( (string) $value, $options, true ), true, $display );
		} else {
			$result = selected( $value, $options, $display );
		}

		if ( $display ) {
			echo esc_html( $result );
		}

		return apply_filters( 'ovabrw_selected', $result, $value, $options, $display );
	}
}

/**
 * Recursive array replace \\
 */
if ( !function_exists( 'ovabrw_recursive_replace' ) ) {
    function ovabrw_recursive_replace( $find, $replace, $array ) {
        if ( !is_array( $array ) ) {
            return str_replace( $find, $replace, $array );
        }

        foreach ( $array as $key => $value ) {
            $array[$key] = ovabrw_recursive_replace( $find, $replace, $value );
        }

        return apply_filters( 'ovabrw_recursive_replace', $array, $find, $replace );
    }
}

/**
 * recursive price
 * @param  mixed $args
 * @return mixed
 */
if ( !function_exists( 'ovabrw_recursive_price' ) ) {
	function ovabrw_recursive_price( $args = [] ) {
		if ( empty( $args ) ) return $args;

		if ( !is_array( $args ) ) {
			return wc_format_decimal( $args );
		}

		foreach ( $args as $k => $v ) {
			$args[$k] = ovabrw_recursive_price( $v );
		}

		return apply_filters( 'ovabrw_recursive_price', $args );
	}
}

/**
 * Round a number
 */
if ( !function_exists( 'ovabrw_round' ) ) {
	function ovabrw_round( $val, int $precision = 0, int $mode = PHP_ROUND_HALF_UP ) {
		if ( ! is_numeric( $val ) ) {
			$val = floatval( $val );
		}

		return apply_filters( 'ovabrw_round', round( $val, $precision, $mode ), $val, $precision, $mode );
	}
}

/**
 * sanitize title
 * @param  mixed $args
 * @return mixed
 */
if ( !function_exists( 'ovabrw_sanitize_title' ) ) {
	function ovabrw_sanitize_title( $args = [] ) {
		if ( empty( $args ) ) return $args;

		if ( !is_array( $args ) ) {
			return sanitize_title( $args );
		}

		foreach ( $args as $k => $v ) {
			$args[$k] = ovabrw_sanitize_title( $v );
		}

		return apply_filters( 'ovabrw_sanitize_title', $args );
	}
}

/**
 * recursive array price
 * @param  mixed $args
 * @return mixed
 */
if ( !function_exists( 'ovabrw_recursive_array_price' ) ) {
	function ovabrw_recursive_array_price( $args = null ) {
		if ( !$args ) return $args;
		if ( !is_array( $args ) ) {
			return wc_format_decimal( $args );
		}

		foreach ( $args as $k => $v ) {
			$args[$k] = ovabrw_recursive_array_price( $v );
		}

		return apply_filters( 'ovabrw_recursive_array_price', $args );
	}
}

/**
 * recursive array date
 * @param  mixed $args
 * @return mixed
 */
if ( !function_exists( 'ovabrw_recursive_array_date' ) ) {
	function ovabrw_recursive_array_date( $args = null ) {
		if ( !$args ) return $args;
		if ( !is_array( $args ) ) {
			return strtotime( $args ) ? $args : '';
		}

		foreach ( $args as $k => $v ) {
			$args[$k] = ovabrw_recursive_array_date( $v );
		}

		return apply_filters( 'ovabrw_recursive_array_date', $args );
	}
}

/**
 * recursive array number
 * @param  mixed $args
 * @return mixed
 */
if ( !function_exists( 'ovabrw_recursive_array_number' ) ) {
	function ovabrw_recursive_array_number( $args = null ) {
		if ( !$args ) return $args;
		if ( !is_array( $args ) ) {
			return absint( $args );
		}

		foreach ( $args as $k => $v ) {
			$args[$k] = ovabrw_recursive_array_number( $v );
		}

		return apply_filters( 'ovabrw_recursive_array_number', $args );
	}
}

/**
 * Check array exists
 */
if ( !function_exists( 'ovabrw_array_exists' ) ) {
	function ovabrw_array_exists( $arr ) {
		if ( !empty( $arr ) && is_array( $arr ) ) {
			return true;
		}

		return false;
	}
}

/**
 * Array merge unique
 */
if ( !function_exists( 'ovabrw_array_merge_unique' ) ) {
	function ovabrw_array_merge_unique( ...$arrays ) {
		$valid_arrays = array();

		// Filter out non-array elements
	    foreach ( $arrays as $array ) {
	        if ( is_array( $array ) ) {
	            $valid_arrays[] = $array;
	        }
	    }

	    // Merge valid arrays
	    $merged_array = array_merge(...$valid_arrays );
	    $unique_array = array_unique( $merged_array );

	    // Reindex array keys
	    $unique_array = array_values( $unique_array );

	    return apply_filters( 'ovabrw_array_merge_unique', $unique_array, ...$arrays );
	}
}

/**
 * Get rental type name
 */
if ( !function_exists( 'ovabrw_get_rental_type_name' ) ) {
	function ovabrw_get_rental_type_name() {
		return apply_filters( 'ovabrw_get_rental_type_name', array(
			'day'				=> esc_html__( '1: Day', 'ova-brw' ),
			'hour'				=> esc_html__( '2: Hour', 'ova-brw' ),
			'mixed'				=> esc_html__( '3: Mixed (Day and Hour)', 'ova-brw' ),
			'period_time' 		=> esc_html__( '4: Period of Time ( 05:00 am - 10:00 am, 1 day, 2 days, 1 month, 6 months, 1 year... )', 'ova-brw' ),
			'transportation' 	=> esc_html__( '5: Transportation', 'ova-brw' ),
			'taxi' 				=> esc_html__( '6: Taxi', 'ova-brw' ),
			'hotel' 			=> esc_html__( '7: Hotel', 'ova-brw' ),
			'appointment' 		=> esc_html__( '8: Appointment', 'ova-brw' )
		));
	}
}

/**
 * Date format
 */
if ( !function_exists( 'ovabrw_date_format' ) ) {
	function ovabrw_date_format() {
		return apply_filters( 'ovabrw_date_format', array(
			'd-m-Y' => sprintf( esc_html__( 'dd-mm-yyyy (%s)', 'ova-brw' ), date( 'd-m-Y', current_time( 'timestamp' ) ) ),
			'm/d/Y' => sprintf( esc_html__( 'mm/dd/yyyy (%s)', 'ova-brw' ), date( 'm/d/Y', current_time( 'timestamp' ) ) ),
			'Y/m/d' => sprintf( esc_html__( 'yyyy/mm/dd (%s)', 'ova-brw' ), date( 'Y/m/d', current_time( 'timestamp' ) ) ),
			'Y-m-d' => sprintf( esc_html__( 'yyyy-mm-dd (%s)', 'ova-brw' ), date( 'Y-m-d', current_time( 'timestamp' ) ) )
		));
	}
}

/**
 * Get date format
 */
if ( !function_exists( 'ovabrw_get_date_format' ) ) {
	function ovabrw_get_date_format() {
		return apply_filters( 'ovabrw_get_date_format_hook', get_option( 'ova_brw_booking_form_date_format', 'd-m-Y' ) );
	}
}

/**
 * Get placeholder date format
 */
if ( !function_exists( 'ovabrw_get_date_placeholder' ) ) {
	function ovabrw_get_date_placeholder() {
		$placeholder = '';
		$date_format = ovabrw_get_date_format();

		switch ( $date_format ) {
			case 'd-m-Y':
				$placeholder = esc_html__( 'd-m-Y', 'ova-brw' );
				break;
			case 'm/d/Y':
				$placeholder = esc_html__( 'm/d/Y', 'ova-brw' );
				break;
			case 'Y/m/d':
				$placeholder = esc_html__( 'Y/m/d', 'ova-brw' );
				break;
			case 'Y-m-d':
				$placeholder = esc_html__( 'Y-m-d', 'ova-brw' );
				break;
			default:
				$placeholder = esc_html__( 'd-m-Y', 'ova-brw' );
				break;
		}

		return apply_filters( 'ovabrw_get_date_placeholder', $placeholder, $date_format );
	}
}

/**
 * Time format
 */
if ( !function_exists( 'ovabrw_time_format' ) ) {
	function ovabrw_time_format() {
		return apply_filters( 'ovabrw_time_formats', array(
			'H:i' 	=> esc_html__( 'H:i (24 hour time)', 'ova-brw' ),
			'h:i' 	=> esc_html__( 'h:i (12 hour time)', 'ova-brw' ),
			'h:i a' => sprintf( esc_html__( 'h:i a (%s)', 'ova-brw' ), date( 'h:i a', current_time( 'timestamp' ) ) ),
			'h:i A' => sprintf( esc_html__( 'h:i A (%s)', 'ova-brw' ), date( 'h:i A', current_time( 'timestamp' ) ) ),
			'g:i' 	=> sprintf( esc_html__( 'g:i (%s)', 'ova-brw' ), date( 'g:i', current_time( 'timestamp' ) ) ),
			'g:i a' => sprintf( esc_html__( 'g:i a (%s)', 'ova-brw' ), date( 'g:i a', current_time( 'timestamp' ) ) ),
			'g:i A' => sprintf( esc_html__( 'g:i A (%s)', 'ova-brw' ), date( 'g:i A', current_time( 'timestamp' ) ) )
		));
	}
}

/**
 * Get time format
 */
if ( !function_exists( 'ovabrw_get_time_format' ) ) {
	function ovabrw_get_time_format() {
		// Get time format
		$time_format = get_option( 'ova_brw_calendar_time_format', 'H:i' );

		// For old version
		if ( '12' == $time_format ) {
			$time_format = 'h:i';
		} elseif ( '24' == $time_format ) {
			$time_format = 'H:i';
		}

		return apply_filters( 'ova_brw_calendar_time_format_hook', $time_format );
	}
}

/**
 * Get placeholder time format
 */
if ( !function_exists( 'ovabrw_get_time_placeholder' ) ) {
	function ovabrw_get_time_placeholder() {
		$placeholder = '';
		$time_format = ovabrw_get_time_format();

		switch ( $time_format ) {
			case 'H:i':
				$placeholder = esc_html__( 'H:i', 'ova-brw' );
				break;
			case 'h:i':
				$placeholder = esc_html__( 'h:i', 'ova-brw' );
				break;
			case 'h:i a':
				$placeholder = esc_html__( 'h:i a', 'ova-brw' );
				break;
			case 'h:i A':
				$placeholder = esc_html__( 'h:i A', 'ova-brw' );
				break;
			case 'g:i':
				$placeholder = esc_html__( 'g:i', 'ova-brw' );
				break;
			case 'g:i a':
				$placeholder = esc_html__( 'g:i a', 'ova-brw' );
				break;
			case 'g:i A':
				$placeholder = esc_html__( 'g:i A', 'ova-brw' );
				break;
			default:
				$placeholder = esc_html__( 'H:i', 'ova-brw' );
				break;
		}
		
		return apply_filters( 'ovabrw_get_time_placeholder', $placeholder, $time_format );
	}
}

/**
 * Get datetime format
 */
if ( !function_exists( 'ovabrw_get_datetime_format' ) ) {
	function ovabrw_get_datetime_format() {
		return apply_filters( 'ovabrw_get_datetime_format', ovabrw_get_date_format() . ' ' . ovabrw_get_time_format() );
	}
}

/**
 * Get string date
 * @param int 		$date
 * @param int 		$time
 * @return string 	$date
 */
if ( !function_exists( 'ovabrw_get_string_date' ) ) {
	function ovabrw_get_string_date( $date = null, $time = null ) {
		// init date
		$string_date = '';

		if ( $date && $time ) {
			$string_date = date( ovabrw_get_date_format(), $date ).' '.date( ovabrw_get_time_format(), $time );
		} elseif ( $date && !$time ) {
			$string_date = date( ovabrw_get_date_format(), $date );
		} elseif ( !$date && $time ) {
			$string_date = date( ovabrw_get_time_format(), $time );
		}

		return apply_filters( 'ovabrw_get_string_date', $string_date, $date, $time );
	}
}

/**
 * Get default pick-up time
 */
if ( !function_exists( 'ovabrw_get_default_pickup_time' ) ) {
	function ovabrw_get_default_pickup_time() {
		return apply_filters( 'ovabrw_get_default_pickup_time', get_option( 'ova_brw_booking_form_default_hour', '07:00' ) );
	}
}

/**
 * Get pick-up group time
 */
if ( !function_exists( 'ovabrw_get_pickup_group_time' ) ) {
	function ovabrw_get_pickup_group_time() {
		// Get from setting
		$group_time = get_option( 'ova_brw_calendar_time_to_book', '07:00, 07:30, 08:00, 08:30, 09:00, 09:30, 10:00, 10:30, 11:00, 11:30, 12:00, 12:30, 13:00, 13:30, 14:00, 14:30, 15:00, 15:30, 16:00, 16:30, 17:00, 17:30, 18:00' );

		// String to array
		if ( $group_time ) {
			$group_time = array_map( 'trim', explode( ',', $group_time ) );
		} else {
			$group_time = [];
		}

		return apply_filters( 'ovabrw_get_pickup_group_time', $group_time );
	}
}

/**
 * Get default drop-off time
 */
if ( !function_exists( 'ovabrw_get_default_dropoff_time' ) ) {
	function ovabrw_get_default_dropoff_time() {
		return apply_filters( 'ovabrw_get_default_dropoff_time', get_option( 'ova_brw_booking_form_default_hour_end_date', '07:00' ) );
	}
}

/**
 * Get drop-off group time
 */
if ( !function_exists( 'ovabrw_get_dropoff_group_time' ) ) {
	function ovabrw_get_dropoff_group_time() {
		// Get from setting
		$group_time = get_option( 'ova_brw_calendar_time_to_book_for_end_date', '07:00, 07:30, 08:00, 08:30, 09:00, 09:30, 10:00, 10:30, 11:00, 11:30, 12:00, 12:30, 13:00, 13:30, 14:00, 14:30, 15:00, 15:30, 16:00, 16:30, 17:00, 17:30, 18:00' );

		// String to array
		if ( $group_time ) {
			$group_time = array_map( 'trim', explode( ',', $group_time ) );
		} else {
			$group_time = [];
		}

		return apply_filters( 'ovabrw_get_dropoff_group_time', $group_time );
	}
}

/**
 * Get default hour for pick-up date
 */
if ( !function_exists( 'ovabrw_get_default_time' ) ) {
	function ovabrw_get_default_time( $product_id = false, $type = 'start' ) {
		// Get time format
		$time_format = ovabrw_get_time_format();

		if ( 'start' == $type ) {
			$default_time 	= get_option( 'ova_brw_booking_form_default_hour', '07:00' );	
			$start_time 	= get_post_meta( $product_id, 'ovabrw_manage_default_hour_start', true );

			if ( 'new_time' == $start_time ) {
				$default_time = get_post_meta( $product_id, 'ovabrw_product_default_hour_start', true );
			}
		} else {
			$default_time = get_option( 'ova_brw_booking_form_default_hour_end_date', '07:00' );

			// Get from Product
			$end_time = get_post_meta( $product_id, 'ovabrw_manage_default_hour_end', true );

			if ( 'new_time' == $end_time ) {
				$default_time = get_post_meta( $product_id, 'ovabrw_product_default_hour_end', true );
			}
		}

		// Check time
		if ( strtotime( $default_time ) ) {
			$default_time = date( ovabrw_get_time_format(), strtotime( $default_time ) );
		} else {
			$default_time = '';
		}
		
		return apply_filters( 'ovabrw_get_default_time', $default_time, $product_id, $type );
	}
}

/**
 * Get string time
 */
if ( !function_exists( 'ovabrw_get_time_string' ) ) {
	function ovabrw_get_time_string( $time ) {
		if ( strtotime( $time ) ) {
			$time = date( ovabrw_get_time_format(), strtotime( $time ) );
		}

		return apply_filters( 'ovabrw_get_time_string', $time );
	}
}

/**
 * Get time step
 */
if ( !function_exists( 'ovabrw_get_time_step' ) ) {
	function ovabrw_get_time_step() {
		// Get step time
		$step_time = get_option( 'ova_brw_booking_form_step_time', 30 );
		if ( !$step_time ) $step_time = 30;

		return apply_filters( 'ovabrw_get_time_step', $step_time );
	}
}

/**
 * Get countries - ISO 3166-1 alpha-2 codes
 */
if ( ! function_exists( 'ovabrw_iso_alpha2' ) ) {
	function ovabrw_iso_alpha2() {
		$countries = [
		    'AD' => esc_html__('Andorra', 'ova-brw'),
		    'AE' => esc_html__('United Arab Emirates', 'ova-brw'),
		    'AF' => esc_html__('Afghanistan', 'ova-brw'),
		    'AG' => esc_html__('Antigua and Barbuda', 'ova-brw'),
		    'AI' => esc_html__('Anguilla', 'ova-brw'),
		    'AL' => esc_html__('Albania', 'ova-brw'),
		    'AM' => esc_html__('Armenia', 'ova-brw'),
		    'AO' => esc_html__('Angola', 'ova-brw'),
		    'AQ' => esc_html__('Antarctica', 'ova-brw'),
		    'AR' => esc_html__('Argentina', 'ova-brw'),
		    'AS' => esc_html__('American Samoa', 'ova-brw'),
		    'AT' => esc_html__('Austria', 'ova-brw'),
		    'AU' => esc_html__('Australia', 'ova-brw'),
		    'AW' => esc_html__('Aruba', 'ova-brw'),
		    'AX' => esc_html__('Åland Islands', 'ova-brw'),
		    'AZ' => esc_html__('Azerbaijan', 'ova-brw'),
		    'BA' => esc_html__('Bosnia and Herzegovina', 'ova-brw'),
		    'BB' => esc_html__('Barbados', 'ova-brw'),
		    'BD' => esc_html__('Bangladesh', 'ova-brw'),
		    'BE' => esc_html__('Belgium', 'ova-brw'),
		    'BF' => esc_html__('Burkina Faso', 'ova-brw'),
		    'BG' => esc_html__('Bulgaria', 'ova-brw'),
		    'BH' => esc_html__('Bahrain', 'ova-brw'),
		    'BI' => esc_html__('Burundi', 'ova-brw'),
		    'BJ' => esc_html__('Benin', 'ova-brw'),
		    'BL' => esc_html__('Saint Barthélemy', 'ova-brw'),
		    'BM' => esc_html__('Bermuda', 'ova-brw'),
		    'BN' => esc_html__('Brunei Darussalam', 'ova-brw'),
		    'BO' => esc_html__('Bolivia (Plurinational State of)', 'ova-brw'),
		    'BQ' => esc_html__('Bonaire, Sint Eustatius and Saba', 'ova-brw'),
		    'BR' => esc_html__('Brazil', 'ova-brw'),
		    'BS' => esc_html__('Bahamas', 'ova-brw'),
		    'BT' => esc_html__('Bhutan', 'ova-brw'),
		    'BV' => esc_html__('Bouvet Island', 'ova-brw'),
		    'BW' => esc_html__('Botswana', 'ova-brw'),
		    'BY' => esc_html__('Belarus', 'ova-brw'),
		    'BZ' => esc_html__('Belize', 'ova-brw'),
		    'CA' => esc_html__('Canada', 'ova-brw'),
		    'CC' => esc_html__('Cocos (Keeling) Islands', 'ova-brw'),
		    'CD' => esc_html__('Congo, Democratic Republic of the', 'ova-brw'),
		    'CF' => esc_html__('Central African Republic', 'ova-brw'),
		    'CG' => esc_html__('Congo', 'ova-brw'),
		    'CH' => esc_html__('Switzerland', 'ova-brw'),
		    'CI' => esc_html__('Côte d\'Ivoire', 'ova-brw'),
		    'CK' => esc_html__('Cook Islands', 'ova-brw'),
		    'CL' => esc_html__('Chile', 'ova-brw'),
		    'CM' => esc_html__('Cameroon', 'ova-brw'),
		    'CN' => esc_html__('China', 'ova-brw'),
		    'CO' => esc_html__('Colombia', 'ova-brw'),
		    'CR' => esc_html__('Costa Rica', 'ova-brw'),
		    'CU' => esc_html__('Cuba', 'ova-brw'),
		    'CV' => esc_html__('Cabo Verde', 'ova-brw'),
		    'CW' => esc_html__('Curaçao', 'ova-brw'),
		    'CX' => esc_html__('Christmas Island', 'ova-brw'),
		    'CY' => esc_html__('Cyprus', 'ova-brw'),
		    'CZ' => esc_html__('Czechia', 'ova-brw'),
		    'DE' => esc_html__('Germany', 'ova-brw'),
		    'DJ' => esc_html__('Djibouti', 'ova-brw'),
		    'DK' => esc_html__('Denmark', 'ova-brw'),
		    'DM' => esc_html__('Dominica', 'ova-brw'),
		    'DO' => esc_html__('Dominican Republic', 'ova-brw'),
		    'DZ' => esc_html__('Algeria', 'ova-brw'),
		    'EC' => esc_html__('Ecuador', 'ova-brw'),
		    'EE' => esc_html__('Estonia', 'ova-brw'),
		    'EG' => esc_html__('Egypt', 'ova-brw'),
		    'EH' => esc_html__('Western Sahara', 'ova-brw'),
		    'ER' => esc_html__('Eritrea', 'ova-brw'),
		    'ES' => esc_html__('Spain', 'ova-brw'),
		    'ET' => esc_html__('Ethiopia', 'ova-brw'),
		    'FI' => esc_html__('Finland', 'ova-brw'),
		    'FJ' => esc_html__('Fiji', 'ova-brw'),
		    'FK' => esc_html__('Falkland Islands (Malvinas)', 'ova-brw'),
		    'FM' => esc_html__('Micronesia (Federated States of)', 'ova-brw'),
		    'FO' => esc_html__('Faroe Islands', 'ova-brw'),
		    'FR' => esc_html__('France', 'ova-brw'),
		    'GA' => esc_html__('Gabon', 'ova-brw'),
		    'GB' => esc_html__('United Kingdom of Great Britain and Northern Ireland', 'ova-brw'),
		    'GD' => esc_html__('Grenada', 'ova-brw'),
		    'GE' => esc_html__('Georgia', 'ova-brw'),
		    'GF' => esc_html__('French Guiana', 'ova-brw'),
		    'GG' => esc_html__('Guernsey', 'ova-brw'),
		    'GH' => esc_html__('Ghana', 'ova-brw'),
		    'GI' => esc_html__('Gibraltar', 'ova-brw'),
		    'GL' => esc_html__('Greenland', 'ova-brw'),
		    'GM' => esc_html__('Gambia', 'ova-brw'),
		    'GN' => esc_html__('Guinea', 'ova-brw'),
		    'GP' => esc_html__('Guadeloupe', 'ova-brw'),
		    'GQ' => esc_html__('Equatorial Guinea', 'ova-brw'),
		    'GR' => esc_html__('Greece', 'ova-brw'),
		    'GS' => esc_html__('South Georgia and the South Sandwich Islands', 'ova-brw'),
		    'GT' => esc_html__('Guatemala', 'ova-brw'),
		    'GU' => esc_html__('Guam', 'ova-brw'),
		    'GW' => esc_html__('Guinea-Bissau', 'ova-brw'),
		    'GY' => esc_html__('Guyana', 'ova-brw'),
		    'HK' => esc_html__('Hong Kong', 'ova-brw'),
		    'HM' => esc_html__('Heard Island and McDonald Islands', 'ova-brw'),
		    'HN' => esc_html__('Honduras', 'ova-brw'),
		    'HR' => esc_html__('Croatia', 'ova-brw'),
		    'HT' => esc_html__('Haiti', 'ova-brw'),
		    'HU' => esc_html__('Hungary', 'ova-brw'),
		    'ID' => esc_html__('Indonesia', 'ova-brw'),
		    'IE' => esc_html__('Ireland', 'ova-brw'),
		    'IL' => esc_html__('Israel', 'ova-brw'),
		    'IM' => esc_html__('Isle of Man', 'ova-brw'),
		    'IN' => esc_html__('India', 'ova-brw'),
		    'IO' => esc_html__('British Indian Ocean Territory', 'ova-brw'),
		    'IQ' => esc_html__('Iraq', 'ova-brw'),
		    'IR' => esc_html__('Iran (Islamic Republic of)', 'ova-brw'),
		    'IS' => esc_html__('Iceland', 'ova-brw'),
		    'IT' => esc_html__('Italy', 'ova-brw'),
		    'JE' => esc_html__('Jersey', 'ova-brw'),
		    'JM' => esc_html__('Jamaica', 'ova-brw'),
		    'JO' => esc_html__('Jordan', 'ova-brw'),
		    'JP' => esc_html__('Japan', 'ova-brw'),
		    'KE' => esc_html__('Kenya', 'ova-brw'),
		    'KG' => esc_html__('Kyrgyzstan', 'ova-brw'),
		    'KH' => esc_html__('Cambodia', 'ova-brw'),
		    'KI' => esc_html__('Kiribati', 'ova-brw'),
		    'KM' => esc_html__('Comoros', 'ova-brw'),
		    'KN' => esc_html__('Saint Kitts and Nevis', 'ova-brw'),
		    'KP' => esc_html__('Korea (Democratic People\'s Republic of)', 'ova-brw'),
		    'KR' => esc_html__('Korea, Republic of', 'ova-brw'),
		    'KW' => esc_html__('Kuwait', 'ova-brw'),
		    'KY' => esc_html__('Cayman Islands', 'ova-brw'),
		    'KZ' => esc_html__('Kazakhstan', 'ova-brw'),
		    'LA' => esc_html__('Lao People\'s Democratic Republic', 'ova-brw'),
		    'LB' => esc_html__('Lebanon', 'ova-brw'),
		    'LC' => esc_html__('Saint Lucia', 'ova-brw'),
		    'LI' => esc_html__('Liechtenstein', 'ova-brw'),
		    'LK' => esc_html__('Sri Lanka', 'ova-brw'),
		    'LR' => esc_html__('Liberia', 'ova-brw'),
		    'LS' => esc_html__('Lesotho', 'ova-brw'),
		    'LT' => esc_html__('Lithuania', 'ova-brw'),
		    'LU' => esc_html__('Luxembourg', 'ova-brw'),
		    'LV' => esc_html__('Latvia', 'ova-brw'),
		    'LY' => esc_html__('Libya', 'ova-brw'),
		    'MA' => esc_html__('Morocco', 'ova-brw'),
		    'MC' => esc_html__('Monaco', 'ova-brw'),
		    'MD' => esc_html__('Moldova, Republic of', 'ova-brw'),
		    'ME' => esc_html__('Montenegro', 'ova-brw'),
		    'MF' => esc_html__('Saint Martin (French part)', 'ova-brw'),
		    'MG' => esc_html__('Madagascar', 'ova-brw'),
		    'MH' => esc_html__('Marshall Islands', 'ova-brw'),
		    'MK' => esc_html__('North Macedonia', 'ova-brw'),
		    'ML' => esc_html__('Mali', 'ova-brw'),
		    'MM' => esc_html__('Myanmar', 'ova-brw'),
		    'MN' => esc_html__('Mongolia', 'ova-brw'),
		    'MO' => esc_html__('Macao', 'ova-brw'),
		    'MP' => esc_html__('Northern Mariana Islands', 'ova-brw'),
		    'MQ' => esc_html__('Martinique', 'ova-brw'),
		    'MR' => esc_html__('Mauritania', 'ova-brw'),
		    'MS' => esc_html__('Montserrat', 'ova-brw'),
		    'MT' => esc_html__('Malta', 'ova-brw'),
		    'MU' => esc_html__('Mauritius', 'ova-brw'),
		    'MV' => esc_html__('Maldives', 'ova-brw'),
		    'MW' => esc_html__('Malawi', 'ova-brw'),
		    'MX' => esc_html__('Mexico', 'ova-brw'),
		    'MY' => esc_html__('Malaysia', 'ova-brw'),
		    'MZ' => esc_html__('Mozambique', 'ova-brw'),
		    'NA' => esc_html__('Namibia', 'ova-brw'),
		    'NC' => esc_html__('New Caledonia', 'ova-brw'),
		    'NE' => esc_html__('Niger', 'ova-brw'),
		    'NF' => esc_html__('Norfolk Island', 'ova-brw'),
		    'NG' => esc_html__('Nigeria', 'ova-brw'),
		    'NI' => esc_html__('Nicaragua', 'ova-brw'),
		    'NL' => esc_html__('Netherlands, Kingdom of the', 'ova-brw'),
		    'NO' => esc_html__('Norway', 'ova-brw'),
		    'NP' => esc_html__('Nepal', 'ova-brw'),
		    'NR' => esc_html__('Nauru', 'ova-brw'),
		    'NU' => esc_html__('Niue', 'ova-brw'),
		    'NZ' => esc_html__('New Zealand', 'ova-brw'),
		    'OM' => esc_html__('Oman', 'ova-brw'),
		    'PA' => esc_html__('Panama', 'ova-brw'),
		    'PE' => esc_html__('Peru', 'ova-brw'),
		    'PF' => esc_html__('French Polynesia', 'ova-brw'),
		    'PG' => esc_html__('Papua New Guinea', 'ova-brw'),
		    'PH' => esc_html__('Philippines', 'ova-brw'),
		    'PK' => esc_html__('Pakistan', 'ova-brw'),
		    'PL' => esc_html__('Poland', 'ova-brw'),
		    'PM' => esc_html__('Saint Pierre and Miquelon', 'ova-brw'),
		    'PN' => esc_html__('Pitcairn', 'ova-brw'),
		    'PR' => esc_html__('Puerto Rico', 'ova-brw'),
		    'PS' => esc_html__('Palestine, State of', 'ova-brw'),
		    'PT' => esc_html__('Portugal', 'ova-brw'),
		    'PW' => esc_html__('Palau', 'ova-brw'),
		    'PY' => esc_html__('Paraguay', 'ova-brw'),
		    'QA' => esc_html__('Qatar', 'ova-brw'),
		    'RE' => esc_html__('Réunion', 'ova-brw'),
		    'RO' => esc_html__('Romania', 'ova-brw'),
		    'RS' => esc_html__('Serbia', 'ova-brw'),
		    'RU' => esc_html__('Russian Federation', 'ova-brw'),
		    'RW' => esc_html__('Rwanda', 'ova-brw'),
		    'SA' => esc_html__('Saudi Arabia', 'ova-brw'),
		    'SB' => esc_html__('Solomon Islands', 'ova-brw'),
		    'SC' => esc_html__('Seychelles', 'ova-brw'),
		    'SD' => esc_html__('Sudan', 'ova-brw'),
		    'SE' => esc_html__('Sweden', 'ova-brw'),
		    'SG' => esc_html__('Singapore', 'ova-brw'),
		    'SH' => esc_html__('Saint Helena, Ascension and Tristan da Cunha', 'ova-brw'),
		    'SI' => esc_html__('Slovenia', 'ova-brw'),
		    'SJ' => esc_html__('Svalbard and Jan Mayen', 'ova-brw'),
		    'SK' => esc_html__('Slovakia', 'ova-brw'),
		    'SL' => esc_html__('Sierra Leone', 'ova-brw'),
		    'SM' => esc_html__('San Marino', 'ova-brw'),
		    'SN' => esc_html__('Senegal', 'ova-brw'),
		    'SO' => esc_html__('Somalia', 'ova-brw'),
		    'SR' => esc_html__('Suriname', 'ova-brw'),
		    'SS' => esc_html__('South Sudan', 'ova-brw'),
		    'ST' => esc_html__('Sao Tome and Principe', 'ova-brw'),
		    'SV' => esc_html__('El Salvador', 'ova-brw'),
		    'SX' => esc_html__('Sint Maarten (Dutch part)', 'ova-brw'),
		    'SY' => esc_html__('Syrian Arab Republic', 'ova-brw'),
		    'SZ' => esc_html__('Eswatini', 'ova-brw'),
		    'TC' => esc_html__('Turks and Caicos Islands', 'ova-brw'),
		    'TD' => esc_html__('Chad', 'ova-brw'),
		    'TF' => esc_html__('French Southern Territories', 'ova-brw'),
		    'TG' => esc_html__('Togo', 'ova-brw'),
		    'TH' => esc_html__('Thailand', 'ova-brw'),
		    'TJ' => esc_html__('Tajikistan', 'ova-brw'),
		    'TK' => esc_html__('Tokelau', 'ova-brw'),
		    'TL' => esc_html__('Timor-Leste', 'ova-brw'),
		    'TM' => esc_html__('Turkmenistan', 'ova-brw'),
		    'TN' => esc_html__('Tunisia', 'ova-brw'),
		    'TO' => esc_html__('Tonga', 'ova-brw'),
		    'TR' => esc_html__('Türkiye', 'ova-brw'),
		    'TT' => esc_html__('Trinidad and Tobago', 'ova-brw'),
		    'TV' => esc_html__('Tuvalu', 'ova-brw'),
		    'TW' => esc_html__('Taiwan, Province of China', 'ova-brw'),
		    'TZ' => esc_html__('Tanzania, United Republic of', 'ova-brw'),
		    'UA' => esc_html__('Ukraine', 'ova-brw'),
		    'UG' => esc_html__('Uganda', 'ova-brw'),
		    'UM' => esc_html__('United States Minor Outlying Islands', 'ova-brw'),
		    'US' => esc_html__('United States of America', 'ova-brw'),
		    'UY' => esc_html__('Uruguay', 'ova-brw'),
		    'UZ' => esc_html__('Uzbekistan', 'ova-brw'),
		    'VA' => esc_html__('Holy See', 'ova-brw'),
		    'VC' => esc_html__('Saint Vincent and the Grenadines', 'ova-brw'),
		    'VE' => esc_html__('Venezuela (Bolivarian Republic of)', 'ova-brw'),
		    'VG' => esc_html__('Virgin Islands (British)', 'ova-brw'),
		    'VI' => esc_html__('Virgin Islands (U.S.)', 'ova-brw'),
		    'VN' => esc_html__('Viet Nam', 'ova-brw'),
		    'VU' => esc_html__('Vanuatu', 'ova-brw'),
		    'WF' => esc_html__('Wallis and Futuna', 'ova-brw'),
		    'WS' => esc_html__('Samoa', 'ova-brw'),
		    'YE' => esc_html__('Yemen', 'ova-brw'),
		    'YT' => esc_html__('Mayotte', 'ova-brw'),
		    'ZA' => esc_html__('South Africa', 'ova-brw'),
		    'ZM' => esc_html__('Zambia', 'ova-brw'),
		    'ZW' => esc_html__('Zimbabwe', 'ova-brw'),
		];

		return apply_filters( 'ovabrw_get_countries_iso_alpha2', $countries );
	}
}

/**
 * Calendar languages
 */
if ( !function_exists( 'ovabrw_calendar_languages' ) ) {
	function ovabrw_calendar_languages() {
		return apply_filters( 'ovabrw_calendar_languages', array(
			'en-GB' => esc_html__( 'English/UK', 'ova-brw' ),
			'af' 	=> esc_html__( 'Afrikaans', 'ova-brw' ),
			'ar-DZ' => esc_html__( 'Algerian Arabic', 'ova-brw' ),
			'ar' 	=> esc_html__( 'Arabic', 'ova-brw' ),
			'az' 	=> esc_html__( 'Azerbaijani', 'ova-brw' ),
			'be' 	=> esc_html__( 'Belarusian', 'ova-brw' ),
			'bg' 	=> esc_html__( 'Bulgarian', 'ova-brw' ),
			'bs' 	=> esc_html__( 'Bosnian', 'ova-brw' ),
			'ca' 	=> esc_html__( 'Inicialització', 'ova-brw' ),
			'cs' 	=> esc_html__( 'Czech', 'ova-brw' ),
			'cy-GB' => esc_html__( 'Welsh/UK', 'ova-brw' ),
			'da' 	=> esc_html__( 'Danish', 'ova-brw' ),
			'de' 	=> esc_html__( 'German', 'ova-brw' ),
			'el' 	=> esc_html__( 'Greek', 'ova-brw' ),
			'en-AU' => esc_html__( 'English/Australia', 'ova-brw' ),
			'en-NZ' => esc_html__( 'English/New Zealand', 'ova-brw' ),
			'eo' 	=> esc_html__( 'Esperanto', 'ova-brw' ),
			'es' 	=> esc_html__( 'Spanish', 'ova-brw' ),
			'et' 	=> esc_html__( 'Estonian', 'ova-brw' ),
			'eu' 	=> esc_html__( 'Karrikas-ek', 'ova-brw' ),
			'fa' 	=> esc_html__( 'Persian (Farsi)', 'ova-brw' ),
			'fi' 	=> esc_html__( 'Finnish', 'ova-brw' ),
			'fo' 	=> esc_html__( 'Faroese', 'ova-brw' ),
			'fr-CA' => esc_html__( 'Canadian-French', 'ova-brw' ),
			'fr-CH' => esc_html__( 'Swiss-French', 'ova-brw' ),
			'fr' 	=> esc_html__( 'French', 'ova-brw' ),
			'gl' 	=> esc_html__( 'Galician', 'ova-brw' ),
			'he' 	=> esc_html__( 'Hebrew', 'ova-brw' ),
			'hi' 	=> esc_html__( 'Hindi', 'ova-brw' ),
			'hr' 	=> esc_html__( 'Croatian', 'ova-brw' ),
			'hu' 	=> esc_html__( 'Hungarian', 'ova-brw' ),
			'hy' 	=> esc_html__( 'Armenian', 'ova-brw' ),
			'id' 	=> esc_html__( 'Indonesian', 'ova-brw' ),
			'is' 	=> esc_html__( 'Icelandic', 'ova-brw' ),
			'it-CH' => esc_html__( 'Italian', 'ova-brw' ),
			'ja' 	=> esc_html__( 'Japanese', 'ova-brw' ),
			'ka' 	=> esc_html__( 'Georgian', 'ova-brw' ),
			'kk' 	=> esc_html__( 'Kazakh', 'ova-brw' ),
			'km' 	=> esc_html__( 'Khmer', 'ova-brw' ),
			'ko' 	=> esc_html__( 'Korean', 'ova-brw' ),
			'ky' 	=> esc_html__( 'Kyrgyz', 'ova-brw' ),
			'lb' 	=> esc_html__( 'Luxembourgish', 'ova-brw' ),
			'lt' 	=> esc_html__( 'Lithuanian', 'ova-brw' ),
			'lv' 	=> esc_html__( 'Latvian', 'ova-brw' ),
			'mk' 	=> esc_html__( 'Macedonian', 'ova-brw' ),
			'ml' 	=> esc_html__( 'Malayalam', 'ova-brw' ),
			'ms' 	=> esc_html__( 'Malaysian', 'ova-brw' ),
			'nb' 	=> esc_html__( 'Norwegian Bokmål', 'ova-brw' ),
			'nl-BE' => esc_html__( 'Dutch (Belgium)', 'ova-brw' ),
			'nl' 	=> esc_html__( 'Dutch', 'ova-brw' ),
			'nn' 	=> esc_html__( 'Norwegian Nynorsk', 'ova-brw' ),
			'no' 	=> esc_html__( 'Norwegian', 'ova-brw' ),
			'pl' 	=> esc_html__( 'Polish', 'ova-brw' ),
			'pt-BR' => esc_html__( 'Brazilian', 'ova-brw' ),
			'pt' 	=> esc_html__( 'Portuguese', 'ova-brw' ),
			'rm' 	=> esc_html__( 'Romansh', 'ova-brw' ),
			'ro' 	=> esc_html__( 'Romanian', 'ova-brw' ),
			'ru' 	=> esc_html__( 'Russian', 'ova-brw' ),
			'sk' 	=> esc_html__( 'Slovak', 'ova-brw' ),
			'sl' 	=> esc_html__( 'Slovenian', 'ova-brw' ),
			'sq' 	=> esc_html__( 'Albanian', 'ova-brw' ),
			'sr' 	=> esc_html__( 'Serbian', 'ova-brw' ),
			'sv' 	=> esc_html__( 'Swedish', 'ova-brw' ),
			'ta' 	=> esc_html__( 'Tamil', 'ova-brw' ),
			'th' 	=> esc_html__( 'Thai', 'ova-brw' ),
			'tj' 	=> esc_html__( 'Tajiki', 'ova-brw' ),
			'tr' 	=> esc_html__( 'Turkish', 'ova-brw' ),
			'uk' 	=> esc_html__( 'Ukrainian', 'ova-brw' ),
			'vi' 	=> esc_html__( 'Vietnamese', 'ova-brw' ),
			'zh-CN' => esc_html__( 'Chinese', 'ova-brw' ),
			'zh-HK' => esc_html__( 'Chinese (Hong Kong)', 'ova-brw' ),
			'zh-TW' => esc_html__( 'Chinese (Taiwan)', 'ova-brw' ),
		));
	}
}

/**
 * Get locate_template
 */
if ( !function_exists( 'ovabrw_locate_template' ) ) {
	function ovabrw_locate_template( $template_name = '', $template_path = '', $default_path = '' ) {
		// Set variable to search in ovabrw-templates folder of theme.
		if ( ! $template_path ) :
			$template_path = 'ovabrw-templates/';
		endif;

		// Set default plugin templates path.
		if ( ! $default_path ) :
			$default_path = OVABRW_PLUGIN_PATH . 'ovabrw-templates/'; // Path to the template folder
		endif;

		// Search template file in theme folder.
		$template = locate_template( array(
			$template_path . $template_name
			// ,$template_name
		) );

		// Get plugins template file.
		if ( ! $template ) :
			$template = $default_path . $template_name;
		endif;

		return apply_filters( 'ovabrw_locate_template', $template, $template_name, $template_path, $default_path );
	}
}

/**
 * Get template
 */
if ( !function_exists( 'ovabrw_get_template' ) ) {
	function ovabrw_get_template( $template_name = '', $args = array(), $tempate_path = '', $default_path = '' ) {
		if ( is_array( $args ) && isset( $args ) ) {
			extract( $args );
		}

		$template_file = ovabrw_locate_template( $template_name, $tempate_path, $default_path );
		if ( ! file_exists( $template_file ) ) :
			_doing_it_wrong( __FUNCTION__, sprintf( '<code>%s</code> does not exist.', $template_file ), '1.0.0' );
			return;
		endif;

		include $template_file;
	}
}

/**
 * Show quantity field
 */
if ( !function_exists( 'ovabrw_show_quantity' ) ) {
	function ovabrw_show_quantity( $product_id = false, $action = 'booking_form' ) {
		if ( !$product_id ) return false;

		// Product get show quantity
		$show_quantity = get_post_meta( $product_id, 'ovabrw_show_number_vehicle', true );

		if ( 'request_form' == $action ) {
			$show_quantity_global = get_option( 'ova_brw_request_booking_form_show_number_vehicle', 'no' );	
		} else {
			$show_quantity_global = get_option( 'ova_brw_booking_form_show_number_vehicle', 'yes' );
		}
		
		switch ( $show_quantity ) {
			case 'in_setting':
				if ( 'yes' == $show_quantity_global ) {
					return true;
				} else {
					return false;
				}
				break;
			case 'yes':
				return true;
				break;
			case 'no':
				return false;
				break;
			default:
				return true;
		}

		return apply_filters( 'ovabrw_show_quantity', false, $product_id, $action );
	}
}

/**
 * Show location
 */
if ( !function_exists( 'ovabrw_show_location' ) ) {
	function ovabrw_show_location( $product_id = false, $type = 'pickup' ) {
		if ( !$product_id ) return false;
		$rental_type = get_post_meta( $product_id, 'ovabrw_price_type', true );

		if ( 'taxi' == $rental_type || 'transportation' == $rental_type ) return true;
		if ( 'hotel' == $rental_type ) return false;

		// Get custom checkout field by Category
		$categories 	= wp_get_post_terms( $product_id, 'product_cat' );
		$category_id 	= isset( $categories[0] ) ? $categories[0]->term_id : '';
		$term_location 	= $category_id ? get_term_meta( $category_id, 'ovabrw_show_loc_booking_form', true ) : [];

		if ( 'pickup' == $type ) {
			$product_show_location = get_post_meta( $product_id, 'ovabrw_show_pickup_location_product', true );
			
			if ( ovabrw_array_exists( $term_location ) && in_array( 'pickup_loc', $term_location ) ) {
				$show_location = 'yes';
			} elseif ( ovabrw_array_exists( $term_location ) && !in_array( 'pickup_loc', $term_location ) ) {
				$show_location = 'no';
			} else {
				$show_location = get_option( 'ova_brw_booking_form_show_pickup_location', 'no' );
			}
		} else {
			$product_show_location = get_post_meta( $product_id, 'ovabrw_show_pickoff_location_product', true );
			
			if ( ovabrw_array_exists( $term_location ) && in_array( 'dropoff_loc', $term_location ) ) {
				$show_location = 'yes';
			} elseif ( ovabrw_array_exists( $term_location ) && !in_array( 'dropoff_loc', $term_location ) ) {
				$show_location = 'no';
			} else {
				$show_location = get_option( 'ova_brw_booking_form_show_pickoff_location', 'no' );
			}
		}

		switch ( $product_show_location ) {
			case 'in_setting':
				if ( 'no' == $show_location ) {
					return false;
				} else {
					return true;
				}
				break;
			case 'yes':
				return true;
				break;
			case 'no':
				return false;
				break;
			default:
				if ( 'no' == $show_location ) {
					return false;
				} else {
					return true;
				}
				break;
		}

		return apply_filters( 'ovabrw_show_location', false, $product_id, $type );
	}
}

/**
 * Request booking form - Show location
 */
if ( !function_exists( 'ovabrw_rqb_show_location' ) ) {
	function ovabrw_rqb_show_location( $product_id = false, $type = 'pickup' ) {
		if ( !$product_id ) return false;

		// Get rental type
		$rental_type = get_post_meta( $product_id, 'ovabrw_price_type', true );
		if ( 'taxi' == $rental_type || 'transportation' == $rental_type ) return true;
		if ( 'hotel' == $rental_type ) return false;

		// Get custom checkout field by Category
		$categories 	= wp_get_post_terms( $product_id, 'product_cat' );
		$category_id 	= isset( $categories[0] ) ? $categories[0]->term_id : '';
		$term_location 	= $category_id ? get_term_meta( $category_id, 'ovabrw_show_loc_booking_form', true ) : [];

		if ( $type == 'pickup' ) {
			$product_show_location = get_post_meta( $product_id, 'ovabrw_show_pickup_location_product', true );

			if ( ovabrw_array_exists( $term_location ) && in_array( 'pickup_loc', $term_location ) ) {
				$rqb_show_location = 'yes';
			} elseif ( ovabrw_array_exists( $term_location ) && !in_array( 'pickup_loc', $term_location ) ) {
				$rqb_show_location = 'no';
			}else {
				$rqb_show_location = get_option( 'ova_brw_request_booking_form_show_pickup_location', 'no' );
			}
		} else {
			$product_show_location = get_post_meta( $product_id, 'ovabrw_show_pickoff_location_product', true );

			if ( ovabrw_array_exists( $term_location ) && in_array( 'dropoff_loc', $term_location ) ) {
				$rqb_show_location = 'yes';
			} elseif ( ovabrw_array_exists( $term_location ) && !in_array( 'dropoff_loc', $term_location ) ) {
				$rqb_show_location = 'no';
			} else {
				$rqb_show_location = get_option( 'ova_brw_request_booking_form_show_pickoff_location', 'no' );
			}
		}

		switch( $product_show_location ) {
			case 'in_setting':
				if ( 'no' == $rqb_show_location ) {
					return false;
				} else {
					return true;
				}
				break;
			case 'yes':
				return true;
				break;
			case 'no':
				return false;
				break;
			default:
				if ( 'no' == $rqb_show_location ) {
					return false;
				} else {
					return true;
				}
				break;
		}

		return apply_filters( 'ovabrw_rqb_show_location', false, $product_id, $type );
	}
}

/**
 * Get drop-off time by locations
 */
if ( !function_exists( 'ovabrw_get_dropoff_time_by_locations' ) ) {
	function ovabrw_get_dropoff_time_by_locations( $product_id, $pickup_location, $dropoff_location ) {
		if ( !$product_id ) return 0;

		// init
		$dropoff_time = 0;
		
		// Get locations
		$locations = ovabrw_get_locations_for_transportation( $product_id );

		if ( ovabrw_array_exists( $locations ) ) {
			foreach ( $locations as $items ) {
				if ( $pickup_location == $items['pickup_location'] && $dropoff_location == $items['dropoff_location'] ) {
					$dropoff_time = (float)$items['location_time'];
					break;
				}
			}
		}

		return apply_filters( 'ovabrw_get_dropoff_time_by_locations', $dropoff_time, $product_id, $pickup_location, $dropoff_location );
	}
}

/**
 * Get locations for transportation
 */
if ( !function_exists( 'ovabrw_get_locations_for_transportation' ) ) {
	function ovabrw_get_locations_for_transportation( $product_id ) {
		if ( !$product_id ) return [];

		// init
		$locations = [];

		// Get data from product
		$pickup_locations 	= get_post_meta( $product_id, 'ovabrw_pickup_location', true );
	    $dropoff_locations 	= get_post_meta( $product_id, 'ovabrw_dropoff_location', true );
	    $location_times 	= get_post_meta( $product_id, 'ovabrw_location_time', true );

	    if ( ovabrw_array_exists( $pickup_locations ) ) {
	        foreach ( $pickup_locations as $k => $pickup_location ) {
	        	$dropoff_location 	= ovabrw_get_meta_data( $k, $dropoff_locations );
	        	$location_time 		= (float)ovabrw_get_meta_data( $k, $location_times );

	        	if ( $pickup_location && $dropoff_location && $location_time ) {
	        		$locations[] = [
	        			'pickup_location' 	=> $pickup_location,
	        			'dropoff_location' 	=> $dropoff_location,
	        			'location_time' 	=> $location_time
	        		];
	        	}
	        }
	    }

	    return apply_filters( 'ovabrw_get_locations_for_transportation', $locations, $product_id );
	}
}

/**
 * Show pick-up date
 */
if ( !function_exists( 'ovabrw_show_date' ) ) {
	function ovabrw_show_date( $product_id = false, $type = 'pickup' ) {
		if ( !$product_id ) return false;

		if ( 'pickup' == $type ) {
			$product_show_date = get_post_meta( $product_id, 'ovabrw_show_pickup_date_product', true );
			$show_date = 'yes';
		} else {
			$rental_type = get_post_meta( $product_id, 'ovabrw_price_type', true ); 

			if ( 'transportation' == $rental_type ) {
				$product_show_date = 'no';

				$show_dropoff_date = get_post_meta( $product_id, 'ovabrw_dropoff_date_by_setting', true );
				if ( 'yes' == $show_dropoff_date ) {
					$product_show_date 	= get_post_meta( $product_id, 'ovabrw_show_pickoff_date_product', true );
					$show_date 			= get_option( 'ova_brw_booking_form_show_dropoff_date', 'yes' );
				}
			} else {
				$product_show_date 	= get_post_meta( $product_id, 'ovabrw_show_pickoff_date_product', true );
				$show_date 			= get_option( 'ova_brw_booking_form_show_dropoff_date', 'yes' );
			}
		}
		
		switch ( $product_show_date ) {
			case 'in_setting':
				if ( 'yes' == $show_date ) {
					return true;
				} else {
					return false;
				}
				break;
			case 'yes':
				return true;
				break;
			case 'no':
				return false;
				break;
			default:
				return true;
				break;
		}

		return apply_filters( 'ovabrw_show_date', false, $product_id, $type );
	}
}

/**
 * Request booking form - show date
 */
if ( !function_exists( 'ovabrw_rqb_show_date' ) ) {
	function ovabrw_rqb_show_date( $product_id = false, $type = 'pickup' ) {
		if ( !$product_id ) return false;

		if ( $type == 'pickup' ) {
			$product_show_date 	= get_post_meta( $product_id, 'ovabrw_show_pickup_date_product', true );
			$show_date 			= 'yes';
		} else {
			$product_show_date 	= get_post_meta( $product_id, 'ovabrw_show_pickoff_date_product', true );
			$show_date 			= get_option( 'ova_brw_request_booking_form_show_pickoff_date', 'yes' );
		}
		
		switch ( $product_show_date ) {
			case 'in_setting':
				if ( 'yes' == $show_date ) {
					return true;
				} else {
					return false;
				}
				break;
			case 'yes':
				return true;
				break;
			case 'no':
				return false;
				break;
			default:
				return true;
		}

		return apply_filters( 'ovabrw_rqb_show_date', $show_date, $product_id, $type );
	}
}

/**
 * Get group time
 */
if ( ! function_exists( 'ovabrw_get_group_time' ) ) {
	function ovabrw_get_group_time( $product_id = false, $type = 'start' ) {
		if ( !$product_id ) return '';

		if ( 'start' == $type ) {
			// Get pick-up time
			$pickup_time = get_post_meta( $product_id, 'ovabrw_manage_time_book_start', true );

			switch( $pickup_time ) {
				case 'in_setting':
					$group_time = ovabrw_get_pickup_group_time();
					break;
				case 'new_time':
					$group_time = get_post_meta( $product_id, 'ovabrw_product_time_to_book_start', true );

					// String to array
					if ( $group_time ) {
						$group_time = array_map( 'trim', explode( ',', $group_time ) );
					} else {
						$group_time = [];
					}
					break;
				case 'no':
					$group_time = '';
					break;
				default:
					$group_time = ovabrw_get_pickup_group_time();
			}
		} else {
			// Get drop-off time
			$dropoff_time = get_post_meta( $product_id, 'ovabrw_manage_time_book_end', true );

			switch( $dropoff_time ) {
				case 'in_setting':
					$group_time = ovabrw_get_dropoff_group_time();
					break;
				case 'new_time':
					$group_time = get_post_meta( $product_id, 'ovabrw_product_time_to_book_end', true );

					// String to array
					if ( $group_time ) {
						$group_time = array_map( 'trim', explode( ',', $group_time ) );
					} else {
						$group_time = [];
					}
					break;
				case 'no':
					$group_time = '';
					break;
				default:
					$group_time = ovabrw_get_dropoff_group_time();
			}
		}

		// Convert by time format
		if ( ovabrw_array_exists( $group_time ) ) {
			$group_time = array_map( function( $time ) {
				return date( ovabrw_get_time_format(), strtotime( $time ) );
			}, array_filter( $group_time, function( $time ) {
				return strtotime( $time ) !== false;
			}));
		}

		return apply_filters( 'ovabrw_get_group_time', $group_time, $product_id, $type );
	}
}

/**
 * Get charged by
 */
if ( ! function_exists( 'ovabrw_get_charged_by' ) ) {
	function ovabrw_get_charged_by( $product_id ) {
		if ( !$product_id ) return false;

		// init
		$charged_by = false;

		// Rental type
		$rental_type = get_post_meta( $product_id, 'ovabrw_price_type', true );

		if ( 'day' == $rental_type ) {
			$charged_by = get_post_meta( $product_id, 'ovabrw_define_1_day', true );
		}

		return apply_filters( 'ovabrw_get_charged_by', $charged_by, $product_id );
	}
}

/**
 * Get custom checkout fields
 */
if ( !function_exists( 'ovabrw_get_cckf' ) ) {
	function ovabrw_get_cckf( $product_id ) {
		if ( !$product_id ) return [];

		// init
		$cckf = [];

		// Product custom checkout field type
		$product_cckf_type = get_post_meta( $product_id, 'ovabrw_manage_custom_checkout_field', true );

		// Custom checkout fields option
		$cckf_option = get_option( 'ovabrw_booking_form', array() );

		// Product category
		$categories 	= wp_get_post_terms( $product_id, 'product_cat' );
		$category_id 	= isset( $categories[0] ) ? $categories[0]->term_id : '';
		$cckf_term_type = $category_id ? get_term_meta( $category_id, 'ovabrw_choose_custom_checkout_field', true ) : '';
		$cckf_term 		= $category_id ? get_term_meta( $category_id, 'ovabrw_custom_checkout_field', true ) : '';
		
		if ( 'new' == $product_cckf_type ) {
			$cckf_product = get_post_meta( $product_id, 'ovabrw_product_custom_checkout_field', true );
			$cckf_product = explode( ',', $cckf_product );
			$cckf_product = array_map( 'trim', $cckf_product );

			if ( ovabrw_array_exists( $cckf_product ) ) {
				foreach ( $cckf_product as $field_name ) {
					if ( array_key_exists( $field_name, $cckf_option ) ) {
						$cckf[$field_name] = $cckf_option[$field_name];
					}
				}
			} 
		} elseif ( 'all' == $cckf_term_type ) {
			$cckf = $cckf_option;
		} elseif ( 'special' == $cckf_term_type ) {
			if ( $cckf_term ) {
				foreach ( $cckf_term as $field_name ) {
					if ( array_key_exists( $field_name, $cckf_option ) ) {
						$cckf[$field_name] = $cckf_option[$field_name];
					}
				}
			}
		} else {
			$cckf = $cckf_option;
		}

		return apply_filters( 'ovabrw_get_cckf', $cckf, $product_id );
	}
}

/**
 * Get calendar prices
 */
if ( !function_exists( 'ovabw_get_calendar_prices' ) ) {
	function ovabw_get_calendar_prices( $product_id ) {
		if ( !$product_id || !apply_filters( 'ovabrw_show_price_calendar', true ) ) return [];

		// init
		$calendar_prices = [];

		// Get rental type
		$rental_type = get_post_meta( $product_id, 'ovabrw_price_type', true );

		if ( 'day' == $rental_type ) {
			$regular_price 	= get_post_meta( $product_id, '_regular_price', true );
		    $daily_monday 	= !empty( get_post_meta( $product_id, 'ovabrw_daily_monday', true ) ) ? (float)get_post_meta( $product_id, 'ovabrw_daily_monday', true ) : (float)$regular_price;
		    $daily_tuesday 	= !empty( get_post_meta( $product_id, 'ovabrw_daily_tuesday', true ) ) ? (float)get_post_meta( $product_id, 'ovabrw_daily_tuesday', true ) : (float)$regular_price;
		    $daily_wednesday = !empty( get_post_meta( $product_id, 'ovabrw_daily_wednesday', true ) ) ? (float)get_post_meta( $product_id, 'ovabrw_daily_wednesday', true ) : (float)$regular_price;
		    $daily_thursday 	= !empty( get_post_meta( $product_id, 'ovabrw_daily_thursday', true ) ) ? (float)get_post_meta( $product_id, 'ovabrw_daily_thursday', true ) : (float)$regular_price;
		    $daily_friday 	= !empty( get_post_meta( $product_id, 'ovabrw_daily_friday', true ) ) ?  (float)get_post_meta( $product_id, 'ovabrw_daily_friday', true ) : (float)$regular_price;
		    $daily_saturday 	= !empty( get_post_meta( $product_id, 'ovabrw_daily_saturday', true ) ) ? (float)get_post_meta( $product_id, 'ovabrw_daily_saturday', true ) : (float)$regular_price;
		    $daily_sunday 	= !empty( get_post_meta( $product_id, 'ovabrw_daily_sunday', true ) ) ? (float)get_post_meta( $product_id, 'ovabrw_daily_sunday', true ) : (float)$regular_price;

		    $calendar_prices = [
		    	[
		    		'type_price' => 'day',
		    	],
		    	[
		    		'ovabrw_daily_monday' 		=> ovabrw_wc_price( $daily_monday ),
		    		'ovabrw_daily_tuesday' 		=> ovabrw_wc_price( $daily_tuesday ),
		    		'ovabrw_daily_wednesday' 	=> ovabrw_wc_price( $daily_wednesday ),
		    		'ovabrw_daily_thursday' 	=> ovabrw_wc_price( $daily_thursday ),
		    		'ovabrw_daily_friday' 		=> ovabrw_wc_price( $daily_friday ),
		    		'ovabrw_daily_saturday' 	=> ovabrw_wc_price( $daily_saturday ),
		    		'ovabrw_daily_sunday' 		=> ovabrw_wc_price( $daily_sunday )
		    	],
		    ];
		} elseif ( 'hour' == $rental_type ) {
			$regular_price_hour = get_post_meta( $product_id, 'ovabrw_regul_price_hour', true );

			$calendar_prices = [
		    	[
		    		'type_price' => 'hour',
		    	],
		    	[
		    		'ovabrw_price_hour' => ovabrw_wc_price( $regular_price_hour )
		    	],
		    ];
		} elseif ( 'mixed' == $rental_type ) {
			$regular_price_day  	= get_post_meta( $product_id, '_regular_price', true );
			$regular_price_hour 	= get_post_meta( $product_id, 'ovabrw_regul_price_hour', true );
			$daily_monday 	= !empty( get_post_meta( $product_id, 'ovabrw_daily_monday', true ) ) ? (float)get_post_meta( $product_id, 'ovabrw_daily_monday', true ) : (float)$regular_price_day;
		    $daily_tuesday 	= !empty( get_post_meta( $product_id, 'ovabrw_daily_tuesday', true ) ) ? (float)get_post_meta( $product_id, 'ovabrw_daily_tuesday', true ) : (float)$regular_price_day;
		    $daily_wednesday = !empty( get_post_meta( $product_id, 'ovabrw_daily_wednesday', true ) ) ? (float)get_post_meta( $product_id, 'ovabrw_daily_wednesday', true ) : (float)$regular_price_day;
		    $daily_thursday 	= !empty( get_post_meta( $product_id, 'ovabrw_daily_thursday', true ) ) ? (float)get_post_meta( $product_id, 'ovabrw_daily_thursday', true ) : (float)$regular_price_day;
		    $daily_friday 	= !empty( get_post_meta( $product_id, 'ovabrw_daily_friday', true ) ) ?  (float)get_post_meta( $product_id, 'ovabrw_daily_friday', true ) : (float)$regular_price_day;
		    $daily_saturday 	= !empty( get_post_meta( $product_id, 'ovabrw_daily_saturday', true ) ) ? (float)get_post_meta( $product_id, 'ovabrw_daily_saturday', true ) : (float)$regular_price_day;
		    $daily_sunday 	= !empty( get_post_meta( $product_id, 'ovabrw_daily_sunday', true ) ) ? (float)get_post_meta( $product_id, 'ovabrw_daily_sunday', true ) : (float)$regular_price_day;

			$calendar_prices = [
		    	[
		    		'type_price' => 'mixed',
		    	],
		    	[
		    		'ovabrw_daily_monday' 		=> ovabrw_wc_price( $regular_price_hour ) . '<br>' . ovabrw_wc_price( $daily_monday ),
		    		'ovabrw_daily_tuesday' 		=> ovabrw_wc_price( $regular_price_hour )  . '<br>' . ovabrw_wc_price( $daily_tuesday ),
		    		'ovabrw_daily_wednesday' 	=> ovabrw_wc_price( $regular_price_hour ) . '<br>' . ovabrw_wc_price( $daily_wednesday ),
		    		'ovabrw_daily_thursday' 	=> ovabrw_wc_price( $regular_price_hour ) . '<br>' . ovabrw_wc_price( $daily_thursday ),
		    		'ovabrw_daily_friday' 		=> ovabrw_wc_price( $regular_price_hour ) . '<br>' . ovabrw_wc_price( $daily_friday ),
		    		'ovabrw_daily_saturday' 	=> ovabrw_wc_price( $regular_price_hour ) . '<br>' . ovabrw_wc_price( $daily_saturday ),
		    		'ovabrw_daily_sunday' 		=> ovabrw_wc_price( $regular_price_hour ) . '<br>' . ovabrw_wc_price( $daily_sunday )
		    	],
		    ];
		} elseif ( 'taxi' == $rental_type ) {
			$regular_price_taxi = get_post_meta( $product_id, 'ovabrw_regul_price_taxi', true );

			$calendar_prices = [
		    	[
		    		'type_price' => 'taxi',
		    	],
		    	[
		    		'ovabrw_price_taxi' => ovabrw_wc_price( $regular_price_taxi ),
		    	],
		    ];
		} elseif ( 'hotel' == $rental_type ) {
			$regular_price 			= get_post_meta( $product_id, 'ovabrw_regular_price_hotel', true );
		    $daily_monday 	= !empty( get_post_meta( $product_id, 'ovabrw_daily_monday', true ) ) ? (float)get_post_meta( $product_id, 'ovabrw_daily_monday', true ) : (float)$regular_price;
		    $daily_tuesday 	= !empty( get_post_meta( $product_id, 'ovabrw_daily_tuesday', true ) ) ? (float)get_post_meta( $product_id, 'ovabrw_daily_tuesday', true ) : (float)$regular_price;
		    $daily_wednesday = !empty( get_post_meta( $product_id, 'ovabrw_daily_wednesday', true ) ) ? (float)get_post_meta( $product_id, 'ovabrw_daily_wednesday', true ) : (float)$regular_price;
		    $daily_thursday 	= !empty( get_post_meta( $product_id, 'ovabrw_daily_thursday', true ) ) ? (float)get_post_meta( $product_id, 'ovabrw_daily_thursday', true ) : (float)$regular_price;
		    $daily_friday 	= !empty( get_post_meta( $product_id, 'ovabrw_daily_friday', true ) ) ?  (float)get_post_meta( $product_id, 'ovabrw_daily_friday', true ) : (float)$regular_price;
		    $daily_saturday 	= !empty( get_post_meta( $product_id, 'ovabrw_daily_saturday', true ) ) ? (float)get_post_meta( $product_id, 'ovabrw_daily_saturday', true ) : (float)$regular_price;
		    $daily_sunday 	= !empty( get_post_meta( $product_id, 'ovabrw_daily_sunday', true ) ) ? (float)get_post_meta( $product_id, 'ovabrw_daily_sunday', true ) : (float)$regular_price;

		    $calendar_prices = [
		    	[
		    		'type_price' => 'hotel',
		    	],
		    	[
		    		'ovabrw_daily_monday' 		=> ovabrw_wc_price( $daily_monday ),
		    		'ovabrw_daily_tuesday' 		=> ovabrw_wc_price( $daily_tuesday ),
		    		'ovabrw_daily_wednesday' 	=> ovabrw_wc_price( $daily_wednesday ),
		    		'ovabrw_daily_thursday' 	=> ovabrw_wc_price( $daily_thursday ),
		    		'ovabrw_daily_friday' 		=> ovabrw_wc_price( $daily_friday ),
		    		'ovabrw_daily_saturday' 	=> ovabrw_wc_price( $daily_saturday ),
		    		'ovabrw_daily_sunday' 		=> ovabrw_wc_price( $daily_sunday )
		    	],
		    ];
		}

		return apply_filters( 'ovabw_get_calendar_prices', json_encode( $calendar_prices ), $product_id );
	}
}

/**
 * Get depost type html
 */
if ( !function_exists( 'ovabrw_get_deposit_type_html' ) ) {
	function ovabrw_get_deposit_type_html( $product_id ) {
		if ( !$product_id ) return '';

		$deposit_html 	= '';
		$deposit_type 	= get_post_meta ( $product_id, 'ovabrw_type_deposit', true );
		$deposit_value 	= get_post_meta ( $product_id, 'ovabrw_amount_deposit', true );

		if ( $deposit_type === 'percent' ) {
			$deposit_html = '<span>'.esc_html( $deposit_value ).'%</span>';
		} elseif ($deposit_type === 'value') {
			$deposit_html = '<span>'.ovabrw_wc_price( $deposit_value ).'</span>';
		}

		return apply_filters( 'ovabrw_get_deposit_type_html', $deposit_html, $product_id );
	}
}

/**
 * Get daily prices
 */
if ( !function_exists( 'ovabrw_get_daily_prices' ) ) {
	function ovabrw_get_daily_prices( $product_id ) {
		if ( !$product_id ) return false;

		$rental_type 	= get_post_meta( $product_id, 'ovabrw_price_type', true );
		$monday     	= get_post_meta( $product_id, 'ovabrw_daily_monday', true );
        $tuesday    	= get_post_meta( $product_id, 'ovabrw_daily_tuesday', true );
        $wednesday  	= get_post_meta( $product_id, 'ovabrw_daily_wednesday', true );
        $thursday   	= get_post_meta( $product_id, 'ovabrw_daily_thursday', true );
        $friday     	= get_post_meta( $product_id, 'ovabrw_daily_friday', true );
        $saturday   	= get_post_meta( $product_id, 'ovabrw_daily_saturday', true );
        $sunday     	= get_post_meta( $product_id, 'ovabrw_daily_sunday', true );

        if ( in_array( $rental_type, [ 'day', 'mixed', 'hotel' ] ) && $monday && $tuesday && $wednesday && $thursday && $friday && $saturday && $sunday ) { 

			$daily = array(
				'monday' 	=> $monday, 
				'tuesday' 	=> $tuesday, 
				'wednesday' => $wednesday, 
				'thursday' 	=> $thursday, 
				'friday' 	=> $friday, 
				'saturday' 	=> $saturday, 
				'sunday' 	=> $sunday
			);
		} else {
			return false;
		}

		return apply_filters( 'ovabrw_get_daily_prices', $daily, $product_id );
	}
}

/**
 * Get order status for booking
 */
if ( !function_exists( 'ovabrw_get_order_status' ) ) {
	function ovabrw_get_order_status() {
		$order_status = get_option( OVABRW_PREFIX.'order_status', [
			'wc-completed',
			'wc-processing'
		]);

		return apply_filters( 'brw_list_order_status', $order_status );
	}
}

/**
 * Get range dates
 */
if ( !function_exists( 'ovabrw_get_range_dates' ) ) {
	function ovabrw_get_range_dates( $start = '', $end = '', $format = "Y-m-d H:i" ) {
	    $dates = array();

	    while ( $start <= $end ) {
	        array_push( $dates, date( $format, $start) );
	        $start += 86400;
	    }

	    return apply_filters( 'ovabrw_get_range_dates', $dates, $start, $end, $format );
	} 
}

/**
 * Get number of between days
 */
if ( !function_exists( 'ovabrw_get_numberof_between_days' ) ) {
	function ovabrw_get_numberof_between_days( $start, $end ) {
		if ( !strtotime( $start ) || !strtotime( $end ) ) return 0;

	    return apply_filters( 'ovabrw_get_numberof_between_days', floor( abs( strtotime( $end ) - strtotime( $start ) ) / ( 60*60*24 ) ), $start, $end );
	}
}

/**
 * Get rental times
 */
if ( !function_exists( 'ovabrw_get_rental_times' ) ) {
	function ovabrw_get_rental_times( $start = '', $end = '', $product_id = '' ) {
		// init
		$rental_times = [
			'rent_time_day_raw' 	=> 0,
			'rent_time_hour_raw' 	=> 0,
			'rent_time_day' 		=> 0,
			'rent_time_hour' 		=> 0
		];

		if ( $start && $end ) {
			// Get charged by
		    $charged_by = $product_id != '' ? ovabrw_get_charged_by( $product_id ) : '';    

		    if ( 'day' == $charged_by ) {
		        $start 	= strtotime( date( 'Y-m-d', $start ) );
		        $end 	= strtotime( date( 'Y-m-d', $end ) ) + 24*60*60 - 1  ;
		    } elseif ( 'hotel' == $charged_by ) {
		    	$start 	= strtotime( date( 'Y-m-d', $start ) );
		        $end 	= strtotime( date( 'Y-m-d', $end ) ) ;
		    }

		    $rental_times['rent_time_day_raw'] 	= ( $end - $start ) / 86400;
		    $rental_times['rent_time_hour_raw'] = ( $end - $start ) / 3600;
		    $rental_times['rent_time_day'] 		= ceil( $rental_times['rent_time_day_raw'] );
		    $rental_times['rent_time_hour'] 	= ceil( $rental_times['rent_time_hour_raw'] );
		}

		return apply_filters( 'ovabrw_get_rental_times', $rental_times, $start, $end, $product_id );
	}
}

/**
 * Get Pick up date from URL in Product detail
 */
if ( !function_exists( 'ovabrw_get_current_date_from_search' ) ) {
	function ovabrw_get_current_date_from_search( $choose_hour = 'yes', $type = 'pickup_date', $product_id = false ) {
		// Get date from URL
		if ( 'pickup_date' == $type ) {
			$time = isset( $_GET['pickup_date'] ) ? strtotime( $_GET['pickup_date'] ) : '';
		} elseif ( 'dropoff_date' == $type ) {
			$time = isset( $_GET['dropoff_date'] ) ? strtotime( $_GET['dropoff_date'] ) : '';
		}

		$dateformat 	= ovabrw_get_date_format();
		$time_format 	= ovabrw_get_time_format();

		if ( $time && $choose_hour ) {
			return date( $dateformat.' '.$time_format, $time );
		} elseif ( $time && ! $choose_hour ) {
			return date( $dateformat, $time );		
		}

		return '';
	}
}

/**
 * Get custom taxonomy display in listing of product
 */
if ( !function_exists( 'ovabrw_get_custom_taxonomies' ) ) {
	function ovabrw_get_custom_taxonomies( $product_id ) {
		$taxonomies = $taxonomies_exist = [];

		// Get custom taxonomies options
		$taxonomies_option = get_option( 'ovabrw_custom_taxonomy', [] );

		// Get categories
		$categories = get_the_terms( $product_id, 'product_cat' );

		if ( ovabrw_array_exists( $categories ) ) {
			foreach ( $categories as $key => $value ) {
				$term_id = $value->term_id;

				// Get custom taxonomies from category
				$custom_taxonomies = get_term_meta( $term_id, 'ovabrw_custom_tax', true);

				if ( ovabrw_array_exists( $custom_taxonomies ) ) {
					foreach ( $custom_taxonomies as $slug ) {
					
						// Get value of terms in product
						$terms = get_the_terms( $product_id, $slug );

						// Get show listing
						$show_listing = isset( $taxonomies_option[$slug]['show_listing'] ) ? $taxonomies_option[$slug]['show_listing'] : '';

						if ( ovabrw_array_exists( $terms ) && $show_listing ) {
							foreach ( $terms as $term ) {
								if ( !in_array( $slug, $taxonomies_exist ) ) {
									array_push( $taxonomies_exist, $slug );
									array_push( $taxonomies, array(
										'slug' => $slug,
										'name' => $term->name
									));
								}
							}
						}
					}
				}
			}
		}

		return apply_filters( 'ovabrw_get_custom_taxonomies', $taxonomies, $product_id );
	}
}

/**
 * Get custom taxonomy of an product
 */
if ( !function_exists( 'ovabrw_get_taxonomy_choosed_product' ) ) {
	function ovabrw_get_taxonomy_choosed_product( $pid, $show_archive = '' ) {
		// Custom taxonomies choosed in post
		$all_cus_tax 	= array();
		$exist_cus_tax 	= array();
		
		// Get Category of product
		$cats = get_the_terms( $pid, 'product_cat' );
		$show_taxonomy_depend_category = get_option( 'ova_brw_search_show_tax_depend_cat', 'yes' );

		if ( 'yes' == $show_taxonomy_depend_category ) {
			if ( $cats ) {
				foreach ( $cats as $key => $cat ) {
					// Get custom taxonomy display in category
					$ovabrw_custom_tax = get_term_meta( $cat->term_id, 'ovabrw_custom_tax', true );
					
					if ( $ovabrw_custom_tax ) {
						foreach( $ovabrw_custom_tax as $key => $value ) {
							array_push( $exist_cus_tax, $value );
						}	
					}
				}
			}

			if ( $exist_cus_tax ) {
				foreach( $exist_cus_tax as $key => $value ) {
					$cus_tax_terms = get_the_terms( $pid, $value );

					if ( $cus_tax_terms ) {
						foreach( $cus_tax_terms as $key => $value ) {
							$list_fields = get_option( 'ovabrw_custom_taxonomy', array() );

							if ( ! empty( $list_fields ) ):
			                    foreach( $list_fields as $key => $field ):
			                    	$enabled 		= isset( $field['enabled'] ) ? $field['enabled'] : '';
			                    	$show_listing 	= isset( $field['show_listing'] ) ? $field['show_listing'] : '';

			                    	if ( $enabled != 'on' ) continue;
			                    	if ( $show_archive && $show_archive != $show_listing ) continue;

			                    	if ( is_object( $value ) && $value->taxonomy == $key ) {
			                    		if ( array_key_exists($key, $all_cus_tax) ) {
			                    			if ( ! in_array( $value->name, $all_cus_tax[$key]['value'] ) ) {
			                    				array_push( $all_cus_tax[$key]['value'], $value->name );
			                    				array_push( $all_cus_tax[$key]['link'], get_term_link( $value->term_id ) );
			                    			}
			                    		} else {
		                    				if ( isset( $field['label_frontend'] ) && $field['label_frontend'] ) {
		                    					$all_cus_tax[$key]['name'] = $field['label_frontend'];	
		                    				} else {
		                    					$all_cus_tax[$key]['name'] = $field['name'];	
		                    				}

		                    				$all_cus_tax[$key]['value'] = array( $value->name );
		                    				$all_cus_tax[$key]['link'] 	= array( get_term_link( $value->term_id ) );
			                    		}

			                    		break;
			                    	}
			                    endforeach;
			                endif;
						}
					}
				}
			}
		} else {
			$list_fields = get_option( 'ovabrw_custom_taxonomy', array() );

			if ( ! empty( $list_fields ) ) {
				foreach( $list_fields as $key => $field ) {
					$enabled 		= isset( $field['enabled'] ) ? $field['enabled'] : '';
					$show_listing 	= isset( $field['show_listing'] ) ? $field['show_listing'] : '';

			        if ( $enabled != 'on' ) continue;
			        if ( $show_archive && $show_archive != $show_listing ) continue;

					$terms = get_the_terms( $pid, $key );

					if ( $terms && !isset( $terms->errors ) ) {
						foreach( $terms as $value ) {
							if ( is_object( $value ) ) {
								if ( array_key_exists( $key, $all_cus_tax ) ) {
									if ( ! in_array( $value->name, $all_cus_tax[$key]['value'] ) ) {
			            				array_push( $all_cus_tax[$key]['value'], $value->name );
			            				array_push( $all_cus_tax[$key]['link'], get_term_link( $value->term_id ) );
			            			}
								} else {
									if ( isset( $field['label_frontend'] ) && $field['label_frontend'] ) {
			        					$all_cus_tax[$key]['name'] = $field['label_frontend'];	
			        				} else {
			        					$all_cus_tax[$key]['name'] = $field['name'];
			        				}

									$all_cus_tax[$key]['value'] = array( $value->name );
									$all_cus_tax[$key]['link'] 	= array( get_term_link( $value->term_id ) );
								}
							}
						}
					}
				}
			}
		}

		return apply_filters( 'ovabrw_get_taxonomy_choosed_product', $all_cus_tax, $pid, $show_archive );
	}
}

/**
 * Get Special Time Product
 */
if ( !function_exists( 'ovabrw_get_special_time' ) ) {
	function ovabrw_get_special_time( $product_id, $rental_type ) {
		// init array special time
		$special_time 	= [];
		$prices 		= [];

		// get special price
		if ( in_array( $rental_type, [ 'day', 'hotel' ] ) ) {
			$ovabrw_rt_price = get_post_meta( $product_id, 'ovabrw_rt_price', true );
		} elseif ( 'hour' == $rental_type ) {
			$ovabrw_rt_price = get_post_meta( $product_id, 'ovabrw_rt_price_hour', true );
		} elseif ( 'mixed' == $rental_type ) {
			$ovabrw_rt_price  		= get_post_meta( $product_id, 'ovabrw_rt_price', true );
			$ovabrw_rt_price_hour 	= get_post_meta( $product_id, 'ovabrw_rt_price_hour', true );
		}

		// get timestamp
		$ovabrw_rt_startdate 	= get_post_meta( $product_id, 'ovabrw_rt_startdate', true );
		$ovabrw_rt_starttime 	= get_post_meta( $product_id, 'ovabrw_rt_starttime', true );
		$ovabrw_rt_enddate 		= get_post_meta( $product_id, 'ovabrw_rt_enddate', true );
		$ovabrw_rt_endtime 		= get_post_meta( $product_id, 'ovabrw_rt_endtime', true );

		if ( ! empty( $ovabrw_rt_price ) ) {
			foreach ( $ovabrw_rt_price as $key => $value ) {
				$start_date = isset( $ovabrw_rt_startdate[$key] ) ? $ovabrw_rt_startdate[$key] : '';
				$start_time = isset( $ovabrw_rt_starttime[$key] ) ? $ovabrw_rt_starttime[$key] : '';
				$end_date 	= isset( $ovabrw_rt_enddate[$key] ) ? $ovabrw_rt_enddate[$key] : '';
				$end_time 	= isset( $ovabrw_rt_endtime[$key] ) ? $ovabrw_rt_endtime[$key] : '';

				if ( ! strtotime( $start_date ) || ! strtotime( $end_date ) ) continue;

				if ( 'hotel' == $rental_type ) {
					$start_time = '00:00';
				}

				if ( $start_time ) $start_date .= ' '.$start_time;
				if ( $end_time ) $end_date .= ' '.$end_time;

				// Start timestamp
				$start_timestamp = strtotime( $start_date );

				// End timestamp
				$end_timestamp 	= strtotime( $end_date );

				// Check price type
				if ( 'mixed' == $rental_type ) {
					$price_mixed = array_key_exists( $key, $ovabrw_rt_price_hour ) ? ( ovabrw_wc_price( $ovabrw_rt_price_hour[$key] ) . '<br>' . ovabrw_wc_price( $value ) ) : ( ovabrw_wc_price(0) . '<br>' . ovabrw_wc_price( $value ) );

					if ( in_array( $value, $prices ) ) {
						$special_time[$price_mixed.'<span hidden>'.$key.'</span>'] = [ $start_timestamp, $end_timestamp ];
					} else {
						$special_time[$price_mixed] = [ $start_timestamp, $end_timestamp ];
						array_push($prices, $value);
					}
				} else {
					if ( in_array( $value, $prices ) ) {
						$special_time[ovabrw_wc_price( $value ).'<span hidden>'.$key.'</span>'] = [ $start_timestamp, $end_timestamp ];
					} else {
						$special_time[ovabrw_wc_price( $value )] = [ $start_timestamp, $end_timestamp ];
						array_push($prices, $value);
					}
				}
			}
		}
		
		return apply_filters( 'ovabrw_get_special_time', $special_time, $product_id, $rental_type );
	}
}

/**
 * Get product template
 */
if ( ! function_exists( 'ovabrw_get_product_template' ) ) {
	function ovabrw_get_product_template( $product_id ) {
		$template = get_option( 'ova_brw_template_elementor_template', 'default' );

		if ( !$product_id ) return $template;

		$products = wc_get_product( $product_id );

		if ( $products ) {
			$categories = $products->get_category_ids();

			if ( ! empty( $categories ) ) {
		        $term_id 	= reset( $categories );
		        $template_by_category = get_term_meta( $term_id, 'ovabrw_product_templates', true );

		        if ( $template_by_category && $template_by_category != 'global' ) {
		        	$template = $template_by_category;
		        }
		    }
		}

		// Multi language
		$object_id = '';

        if ( is_plugin_active( 'sitepress-multilingual-cms/sitepress.php' ) ) {
            $object_id = apply_filters( 'wpml_object_id', $template, 'elementor_library', TRUE  );
        } elseif ( is_plugin_active( 'polylang/polylang.php' ) || is_plugin_active( 'polylang-pro/polylang.php' ) ) {
            $object_id = pll_get_post( $template );
        }

        if ( $object_id ) {
        	$template = $object_id;
        }

		return apply_filters( 'ovabrw_get_product_template', $template, $product_id );
	}
}

/**
 * Check locations
 */
if ( !function_exists( 'ovabrw_check_location' ) ) {
	function ovabrw_check_location( $product_id = null, $pickup_loc = '', $dropoff_loc = '' ) {
		if ( ! $product_id ) return false;

		$data_pickup_loc 	= get_post_meta( $product_id, 'ovabrw_st_pickup_loc', true );
		$data_dropoff_loc 	= get_post_meta( $product_id, 'ovabrw_st_dropoff_loc', true );

		if ( ! empty( $data_pickup_loc ) && is_array( $data_pickup_loc ) ) {
			foreach ( $data_pickup_loc as $k => $p_loc ) {
				$d_loc = isset( $data_dropoff_loc[$k] ) ? $data_dropoff_loc[$k] : '';

				if ( $pickup_loc && $dropoff_loc && $p_loc === $pickup_loc && $d_loc === $dropoff_loc ) {
					return true;
				} elseif ( $pickup_loc && ! $dropoff_loc && $p_loc === $pickup_loc ) {
					return true;
				} elseif ( ! $pickup_loc && $dropoff_loc && $d_loc === $dropoff_loc ) {
					return true;
				}
			}
		} else {
			return true;
		}

		return false;
	}
}

/**
 * Check key in array
 */
if ( !function_exists( 'ovabrw_check_array' ) ) {
	function ovabrw_check_array( $args, $key ) {
		if ( !empty( $args ) && is_array( $args ) ) {
			if ( isset( $args[$key] ) && $args[$key] ) {
				return true;
			}
		}

		return false;
	}
}

/**
 * Get input date for rental by distance
 */
if ( !function_exists( 'ovabrw_taxi_input_date' ) ) {
	function ovabrw_taxi_input_date( $date = '', $duration = 0 ) {
		$result = [
			'pickup_date_new' 	=> '',
			'pickoff_date_new' 	=> '',
		];

		if ( ! $date ) return $result;
		if ( ! $duration ) $duration = 0;

		if ( strtotime( $date ) ) {
			$result['pickup_date_new'] 	= strtotime( $date );
			$result['pickoff_date_new'] = strtotime( $date ) + $duration;
		}

		return apply_filters( 'ovabrw_taxi_input_date', $result, $date, $duration );
	}
}

/**
 * Get text distance
 */
if ( !function_exists( 'ovarw_taxi_get_distance_text' ) ) {
	function ovarw_taxi_get_distance_text( $distance = 0, $product_id = false ) {
		$price_by = 'km';

		if ( $product_id ) {
			$price_by = get_post_meta( $product_id, 'ovabrw_map_price_by', true );

			if ( ! $price_by ) $price_by = 'km';
		}

        if ( $distance ) {
        	if ( $price_by === 'km' ) {
        		$distance = apply_filters( 'ovabrw_ft_distance_text', round( $distance / 1000, 2 ), $product_id );
        	} else {
        		$distance = apply_filters( 'ovabrw_ft_distance_text', round( $distance / 1609.34, 2 ), $product_id );
        	}
        } else {
            $distance = 0;
        }

        return apply_filters( 'ovarw_taxi_get_distance_text', sprintf( esc_html__( '%s %s', 'ova-brw' ), $distance, $price_by ), $distance, $product_id );
	}
}

/**
 * Get text duration
 */
if ( !function_exists( 'ovarw_taxi_get_duration_text' ) ) {
	function ovarw_taxi_get_duration_text( $duration ) {
		$hour = $minute = 0;

        if ( $duration ) {
            $hour 	= absint( $duration / 3600 );
            $minute = round( ( $duration % 3600 ) / 60 );
        }

        return apply_filters( 'ovarw_taxi_get_duration_text', sprintf( esc_html__( '%sh%sm', 'ova-brw' ), $hour, $minute ), $duration );
	}
}

/**
 * Get all font
 */
if ( !function_exists( 'ovabrw_get_all_font' ) ) {
	function ovabrw_get_all_font() {
		$font_file 	= OVABRW_PLUGIN_URI . 'assets/libs/google_font/api/google-fonts-alphabetical.json';
        $request 	= wp_remote_get( $font_file );

        if ( is_wp_error( $request ) ) {
            return "";
        }

        $body       = wp_remote_retrieve_body( $request );
        $content    = json_decode( $body );
        $all_fonts 	= $content->items;

        if ( get_option('ovabrw_glb_custom_font', '') != '' ) {

        	$glb_custom_font 	= str_replace( '\"', '"', get_option( 'ovabrw_glb_custom_font' ) );
            $list_custom_font 	= explode( '|', $glb_custom_font );

            foreach ( $list_custom_font as $key => $font ) {
                $cus_font = json_decode( $font );
                $cus_font_family = $cus_font['0'];
                $cus_font_weight = explode( ':', $cus_font['1'] );

                $all_fonts[] = json_decode(json_encode( array(
                    "kind"      => "webfonts#webfont",
                    "family"    => $cus_font_family,
                    "category"  => "sans-serif",
                    "variants"  => $cus_font_weight,
                ) ) );
            }
        }
        
        return apply_filters( 'ovabrw_get_all_font', $all_fonts );
	}
}

/**
 * Enable global typography
 */
if ( !function_exists( 'ovabrw_global_typography' ) ) {
	function ovabrw_global_typography() {
		if ( 'yes' == get_option( 'ovabrw_enable_global_typography', 'yes' ) ) return true;

		return false;
	}
}

/**
 * Is archive product
 */
if ( !function_exists( 'ovabrw_is_archive_product' ) ) {
	function ovabrw_is_archive_product() {
		if ( ovabrw_global_typography() ) {
			if ( is_product_category() ) {
				$terms = get_queried_object();

				if ( ! empty( $terms ) && is_object( $terms ) ) {
					$term_id = $terms->term_id;

					if ( $term_id ) {
						$display = get_term_meta( $term_id, 'ovabrw_cat_dis', true );

						if ( 'rental' == $display ) {
							return true;
						} else {
							return false;
						}
					}
				}
			}

			if ( is_product_taxonomy() ) {
				$display = get_option( 'ova_brw_display_product_taxonomy', 'rental' );

				if ( 'rental' == $display ) {
					return true;
				} else {
					return false;
				}
			}

			if ( is_shop() ) {
				$display = get_option( 'ova_brw_display_shop_page', 'rental' );

				if ( 'rental' == $display ) {
					return true;
				} else {
					return false;
				}
			}
		}

		return false;
	}
}

/**
 * Is rental product
 */
if ( !function_exists( 'ovabrw_is_rental_product' ) ) {
	function ovabrw_is_rental_product( $product_id = false ) {
		global $product;

		if ( $product_id ) $product = wc_get_product( $product_id );
		if ( $product && $product->is_type( 'ovabrw_car_rental' ) ) return true;

		return false;
	}
}

/**
 * Get Card Template
 */
if ( !function_exists( 'ovabrw_get_card_template' ) ) {
	function ovabrw_get_card_template() {
		if ( isset( $_GET['card'] ) && $_GET['card'] ) {
			$card_template = trim( $_GET['card'] );
		} else {
			$card_template = get_option( 'ovabrw_glb_card_template', 'card1' );

			if ( get_queried_object_id() ) {
				$term_card_template = get_term_meta( get_queried_object_id(), 'ovabrw_card_template', true );

				if ( $term_card_template ) $card_template = $term_card_template;
			}
		}

		return apply_filters( 'ovabrw_get_card_template', $card_template );
	}
}

// Get Cart Templates
if ( !function_exists( 'ovabrw_get_all_card_templates' ) ) {
	function ovabrw_get_all_card_templates() {
		$card_templates = [
			'card1' => esc_html__( 'Card 1', 'ova-brw' ),
			'card2' => esc_html__( 'Card 2', 'ova-brw' ),
			'card3' => esc_html__( 'Card 3', 'ova-brw' ),
			'card4' => esc_html__( 'Card 4', 'ova-brw' ),
			'card5' => esc_html__( 'Card 5', 'ova-brw' ),
			'card6' => esc_html__( 'Card 6', 'ova-brw' )
		];

		return apply_filters( 'ovabrw_get_all_card_templates', $card_templates );
	}
}

/**
 * Allow booking when booking time include date disable
 */
if ( !function_exists( 'ovabrw_allow_boooking_incl_disable_week_day' ) ) {
	function ovabrw_allow_boooking_incl_disable_week_day() {
		return 'yes' == get_option( 'ova_brw_booking_form_disable_week_day', 'yes' ) ? true : false;
	}
}

/**
 * Check table price
 */
if ( !function_exists( 'ovabrw_check_table_price' ) ) {
	function ovabrw_check_table_price( $product_id = null ) {
		if ( !$product_id ) return false;

		$daily = ovabrw_get_daily_prices( $product_id );
		if ( !empty( $daily ) && is_array( $daily ) ) return true;

		// Get rental type
		$rental_type = ovabrw_get_post_meta( $product_id, 'price_type' );

		// Discounts
		if ( 'day' == $rental_type || 'hour' == $rental_type || 'mixed' == $rental_type ) {
			$discount_min = ovabrw_get_post_meta( $product_id, 'global_discount_duration_val_min' );
			if ( ovabrw_array_exists( $discount_min ) ) return true;
		} elseif ( 'period_time' == $rental_type ) {
			$peoftime_discount = ovabrw_get_post_meta( $product_id, 'petime_discount' );
			if ( ovabrw_array_exists( $peoftime_discount ) ) return true;
		} elseif ( 'taxi' == $rental_type ) {
			$discount_price = ovabrw_get_post_meta( $product_id, 'discount_distance_price' );
			if ( ovabrw_array_exists( $discount_price ) ) return true;
		} elseif ( 'hotel' == $rental_type ) {
			$discount_price = ovabrw_get_post_meta( $product_id, 'global_discount_price' );
			if ( ovabrw_array_exists( $discount_price ) ) return true;
		} // End Discounts
		
		// Special Times
		if ( 'day' == $rental_type || 'mixed' == $rental_type || 'hotel' == $rental_type ) {
			$special_price = ovabrw_get_post_meta( $product_id, 'rt_price' );
			if ( ovabrw_array_exists( $special_price ) ) return true;
		} elseif ( 'hour' == $rental_type || 'mixed' == $rental_type ) {
			$special_price = ovabrw_get_post_meta( $product_id, 'rt_price_hour' );
			if ( ovabrw_array_exists( $special_price ) ) return true;
		} elseif ( 'taxi' == $rental_type ) {
			$special_price = ovabrw_get_post_meta( $product_id, 'st_price_distance' );
			if ( ovabrw_array_exists( $special_price ) ) return true;
		} elseif ( 'appointment' == $rental_type ) {
			$special_price = ovabrw_get_post_meta( $product_id, 'special_price' );
			if ( ovabrw_array_exists( $special_price ) ) return true;
		} // End Special times

		return false;
	}
}

/**
 * Get Price - Multi Currency
 */
if ( !function_exists( 'ovabrw_wc_price' ) ) {
	function ovabrw_wc_price( $price = null, $args = array(), $convert = true ) {
		$new_price = $price;

		if ( ! $price ) $new_price = 0;		

		$current_currency = isset( $args['currency'] ) && $args['currency'] ? $args['currency'] : false;

		// CURCY - Multi Currency for WooCommerce
		// WooCommerce Multilingual & Multicurrency
		if ( is_plugin_active( 'woo-multi-currency/woo-multi-currency.php' ) || is_plugin_active( 'woocommerce-multi-currency/woocommerce-multi-currency.php' ) ) {
			$new_price = wmc_get_price( $price, $current_currency );
		} elseif ( is_plugin_active( 'woocommerce-multilingual/wpml-woocommerce.php' ) ) {
			if ( $convert ) {
				// WPML multi currency
	    		global $woocommerce_wpml;

	    		if ( $woocommerce_wpml && is_object( $woocommerce_wpml ) ) {
	    			if ( wp_doing_ajax() ) add_filter( 'wcml_load_multi_currency_in_ajax', '__return_true' );

			        $multi_currency     = $woocommerce_wpml->get_multi_currency();
			        $currency_options   = $woocommerce_wpml->get_setting( 'currency_options' );
			        $WMCP   			= new WCML_Multi_Currency_Prices( $multi_currency, $currency_options );
			        $new_price  		= $WMCP->convert_price_amount( $price, $current_currency );
			    }
			}
		}
		
		return apply_filters( 'ovabrw_wc_price', wc_price( $new_price, $args ), $price, $args, $convert );
	}
}

/**
 * Convert price
 */
if ( !function_exists( 'ovabrw_convert_price' ) ) {
	function ovabrw_convert_price( $price = null, $args = array(), $convert = true ) {
		$new_price = $price;

		if ( ! $price ) $new_price = 0;

		$current_currency = isset( $args['currency'] ) && $args['currency'] ? $args['currency'] : false;

		// CURCY - Multi Currency for WooCommerce
		// WooCommerce Multilingual & Multicurrency
		if ( is_plugin_active( 'woo-multi-currency/woo-multi-currency.php' ) || is_plugin_active( 'woocommerce-multi-currency/woocommerce-multi-currency.php' ) ) {
			$new_price = wmc_get_price( $price, $current_currency );
		} elseif ( is_plugin_active( 'woocommerce-multilingual/wpml-woocommerce.php' ) ) {
			if ( $convert ) {
				// WPML multi currency
	    		global $woocommerce_wpml;

	    		if ( $woocommerce_wpml && is_object( $woocommerce_wpml ) ) {
	    			if ( wp_doing_ajax() ) add_filter( 'wcml_load_multi_currency_in_ajax', '__return_true' );

			        $multi_currency     = $woocommerce_wpml->get_multi_currency();
			        $currency_options   = $woocommerce_wpml->get_setting( 'currency_options' );
			        $WMCP   			= new WCML_Multi_Currency_Prices( $multi_currency, $currency_options );
			        $new_price  		= $WMCP->convert_price_amount( $price, $current_currency );
			    }
			}
		}
		
		return apply_filters( 'ovabrw_convert_price', $new_price, $price, $args, $convert );
	}
}

/**
 * Convert price in Admin
 */
if ( !function_exists( 'ovabrw_convert_price_in_admin' ) ) {
	function ovabrw_convert_price_in_admin( $price = null, $currency_code = '' ) {
		$new_price = $price;

		if ( ! $price ) $new_price = 0;

		if ( is_plugin_active( 'woo-multi-currency/woo-multi-currency.php' ) || is_plugin_active( 'woocommerce-multi-currency/woocommerce-multi-currency.php' ) ) {
			$setting = WOOMULTI_CURRENCY_F_Data::get_ins();

			/*Check currency*/
			$selected_currencies = $setting->get_list_currencies();
			$current_currency    = $setting->get_current_currency();

			if ( ! $currency_code || $currency_code === $current_currency ) {
				return $new_price;
			}

			if ( $new_price ) {
				if ( $currency_code && isset( $selected_currencies[ $currency_code ] ) ) {
					$new_price = $price * (float) $selected_currencies[ $currency_code ]['rate'];
				} else {
					$new_price = $price * (float) $selected_currencies[ $current_currency ]['rate'];
				}
			}
		} elseif ( is_plugin_active( 'woocommerce-multilingual/wpml-woocommerce.php' ) ) {
			// WPML multi currency
    		global $woocommerce_wpml;

    		if ( $woocommerce_wpml && is_object( $woocommerce_wpml ) ) {
    			if ( wp_doing_ajax() ) add_filter( 'wcml_load_multi_currency_in_ajax', '__return_true' );

		        $multi_currency     = $woocommerce_wpml->get_multi_currency();
		        $currency_options   = $woocommerce_wpml->get_setting( 'currency_options' );
		        $WMCP   			= new WCML_Multi_Currency_Prices( $multi_currency, $currency_options );
		        $new_price  		= $WMCP->convert_price_amount( $price, $currency_code );
		    }
		}

		return apply_filters( 'ovabrw_convert_price_in_admin', $new_price, $price, $currency_code );
	}
}

/**
 * Loading reCAPTCHA
 */
if ( !function_exists( 'ovabrw_loading_reCAPTCHA' ) ) {
	function ovabrw_loading_reCAPTCHA() {
		// reCAPTCHA
		if ( 'yes' == get_option( 'ova_brw_recapcha_enable', 'no' ) ) {
			$recaptcha_type = ovabrw_get_recaptcha_type();
			$site_key 		= ovabrw_get_recaptcha_site_key();

			wp_enqueue_script( 'ovabrw_recapcha_loading', OVABRW_PLUGIN_URI.'assets/js/frontend/ova-brw-recaptcha.min.js', [], false, false );
			wp_localize_script( 'ovabrw_recapcha_loading', 'ovabrw_recaptcha', array( 'site_key' => $site_key, 'form' => get_option( 'ova_brw_recapcha_form', '' ) ) );

			if ( $recaptcha_type === 'v3' ) {
				wp_enqueue_script( 'ovabrw_recaptcha', 'https://www.google.com/recaptcha/api.js?onload=ovabrwLoadingReCAPTCHAv3&render='.$site_key, [], false, false );
			} else {
				wp_enqueue_script( 'ovabrw_recaptcha', 'https://www.google.com/recaptcha/api.js?onload=ovabrwLoadingReCAPTCHAv2&render=explicit', [], false, false );
			}
		}
	}
}

/**
 * reCAPTCHA type
 */
if ( !function_exists( 'ovabrw_get_recaptcha_type' ) ) {
	function ovabrw_get_recaptcha_type() {
		return get_option( 'ova_brw_recapcha_type', 'v3' );
	}
}

/**
 * reCAPTCHA site key
 */
if ( !function_exists( 'ovabrw_get_recaptcha_site_key' ) ) {
	function ovabrw_get_recaptcha_site_key() {
		if ( ovabrw_get_recaptcha_type() === 'v3' ) {
			return get_option( 'ova_brw_recapcha_v3_site_key', '' );
		} else {
			return get_option( 'ova_brw_recapcha_v2_site_key', '' );
		}
	}
}

/**
 * reCAPTCHA secret key
 */
if ( !function_exists( 'ovabrw_get_recaptcha_secret_key' ) ) {
	function ovabrw_get_recaptcha_secret_key() {
		if ( ovabrw_get_recaptcha_type() === 'v3' ) {
			return get_option( 'ova_brw_recapcha_v3_secret_key', '' );
		} else {
			return get_option( 'ova_brw_recapcha_v2_secret_key', '' );
		}
	}
}

/**
 * reCAPTCHA client IP
 */
if ( !function_exists( 'ovabrw_get_recaptcha_client_ip' ) ) {
	function ovabrw_get_recaptcha_client_ip() {
		if ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} elseif ( ! empty( $_SERVER['REMOTE_ADDR'] ) ) {
			$ip = $_SERVER['REMOTE_ADDR'];
		} elseif ( ! empty( $_SERVER['HTTP_CLIENT_IP'] ) ) {
			$ip = $_SERVER['HTTP_CLIENT_IP'];
		} else {
			$ip = '0.0.0.0';
		}

		return apply_filters( 'ovabrw_get_recaptcha_client_ip', $ip );
	}
}

/**
 * reCAPTCHA host
 */
if ( !function_exists( 'ovabrw_get_recaptcha_host' ) ) {
	function ovabrw_get_recaptcha_host() {
		$host 	= '';
		$url 	= parse_url( site_url() );

		if ( isset( $url['host'] ) && $url['host'] ) {
			$host = $url['host'];
		}

		return apply_filters( 'ovabrw_get_recaptcha_host', $host );
	}
}

/**
 * reCAPTCHA error
 */
if ( !function_exists( 'ovabrw_get_recaptcha_error' ) ) {
	function ovabrw_get_recaptcha_error( $code = '' ) {
		$mesg = apply_filters( 'ovabrw_recaptcha_error_message', [
			'default' 					=> esc_html__( 'An error occurred with reCAPTCHA. Please try again later.', 'ova-brw' ),
			'missing-input-secret' 		=> esc_html__( 'The secret parameter is missing.', 'ova-brw' ),
			'invalid-input-secret' 		=> esc_html__( 'The secret parameter is invalid or malformed.', 'ova-brw' ),
			'missing-input-response' 	=> esc_html__( 'The response parameter is missing.', 'ova-brw' ),
			'invalid-input-response' 	=> esc_html__( 'The response parameter is invalid or malformed.', 'ova-brw' ),
			'bad-request' 				=> esc_html__( 'The request is invalid or malformed.', 'ova-brw' ),
			'timeout-or-duplicate' 		=> esc_html__( 'The response is no longer valid: either is too old or has been used previously.', 'ova-brw' )
		]);

		$error = isset( $mesg[$code] ) ? $mesg[$code] : $mesg['default'];

		return apply_filters( 'ovabrw_get_recaptcha_error', $error, $code );
	}
}

/**
 * reCAPTCHA API response
 */
if ( !function_exists( 'ovabrw_recaptcha_api_response' ) ) {
	function ovabrw_recaptcha_api_response( $token = '' ) {
		// Params
		$params = [
			'secret'   => ovabrw_get_recaptcha_secret_key(),
			'response' => $token,
			'remoteip' => ovabrw_get_recaptcha_client_ip()
		];

		// Options
		$opts = [
			'http' => [
				'method'  => 'POST',
				'header'  => 'Content-type: application/x-www-form-urlencoded',
				'content' => http_build_query( $params )
			]
		];

		$context = stream_context_create( $opts );
		$res     = file_get_contents( 'https://www.google.com/recaptcha/api/siteverify', false, $context );
		$res     = json_decode( $res, true );

		return apply_filters( 'ovabrw_recaptcha_api_response', $res, $token );
	}
}

/**
 * Verify reCAPTCHA v2
 */
if ( !function_exists( 'ovabrw_verify_recaptcha_v2' ) ) {
	function ovabrw_verify_recaptcha_v2( $token = '' ) {
		// Get recaptcha error
		$error = ovabrw_get_recaptcha_error();

		// Get api response
		if ( $token ) {
			$response 	= ovabrw_recaptcha_api_response( $token );
			$success 	= ovabrw_get_meta_data( 'success', $response );
			$hostname 	= ovabrw_get_meta_data( 'hostname', $response );

			if ( $success && $hostname == ovabrw_get_recaptcha_host() ) {
				$error = '';
			} else {
				if ( isset( $res['error-codes'][0] ) && $res['error-codes'][0] ) {
			        $error = ovabrw_get_recaptcha_error( $res['error-codes'][0] );
			    }
			}
		}

		return apply_filters( 'ovabrw_verify_recaptcha_v2', $error, $token );
	}
}

/**
 * Verify reCAPTCHA v3
 */
if ( !function_exists( 'ovabrw_verify_recaptcha_v3' ) ) {
	function ovabrw_verify_recaptcha_v3( $token = '' ) {
		// Get recaptcha error
		$error = ovabrw_get_recaptcha_error();

		// Score
		$score = apply_filters( 'ovabrw_recaptcha_score', 0.5 );

		// Get api response
		if ( $token ) {
			$response 	= ovabrw_recaptcha_api_response( $token );
			$success 	= ovabrw_get_meta_data( 'success', $response );
			$hostname 	= ovabrw_get_meta_data( 'hostname', $response );
			$action 	= ovabrw_get_meta_data( 'action', $response );
			$res_score 	= (float)ovabrw_get_meta_data( 'score', $response );

			if ( $success && $hostname == ovabrw_get_recaptcha_host() && $action == 'ovabrwVerifyForm' && $res_score > $score ) {
				$error = '';
			} else {
				if ( isset( $res['error-codes'][0] ) && $res['error-codes'][0] ) {
			        $error = ovabrw_get_recaptcha_error( $res['error-codes'][0] );
			    }
			}
		}

		return apply_filters( 'ovabrw_verify_recaptcha_v3', $error, $token );
	}
}

/**
 * reCAPTCHA form
 */
if ( !function_exists( 'ovabrw_get_recaptcha_form' ) ) {
	function ovabrw_get_recaptcha_form( $form = '' ) {
		if ( 'yes' != get_option( 'ova_brw_recapcha_enable', 'no' ) ) return false;
		if ( 'both' == get_option( 'ova_brw_recapcha_form', '' ) ) return true;
		if ( $form == get_option( 'ova_brw_recapcha_form', '' ) ) return true;

		return false;
	}
}

/**
 * Get all specifications
 */
if ( !function_exists( 'ovabrw_get_all_specifications' ) ) {
	function ovabrw_get_all_specifications( $product_id = null ) {
		if ( ! $product_id ) return false;

		$specifications = ovabrw_recursive_replace( '\\', '', get_option( 'ovabrw_specifications', [] ) );
        if ( empty( $specifications ) ) $specifications = [];

        $product_specifications = [];

        $categories = wp_get_post_terms( $product_id, 'product_cat' );
        $term_id    = isset( $categories[0] ) && is_object( $categories[0] ) ? $categories[0]->term_id : '';
        $term_specifications = $term_id ? get_term_meta( $term_id, 'ovabrw_choose_specifications', true ) : '';

        if ( 'all' == $term_specifications ) {
            $product_specifications = $specifications;
        } elseif ( 'special' == $term_specifications ) {
            $special_specifications = get_term_meta( $term_id, 'ovabrw_specifications', true );

            if ( ovabrw_array_exists( $special_specifications ) ) {
                foreach ( $special_specifications as $name ) {
                    if ( array_key_exists( $name, $specifications ) ) {
                        $product_specifications[$name] = $specifications[$name];
                    }
                }
            }
        } else {
            $product_specifications = $specifications;
        }

        // Filter product specifications
        if ( ovabrw_array_exists( $product_specifications ) ) {
        	$product_specifications = array_filter( $product_specifications, function ( $item ) {
			    return ( isset( $item['enable'] ) && $item['enable'] );
			});
        }

        return apply_filters( 'ovabrw_get_all_specifications', $product_specifications, $product_id );
	}
}

/**
 * Create remaining invoice
 */
if ( !function_exists( 'ovabrw_create_remaining_invoice' ) ) {
    function ovabrw_create_remaining_invoice( $order_id, $data ) {
        $order = wc_get_order( $order_id );

        try {
            $new_order = new WC_Order;
            $new_order->set_props( array(
                'status'              => 'wc-pending',
                'customer_id'         => $order->get_user_id(),
                'customer_note'       => $order->get_customer_note(),
                'billing_first_name'  => $order->get_billing_first_name(),
                'billing_last_name'   => $order->get_billing_last_name(),
                'billing_company'     => $order->get_billing_company(),
                'billing_address_1'   => $order->get_billing_address_1(),
                'billing_address_2'   => $order->get_billing_address_2(),
                'billing_city'        => $order->get_billing_city(),
                'billing_state'       => $order->get_billing_state(),
                'billing_postcode'    => $order->get_billing_postcode(),
                'billing_country'     => $order->get_billing_country(),
                'billing_email'       => $order->get_billing_email(),
                'billing_phone'       => $order->get_billing_phone(),
                'shipping_first_name' => $order->get_shipping_first_name(),
                'shipping_last_name'  => $order->get_shipping_last_name(),
                'shipping_company'    => $order->get_shipping_company(),
                'shipping_address_1'  => $order->get_shipping_address_1(),
                'shipping_address_2'  => $order->get_shipping_address_2(),
                'shipping_city'       => $order->get_shipping_city(),
                'shipping_state'      => $order->get_shipping_state(),
                'shipping_postcode'   => $order->get_shipping_postcode(),
                'shipping_country'    => $order->get_shipping_country(),
            ));
            $new_order->set_currency( $order->get_currency() );
            $new_order->save();
        } catch ( Exception $e ) {
            $order->add_order_note( sprintf( __( 'Error: Unable to create follow up payment (%s)', 'ova-brw' ), $e->getMessage() ) );
            return;
        }

        // Order total
        $order_total = $data['total'];

        // Handle items
        $item_id = $new_order->add_product( $data['product'], $data['qty'], array(
            'totals' => array(
                'subtotal' 	=> $data['subtotal'],
                'total' 	=> $data['total']
            )
        ));

        // Get order line item
        $line_item = $new_order->get_item( $item_id );

        $new_order->set_parent_id( $order_id );
        $new_order->set_date_created( date( 'Y-m-d H:i:s', current_time( 'timestamp' ) ) );

        // Get tax rate id
        $tax_class 		= $data['product']->get_tax_class();
        $tax_rate_id 	= 0;
        if ( wc_tax_enabled() ) {
        	$tax_rates = WC_Tax::get_rates( $tax_class );

	        if ( ! empty( $tax_rates ) ) {
	            $tax_rate_id = key( $tax_rates );
	        }
        }

        // Remaining tax amount
        $remaining_tax = isset( $data['remaining_tax'] ) ? floatval( $data['remaining_tax'] ) : 0;

        // Insurance amount
        $insurance_amount 	= isset( $data['insurance_amount'] ) ? floatval( $data['insurance_amount'] ) : 0;
        $insurance_tax 		= isset( $data['insurance_tax'] ) ? floatval( $data['insurance_tax'] ) : 0;

        // Add item fee
        if ( $insurance_amount ) {
        	// Update order total
        	$order_total += $insurance_amount;

	        // Get insurance name
	        $insurance_name = OVABRW()->options->get_insurance_name();

	        // Init order item fee
        	$item_fee = new WC_Order_Item_Fee();

        	$item_fee_data = array(
        		'name'      => $insurance_name,
                'amount'    => $insurance_amount,
                'total'     => $insurance_amount,
                'order_id'  => $order_id
        	);

        	// Add item fee tax
        	if ( wc_tax_enabled() && $insurance_tax ) {
        		// Update order total
            	$order_total += $insurance_tax;

        		// Set tax for item fee
        		$item_fee_data['tax_class'] = $tax_class ? $tax_class : 0;
        		$item_fee_data['total_tax'] = $insurance_tax;
        		$item_fee_data['taxes'] 	= array(
        			'total' => array(
        				$tax_rate_id => $insurance_tax
        			)
        		);

        		// Order add meta insurance tax
        		$new_order->add_meta_data( '_ova_insurance_tax', $insurance_tax );

        		// Line item add meta insurance tax
        		$line_item->add_meta_data( 'ovabrw_insurance_tax', $insurance_tax );
        	}

            $item_fee->set_props( $item_fee_data );
            $item_fee->save();

            // Order add item fee
            $new_order->add_item( $item_fee );

            // Order add meta data
            $new_order->add_meta_data( '_ova_insurance_key', sanitize_title( $insurance_name ) );
            $new_order->add_meta_data( '_ova_insurance_amount', $insurance_amount );

            // Line item add meta data
            $line_item->add_meta_data( 'ovabrw_insurance_amount', $insurance_amount );
            $line_item->save();
        }

    	// Add item tax
        if ( wc_tax_enabled() && $remaining_tax ) {
        	// Update order total
        	$order_total += $remaining_tax;

        	// Order tax amount
        	$order_tax_amount = $remaining_tax + $insurance_tax;

        	// Init order item tax
            $item_tax = new WC_Order_Item_Tax();

            $item_tax->set_props( array(
                'rate_id'            => $tax_rate_id,
                'tax_total'          => $order_tax_amount,
                'shipping_tax_total' => 0,
                'rate_code'          => WC_Tax::get_rate_code( $tax_rate_id ),
                'label'              => WC_Tax::get_rate_label( $tax_rate_id ),
                'compound'           => WC_Tax::is_compound( $tax_rate_id ),
                'rate_percent'       => WC_Tax::get_rate_percent_value( $tax_rate_id ),
            ));

            $item_tax->save();
            $new_order->add_item( $item_tax );
            $new_order->set_cart_tax( $order_tax_amount );

            // Set tax for line item
            $line_item->set_props( array(
            	'taxes' => array(
            		'total' 	=> array( $tax_rate_id => $remaining_tax ),
            		'subtotal' 	=> array( $tax_rate_id => $remaining_tax )
            	)
            ));
            $line_item->save();

            // Prices include tax
            $prices_incl_tax = $order->get_meta( '_ova_prices_include_tax' );
            if ( $prices_incl_tax ) {
                $new_order->update_meta_data( '_ova_prices_include_tax', $prices_incl_tax );
            }
        }
        
        // Order set total
        $new_order->set_total( $order_total );
        $new_order->save();

        wc_add_order_item_meta( $item_id, 'ovabrw_parent_order_id', $order_id );

        wc_update_order_item( $item_id, array( 'order_item_name' => sprintf( __( 'Payment remaining for %s', 'ova-brw' ) , $data['product']->get_title() ) ) );

        return $new_order->get_id();
    }
}

/**
 * Get rental product
 */
if ( !function_exists( 'ovabrw_get_rental_product' ) ) {
	function ovabrw_get_rental_product( $args = array() ) {
		global $product;

		// Get product ID
		$product_id = isset( $args['product_id'] ) ? $args['product_id'] : '';
		if ( !$product_id ) {
			$product_id = isset( $args['id'] ) ? $args['id'] : '';
		}

		// Single product
		if ( is_single() ) {
			if ( !$product && $product_id ) {
				$product = wc_get_product( $product_id );
			}
		} else {
			if ( $product_id ) {
				$product = wc_get_product( $product_id );
			}
		}

		// Check is rental product
		if ( $product && !$product->is_type('ovabrw_car_rental') ) {
			if ( !is_archive() ) {
				return false;
			}
		}

		return apply_filters( 'ovabrw_get_rental_product', $product );
	}
}

/**
 * Get meta data
 * @param  string 	$key
 * @param  array 	$args
 * @param  mixed 	$default
 * @return mixed 	$value
 */
if ( !function_exists( 'ovabrw_get_meta_data' ) ) {
	function ovabrw_get_meta_data( $key = '', $args = array(), $default = false ) {
		$value = '';

		// Check $args
		if ( empty( $args ) || !is_array( $args ) ) $args = array();

		// Get value by key
		if ( $key !== '' && isset( $args[$key] ) && '' !== $args[$key] ) {
			$value = $args[$key];
		}

		// Set default
		if ( !$value && false !== $default ) {
			$value = $default;
		}

		return apply_filters( 'ovabrw_get_meta_data', $value, $key, $args, $default );
	}
}

/**
 * Get option
 * @param  string 	$name
 * @return mixed 	$value
 */
if ( !function_exists( 'ovabrw_get_option' ) ) {
	function ovabrw_get_option( $name = '', $default = false ) {
		$value = '';

		if ( $name ) {
			$value = get_option( OVABRW_PREFIX.$name );

			if ( $value === false && $default !== false ) {
				$value = $default;
			}
		}

		return apply_filters( 'ovabrw_get_option', $value, $name, $default );
	}
}

/**
 * Get predefined ranges
 */
if ( !function_exists( 'ovabrw_get_predefined_ranges' ) ) {
	function ovabrw_get_predefined_ranges() {
		$today 			= esc_html__( 'Today', 'ova-brw' );
		$next_day 		= esc_html__( 'Next Day', 'ova-brw' );
		$this_week 		= esc_html__( 'This Week', 'ova-brw' );
		$next_week 		= esc_html__( 'Next Week', 'ova-brw' );
		$this_month 	= esc_html__( 'This Month', 'ova-brw' );
		$next_month 	= esc_html__( 'Next Month', 'ova-brw' );
		$date_format 	= 'Y-m-d';
		$start_of_week 	= get_option( 'ova_brw_calendar_first_day', 1 );
		$dayOfWeek 		= date('l', strtotime("Sunday +{$start_of_week} days"));
		// Next month
		$month_number 	= date( 'm', strtotime( 'next month' ) );
		$year_number 	= date( 'Y', strtotime( 'next month' ) );
		$day_number 	= date( 't', strtotime( 'next month' ) );

		// Predefined ranges
		$predefined_ranges = array(
			$today 		=> array(
				date( $date_format ),
				date( $date_format )
			),
			$next_day 	=> array(
				date( $date_format, strtotime('+1 day') ),
				date( $date_format, strtotime('+1 day') )
			),
			$this_week 	=> array(
				date( $date_format, strtotime( "last {$dayOfWeek}" ) ),
				date( $date_format, strtotime( "next {$dayOfWeek} -1 day" ) )
			),
			$next_week 	=> array(
				date( $date_format, strtotime( "next {$dayOfWeek}" ) ),
				date( $date_format, strtotime( "next {$dayOfWeek} +6 days" ))
			),
			$this_month => array(
				date( $date_format, strtotime( date('Y').'-'.date('m').'-01') ),
				date( $date_format, strtotime( date('Y').'-'.date('m').'-'.date('t') ) )
			),
			$next_month => array(
				date( $date_format, strtotime( $year_number.'-'.$month_number.'-01') ),
				date( $date_format, strtotime( $year_number.'-'.$month_number.'-'.$day_number ) )
			)
		);

		return apply_filters( 'ovabrw_get_predefined_ranges', $predefined_ranges );
	}
}

/**
 * Validation messages
 */
if ( !function_exists( 'ovabrw_get_validation_messages' ) ) {
	function ovabrw_get_validation_messages() {
		return apply_filters( 'ovabrw_get_validation_messages', array(
			'dateFormat' 	=> ovabrw_get_date_format(),
			'required' 		=> esc_html__( 'This field is required.', 'ova-brw' ),
			'duplicateID' 	=> esc_html__( 'Duplicate ID.', 'ova-brw' ),
			'duplicateTime' => esc_html__( 'Duplicate time.', 'ova-brw' ),
			'duplicateDate' => esc_html__( 'Duplicate date.', 'ova-brw' ),
			'conditions' 	=> esc_html__( 'Please read and accept the terms and conditions to continue.', 'ova-brw' ),
			'reCAPTCHA'  	=> esc_html__( 'Please verify that you are not a robot.', 'ova-brw' ),
			'email' 		=> esc_html__( 'Please enter a valid email address.', 'ova-brw' ),
			'phone' 		=> esc_html__( 'Please enter a valid phone number.', 'ova-brw' ),
			'url' 			=> esc_html__( 'Please enter a valid URL.', 'ova-brw' ),
			'date' 			=> esc_html__( 'Please enter a valid date.', 'ova-brw' ),
			'number' 		=> esc_html__( 'Please enter a valid number.', 'ova-brw' ),
			'digits' 		=> esc_html__( 'Please enter only digits.', 'ova-brw' ),
			'size' 			=> esc_html__( 'Please select a file less than [size] MB.' ),
			'fileType' 		=> esc_html__( 'Invalid file type. Please upload an image file (.jpg, .jpeg, .png, .pdf, .doc).', 'ova-brw' ),
			'min' 			=> esc_html__( 'Please enter a value greater than or equal to [number].', 'ova-brw' ),
			'max' 			=> esc_html__( 'Please enter a value less than or equal to [number].', 'ova-brw' ),
			'minQty' 		=> esc_html__( 'Minimum quantity: [number].', 'ova-brw' ),
			'maxQty' 		=> esc_html__( 'Maximum quantity: [number].', 'ova-brw' ),
			'minGuests' 	=> esc_html__( 'Minimum number of guests: [number].', 'ova-brw' ),
			'maxGuests' 	=> esc_html__( 'Maximum number of guests: [number].', 'ova-brw' ),
			'minGuest' 		=> esc_html__( 'Minimum number of [guest]: [number].', 'ova-brw' ),
			'maxGuest' 		=> esc_html__( 'Maximum number of [guest]: [number].', 'ova-brw' ),
			'mapAPI' 		=> esc_html__( 'This page can\'t load Google Maps properly.', 'ovabrw-' )
		));
	}
}

/**
 * Get post meta
 * @param  int 		$id
 * @param  string 	$name
 * @param  mixed 	$default
 * @return mixed 	$value
 */
if ( !function_exists( 'ovabrw_get_post_meta' ) ) {
	function ovabrw_get_post_meta( $id = null, $name = '', $default = false ) {
		$value = '';

		if ( $id && $name ) {
			$value = get_post_meta( $id, OVABRW_PREFIX.$name, true );

			if ( ! $value && $default !== false ) {
				$value = $default;
			}
		}

		return apply_filters( 'ovabrw_get_post_meta', $value, $id, $name, $default );
	}
}