<?php defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'OVABRW_Elementor' ) ) {
	class OVABRW_Elementor {
		function __construct() {
			add_action( 'elementor/elements/categories_registered', array( $this, 'categories_registered' ) );
			add_action( 'elementor/widgets/register', array( $this, 'widgets_register' ) );
			add_action( 'elementor/frontend/after_register_scripts', array( $this, 'after_register_scripts' ) );
		}

		public function categories_registered() {
			\Elementor\Plugin::instance()->elements_manager->add_category(
		        'ovatheme',
		        [
		            'title' => esc_html__( 'Ovatheme', 'ova-brw' ),
		            'icon' 	=> 'fa fa-plug',
		        ]
		    );

		    \Elementor\Plugin::instance()->elements_manager->add_category(
		        'ovabrw-product',
		        [
		            'title' => esc_html__( 'BRW Product', 'ova-brw' ),
		            'icon' 	=> 'fa fa-plug',
		        ]
		    );
		}

		public function widgets_register( $widgets_manager ) {
			$files = glob(OVABRW_PLUGIN_PATH.'elementor/widgets/*.php');

	        foreach ( $files as $file ) {
	            $file = OVABRW_PLUGIN_PATH.'elementor/widgets/' . wp_basename($file);

	            if ( file_exists( $file ) ) {
	                require_once $file;
	            }
	        }
		}

		public function after_register_scripts() {
			wp_enqueue_script( 'ovabrw-script-elementor', OVABRW_PLUGIN_URI.'assets/js/frontend/ova-script-elementor.min.js', [ 'jquery' ], false, true );
		}
	}

	new OVABRW_Elementor();
}