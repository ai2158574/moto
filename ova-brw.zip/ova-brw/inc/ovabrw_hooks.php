<?php if ( !defined( 'ABSPATH' ) ) exit();

// add_filter show Wysiwyg Editor
add_filter( 'ovabrw_the_content', 'do_blocks', 9 );
add_filter( 'ovabrw_the_content', 'wptexturize' );
add_filter( 'ovabrw_the_content', 'convert_smilies', 20 );
add_filter( 'ovabrw_the_content', 'wpautop' );
add_filter( 'ovabrw_the_content', 'shortcode_unautop' );
add_filter( 'ovabrw_the_content', 'prepend_attachment' );
add_filter( 'ovabrw_the_content', 'wp_filter_content_tags' );
add_filter( 'ovabrw_the_content', 'wp_replace_insecure_home_url' );
add_filter( 'ovabrw_the_content', 'do_shortcode', 11 );

/* Load Template */
add_filter( 'template_include', 'ovabrw_template_loader', 99 );
if ( !function_exists( 'ovabrw_template_loader' ) ) {
    function ovabrw_template_loader( $template ) {
        $search             = sanitize_text_field( ovabrw_get_meta_data( 'ovabrw_search', $_REQUEST ) );
        $request_booking    = sanitize_text_field( ovabrw_get_meta_data( 'request_booking', $_REQUEST ) );

        // Get product template options
        $product_template = get_option( 'ova_brw_template_elementor_template', 'default' );

        // Single Product
        if ( is_product() ) {
            $product_id = get_the_id();
            $product    = wc_get_product( $product_id );

            if ( $product->is_type('ovabrw_car_rental') ) {
                // Get product template
                $prod_template = get_post_meta( $product_id, 'ovabrw_product_template', true );

                if ( $prod_template && 'global' != $prod_template ) {
                    if ( 'default' == $prod_template ) {
                        return $template;
                    } elseif ( ovabrw_global_typography() && 'modern' == $prod_template ) {
                        return ovabrw_get_template( 'modern/single/ovabrw-single-product.php' );
                    } else {
                        return ovabrw_get_template( 'ovabrw_single_product.php', array( 'template' => $prod_template ) );
                    }
                }

                // Woo Settings
                if ( 'default' == $product_template ) {
                    $template_by_category = ovabrw_get_product_template( $product_id );

                    if ( $template_by_category && 'default' != $template_by_category ) {
                        $template = ovabrw_get_template( 'ovabrw_single_product.php', array( 'template' => $template_by_category ) );
                    }
                } elseif ( ovabrw_global_typography() && 'modern' == $product_template ) {
                    $template_by_category = ovabrw_get_product_template( $product_id );

                    if ( $template_by_category && 'modern' != $template_by_category ) {
                        $template = ovabrw_get_template( 'ovabrw_single_product.php', array( 'template' => $template_by_category ) );
                    } else {
                        $template = ovabrw_get_template( 'modern/single/ovabrw-single-product.php' );
                    }
                } else {
                    $template = ovabrw_get_template( 'ovabrw_single_product.php' );
                }
            }
        }

        // Archive Product
        if ( ovabrw_is_archive_product() && '' == $search ) {
            ovabrw_get_template( 'modern/products/ovabrw-archive-product.php' );

            return false;
        }
        
        // Search Form
        if ( '' != $search ) {
            return ovabrw_get_template( 'search_result.php' );
        }
        
        // Request Booking Form
        if ( '' != $request_booking ) {
            if ( OVABRW_Mail::instance()->mail_request_booking( $_REQUEST ) ) {
                // Webhook request booking success
                do_action( 'ovabrw_mail_request_booking_sent', $_REQUEST );

                $thank_page = get_option( 'ova_brw_request_booking_form_thank_page' );
                if ( !$thank_page ) $thank_page = home_url();

                $object_id  = '';

                // Multi language
                if ( is_plugin_active( 'sitepress-multilingual-cms/sitepress.php' ) ) {
                    $thank_page_id  = url_to_postid( $thank_page );
                    $object_id      = apply_filters( 'wpml_object_id', $thank_page_id, 'page', TRUE  );
                } elseif ( is_plugin_active( 'polylang/polylang.php' ) || is_plugin_active( 'polylang-pro/polylang.php' ) ) {
                    $thank_page_id  = url_to_postid( $thank_page );
                    $object_id      = pll_get_post( $thank_page_id );
                }

                if ( $object_id ) {
                    $thank_page = get_permalink( $object_id );
                }

                wp_safe_redirect( $thank_page );
            } else {
                $error_page = get_option( 'ova_brw_request_booking_form_error_page' );
                if ( !$error_page ) $error_page = home_url();

                $object_id  = '';

                // Multi language
                if ( is_plugin_active( 'sitepress-multilingual-cms/sitepress.php' ) ) {
                    $error_page_id  = url_to_postid( $error_page );
                    $object_id      = apply_filters( 'wpml_object_id', $error_page_id, 'page', TRUE  );
                } elseif ( is_plugin_active( 'polylang/polylang.php' ) || is_plugin_active( 'polylang-pro/polylang.php' ) ) {
                    $error_page_id  = url_to_postid( $error_page );
                    $object_id      = pll_get_post( $error_page_id );
                }

                if ( $object_id ) {
                    $error_page = get_permalink( $object_id );
                }
                
                wp_safe_redirect( $error_page );
            }

            exit();
        }

        return $template;
    }
}

// Support Apple and Google Pay Button
add_filter( 'wcpay_payment_request_supported_types', function( $product_types ) {
    if ( ovabrw_array_exists( $product_types ) ) {
        array_push( $product_types , 'ovabrw_car_rental' );
    }

    return $product_types;
});

// Add javascript to head
add_action('admin_head', 'ovabrw_hook_javascript');
add_action('wp_head', 'ovabrw_hook_javascript');
if ( !function_exists( 'ovabrw_hook_javascript' ) ) {
    function ovabrw_hook_javascript() {
        // Defined label for custom checkout field
        $label_option_value = esc_html__( 'text', 'ova-brw' );
        $label_option_text  = esc_html__( 'text', 'ova-brw' );
        $label_add_new_opt  = esc_html__( 'Add new option', 'ova-brw' );
        $label_remove_opt   = esc_html__( 'Remove option', 'ova-brw' );
        $label_are_you_sure = esc_html__( 'Are you sure ?', 'ova-brw' );

        // Notifi disable day
        $notifi_disable_day = esc_html__( 'You cannot book on this day!', 'ova-brw' );

        // Global color
        $light_color    = get_option( 'ovabrw_glb_light_color', '#C3C3C3' );
        $text_color     = get_option( 'ovabrw_glb_text_color', '#555555' );
        ?>
            <script type="text/javascript">
                var labelOptionValue  = '<?php echo esc_attr( $label_option_value ); ?>';
                var labelOptionText   = '<?php echo esc_attr( $label_option_text ); ?>';
                var labelAddNewOption   = '<?php echo esc_attr( $label_add_new_opt ); ?>';
                var labelRemoveOption    = '<?php echo ( $label_remove_opt ); ?>';
                var labelAreYouSure     = '<?php echo ( $label_are_you_sure ); ?>';

                // Init notificate disable day calendar
                var notifiDisableWeekDays = '<?php echo esc_attr( $notifi_disable_day ); ?>';

                // Global Color
                var ovabrwLightColor = '<?php echo esc_attr( $light_color ); ?>';
                var ovabrwTextColor = '<?php echo esc_attr( $text_color ); ?>';
            </script>
        <?php
    }
}

/**
 * Hook: woocommerce_product_tabs
 * @hooked: ovabrw_woo_new_product_tab - 10
 */
add_filter( 'woocommerce_product_tabs', 'ovabrw_woo_new_product_tab', 10 );

/**
 * Hook: woocommerce_after_shop_loop_item_title.
 *
 * @hooked ovabrw_product_price - 9
 */
add_action( 'woocommerce_after_shop_loop_item_title', 'ovabrw_product_price', 9 );
if ( !function_exists( 'ovabrw_product_price' ) ) {
    function ovabrw_product_price() {
        return ovabrw_get_template( 'loop/price.php' );
    }
}

/**
 * Hook: woocommerce_after_shop_loop_item.
 *
 * @hooked ovabrw_loop_featured - 9
 */
add_action( 'woocommerce_after_shop_loop_item', 'ovabrw_loop_featured', 9 );
if ( !function_exists( 'ovabrw_loop_featured' ) ) {
    function ovabrw_loop_featured() {
        if ( 'yes' == get_option( 'ova_brw_archive_product_show_features', 'yes' ) ) {
            return ovabrw_get_template( 'loop/featured.php' );
        }
    }
}

/**
 * Hook: woocommerce_after_shop_loop_item.
 *
 * @hooked ovabrw_loop_taxonomy - 9
 */
add_action( 'woocommerce_after_shop_loop_item', 'ovabrw_loop_taxonomy', 9 );
if ( !function_exists( 'ovabrw_loop_taxonomy' ) ) {
    function ovabrw_loop_taxonomy() {
        return ovabrw_get_template( 'loop/taxonomy.php' );
    }
}

/**
 * Hook: woocommerce_after_shop_loop_item.
 *
 * @hooked ovabrw_loop_attributes - 8
 */
add_action( 'woocommerce_after_shop_loop_item', 'ovabrw_loop_attributes', 8 );
if ( !function_exists( 'ovabrw_loop_attributes' ) ) {
    function ovabrw_loop_attributes() {
        if ( 'yes' == get_option( 'ova_brw_archive_product_show_attribute', 'yes' ) ) {
            return ovabrw_get_template( 'loop/attributes.php' );
        }
    }
}

/**
 * Hook: woocommerce_single_product_summary
 * @hooked ovabrw_woocommerce_template_single_price - 10
 */
add_action( 'woocommerce_single_product_summary', 'ovabrw_woocommerce_template_single_price', 9 );
if ( !function_exists( 'ovabrw_woocommerce_template_single_price' ) ) {
    function ovabrw_woocommerce_template_single_price() {
        if ( 'yes' == get_option( 'ova_brw_template_show_price', 'yes' ) ) {
            return ovabrw_get_template( 'single/price.php' );
        }
    }
}

/**
 * Hook: woocommerce_single_product_summary
 * @hooked ovabrw_woocommerce_template_single_cus_tax - 65
 */
add_action( 'woocommerce_single_product_summary', 'ovabrw_woocommerce_template_single_cus_tax', 65 );
if ( !function_exists( 'ovabrw_woocommerce_template_single_cus_tax' ) ) {
    function ovabrw_woocommerce_template_single_cus_tax() {
        if ( 'yes' == get_option( 'ova_brw_template_show_cus_tax', 'yes' ) ) {
            return ovabrw_get_template( 'single/custom_taxonomy.php' );
        }
    }
}

/**
 * Hook: woocommerce_single_product_summary
 * @hooked ovabrw_woocommerce_template_single_specifications - 70
 */
add_action( 'woocommerce_single_product_summary', 'ovabrw_woocommerce_template_single_specifications', 70 );
if ( !function_exists( 'ovabrw_woocommerce_template_single_specifications' ) ) {
    function ovabrw_woocommerce_template_single_specifications() {
        if ( 'yes' == get_option( 'ova_brw_template_show_specifications', 'yes' ) ) {
            return ovabrw_get_template( 'single/specifications.php' );
        }
    }
}

/**
 * Hook: woocommerce_single_product_summary
 * @hooked ovabrw_woocommerce_template_single_featured - 70
 */
add_action( 'woocommerce_single_product_summary', 'ovabrw_woocommerce_template_single_featured', 70 );
if ( !function_exists( 'ovabrw_woocommerce_template_single_featured' ) ) {
    function ovabrw_woocommerce_template_single_featured() {
        if ( 'yes' == get_option( 'ova_brw_template_show_feature', 'yes' ) ) {
            return ovabrw_get_template( 'single/features.php' );
        }
    }
}

/**
 * Hook: woocommerce_single_product_summary
 * @hooked ovabrw_woocommerce_template_single_table_price - 71
 */
add_action( 'woocommerce_single_product_summary', 'ovabrw_woocommerce_template_single_table_price', 71 );
if ( !function_exists( 'ovabrw_woocommerce_template_single_table_price' ) ) {
    function ovabrw_woocommerce_template_single_table_price() {
        if ( 'yes' == get_option( 'ova_brw_template_show_table_price', 'yes' ) ) {
            return ovabrw_get_template( 'single/table_price.php' );
        }
    }
}

/**
 * Hook: woocommerce_single_product_summary
 * @hooked ovabrw_woocommerce_template_single_untime - 72
 */
add_action( 'woocommerce_single_product_summary', 'ovabrw_woocommerce_template_single_untime', 72 );
if ( !function_exists( 'ovabrw_woocommerce_template_single_untime' ) ) {
    function ovabrw_woocommerce_template_single_untime() {
        if ( 'yes' == get_option( 'ova_brw_template_show_maintenance', 'yes' ) ) {
            return ovabrw_get_template( 'single/unavailable_time.php' );
        }
    }
}

/**
 * Hook: woocommerce_single_product_summary
 * @hooked ovabrw_woocommerce_template_single_calendar - 73
 */
add_action( 'woocommerce_single_product_summary', 'ovabrw_woocommerce_template_single_calendar', 73 );
if ( !function_exists( 'ovabrw_woocommerce_template_single_calendar' ) ) {
    function ovabrw_woocommerce_template_single_calendar() {
        if ( 'yes' == get_option( 'ova_brw_template_show_calendar', 'yes' ) ) { 
            return ovabrw_get_template( 'single/calendar.php' );
        }
    }
}

/**
 * Hook: woocommerce_single_product_summary
 * @hooked ovabrw_woocommerce_template_single_booking_form - 74
 */
add_action( 'woocommerce_single_product_summary', 'ovabrw_woocommerce_template_single_booking_form', 74 );
if ( !function_exists( 'ovabrw_woocommerce_template_single_booking_form' ) ) {
    function ovabrw_woocommerce_template_single_booking_form() {
        if ( 'yes' == get_option( 'ova_brw_template_show_booking_form', 'yes' ) ) { 
            return ovabrw_get_template( 'single/booking-form.php' );
        }
    }
}

/**
 * Hook: ovabrw_booking_form
 * @hooked: ovabrw_booking_form_fields - 5
 */
add_action( 'ovabrw_booking_form', 'ovabrw_booking_form_fields', 5, 1 );
if ( !function_exists( 'ovabrw_booking_form_fields' ) ) {
    function ovabrw_booking_form_fields( $product_id ) {
        return ovabrw_get_template( 'single/booking-form/fields.php', [
            'product_id' => $product_id
        ]);
    }
}

/**
 * Hook: ovabrw_booking_form
 * @hooked: ovabrw_booking_form_extra_fields - 10
 */
add_action( 'ovabrw_booking_form', 'ovabrw_booking_form_extra_fields', 10, 1 );
if ( !function_exists( 'ovabrw_booking_form_extra_fields' ) ) {
    function ovabrw_booking_form_extra_fields( $product_id ) {
        return ovabrw_get_template( 'single/booking-form/extra_fields.php', [
            'product_id' => $product_id
        ]);  
    }
}

/**
 * Hook: ovabrw_booking_form
 * @hooked: ovabrw_booking_form_resource - 15
 */
add_action( 'ovabrw_booking_form', 'ovabrw_booking_form_resource', 15, 1 );
if ( !function_exists( 'ovabrw_booking_form_resource' ) ) {
    function ovabrw_booking_form_resource( $product_id ) {
        if ( 'yes' == get_option( 'ova_brw_booking_form_show_extra_resource', 'yes' ) ) {
            return ovabrw_get_template( 'single/booking-form/resource.php', [
                'product_id' => $product_id
            ]);
        }
    }
}

/**
 * Hook: ovabrw_booking_form
 * @hooked: ovabrw_booking_form_services - 20
 */
add_action( 'ovabrw_booking_form', 'ovabrw_booking_form_services', 20, 1 );
if ( !function_exists( 'ovabrw_booking_form_services' ) ) {
    function ovabrw_booking_form_services( $product_id ) {
        if ( 'yes' == get_option( 'ova_brw_booking_form_show_extra_service', 'yes' ) ) {
            return ovabrw_get_template( 'single/booking-form/services.php', [
                'product_id' => $product_id
            ]);
        }
    }
}

/**
 * Hook: ovabrw_booking_form
 * @hooked: ovabrw_booking_form_deposit - 25
 */
add_action( 'ovabrw_booking_form', 'ovabrw_booking_form_deposit', 25, 1 );
if ( !function_exists( 'ovabrw_booking_form_deposit' ) ) {
    function ovabrw_booking_form_deposit( $product_id ) {
        $enable_deposit = get_post_meta ( $product_id, 'ovabrw_enable_deposit', true );

        if ( 'yes' == $enable_deposit ) {
            return ovabrw_get_template( 'single/booking-form/deposit.php', [
                'product_id' => $product_id
            ]);
        }
        
        return;
    }
}

/**
 * Hook: ovabrw_booking_form
 * @hooked: ovabrw_booking_form_ajax_total - 30
 */
add_action( 'ovabrw_booking_form', 'ovabrw_booking_form_ajax_total', 30, 1 );
if ( !function_exists( 'ovabrw_booking_form_ajax_total' ) ) {
    function ovabrw_booking_form_ajax_total( $product_id ) {
        return ovabrw_get_template( 'single/booking-form/ajax_total.php', [
            'product_id' => $product_id
        ]);
    }
}

/**
 * Hook: ovabrw_table_price_weekdays
 * @hooked: ovabrw_table_price_weekdays - 10
 */
add_action( 'ovabrw_table_price_weekdays', 'ovabrw_table_price_weekdays', 10, 1 );
if ( !function_exists( 'ovabrw_table_price_weekdays' ) ) {
    function ovabrw_table_price_weekdays( $product_id ) {
        $price_type = get_post_meta( $product_id, 'ovabrw_price_type', true );
        $monday     = get_post_meta( $product_id, 'ovabrw_daily_monday', true );
        $tuesday    = get_post_meta( $product_id, 'ovabrw_daily_tuesday', true );
        $wednesday  = get_post_meta( $product_id, 'ovabrw_daily_wednesday', true );
        $thursday   = get_post_meta( $product_id, 'ovabrw_daily_thursday', true );
        $friday     = get_post_meta( $product_id, 'ovabrw_daily_friday', true );
        $saturday   = get_post_meta( $product_id, 'ovabrw_daily_saturday', true );
        $sunday     = get_post_meta( $product_id, 'ovabrw_daily_sunday', true );

        if ( ( 'day' == $price_type || 'mixed' == $price_type ) && $monday && $tuesday && $wednesday && $thursday && $friday && $saturday && $sunday ) { 
            return ovabrw_get_template( 'single/table-price/weekdays.php', [
                'product_id' => $product_id
            ]);
        }
    }
}

/**
 * Hook: ovabrw_table_price_global_discount_day
 * @hooked: ovabrw_table_price_global_discount_day - 10
 */
add_action( 'ovabrw_table_price_global_discount_day', 'ovabrw_table_price_global_discount_day', 10, 1 );
if ( !function_exists( 'ovabrw_table_price_global_discount_day' ) ) {
    function ovabrw_table_price_global_discount_day( $product_id ) {
        return ovabrw_get_template( 'single/table-price/global_discount_day.php', [
            'product_id' => $product_id
        ]); 
    }
}

/**
 * Hook: ovabrw_table_price_global_discount_hour
 * @hooked: ovabrw_table_price_global_discount_hour - 10
 */
add_action( 'ovabrw_table_price_global_discount_hour', 'ovabrw_table_price_global_discount_hour', 10, 1 );
if ( !function_exists( 'ovabrw_table_price_global_discount_hour' ) ) {
    function ovabrw_table_price_global_discount_hour( $product_id ) {
        return ovabrw_get_template( 'single/table-price/global_discount_hour.php', [
            'product_id' => $product_id
        ]);
    }
}

/**
 * Hook: ovabrw_table_price_seasons_day
 * @hooked: ovabrw_table_price_seasons_day - 10
 */
add_action( 'ovabrw_table_price_seasons_day', 'ovabrw_table_price_seasons_day', 10, 1 );
if ( !function_exists( 'ovabrw_table_price_seasons_day' ) ) {
    function ovabrw_table_price_seasons_day( $product_id ) {
        return ovabrw_get_template( 'single/table-price/seasons_day.php', [
            'product_id' => $product_id
        ]);
    }
}

/**
 * Hook: ovabrw_table_price_seasons_hour
 * @hooked: ovabrw_table_price_seasons_hour - 10
 */
add_action( 'ovabrw_table_price_seasons_hour', 'ovabrw_table_price_seasons_hour', 10, 1 );
if ( !function_exists( 'ovabrw_table_price_seasons_hour' ) ) {
    function ovabrw_table_price_seasons_hour( $product_id ) {
        return ovabrw_get_template( 'single/table-price/seasons_hour.php', [
            'product_id' => $product_id
        ]);
    }
}

/**
 * Hook: ovabrw_table_price_period_time
 * @hooked: ovabrw_table_price_period_time - 10
 */
add_action( 'ovabrw_table_price_period_time', 'ovabrw_table_price_period_time', 10, 1 );
if ( !function_exists( 'ovabrw_table_price_period_time' ) ) {
    function ovabrw_table_price_period_time( $product_id ) {
        return ovabrw_get_template( 'single/table-price/period_time.php', [
            'product_id' => $product_id
        ]);
    }
}

/**
 * Hook: ovabrw_request_booking_form
 * @hooked: ovabrw_request_booking_form - 10
 */
add_action( 'ovabrw_request_booking_form', 'ovabrw_request_booking_form', 10, 0 );
if ( !function_exists( 'ovabrw_request_booking_form' ) ) {
    function ovabrw_request_booking_form() {
        return ovabrw_get_template( 'single/request_booking.php' );
    }
}

// Register in wc_order_statuses.
add_filter( 'wc_order_statuses', 'wc_closed_order_statuses' );
if ( !function_exists( 'wc_closed_order_statuses' ) ) {
    function wc_closed_order_statuses( $order_statuses ) {
        $order_statuses['wc-closed'] = _x( 'Closed', 'Order status', 'ova-brw' );

        return $order_statuses;
    }
}

// Replace product link in Search Result Page
add_filter( 'woocommerce_loop_product_link', 'ovarbrw_woocommerce_loop_product_link', 10, 1 );
if ( !function_exists( 'ovarbrw_woocommerce_loop_product_link' ) ) {
    function ovarbrw_woocommerce_loop_product_link( $product_link ) {
        if ( isset( $_GET['ovabrw_search'] ) ) {
            if ( isset( $_GET['ovabrw_pickup_date'] ) && $_GET['ovabrw_pickup_date'] ) {
                $product_link = add_query_arg( 'pickup_date', $_GET['ovabrw_pickup_date'], $product_link );
            }
            if ( isset( $_GET['ovabrw_pickoff_date'] ) && $_GET['ovabrw_pickoff_date'] ) {
                $product_link = add_query_arg( 'dropoff_date', $_GET['ovabrw_pickoff_date'], $product_link );
            }
            if ( isset( $_GET['ovabrw_pickup_loc'] ) && $_GET['ovabrw_pickup_loc'] ) {
                $product_link = add_query_arg( 'pickup_loc', $_GET['ovabrw_pickup_loc'], $product_link );
            }
            if ( isset( $_GET['ovabrw_pickoff_loc'] ) && $_GET['ovabrw_pickoff_loc'] ) {
                $product_link = add_query_arg( 'pickoff_loc', $_GET['ovabrw_pickoff_loc'], $product_link );
            }
        }

        return $product_link;
    }
}

add_filter( 'woocommerce_loop_add_to_cart_link', 'ovarbrw_woocommerce_loop_add_to_cart_link', 10, 3 );
if ( ! function_exists( 'ovarbrw_woocommerce_loop_add_to_cart_link' ) ) {
    function ovarbrw_woocommerce_loop_add_to_cart_link( $link, $product, $args ) {
        $product_link = $product->add_to_cart_url();

        if ( isset( $_GET['ovabrw_search'] ) ) {
            if ( isset( $_GET['ovabrw_pickup_date'] ) && $_GET['ovabrw_pickup_date'] ) {
                $product_link = add_query_arg( 'pickup_date', $_GET['ovabrw_pickup_date'], $product_link );
            }
            if ( isset( $_GET['ovabrw_pickoff_date'] ) && $_GET['ovabrw_pickoff_date'] ) {
                $product_link = add_query_arg( 'dropoff_date', $_GET['ovabrw_pickoff_date'], $product_link );
            }
            if ( isset( $_GET['ovabrw_pickup_loc'] ) && $_GET['ovabrw_pickup_loc'] ) {
                $product_link = add_query_arg( 'pickup_loc', $_GET['ovabrw_pickup_loc'], $product_link );
            }
            if ( isset( $_GET['ovabrw_pickoff_loc'] ) && $_GET['ovabrw_pickoff_loc'] ) {
                $product_link = add_query_arg( 'pickoff_loc', $_GET['ovabrw_pickoff_loc'], $product_link );
            }
        }
        
        return sprintf(
            '<a href="%s" data-quantity="%s" class="%s" %s>%s</a>',
            esc_url( $product_link ),
            esc_attr( isset( $args['quantity'] ) ? $args['quantity'] : 1 ),
            esc_attr( isset( $args['class'] ) ? $args['class'] : 'button' ),
            isset( $args['attributes'] ) ? wc_implode_html_attributes( $args['attributes'] ) : '',
            esc_html( $product->add_to_cart_text() )
        );
    }
}

// Allow users cancel Order
add_filter( 'woocommerce_valid_order_statuses_for_cancel', 'ovabrw_woo_valid_order_statuses_for_cancel', 10, 2 );
if ( ! function_exists( 'ovabrw_woo_valid_order_statuses_for_cancel' ) ) {
    function ovabrw_woo_valid_order_statuses_for_cancel( $array_status, $order ) {
        $order_status_can_cancel = $time_can_cancel = $other_condition = $total_order_valid = true;
         
        if ( in_array( $order->get_status(), array( 'pending', 'failed' ) ) ) {
            return array( 'pending', 'failed' );
        }

        // Check order status can order
        if ( !in_array( $order->get_status(), apply_filters( 'ovabrw_order_status_can_cancel', array( 'completed', 'processing', 'on-hold', 'pending', 'failed' ) ) )  ){
            $order_status_can_cancel = false;
        }
        
        // Validate before x hours can cancel
        // Get Meta Data type line_item of Order
        $order_line_items = $order->get_items( apply_filters( 'woocommerce_purchase_order_item_types', 'line_item' ) );
        foreach( $order_line_items as $item_id => $item ) {
            $product_id = $item->get_product_id();
            $product    = wc_get_product( $product_id );

            if ( ! $product ) continue;

            $cancel_valid_minutes   = floatval( get_option( 'ova_brw_cancel_before_x_hours', 0 ) );
            $cancel_valid_total     = floatval( get_option( 'ova_brw_cancel_condition_total_order', 1 ) );

            // Check if product type is rental
            if ( $product->get_type() == 'ovabrw_car_rental' ) {
                // Get value of pickup date, pickoff date
                if ( $item && is_object( $item ) ) {
                    $ovabrw_pickup_date = strtotime( $item->get_meta('ovabrw_pickup_date') );

                    if ( ! ( $ovabrw_pickup_date > current_time( 'timestamp' ) && $ovabrw_pickup_date - current_time( 'timestamp' ) > $cancel_valid_minutes*60*60  ) ) {
                       $time_can_cancel = false;
                       break;
                    }
                }
            }
        }

        // Cancel by total order
        if ( empty( $cancel_valid_total ) ) {
            $total_order_valid = true;
        } else if ( $order->get_total() > floatval( $cancel_valid_total ) ) {
            $total_order_valid = false;
        }
        
        // Other condition
        $other_condition = apply_filters( 'ovabrw_other_condition_to_cancel_order', true, $order );
        if ( $order_status_can_cancel && $time_can_cancel && $total_order_valid && $other_condition ) {
            return array( 'completed', 'processing', 'on-hold', 'pending', 'failed' );
        } else {
            return array();
        }
    }
}

if ( ! function_exists( 'ovabrw_woo_new_product_tab' ) ) {
    function ovabrw_woo_new_product_tab( $tabs ) {
        // Add Request Booking Tab
        $product_id = get_the_id();
        $product    = wc_get_product( $product_id );

        if ( $product ) {
            // Check product template
            $flag = true;

            $product_template = get_post_meta( $product_id, 'ovabrw_product_template', true );

            if ( 'global' === $product_template ) {
                $product_template = get_option( 'ova_brw_template_elementor_template', 'default' );

                if ( ovabrw_global_typography() && $product_template === 'modern' ) {
                    $template_by_category = ovabrw_get_product_template( $product_id );

                    if ( $template_by_category && $template_by_category !== 'modern' ) {
                        $flag = true;
                    } else {
                        $flag = false;
                    }
                }
            }

            if ( 'yes' == get_option( 'ova_brw_template_show_request_booking', 'yes' ) && $product->get_type() == 'ovabrw_car_rental' && apply_filters( 'ovabrw_ft_show_request_booking_in_product_tabs', $flag ) ) {
                $tabs['ovabrw_reqest_booking'] = array(
                    'title'     => esc_html__( 'Request for booking', 'ova-brw' ),
                    'priority'  => (int)get_option( 'ova_brw_request_booking_form_order_tab', 9 ),
                    'callback'  => 'ovabrw_woo_request_booking_tab_content'
                );
            }

            // Add Extra Tab
            $ovabrw_manage_extra_tab = get_post_meta( $product_id, 'ovabrw_manage_extra_tab', true );

            switch( $ovabrw_manage_extra_tab ) {
                case 'in_setting' : {
                    $short_code_form = get_option('ova_brw_extra_tab_shortcode_form', '');
                    break;
                }
                case 'new_form' : {
                    $short_code_form = get_post_meta( $product_id, 'ovabrw_extra_tab_shortcode', true );
                    break;
                }
                case 'no' : {
                    $short_code_form = '';
                    break;
                }
                default: {
                    $short_code_form = get_option('ova_brw_extra_tab_shortcode_form', '');
                    break;
                }
            }

            if ( !$product || $product->get_type() !== 'ovabrw_car_rental' ) return $tabs;

            // Extra tab
            if ( 'yes' == get_option( 'ova_brw_template_show_extra_tab', 'yes' ) && $short_code_form != ''   ) {
                $tabs['ovabrw_extra_tab'] = array(
                    'title'     => esc_html__( 'Extra Tab', 'ova-brw' ),
                    'priority'  => (int)get_option( 'ova_brw_extra_tab_order_tab', 21 ),
                    'callback'  => 'ova_new_product_tab_extra_tab'
                );
            }

            // Product place
            if ( get_option( 'ova_brw_template_show_place', 'yes' ) === 'yes' && get_option( 'ova_brw_google_key_map' ) ) {

                $latitude   = ovabrw_get_post_meta( $product->get_id(), 'latitude' );
                $longitude  = ovabrw_get_post_meta( $product->get_id(), 'longitude' );

                if ( $latitude && $longitude ) {
                    // Enqueue Map
                    wp_enqueue_script( 'ovabrw-google-maps','https://maps.googleapis.com/maps/api/js?key='.get_option( 'ova_brw_google_key_map', '' ).'&loading=async&callback=Function.prototype&libraries=places', false, true );

                    $tabs['ovabrw_product_place'] = array(
                        'title'     => esc_html__( 'Place', 'ova-brw' ),
                        'priority'  => (int) get_option( 'ova_brw_product_place_priority', 22 ),
                        'callback'  => 'ovabrw_product_tab_product_place'
                    );
                }
            }
        }
        return $tabs;
    }
}

// Request booking tab callback
if ( ! function_exists( 'ovabrw_woo_request_booking_tab_content' ) ) {
    function ovabrw_woo_request_booking_tab_content() { 
       return ovabrw_get_template( 'single/request_booking.php' );
    }
}

// Extra tab callback
if ( ! function_exists( 'ova_new_product_tab_extra_tab' ) ) {
    function ova_new_product_tab_extra_tab() {
        return ovabrw_get_template( 'single/contact_form.php' );
    }
}

// Product place tab callback
if ( ! function_exists( 'ovabrw_product_tab_product_place' ) ) {
    function ovabrw_product_tab_product_place() {
        global $product;

        if ( $product && $product->is_type('ovabrw_car_rental') ) {
            $product_id = $product->get_id();
            $zoom       = (int) get_option( 'ova_brw_google_map_zoom', 17 );
            $address    = ovabrw_get_post_meta( $product_id, 'address' );
            $latitude   = ovabrw_get_post_meta( $product_id, 'latitude' );
            $longitude  = ovabrw_get_post_meta( $product_id, 'longitude' );

            // Check latitude & longitude
            if ( !$latitude || !$longitude ) return;

            return ovabrw_get_template( 'modern/single/detail/ovabrw-product-place.php', array(
                'product_id'    => $product_id,
                'zoom'          => $zoom,
                'latitude'      => $latitude,
                'longitude'     => $longitude,
                'address'       => $address
            ));
        }
    }
}

// Check booked orders when product hide drop-off date
add_filter( 'ovabrw_check_equal_booking_times', function( $result, $product_id ) {
    $show_pickoff_date = ovabrw_show_date( $product_id, 'dropoff' );

    if ( ! $show_pickoff_date ) return true;

    return $result;
}, 10, 2 );

// Product Detail - Show/Hide element
add_action( 'init', function() {
    // Feature Image/ Gallery
    if ( get_option( 'ova_brw_template_feature_image', 'yes' ) !== 'yes' ) {
        remove_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_images', 20 );
    }

    // Title
    if ( get_option( 'ova_brw_template_show_title', 'yes' ) !== 'yes' ) {
        remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_title', 5 );
    }

    // Price
    if ( get_option( 'ova_brw_template_show_price', 'yes' ) !== 'yes' ) {
        remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 10 );
    }

    // Meta
    if ( get_option( 'ova_brw_template_show_meta', 'yes' ) !== 'yes' ) {
        remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40 );
    }

    // Review
    if ( get_option( 'ova_brw_template_show_review_product', 'yes' ) !== 'yes' ) {
        remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_rating', 10 );
    }

    // Related
    if ( get_option( 'ova_brw_template_show_related_product', 'yes' ) !== 'yes' ) {
        remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );
    }
});
// Product Review
add_filter( 'woocommerce_product_tabs', function( $product_tabs ) {
    if ( get_option( 'ova_brw_template_show_review_product', 'yes' ) !== 'yes' && isset( $product_tabs['reviews'] ) ) {
        unset( $product_tabs['reviews'] );
    }

    return $product_tabs;
}, 11 );

// Woo webhook - Add request booking
add_filter( 'woocommerce_webhook_topic_hooks', function( $topic_hooks, $wc_webhook ) {
    $topic_hooks['ovabrw.request_booking'] = [
        'ovabrw_mail_request_booking_sent'
    ];

    return $topic_hooks;
}, 10, 2 );

// Woo valid webhook resource
add_filter( 'woocommerce_valid_webhook_resources', function( $valid_resources ) {
    $valid_resources[] = 'ovabrw';

    return $valid_resources;
});

// Woo valid webhook events
add_filter( 'woocommerce_valid_webhook_events', function( $valid_events ) {
    $valid_events[] = 'request_booking';

    return $valid_events;
});

// Woo webhook - View request booking
add_filter( 'woocommerce_webhook_topics', function( $topics ) {
    $topics['ovabrw.request_booking'] = esc_html__( 'Booking request successful', 'ova-brw' );

    return $topics;
});

// Woo webhook - send data request
add_action( 'woocommerce_webhook_payload', function( $payload, $resource, $resource_id, $id ) {
    if ( 'ovabrw' === $resource ) {
        $payload = $resource_id;
    }

    return $payload;
}, 10, 4 );