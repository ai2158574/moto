<?php defined( 'ABSPATH' ) || exit();

if ( ! class_exists( 'OVABRW_Ajax' ) ) {
	class OVABRW_Ajax {
		public function __construct() {
			$this->init();
		}

		public function init() {
			$arr_ajax = [
				'load_name_product',
				'load_tag_product',
				'get_package_by_time',
				'calculate_total',
				'get_tax_in_cat',
				'search_map',
				'product_ajax_filter',
				'search_taxi_ajax',
				'verify_reCAPTCHA',
				'loading_datetimepicker',
				'get_time_slots',
				'time_slots_location'
			];

			foreach ( $arr_ajax as $name ) {
				add_action( 'wp_ajax_'.OVABRW_PREFIX.$name, array( $this, OVABRW_PREFIX.$name ) );
				add_action( 'wp_ajax_nopriv_'.OVABRW_PREFIX.$name, array( $this, OVABRW_PREFIX.$name ) );
			}
		}

		public function ovabrw_load_name_product() {
			// Check security
			check_admin_referer( 'ovabrw-security-ajax', 'security' );

			// Get keyword
			$keyword 	= sanitize_text_field( ovabrw_get_meta_data( 'keyword', $_POST ) );
			$the_query 	= new WP_Query([
				'post_type' 		=> 'product',
				's' 				=> preg_replace( "/[^a-zA-Z]+/", " ", $keyword ),
				'posts_per_page' 	=> '10'
			]);

			// Title
			$title = [];

			if ( $the_query->have_posts() ) :
				while ( $the_query->have_posts() ): $the_query->the_post();
					$title[] = html_entity_decode( get_the_title() );
				endwhile;
				wp_reset_postdata();  
			endif;

			echo json_encode( $title );
			wp_die();
		}

		public function ovabrw_load_tag_product() {
			// Check security
			check_admin_referer( 'ovabrw-security-ajax', 'security' );

			// Get keyword
			$keyword = sanitize_text_field( ovabrw_get_meta_data( 'keyword', $_POST ) );

		    $the_query = new WP_Term_Query([
		    	'taxonomy' 	=> 'product_tag',
		        'search' 	=> $keyword
		    ]);

		    // Title
		    $title = [];

		    if ( $the_query->terms ) {
		        foreach ( $the_query->terms as $term ) {
		            $title[] =  $term->name;
		        }
		        wp_reset_postdata();  
		    }

			echo json_encode($title);
			wp_die();
		}

		public function ovabrw_get_package_by_time() {
			// Check security
			check_admin_referer( 'ovabrw-security-ajax', 'security' );

			$product_id = sanitize_text_field( ovabrw_get_meta_data( 'product_id', $_POST ) );
			$start_date = strtotime( ovabrw_get_meta_data( 'start_date', $_POST ) );

		    // Get list package of period time
			$package_ids 	= get_post_meta( $product_id, 'ovabrw_petime_id', true );
			$package_labels = get_post_meta( $product_id, 'ovabrw_petime_label', true );

			// Package available
		    $package_available 	= [
		    	'' => esc_html__( 'Select Package', 'ova-brw' )
		    ];

			if ( ovabrw_array_exists( $package_ids ) ) {
				foreach ( $package_ids as $k => $package_id ) {
					$package_label = ovabrw_get_meta_data( $k, $package_labels );

					// Get start date, end date
					$new_input_date = ovabrw_new_input_date( $product_id, $start_date, '', $package_id, '', '' );

					$pickup_date_new    = $new_input_date['pickup_date_new'];
	        		$pickoff_date_new   = $new_input_date['pickoff_date_new'];
	        		$check_vehicle 		= ova_validate_manage_store( $product_id, $pickup_date_new, $pickoff_date_new, '', '', false, 'search', 1 );
				
					if ( $check_vehicle && $check_vehicle['status'] && ( $check_vehicle['vehicle_availables'] || $check_vehicle['number_vehicle_available'] ) ) {
						$package_available[$package_id] = $package_label;
					}
				}
			}

			if ( empty( $package_available ) || count( $package_available ) <= 1 ) {
				$package_available = [
					'' => esc_html__( 'There are no packages', 'ova-brw' )
				];
			}
			
			echo json_encode( $package_available );
			wp_die();
		}

		public function ovabrw_calculate_total() {
			// Check security
			check_admin_referer( 'ovabrw-security-ajax', 'security' );
			
			$product_id 	= sanitize_text_field( ovabrw_get_meta_data( 'id', $_POST ) );
			$pickup_loc 	= sanitize_text_field( ovabrw_get_meta_data( 'pickup_loc', $_POST ) );
			$dropoff_loc 	= sanitize_text_field( ovabrw_get_meta_data( 'dropoff_loc', $_POST ) );
			$pickup_date 	= sanitize_text_field( ovabrw_get_meta_data( 'pickup_date', $_POST ) );
			$dropoff_date 	= sanitize_text_field( ovabrw_get_meta_data( 'dropoff_date', $_POST ) );
			$package_id 	= sanitize_text_field( ovabrw_get_meta_data( 'package_id', $_POST ) );
			$quantity 		= sanitize_text_field( ovabrw_get_meta_data( 'quantity', $_POST, 1 ) );
			$deposit 		= sanitize_text_field( ovabrw_get_meta_data( 'deposit', $_POST ) );
			$resources 		= str_replace( '\\', '', ovabrw_get_meta_data( 'resources', $_POST ) );
			$resources_qty 	= str_replace( '\\', '', ovabrw_get_meta_data( 'resources_qty', $_POST ) );
			$services 		= str_replace( '\\', '', ovabrw_get_meta_data( 'services', $_POST ) );
			$services_qty 	= str_replace( '\\', '', ovabrw_get_meta_data( 'services_qty', $_POST ) );
			$custom_ckf 	= str_replace( '\\', '', ovabrw_get_meta_data( 'custom_ckf', $_POST ) );
			$custom_ckf_qty = str_replace( '\\', '', ovabrw_get_meta_data( 'custom_ckf_qty', $_POST ) );
			$custom_ckf 	= (array) json_decode( $custom_ckf );
			$custom_ckf_qty = (array) json_decode( $custom_ckf_qty );
			$services 		= (array) json_decode( $services );
			$services_qty 	= (array) json_decode( $services_qty );
			$resources 		= (array) json_decode( $resources );
			$resources_qty 	= (array) json_decode( $resources_qty );

			// Taxi
			$duration_map 	= sanitize_text_field( ovabrw_get_meta_data( 'duration_map', $_POST ) );
			$duration 		= sanitize_text_field( ovabrw_get_meta_data( 'duration', $_POST, 0 ) );
			$distance 		= sanitize_text_field( ovabrw_get_meta_data( 'distance', $_POST ) );
			$extra_time 	= sanitize_text_field( ovabrw_get_meta_data( 'extra_time', $_POST ) );

			// Rental Type
			$rental_type = ovabrw_get_post_meta( $product_id, 'price_type' );

			// Object Rental Types
        	$rental_object = isset( OVABRW_Rental_Types::instance()->rental_types[$rental_type] ) ? OVABRW_Rental_Types::instance()->rental_types[$rental_type] : '';

        	if ( empty( $rental_object ) || !is_object( $rental_object ) ) {
        		echo 0;
				wp_die();
        	}

        	// Set Product ID
        	$rental_object->set_ID( $product_id );

        	$new_date = [
        		'pickup_date_new' 	=> '',
        		'dropoff_date_new' 	=> '',
        	];

        	switch ( $rental_type ) {
        		case 'day':
        			$new_date = $rental_object->get_strtotime_input_date( strtotime( $pickup_date ), strtotime( $dropoff_date ) );
        			break;
        		case 'hour':
        			$new_date = $rental_object->get_strtotime_input_date( strtotime( $pickup_date ), strtotime( $dropoff_date ) );
        			break;
        		case 'mixed':
        			$new_date = $rental_object->get_strtotime_input_date( strtotime( $pickup_date ), strtotime( $dropoff_date ) );
        			break;
        		case 'period_time':
        			$new_date = $rental_object->get_strtotime_input_date( strtotime( $pickup_date ), $package_id );
        			break;
        		case 'transportation':
        			$new_date = $rental_object->get_strtotime_input_date( strtotime( $pickup_date ), strtotime( $dropoff_date ), $pickup_loc, $dropoff_loc );
        			break;
        		case 'taxi':
        			$new_date = $rental_object->get_strtotime_input_date( $pickup_date, $duration );
        			break;
        		case 'hotel':
        			$new_date = $rental_object->get_strtotime_input_date( strtotime( $pickup_date ), strtotime( $dropoff_date ) );
        			break;
        		case 'appointment':
        			$new_date = $rental_object->get_strtotime_input_date( strtotime( $pickup_date ), strtotime( $dropoff_date ) );
        			break;
        		default:
        			break;
        	}

			// Ajax Validation Booking
			$validation_booking = $rental_object->ovabrw_ajax_validation_booking( $new_date['pickup_date_new'], $new_date['dropoff_date_new'], $_POST );

			if ( $validation_booking ) {
				$total['error'] = $validation_booking;
				echo json_encode( $total ); wp_die();
			}

			// Check available quantity
	        $data_available = $rental_object->get_qty_available( $new_date['pickup_date_new'], $new_date['dropoff_date_new'], $pickup_loc, $dropoff_loc, 'cart' );
	        $qty_available 	= $data_available['qty_available'];

	        if ( $quantity > $qty_available ) {
	        	if ( $qty_available > 0 ) {
	        		$total['error'] = sprintf( esc_html__( 'Items available: %s', 'ova-brw'  ), $qty_available );
	        	} else {
	        		$total['error'] = esc_html__( 'Out stock!', 'ova-brw' );
	        	}

                echo json_encode( $total ); wp_die();
	        }

	        // Qty available
		    $total['number_vehicle_available'] = $qty_available;

	        // Add Cart item
	        $cart_item = [
	        	'ovabrw_checkin' 		=> $new_date['pickup_date_new'],
	        	'ovabrw_checkout' 		=> $new_date['dropoff_date_new'],
	        	'ovabrw_pickup_loc' 	=> $pickup_loc,
	        	'ovabrw_pickoff_loc' 	=> $dropoff_loc,
	        	'package_id' 			=> $package_id,
	        	'ovabrw_number_vehicle' => $quantity,
	        	'custom_ckf' 			=> $custom_ckf,
	        	'custom_ckf_qty' 		=> $custom_ckf_qty,
	        	'resources' 			=> $resources,
	        	'resources_qty' 		=> $resources_qty,
	        	'ovabrw_service' 		=> $services,
	        	'ovabrw_service_qty' 	=> $services_qty,
	        	'ova_type_deposit' 		=> $deposit,
	        	'duration_map' 			=> $duration_map,
	        	'duration' 				=> $duration,
	        	'distance' 				=> $distance,
	        	'extra_time' 			=> $extra_time,
	        ];

	        // Get line total
			$line_total = $rental_object->get_total( $cart_item );

			$insurance_amount = floatval( $rental_object->get_value( 'amount_insurance' ) ) * $quantity;

			// Multi Currency
        	if ( is_plugin_active( 'woocommerce-multilingual/wpml-woocommerce.php' ) ) {
                $line_total 		= ovabrw_convert_price( $line_total );
                $insurance_amount 	= ovabrw_convert_price( $insurance_amount );
            }

            // Total amount
            $total_amount = $line_total;
            if ( $insurance_amount ) $total_amount += $insurance_amount;

            // Deposit
            if ( 'deposit' === $deposit ) {
            	$deposit_type 	= $rental_object->get_value( 'type_deposit' );
            	$deposit_value 	= floatval( $rental_object->get_value( 'amount_deposit' ) );

            	// Calculate deposit
            	if ( 'percent' === $deposit_type ) { // Percent
            		$line_total = floatval( ( $line_total * $deposit_value ) / 100 );

            		if ( $insurance_amount && OVABRW()->options->remaining_amount_incl_insurance() ) {
		            	$insurance_amount = floatval( ( $insurance_amount * $deposit_value ) / 100 );
		            }
            	} elseif ( 'value' === $deposit_type ) { // Fixed
            		$line_total = floatval( $deposit_value );
            	}
            }

            // Insurance amount
            if ( $insurance_amount ) {
            	$line_total += $insurance_amount;

            	$insurance_html = sprintf( esc_html__( '(includes %s insurance)', 'ova-brw' ), ovabrw_wc_price( $insurance_amount ) );

            	$total['amount_insurance'] = apply_filters( 'ovabrw_ajax_insurance_html', $insurance_html, $product_id );
            }
			
			if ( $line_total <= 0 && apply_filters( 'ovabrw_required_total', false ) ) {
				echo 0;	
			} else {
				if ( 'deposit' === $deposit ) {
					$line_total = wp_kses_post( sprintf( __( 'Deposit: <span class="show_total">%s</span> (of %s)', 'ova-brw' ), ovabrw_wc_price( $line_total ), ovabrw_wc_price( $total_amount ) ) );
				} else {
					$line_total = wp_kses_post( sprintf( __( 'Total: <span class="show_total">%s</span>', 'ova-brw' ), ovabrw_wc_price( $line_total ) ) );
				}

				// Tax enabled
				if ( wc_tax_enabled() && apply_filters( 'ovabrw_show_tax_label', true ) ) {
					$product = wc_get_product( $product_id );

					if ( $product->is_taxable() && !wc_prices_include_tax() ) {
						$line_total .= ' <small class="tax_label">'.esc_html__( '(excludes tax)', 'ova-brw' ).'</small>';
					}
				}

				$total['line_total'] = apply_filters( 'ovabrw_ajax_total_filter', $line_total, $product_id );
				echo json_encode($total);
			}

			wp_die();
		}

		public function ovabrw_get_tax_in_cat() {
			// Check security
			check_admin_referer( 'ovabrw-security-ajax', 'security' );

			$category 			= ovabrw_get_meta_data( 'cat_val', $_POST );
			$list_tax_values 	= [];
			$get_term 			= get_term_by( 'slug', $category, 'product_cat' );
			$term_id 			= $get_term->term_id;
			$custom_taxonomies 	= get_term_meta( $term_id, 'ovabrw_custom_tax', true );
					
			if ( ovabrw_array_exists( $custom_taxonomies ) ) {
				foreach ( $custom_taxonomies as $key => $value ) {
					if ( $value && !in_array( $value, $list_tax_values ) ) {
						array_push( $list_tax_values, $value );
					}
				}
			}

			echo implode(",", $list_tax_values ); 
			wp_die();
		}

		public function ovabrw_search_map() {
			// Check security
			check_admin_referer( 'ovabrw-security-ajax', 'security' );

			$data = $_POST;
			$map_lat 	= floatval( ovabrw_get_meta_data( 'map_lat', $_POST ) );
			$map_lng 	= floatval( ovabrw_get_meta_data( 'map_lng', $_POST ) );
			$radius 	= floatval( ovabrw_get_meta_data( 'radius', $_POST, 50 ) );

			// Get post in
			$post_in 		= $arr_distance = array();
			$product_ids 	= OVABRW()->options->get_products_rental();

			if ( $map_lat && $map_lng ) {
				foreach ( $product_ids as $product_id ) {
					/* Latitude Longitude Search */
					$lat_search = deg2rad($map_lat);
					$lng_search = deg2rad($map_lng);

					/* Latitude Longitude Post */
					$lat_post = ovabrw_get_post_meta( $product_id, 'latitude' );
					$lng_post = ovabrw_get_post_meta( $product_id, 'longitude' );

					if ( !$lat_post || !$lng_post ) continue;

					$lat_post = deg2rad( $lat_post );
					$lng_post = deg2rad( $lng_post );

					$lat_delta = $lat_post - $lat_search;
					$lon_delta = $lng_post - $lng_search;

					// $angle = 2 * asin(sqrt(pow(sin($lat_delta / 2), 2) + cos($lat_search) * cos($lat_post) * pow(sin($lon_delta / 2), 2)));
					$angle = acos(sin($lat_search) * sin($lat_post) + cos($lat_search) * cos($lat_post) * cos($lng_search - $lng_post));

					/* 6371 = the earth's radius in km */
					/* 3959 = the earth's radius in mi */
					$distance =  6371 * $angle;

					if ( $distance <= $radius || !$map_lat ) {
						array_push( $arr_distance, $distance );
						array_push( $post_in, $product_id );
					}
				}

				wp_reset_postdata();
				array_multisort($arr_distance, $post_in);
			} else {
				foreach ( $product_ids as $product_id )  {
					array_push( $post_in, $product_id );
				}
			}

			if ( $map_lat && ! $post_in ) {
				$post_in = array('');
			}
			/***** End Query Radius *****/

			$sort 			= sanitize_text_field( ovabrw_get_meta_data( 'sort', $_POST ) );
			$order 			= sanitize_text_field( ovabrw_get_meta_data( 'order', $_POST ) );
			$orderby 		= sanitize_text_field( ovabrw_get_meta_data( 'orderby', $_POST ) );
			$per_page 		= sanitize_text_field( ovabrw_get_meta_data( 'per_page', $_POST ) );
			$paged 			= (int)ovabrw_get_meta_data( 'paged', $_POST, 1 );
			$name 			= sanitize_text_field( ovabrw_get_meta_data( 'name', $_POST ) );
		    $pickup_loc 	= sanitize_text_field( ovabrw_get_meta_data( 'pickup_loc', $_POST ) );
		    $pickoff_loc 	= sanitize_text_field( ovabrw_get_meta_data( 'dropoff_loc', $_POST ) );
		    $pickup_date 	= strtotime( ovabrw_get_meta_data( 'start_date', $_POST ) );
		    $pickoff_date 	= strtotime( ovabrw_get_meta_data( 'end_date', $_POST ) );
		    $duration 		= (int)ovabrw_get_meta_data( 'ovabrw_package', $_POST );
		    $category 		= sanitize_text_field( ovabrw_get_meta_data( 'cat', $_POST ) );
		    $card 			= sanitize_text_field( ovabrw_get_meta_data( 'card', $_POST ) );
		    $column 		= sanitize_text_field( ovabrw_get_meta_data( 'column', $_POST ) );
		    $attribute 		= sanitize_text_field( ovabrw_get_meta_data( 'attribute', $_POST ) );
		    $attr_value 	= sanitize_text_field( ovabrw_get_meta_data( 'attr_value', $_POST ) );
		    $tags 			= sanitize_text_field( ovabrw_get_meta_data( 'tags', $_POST ) );
		    $taxonomies 	= sanitize_text_field( ovabrw_get_meta_data( 'taxonomies', $_POST ) );
		    $quantity       = (int)sanitize_text_field( ovabrw_get_meta_data( 'quantity', $_POST , 1 ) );
		    $adults         = sanitize_text_field( ovabrw_get_meta_data( 'adults', $_POST ) );
            $children       = sanitize_text_field( ovabrw_get_meta_data( 'children', $_POST ) );
            $babies         = sanitize_text_field( ovabrw_get_meta_data( 'babies', $_POST ) );

            // Taxonomies
		    $taxonomies 	= str_replace( '\\', '',  $taxonomies);
			if ( $taxonomies ) {
				$taxonomies = json_decode( $taxonomies, true );
			}

			// Base query
		    $args_base = [
		    	'post_type'      => 'product',
				'post_status'    => 'publish',
				'posts_per_page' => -1
		    ];

		    // sort
		    $args_orderby 	= $orderby ? [ 'orderby' => $orderby ] : [ 'orderby' => 'title' ];
		    $args_order 	= $order ? [ 'order' => $order ] : [ 'order' => 'DESC' ];

		    switch ( $sort ) {
				case 'date-desc':
					$args_orderby 	= [ 'orderby' => 'date' ];
					$args_order 	= [ 'order' => 'DESC' ];
					$order 			= 'DESC';
					break;
				case 'date-asc':
					$args_orderby 	= [ 'orderby' => 'date' ];
					$args_order 	= [ 'order' => 'ASC' ];
					$order 			= 'ASC';
					break;
				case 'a-z':
					$args_orderby 	= [ 'orderby' => 'title' ];
					$args_order 	= [ 'order' => 'ASC' ];
					$order 			= 'ASC';
					break;
				case 'z-a':
					$args_orderby 	= [ 'orderby' => 'title' ];
					$args_order 	= [ 'order' => 'DESC' ];
					$order 			= 'DESC';
					break;
				case 'rating':
					$args_orderby = [
						'orderby' 	=> 'meta_value_num',
						'meta_key' 	=> '_wc_average_rating'
					];
					break;
				default:
					break;
			}

			$args_basic 	= array_merge_recursive( $args_base, $args_orderby, $args_order );
			$args_radius 	= $args_name = $args_taxonomy = $args_tax_attr = $item_ids = array();

			// Query Result
			if ( $post_in ) {
				$args_radius = [ 'post__in' => $post_in ];
			}

			// Query Name
			if ( $name ) {
				$args_name = [ 's' => preg_replace( "/[^a-zA-Z]+/", " ", $name ) ];
			}

			// Query Categories
			if ( $category ) {
				$args_tax_attr[] = [
		            'taxonomy' 	=> 'product_cat',
		            'field' 	=> 'slug',
		            'terms' 	=> $category
		        ];
			}

			// Query Attribute
			if ( $attribute ) {
		        $args_tax_attr[] = [
		            'taxonomy' 	=> 'pa_' . $attribute,
		            'field' 	=> 'slug',
		            'terms' 	=> [$attr_value],
		            'operator'  => 'IN',
		        ];
		    }

		    // Query Tags
			if ( $tags ) {
				$args_tax_attr[] = [
		            'taxonomy' 	=> 'product_tag',
		            'field' 	=> 'name',
		            'terms' 	=> $tags
		        ];
			}

			// Query taxonomy custom
		    if ( $taxonomies && is_array( $taxonomies ) ) {
		    	foreach ( $taxonomies as $slug => $value) {
		    		$taxo_name = isset( $data[$slug] ) ? sanitize_text_field( $data[$slug] ) : '';
		    		if ( $taxo_name ) {
		    			$args_tax_attr[] = [
				            'taxonomy' 	=> $slug,
				            'field' 	=> 'slug',
				            'terms' 	=> $taxo_name
				        ];
		    		}
		    	}
		    }

			// Query taxonomy
			if ( ! empty( $args_tax_attr )) {
		        $args_taxonomy = [
		        	'tax_query' => [
		        		'relation' => 'AND',
		                $args_tax_attr
		        	]
		        ];
		    }

		     // Meta Query
            $args_meta_query_arr = $meta_query = [];

            // ==> Search by Guest
            if ( $adults != '' ) {
                $args_meta_query_arr[] = [
                    'key'     => 'ovabrw_max_adults',
                    'value'   => $adults,
                    'type'    => 'numeric',
                    'compare' => '>=',
                ];
            }

            if ( $children != '' ) {
                $args_meta_query_arr[] = [
                    'key'     => 'ovabrw_max_children',
                    'value'   => $children,
                    'type'    => 'numeric',
                    'compare' => '>=',
                ];
            }

            if ( $babies != '' ) {
                $args_meta_query_arr[] = [
                    'key'     => 'ovabrw_max_babies',
                    'value'   => $babies,
                    'type'    => 'numeric',
                    'compare' => '>=',
                ];
            }

            if ( !empty( $args_meta_query_arr ) ) {
                $meta_query = [
                	'meta_query' => [
                		'relation' => 'AND',
                        $args_meta_query_arr
                	]
                ];
            }

			$args = array_merge_recursive( $args_basic, $args_radius, $args_name, $args_taxonomy, $meta_query );

			// Get All products
		    $items = new WP_Query( apply_filters( 'ovabrw_ft_items_query_search_map', $args, $data ));

		    if ( $items->have_posts() ) : while ( $items->have_posts() ) : $items->the_post();
		        // Product ID
		        $id = get_the_id();

		        // Check location
                if ( $pickup_loc || $pickoff_loc ) {
                    if ( !ovabrw_check_location( $id, $pickup_loc, $pickoff_loc ) ) continue;
                }

		        // Set Pick-up, Drop-off Date again
		        $new_input_date 	= ovabrw_new_input_date( $id, $pickup_date, $pickoff_date, '', $pickup_loc, $pickoff_loc );
		        $pickup_date_new 	= $new_input_date['pickup_date_new'];
		        $pickoff_date_new 	= $new_input_date['pickoff_date_new'];

		        if ( $duration && $pickup_date_new ) {
		        	$pickoff_date_new = $pickoff_date_new + $duration;
		        }

		        if ( $pickup_date_new && $pickoff_date_new ) {
		        	// Get items available
		        	$items_available = ova_validate_manage_store( $id, $pickup_date_new, $pickoff_date_new, $pickup_loc, $pickoff_loc, $passed = false, $validate = 'search' );
			        
			        if ( $items_available && $items_available['status'] ) {
			        	$number_available = intval( $items_available['number_vehicle_available'] );

		        		if ( $number_available >= $quantity ) {
		        			array_push( $item_ids, $id );
		        		}
			        }
		        } else {
		        	array_push( $item_ids, $id );
		        }
		    endwhile; else :
		        $result = '<div class="not_found_product">'. esc_html( 'No product found', 'ova-brw' ) .'</div>';
		    	$results_found = '<div class="results_found"><span>'. esc_html__( '0 Result Found', 'ova-brw' ) .'</span></div>';
		    endif; wp_reset_postdata();

		    if ( $item_ids ) {
		        $args_product = [
		        	'post_type' 		=> 'product',
		            'posts_per_page' 	=> $per_page,
		            'paged' 			=> $paged,
		            'post_status' 		=> 'publish',
		            'post__in' 			=> $item_ids,
		            'orderby' 			=> 'post__in',
		            'order' 			=> $order ? $order : 'DESC'
		        ];

		        $products = new WP_Query( apply_filters( 'ovabrw_ft_query_search_map', $args_product, $data ));

		        // Card
		        if ( $card == 'card5' || $card == 'card6' ) $column = 'one-column';

		        ob_start();
		        ?>
		        <div class="ovabrw_product_archive <?php echo esc_attr( $column ); ?>">
					<?php
						woocommerce_product_loop_start();
						if ( $products->have_posts() ) : while ( $products->have_posts() ) : $products->the_post();
							$id 			= get_the_id();
							$product 		= wc_get_product( $id );
							$html_price 	= OVABRW()->options->get_html_price( $id );

							if ( $html_price ) {
								$data_html_price = htmlentities( $html_price );
							} else {
								$data_html_price = '';
							}

							$lat_product 	= get_post_meta( $id, 'ovabrw_latitude', true );
							$lng_product 	= get_post_meta( $id, 'ovabrw_longitude', true );

							if ( $card ) {
								$thumbnail_type = get_option( 'ovabrw_glb_'.$card.'_thumbnail_type', 'slider' );

								ovabrw_get_template( 'modern/products/cards/ovabrw-'.$card.'.php', [ 'product_id' => $id, 'thumbnail_type' => $thumbnail_type ] );
							} else {
								wc_get_template_part( 'content', 'product' );
							}

							?>
							<input
								type="hidden"
								class="data_product"
								data-link_product="<?php echo esc_attr( get_the_permalink() ); ?>"
								data-title_product="<?php echo esc_attr( get_the_title() ); ?>"
								data-average_rating="<?php echo $product->get_average_rating(); ?>"
								data-number_comment="<?php echo get_comments_number( $id ); ?>"
								data-map_lat_product="<?php echo $lat_product; ?>"
								data-map_lng_product="<?php echo $lng_product; ?>"
								data-thumbnail_product="<?php echo wp_get_attachment_image_url( get_post_thumbnail_id() , 'thumbnail' ); ?>"
								data-html_price="<?php echo $data_html_price; ?>"
							/>
							<?php
						endwhile; else :
						?>
							<div class="not_found_product"><?php esc_html_e( 'Product not found', 'ova-brw' ); ?></div>
						<?php
						endif; wp_reset_postdata();
						woocommerce_product_loop_end();
					?>
				</div>
		        <?php
		        $total = $products->max_num_pages;

				if (  $total > 1 ): ?>
					<div class="ovabrw_pagination_ajax">
					<?php
						echo OVABRW()->options->get_html_pagination_ajax( $products->found_posts, $products->query_vars['posts_per_page'], $paged );
					?>
					</div>
					<?php
				endif;

				$result = ob_get_contents(); 
				ob_end_clean();

				ob_start();
				?>
					<div class="results_found">
						<?php if ( $products->found_posts == 1 ): ?>
						<span>
							<?php echo sprintf( esc_html__( '%s Result Found', 'ova-brw' ), esc_html( $products->found_posts ) ); ?>
						</span>
						<?php else: ?>
						<span>
							<?php echo sprintf( esc_html__( '%s Results Found', 'ova-brw' ), esc_html( $products->found_posts ) ); ?>
						</span>
						<?php endif; ?>

						<?php if ( 1 == ceil( $products->found_posts/ $products->query_vars['posts_per_page']) && $products->have_posts() ): ?>
							<span>
								<?php echo sprintf( esc_html__( '(Showing 1-%s)', 'ova-brw' ), esc_html( $products->found_posts ) ); ?>
							</span>
						<?php elseif ( !$products->have_posts() ): ?>
							<span></span>
						<?php else: ?>
							<span>
								<?php echo sprintf( esc_html__( '(Showing 1-%s)', 'ova-brw' ), esc_html( $products->query_vars['posts_per_page'] ) ); ?>
							</span>
						<?php endif; ?>
					</div>

				<?php
				$results_found = ob_get_contents();
				ob_end_clean();

				echo json_encode([
					'result' 		=> $result,
					'results_found' => $results_found
				]);
				wp_die();
		    } else {
		    	$result = '<div class="not_found_product">'. esc_html( 'No product found', 'ova-brw' ) .'</div>';
		    	$results_found = '<div class="results_found"><span>'. esc_html__( '0 Result Found', 'ova-brw' ) .'</span></div>';
		    	echo json_encode([
		    		'result' 		=> $result,
		    		'results_found' => $results_found
		    	]);
		    	wp_die();
		    }
		}

		public function ovabrw_product_ajax_filter() {
			// Check security
            check_admin_referer( 'ovabrw-security-ajax', 'security' );

			$term_id 		= ovabrw_get_meta_data( 'term_id', $_POST );
			$template 		= ovabrw_get_meta_data( 'template', $_POST, 'card1' );
			$posts_per_page = ovabrw_get_meta_data( 'posts_per_page', $_POST, 6 );
			$orderby 		= ovabrw_get_meta_data( 'orderby', $_POST, 'ID' );
			$order 			= ovabrw_get_meta_data( 'order', $_POST, 'DESC' );
			$pagination 	= ovabrw_get_meta_data( 'pagination', $_POST );
			$paged 			= ovabrw_get_meta_data( 'paged', $_POST, 1 );

			$products = OVABRW()->options->get_product_ajax_filter([
				'paged' 			=> $paged,
				'posts_per_page' 	=> $posts_per_page,
				'orderby' 			=> $orderby,
				'order' 			=> $order,
				'term_id' 			=> $term_id
			]);

			ob_start();
			if ( $products->have_posts() ) : while ( $products->have_posts() ):
				$products->the_post();

				if ( $template ): ?>
					<li class="item">
						<?php ovabrw_get_template( 'modern/products/cards/ovabrw-'.$template.'.php' ); ?>
					</li>
				<?php else:
					wc_get_template_part( 'content', 'product' );
				endif;
			endwhile; else : ?>
				<div class="not-found">
					<?php esc_html_e( 'Product not found', 'ova-brw' ); ?>
				</div>
			<?php endif; wp_reset_postdata();

			$result = ob_get_contents();
			ob_end_clean();

			ob_start();
			if ( 'yes' == $pagination ) {
				$pages 		= $products->max_num_pages;
				$limit 		= $products->query_vars['posts_per_page'];
				$current 	= $paged;

				if ( $pages > 1 ):
					for ( $i = 1; $i <= $pages; $i++ ): ?>
					<li>
						<span
							class="page-numbers<?php echo $i == $current ? ' current' : ''; ?>"
							data-paged="<?php echo esc_attr( $i ); ?>">
							<?php echo esc_html( $i ); ?>
						</span>
					</li>
				<?php endfor; endif;
			}

			$pagination = ob_get_contents();
			ob_end_clean();

			echo json_encode([
				'result' 		=> $result,
				'pagination' 	=> $pagination
			]);

			wp_die();
		}

		public function ovabrw_search_taxi_ajax() {
			// Check security
            check_admin_referer( 'ovabrw-security-ajax', 'security' );

			$origin 		= ovabrw_get_meta_data( 'origin_locaiton', $_POST );
			$destination 	= ovabrw_get_meta_data( 'destination_location', $_POST );
			$duration 		= ovabrw_get_meta_data( 'duration', $_POST );
			$distance 		= ovabrw_get_meta_data( 'distance', $_POST );
			$pickup_date 	= ovabrw_get_meta_data( 'pickup_date', $_POST );
			$dropoff_date 	= '';
			$category 		= ovabrw_get_meta_data( 'category', $_POST );
			$number_seats 	= ovabrw_get_meta_data( 'number_seats', $_POST );
			$quantity 		= ovabrw_get_meta_data( 'quantity', $_POST );
			$taxonomies 	= ovabrw_get_meta_data( 'taxonomies', $_POST );
			$card 			= ovabrw_get_meta_data( 'card', $_POST, 'card1' );
			$posts_per_page = ovabrw_get_meta_data( 'posts_per_page', $_POST, 6 );
			$column 		= ovabrw_get_meta_data( 'column', $_POST, 'three-column' );
			$term 			= ovabrw_get_meta_data( 'term', $_POST );
			$orderby 		= ovabrw_get_meta_data( 'orderby', $_POST, 'date' );
			$order 			= ovabrw_get_meta_data( 'order', $_POST, 'DESC' );
			$pagination 	= ovabrw_get_meta_data( 'pagination', $_POST );
			$paged 			= ovabrw_get_meta_data( 'paged', $_POST, 1 );

			// Taxonomies
			$taxonomies 	= str_replace( '\\', '',  $taxonomies);
			if ( $taxonomies ) {
				$taxonomies = json_decode( $taxonomies, true );
			}

			// Init
			$item_ids = $tax_query = $taxonomies_query = array();

			// Base query
            $args_base = [
            	'post_type'         => 'product',
                'posts_per_page'    => '-1',
                'post_status'       => 'publish',
                'fields'            => 'ids',
                'tax_query'         => [
                	'relation'      => 'AND',
                    [
                    	'taxonomy'  => 'product_type',
                        'field'     => 'slug',
                        'terms'     => 'ovabrw_car_rental'
                    ]
                ]
            ];

            // Product category
            if ( $category ) {
                $taxonomies_query[] = [
                    'taxonomy'  => 'product_cat',
                    'field'     => 'slug',
                    'terms'     => $category
                ];
            } else {
            	if ( $term ) {
            		$taxonomies_query[] = [
	                    'taxonomy'  => 'product_cat',
	                    'field'     => 'slug',
	                    'terms'     => $term
	                ];
            	}
            }

            // Query taxonomy custom
		    if ( $taxonomies && is_array( $taxonomies ) ) {
		    	foreach ( $taxonomies as $slug => $value) {
		    		$taxonomy_name = isset( $_POST[$slug] ) ? $_POST[$slug] : '';

		    		if ( $taxonomy_name ) {
		    			$taxonomies_query[] = [
				            'taxonomy' 	=> $slug,
				            'field' 	=> 'slug',
				            'terms' 	=> $taxonomy_name
				        ];
		    		}
		    	}
		    }

            if ( ovabrw_array_exists( $taxonomies_query ) ) {
            	$tax_query = [
                    'tax_query' => [
                        $taxonomies_query
                    ]
                ];
            }

            // Meta Query
            $args_meta_query_arr = $meta_query = [];

            // Number seats
            if ( $number_seats ) {
                $args_meta_query_arr[] = [
                    'key'     => 'ovabrw_max_seats',
                    'value'   => $number_seats,
                    'type'    => 'numeric',
                    'compare' => '>=',
                ];
            }

            if ( ovabrw_array_exists( $args_meta_query_arr ) ) {
                $meta_query = [
                	'meta_query' => [
                		'relation'  => 'AND',
                        $args_meta_query_arr
                	]
                ];
            }

            // Merge query
            $args_query = array_merge_recursive( $args_base, $tax_query, $meta_query );

            // Get product ids
            $product_ids = get_posts( $args_query );

            // Taxi
            if ( $pickup_date ) {
            	if ( $duration ) {
            		$dropoff_date = date( 'Y-m-d H:i', strtotime( $pickup_date ) + intval( $duration ) );
            	} else {
            		$dropoff_date = $pickup_date;
            	}
            }

            if ( ! empty( $product_ids ) && is_array( $product_ids ) ) {
                foreach ( $product_ids as $product_id ) {
                    // Check dates
                    if ( strtotime( $pickup_date ) && strtotime( $dropoff_date ) ) {
                        $type = get_post_meta( $product_id, 'ovabrw_price_type', true );

                        // Object Rental Types
                        $rental_object = isset( OVABRW_Rental_Types::instance()->rental_types[$type] ) ? OVABRW_Rental_Types::instance()->rental_types[$type] : '';

                        if ( empty( $rental_object ) || ! is_object( $rental_object ) ) {
                            continue;
                        }

                        // Set Product ID
                        $rental_object->set_ID( $product_id );

                        // Check available quantity
                        $data_available = $rental_object->get_qty_available( strtotime( $pickup_date ), strtotime( $dropoff_date ), '', '', 'search' );

                        if ( ! $data_available ) continue;

                        $qty_available  = intval( $data_available['qty_available'] );

                        if ( $qty_available && $qty_available >= $quantity ) {
                            array_push( $item_ids, $product_id );
                        }
                    } else {
                        array_push( $item_ids, $product_id );
                    }
                }
            }

            $products = '';
            // Get Products
            if ( $item_ids ) {
                $args_query = [
                	'post_type'         => 'product',
                    'posts_per_page'    => $posts_per_page,
                    'paged'             => $paged,
                    'post_status'       => 'publish',
                    'post__in'          => $item_ids,
                    'order'             => $order,
                    'orderby'           => $orderby
                ];

                // Orderby: rating
                if ( 'rating' === $orderby ) {
                	$args_query['orderby'] 	= 'meta_value_num';
                	$args_query['meta_key'] = '_wc_average_rating';
                }

                $products = new WP_Query( $args_query );
            }

            ob_start();
			if ( $products && $products->have_posts() ) : while ( $products->have_posts() ):
				$products->the_post();

				if ( $card ): ?>
					<li class="item">
						<?php ovabrw_get_template( 'modern/products/cards/ovabrw-'.$card.'.php' ); ?>
					</li>
				<?php else:
					wc_get_template_part( 'content', 'product' );
				endif;
			endwhile; else : ?>
				<div class="not-found">
					<?php esc_html_e( 'Product not found', 'ova-brw' ); ?>
				</div>
			<?php endif; wp_reset_postdata();

			$result = ob_get_contents();
			ob_end_clean();

			ob_start();
			if ( 'yes' === $pagination && $products ) {
				$pages 		= $products->max_num_pages;
				$limit 		= $products->query_vars['posts_per_page'];
				$current 	= $paged;

				if ( $pages > 1 ):
					for ( $i = 1; $i <= $pages; $i++ ): ?>
					<li>
						<span
							class="page-numbers<?php echo $i == $current ? ' current' : ''; ?>"
							data-paged="<?php echo esc_attr( $i ); ?>">
							<?php echo esc_html( $i ); ?>
						</span>
					</li>
				<?php endfor; endif;
			}

			$pagination = ob_get_contents();
			ob_end_clean();

			echo json_encode([
				'result' 		=> $result,
				'pagination' 	=> $pagination
			]);
			wp_die();
		}

		public function ovabrw_verify_reCAPTCHA() {
			// Check security
            check_admin_referer( 'ovabrw-security-ajax', 'security' );
			
			if ( !ovabrw_array_exists( $_POST ) ) {
				echo esc_html( ovabrw_get_recaptcha_error() );
				wp_die();
			}

			$token 	= isset( $_POST['token'] ) ? $_POST['token'] : '';
			$mess 	= '';

			if ( 'v2' == ovabrw_get_recaptcha_type() ) {
				$mess = ovabrw_verify_recaptcha_v2( $token );
			} elseif ( 'v3' == ovabrw_get_recaptcha_type() ) {
				$mess = ovabrw_verify_recaptcha_v3( $token );
			}

			echo esc_html( $mess );
			wp_die();
		}

		/**
		 * Loading datetimepicker
		 */
		public function ovabrw_loading_datetimepicker() {
			// Check security
			check_admin_referer( 'ovabrw-security-ajax', 'security' );

			// Get product ID
			$product_id = absint( ovabrw_get_meta_data( 'product_id', $_POST ) );
			if ( !$product_id ) wp_die();

			// Get product object
			$product = wc_get_product( $product_id );
			if ( !$product || !$product->is_type( 'ovabrw_car_rental' ) ) wp_die();

			// Get datepicker options
			$datepicker_options = $product->get_datepicker_options();

			// Get timepicker options
			$timepicker_options = $product->get_timepicker_options();

			if ( ovabrw_array_exists( $datepicker_options ) ) {
				echo wp_json_encode([
					'datePickerOptions' => $datepicker_options,
					'timePickerOptions' => $timepicker_options
				]);
			}

			wp_die();
		}

		/**
		 * Get time slots
		 */
		public function ovabrw_get_time_slots() {
			// Check security
			check_admin_referer( 'ovabrw-security-ajax', 'security' );

			// init results
			$results['error'] = esc_html__( 'There are no time slots available. Please choose another date.', 'ova-brw' );

			// Product ID
			$product_id = (int)ovabrw_get_meta_data( 'product_id', $_POST );

			// Pick-up date
			$pickup_date = strtotime( ovabrw_get_meta_data( 'pickup_date', $_POST ) );

			// Location name
			$location_name = ovabrw_get_meta_data( 'location_name', $_POST );

			// Timeslots name
			$timeslot_name = ovabrw_get_meta_data( 'timeslot_name', $_POST );

			// Use location
			$use_location = ovabrw_get_post_meta( $product_id, 'use_location' );

			if ( $use_location ) {
				// Get time slots
				$time_slots = OVABRW()->options->get_time_slots_use_location( $product_id, $pickup_date );

				if ( ovabrw_array_exists( $time_slots ) ) {
					// Get timeslots location data
					$timeslots_location_data = OVABRW()->options->get_time_slots_location( $time_slots, $location_name );

					// Time slots location HTML
					$timeslots_location = ovabrw_get_meta_data( 'locations', $timeslots_location_data );

					// Default time slots
					$default_timeslots = ovabrw_get_meta_data( 'default_timeslots', $timeslots_location_data );

					// Get time slots data
					$timeslots_data = OVABRW()->options->get_time_slots_html( $default_timeslots, $timeslot_name );

					// Get time slots HTML
					$timeslots_html = ovabrw_get_meta_data( 'timeslots', $timeslots_data );

					if ( $timeslots_location && $timeslots_html ) {
						unset( $results['error'] );

						$results['timeslots_location'] 	= $timeslots_location;
						$results['timeslots_html'] 		= $timeslots_html;

						// Date format
						$date_format = ovabrw_get_date_format();

						// Time format
						$time_format = ovabrw_get_time_format();

						// Get drop-off date
						$results['dropoff_date'] = '';

						// Get end date
						$end_date = ovabrw_get_meta_data( 'end_date', $timeslots_data );

						if ( $end_date ) {
							$results['dropoff_date'] = date( $date_format.' '.$time_format, $end_date );
						}
					}
				}
			} else {
				// Get time slots
				$time_slots = OVABRW()->options->get_time_slots( $product_id, $pickup_date );

				if ( ovabrw_array_exists( $time_slots ) ) {
					// Get time slots data
					$timeslots_data = OVABRW()->options->get_time_slots_html( $time_slots, $timeslot_name );

					// Get time slots HTML
					$timeslots_html = ovabrw_get_meta_data( 'timeslots', $timeslots_data );

					if ( $timeslots_html ) {
						unset( $results['error'] );

						$results['timeslots_html'] = $timeslots_html;

						// Date format
						$date_format = ovabrw_get_date_format();

						// Time format
						$time_format = ovabrw_get_time_format();

						// Get drop-off date
						$results['dropoff_date'] = '';

						// Get end date
						$end_date = ovabrw_get_meta_data( 'end_date', $timeslots_data );

						if ( $end_date ) {
							$results['dropoff_date'] = date( $date_format.' '.$time_format, $end_date );
						}
					}
				}
			}

			echo wp_json_encode( $results );

			wp_die();
		}

		/**
		 * Get time slots location
		 */
		public function ovabrw_time_slots_location() {
			// Check security
			check_admin_referer( 'ovabrw-security-ajax', 'security' );

			// init results
			$results['error'] = esc_html__( 'There are no time slots available. Please choose another location.', 'ova-brw' );

			// Location
			$location = ovabrw_get_meta_data( 'location', $_POST );

			// Time slots data
			$timeslots_data = ovabrw_get_meta_data( 'time_slots', $_POST );

			// Get time slots
			$time_slots = ovabrw_get_meta_data( $location, $timeslots_data );

			if ( ovabrw_array_exists( $time_slots ) ) {
				// Timeslots name
				$timeslot_name = ovabrw_get_meta_data( 'timeslot_name', $_POST );

				// Get time slots data
				$timeslots_data = OVABRW()->options->get_time_slots_html( $time_slots, $timeslot_name );

				// Get time slots HTML
				$timeslots_html = ovabrw_get_meta_data( 'timeslots', $timeslots_data );

				if ( $timeslots_html ) {
					// Timeslots HTML
					$results['timeslots_html'] = $timeslots_html;

					// Start date
					$start_date = ovabrw_get_meta_data( 'start_date', $timeslots_data );

					// Get end date
					$end_date = ovabrw_get_meta_data( 'end_date', $timeslots_data );

					if ( $start_date & $end_date ) {
						unset( $results['error'] );

						// Date format
						$date_format = ovabrw_get_date_format();

						// Time format
						$time_format = ovabrw_get_time_format();

						// Drop-off date
						$results['dropoff_date'] = date( $date_format.' '.$time_format, $end_date );
					}
				}
			}

			echo wp_json_encode( $results );

			wp_die();
		}
	}

	new OVABRW_Ajax();
}