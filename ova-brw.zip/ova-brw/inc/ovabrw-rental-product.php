<?php defined( 'ABSPATH' ) || exit;

/**
 * Rental product class.
 */
class WC_Product_Ovabrw_Car_Rental extends WC_Product {
	/**
     * Initialize tour product.
     *
     * @param WC_Product|int $product Product instance or ID.
     */
    public function __construct( $product = 0 ) {
        parent::__construct( $product );
    }

    /**
     * Get internal type.
     *
     * @return string
     */
    public function get_type() {
        return OVABRW_RENTAL;
    }

    /**
     * Get tour meta key
     * @param  string $key
     * @return string $key
     */
    public function get_meta_key( $key = '' ) {
        if ( $key ) $key = OVABRW_PREFIX.$key;

        return apply_filters( 'ovabrw_product_get_meta_key', $key );
    }

    /**
     * Get meta value by key
     * @param  string $key
     * @param  string $default
     * @return string $value
     */
    public function get_meta_value( $key = '', $default = false ) {
        $value = $this->get_meta( $this->get_meta_key( $key ) );

        if ( ! $value && $default !== false ) $value = $default;

        return apply_filters( 'ovabrw_get_meta_value', $value, $key, $default, $this );
    }

    /**
     * Get Timepicker options
     */
    public function get_timepicker_options() {
    	// Get datepicker options
        $timepicker = OVABRW()->options->get_timepicker_options();

        // Allow start times
        $timepicker['allowStartTimes'] = ovabrw_get_group_time( $this->get_id(), 'start' );

        // Allow end times
        $timepicker['allowEndTimes'] = ovabrw_get_group_time( $this->get_id(), 'end' );

        // Default start time
        $timepicker['defaultStartTime'] = ovabrw_get_default_time( $this->get_id(), 'start' );

        // Default end time
        $timepicker['defaultEndTime'] = ovabrw_get_default_time( $this->get_id(), 'end' );

        return apply_filters( 'ovabrw_get_product_timepicker_options', $timepicker, $this );
    }

    /**
     * Get Datepicker options
     */
    public function get_datepicker_options() {
        // Date format
        $date_format = ovabrw_get_date_format();

        // Time format
        $time_format = ovabrw_get_time_format();

        // Get datepicker options
        $datepicker = OVABRW()->options->get_datepicker_options();

        // Rental type
        $rental_type = $this->get_rental_type();
        $datepicker['rentalType'] = $rental_type;

        // Charged by
        $charged_by = $this->get_meta_value('define_1_day');
        $datepicker['chargedBy'] = $charged_by;

        // Min days
        if ( ( 'day' == $rental_type && 'hotel' == $charged_by ) || 'hotel' == $rental_type ) {
        	// RangePlugin
        	$datepicker['RangePlugin']['locale']['one'] 	= esc_html__( 'night', 'ova-brw' );
        	$datepicker['RangePlugin']['locale']['other'] 	= esc_html__( 'nights', 'ova-brw' );

        	// Min days
        	$min_days = 2;

        	// Product min days
        	$product_min_days = floor( (float)$this->get_meta_value( 'rent_day_min' ) );
        	if ( $product_min_days > 1 ) {
        		$min_days = $product_min_days + 1;
        	}

        	// Add min days
        	$datepicker['LockPlugin']['minDays'] = $min_days;

        	// Product max days
        	$product_max_day = floor( (float)$this->get_meta_value( 'rent_day_max' ) );
        	if ( $product_max_day ) {
        		// Add max days
        		$datepicker['LockPlugin']['maxDays'] = $product_max_day + 1;
        	}
        } elseif ( 'hour' == $rental_type || 'mixed' == $rental_type ) {
        	// RangePlugin
        	$datepicker['RangePlugin']['locale']['one'] 	= esc_html__( 'hour', 'ova-brw' );
        	$datepicker['RangePlugin']['locale']['other'] 	= esc_html__( 'hours', 'ova-brw' );

        	// Product min hours
        	$product_min_hours 	= (float)$this->get_meta_value( 'rent_hour_min' );
        	$product_min_days 	= floor( $product_min_hours / 24 );

        	if ( $product_min_days ) {
        		// Add min days
        		$datepicker['LockPlugin']['minDays'] = $product_min_days;
        	}

        	// Product min hours
        	$product_max_hours 	= (float)$this->get_meta_value( 'rent_hour_max' );
        	$product_max_days 	= floor( $product_max_hours / 24 );

        	if ( $product_max_days ) {
        		// Add max days
        		$datepicker['LockPlugin']['maxDays'] = $product_max_days;
        	}
        } else {
        	// Product min days
        	$product_min_days = floor( (float)$this->get_meta_value( 'rent_day_min' ) );
        	if ( $product_min_days ) {
        		// Add min days
        		$datepicker['LockPlugin']['minDays'] = $product_min_days;
        	}
        	
        	// Product max days
        	$product_max_day = floor( (float)$this->get_meta_value( 'rent_day_max' ) );
        	if ( $product_max_day ) {
        		// Add max days
        		$datepicker['LockPlugin']['maxDays'] = $product_max_day;
        	}
        }

        // Global min date
        $min_date = $datepicker['LockPlugin']['minDate'];

        if ( ! $min_date || strtotime( $min_date ) < current_time( 'timestamp' ) ) {
            $min_date = date( $date_format, current_time( 'timestamp' ) );
        }

        // Preparation time X days from today
        $preparation_time = $this->get_preparation_time();
        if ( $preparation_time && strtotime( $preparation_time ) > strtotime( $min_date ) ) {
            $min_date = $preparation_time;
        }

        // Update min date & start date
        $datepicker['LockPlugin']['minDate']    = $min_date;
        $datepicker['startDate']                = $min_date;
        $datepicker['timestamp'] 				= time();

        // Disable weekdays
        $disable_weekdays = $this->get_disable_weekdays();
        if ( ovabrw_array_exists( $disable_weekdays ) ) {
            $datepicker['disableWeekDays'] = $disable_weekdays;
        }

        // Booked dates
        $booked_dates = OVABRW()->options->get_booked_dates( $this->get_id() );
        if ( ovabrw_array_exists( $booked_dates ) ) {
			$booked_dates = array_map( function( $item ) {
			    return date( ovabrw_get_date_format(), strtotime( $item['start_v2'] ) );
			}, array_filter( $booked_dates, function( $item ) {
			    return ovabrw_get_meta_data( 'rendering', $item ) && strtotime( ovabrw_get_meta_data( 'start_v2', $item ) );
			}));

			if ( ovabrw_array_exists( $booked_dates ) ) {
	            $datepicker['bookedDates'] = ovabrw_array_merge_unique( $datepicker['bookedDates'], $booked_dates );
	        }
        }

        return apply_filters( 'ovabrw_get_product_datepicker_options', $datepicker, $this );
    }

    /**
     * Get Preparation time
     * @return string $date
     */
    public function get_preparation_time() {
        $date = '';

        // Date format
        $date_format = ovabrw_get_date_format();

        // Product preparation time
        $preparation_time = (int)$this->get_meta_value( 'preparation_time' );

        if ( $preparation_time ) {
            if ( $preparation_time === 1 ) {
                $date = date( $date_format, strtotime( '+1 day' ) );
            } else {
                $date = date( $date_format, strtotime( '+'.$preparation_time.' days' ) );
            }
        }

        return apply_filters( 'ovabrw_get_product_preparation_time', $date, $this );
    }

    /**
     * Get disable weekdays
     */
    public function get_disable_weekdays() {
        $disable_weekdays = $this->get_meta_value( 'product_disable_week_day', [] );

		if ( !ovabrw_array_exists( $disable_weekdays ) ) {
		    $disable_weekdays = get_option( 'ova_brw_calendar_disable_week_day', [] );
		}
		if ( ovabrw_array_exists( $disable_weekdays ) ) {
        	$key = array_search( '0', $disable_weekdays );
			if ( $key !== false ) $disable_weekdays[$key] = '7';
        } else {
        	if ( $disable_weekdays && !is_array( $disable_weekdays ) ) {
        		$disable_weekdays = explode( ',', $disable_weekdays );
        		$disable_weekdays = array_map( 'trim', $disable_weekdays );
        	}
        }

        // Rental type: Appointment
        if ( 'appointment' == $this->get_rental_type() ) {
        	$timeslots_start 	= $this->get_meta_value( 'time_slots_start', [] );
        	$timeslots_end 		= $this->get_meta_value( 'time_slots_end', [] );
        	$timeslots_qtys 	= $this->get_meta_value( 'time_slots_quantity', [] );

        	// Weekdays array
	        $weekdays = [
	        	'1' => 'monday',
	            '2' => 'tuesday',
	            '3' => 'wednesday',
	            '4' => 'thursday',
	            '5' => 'friday',
	            '6' => 'saturday',
	            '7' => 'sunday'
	        ];

	        // Today
	        $current_time = current_time( 'timestamp' );

	        // Today of week
	        $todayofweek = OVABRW()->options->get_string_dayofweek( $current_time );

	        // Loop weekdays
	        foreach ( $weekdays as $number_day => $string_day ) {
	        	if ( !in_array( $number_day, $disable_weekdays ) ) {
	        		$start_times 	= ovabrw_get_meta_data( $string_day, $timeslots_start, [] );
	                $quantities 	= ovabrw_get_meta_data( $string_day, $timeslots_qtys, [] );

	                if ( !ovabrw_array_exists( $start_times ) || !ovabrw_array_exists( $quantities ) ) {
	                    $disable_weekdays[] = (string)$number_day;
	                } else {
	                	$is_blocked = false;

	                	foreach ( $start_times as $k => $start_time ) {
	                        $quantity = (int)ovabrw_get_meta_data( $k, $quantities );

	                        if ( $quantity ) {
	                        	$is_blocked = true;
	                        	break;
	                        }
	                    }

	                    // is blocked
	                    if ( !$is_blocked ) {
	                        $disable_weekdays[] = (string)$number_day;
	                    }
	                }
	        	}
	        } // End Loop
        }

        return apply_filters( 'ovabrw_get_product_disable_weekdays', $disable_weekdays, $this );
    }

    /**
     * Get rental type
     */
    public function get_rental_type() {
    	return apply_filters( 'ovabrw_get_rental_type', $this->get_meta_value( 'price_type' ), $this );
    }

    /**
     * Show location
     */
    public function show_location( $type = 'pickup' ) {
    	$rental_type = $this->get_rental_type();

		if ( 'taxi' == $rental_type || 'transportation' == $rental_type ) return true;
		if ( 'hotel' == $rental_type ) return false;

		// Get custom checkout field by Category
		$categories 	= wp_get_post_terms( $this->get_id(), 'product_cat' );
		$category_id 	= isset( $categories[0] ) ? $categories[0]->term_id : '';
		$term_location 	= $category_id ? get_term_meta( $category_id, 'ovabrw_show_loc_booking_form', true ) : [];

		if ( 'pickup' == $type ) {
			$product_show_location = $this->get_meta_value( 'show_pickup_location_product' );
			
			if ( ovabrw_array_exists( $term_location ) && in_array( 'pickup_loc', $term_location ) ) {
				$show_location = 'yes';
			} elseif ( ovabrw_array_exists( $term_location ) && !in_array( 'pickup_loc', $term_location ) ) {
				$show_location = 'no';
			} else {
				$show_location = get_option( 'ova_brw_booking_form_show_pickup_location', 'no' );
			}
		} else {
			$product_show_location = $this->get_meta_value( 'show_pickoff_location_product' );
			
			if ( ovabrw_array_exists( $term_location ) && in_array( 'dropoff_loc', $term_location ) ) {
				$show_location = 'yes';
			} elseif ( ovabrw_array_exists( $term_location ) && !in_array( 'dropoff_loc', $term_location ) ) {
				$show_location = 'no';
			} else {
				$show_location = get_option( 'ova_brw_booking_form_show_pickoff_location', 'no' );
			}
		}

		switch ( $product_show_location ) {
			case 'in_setting':
				if ( 'no' == $show_location ) {
					return false;
				} else {
					return true;
				}
				break;
			case 'yes':
				return true;
				break;
			case 'no':
				return false;
				break;
			default:
				if ( 'no' == $show_location ) {
					return false;
				} else {
					return true;
				}
				break;
		}

		return apply_filters( 'ovabrw_show_location', false, $this->get_id(), $type );
    }

    /**
     * Show drop-off date
     */
    public function show_dropoff_date() {
    	$rental_type = $this->get_rental_type();

		if ( 'transportation' == $rental_type ) {
			$product_show_date = 'no';
			$show_dropoff_date = $this->get_meta_value( 'dropoff_date_by_setting' );

			if ( 'yes' == $show_dropoff_date ) {
				$product_show_date = $this->get_meta_value( 'show_pickoff_date_product' );

				// Global show date
				$show_date = get_option( 'ova_brw_booking_form_show_dropoff_date', 'yes' );
			}
		} else {
			$product_show_date = $this->get_meta_value( 'show_pickoff_date_product' );

			// Global show date
			$show_date = get_option( 'ova_brw_booking_form_show_dropoff_date', 'yes' );
		}

		switch ( $product_show_date ) {
			case 'in_setting':
				if ( 'yes' == $show_date ) {
					return true;
				} else {
					return false;
				}
				break;
			case 'yes':
				return true;
				break;
			case 'no':
				return false;
				break;
			default:
				return true;
				break;
		}

		return apply_filters( 'ovabrw_show_date', false, $this->get_id() );
    }

    /**
     * Show quantity
     */
    public function show_quantity( $action = '' ) {
    	// Product get show quantity
		$show_quantity = $this->get_meta_value( 'show_number_vehicle' );

		if ( 'request_form' == $action ) {
			$quantity_global = get_option( 'ova_brw_request_booking_form_show_number_vehicle', 'no' );	
		} else {
			$quantity_global = get_option( 'ova_brw_booking_form_show_number_vehicle', 'yes' );
		}
		
		switch ( $show_quantity ) {
			case 'in_setting':
				if ( 'yes' == $quantity_global ) {
					return true;
				} else {
					return false;
				}
				break;
			case 'yes':
				return true;
				break;
			case 'no':
				return false;
				break;
			default:
				return true;
		}

		return apply_filters( 'ovabrw_show_quantity', false, $this->get_id(), $action );
    }

    /**
     * Request booking - Show location
     */
    public function rqb_show_location( $type = 'pickup' ) {
    	// Get rental type
		$rental_type = $this->get_rental_type();

		if ( 'taxi' == $rental_type || 'transportation' == $rental_type ) return true;
		if ( 'hotel' == $rental_type ) return false;

		// Get custom checkout field by Category
		$categories 	= wp_get_post_terms( $this->get_id(), 'product_cat' );
		$category_id 	= isset( $categories[0] ) ? $categories[0]->term_id : '';
		$term_location 	= $category_id ? get_term_meta( $category_id, 'ovabrw_show_loc_booking_form', true ) : [];

		if ( $type == 'pickup' ) {
			$product_show_location = $this->get_meta_value( 'show_pickup_location_product' );

			if ( ovabrw_array_exists( $term_location ) && in_array( 'pickup_loc', $term_location ) ) {
				$rqb_show_location = 'yes';
			} elseif ( ovabrw_array_exists( $term_location ) && !in_array( 'pickup_loc', $term_location ) ) {
				$rqb_show_location = 'no';
			}else {
				$rqb_show_location = get_option( 'ova_brw_request_booking_form_show_pickup_location', 'no' );
			}
		} else {
			$product_show_location = $this->get_meta_value( 'show_pickoff_location_product' );

			if ( ovabrw_array_exists( $term_location ) && in_array( 'dropoff_loc', $term_location ) ) {
				$rqb_show_location = 'yes';
			} elseif ( ovabrw_array_exists( $term_location ) && !in_array( 'dropoff_loc', $term_location ) ) {
				$rqb_show_location = 'no';
			} else {
				$rqb_show_location = get_option( 'ova_brw_request_booking_form_show_pickoff_location', 'no' );
			}
		}

		switch( $product_show_location ) {
			case 'in_setting':
				if ( 'no' == $rqb_show_location ) {
					return false;
				} else {
					return true;
				}
				break;
			case 'yes':
				return true;
				break;
			case 'no':
				return false;
				break;
			default:
				if ( 'no' == $rqb_show_location ) {
					return false;
				} else {
					return true;
				}
				break;
		}

		return apply_filters( 'ovabrw_rqb_show_location', false, $this->get_id(), $type );
    }

    /**
     * Request booking - Show drop-off date
     */
    public function rqb_show_dropoff_date() {
    	$rental_type = $this->get_rental_type();

    	if ( 'transportation' == $rental_type ) {
			$product_show_date = 'no';
			$show_dropoff_date = $this->get_meta_value( 'dropoff_date_by_setting' );

			if ( 'yes' == $show_dropoff_date ) {
				$product_show_date = $this->get_meta_value( 'show_pickoff_date_product' );

				// Global show date
				$show_date = get_option( 'ova_brw_request_booking_form_show_pickoff_date', 'yes' );
			}
		} else {
			$product_show_date = $this->get_meta_value( 'show_pickoff_date_product' );

			// Global show date
			$show_date = get_option( 'ova_brw_request_booking_form_show_pickoff_date', 'yes' );
		}
		
		switch ( $product_show_date ) {
			case 'in_setting':
				if ( 'yes' == $show_date ) {
					return true;
				} else {
					return false;
				}
				break;
			case 'yes':
				return true;
				break;
			case 'no':
				return false;
				break;
			default:
				return true;
		}

		return apply_filters( 'ovabrw_rqb_show_date', false, $this->get_id() );
    }
}