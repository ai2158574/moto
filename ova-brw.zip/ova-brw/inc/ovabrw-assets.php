<?php defined( 'ABSPATH' ) || exit();

if ( ! class_exists( 'OVABRW_Assets' ) ) {
	class OVABRW_Assets {
		public function __construct() {
			/**
			 * Load google font from customize
			 */
			add_action( 'wp_enqueue_scripts', array( $this, 'loading_google_fonts' ) );

			/**
			 * Enqueue styles
			 */
			add_action( 'wp_enqueue_scripts', array( $this, 'frontend_styles' ) );

			/**
			 * Enqueue scripts
			 */
			add_action( 'wp_enqueue_scripts', array( $this, 'frontend_scripts' ) );

			/**
			 * Enqueue style from customize
			 */
			add_action('wp_enqueue_scripts', array( $this, 'enqueue_customize' ), 11 );
		}

		/**
		 * Loading google fonts
		 */
		public function loading_google_fonts() {
			if ( ovabrw_global_typography() ) {
				$primary_font 	= get_option( 'ovabrw_glb_primary_font', 'Poppins' );
				$font_weight 	= get_option( 'ovabrw_glb_primary_font_weight', array(
					"100",
			        "100italic",
			        "200",
			        "200italic",
			        "300",
			        "300italic",
			        "regular",
			        "italic",
			        "500",
			        "500italic",
			        "600",
			        "600italic",
			        "700",
			        "700italic",
			        "800",
			        "800italic",
			        "900",
			        "900italic",
				));

				$str_font_weight = '100,200,300,400,500,600,700,800,900';

				if ( ! empty( $font_weight ) && is_array( $font_weight ) ) {
					$str_font_weight = implode( ',', $font_weight );
				}

				if ( $primary_font && $str_font_weight ) {
					$font_url = add_query_arg(
						array(
							'family' => urlencode( $primary_font.':'.$str_font_weight ),
						),
						'//fonts.googleapis.com/css'
					);

					$google_font = esc_url_raw( $font_url );

					wp_enqueue_style( 'ovabrw-google-font', $google_font, array(), null );
				}
			}
		}

		/**
		 * Enqueue styles
		 */
		public function frontend_styles() {
			// Get current version
			$version = OVABRW()->version;

			// Tippy scale stype
			wp_enqueue_style( 'ovabrw-tippy-scale', OVABRW_PLUGIN_URI.'assets/libs/tippy/scale.css', array(), $version );

			// Timepicker style
			wp_enqueue_style( 'ovabrw-timepicker', OVABRW_PLUGIN_URI.'assets/libs/timepicker/timepicker.min.css', array(), $version );

			// Calendar
			wp_enqueue_style( 'ovabrw-calendar', OVABRW_PLUGIN_URI.'assets/libs/fullcalendar/main.min.css', array(), $version );

			// Global typography enabled
			if ( ovabrw_global_typography() ) {
				// Fancybox
				wp_enqueue_style( 'ovabrw-fancybox', OVABRW_PLUGIN_URI.'/assets/libs/fancybox/fancybox.css', array(), $version );

				// Carosel
				wp_enqueue_style( 'ovabrw-carousel', OVABRW_PLUGIN_URI.'assets/libs/carousel/owl.carousel.min.css', array(), $version );

				// Flaticon
			    if ( apply_filters( 'ovabrw_use_brwicon', true ) ) {
			    	wp_enqueue_style( 'ovabrw-icon', OVABRW_PLUGIN_URI.'assets/libs/flaticons/brwicon/font/flaticon_brw.css', array(), $version );
			    }
			}

			// Add elegant
			if ( apply_filters( 'ovabrw_use_elegant_font', true ) ) {
				wp_enqueue_style( 'ovabrw-elegant-font', OVABRW_PLUGIN_URI.'assets/libs/elegant_font/style.css', array(), $version );	
			}

			// Add flaticon
			if ( apply_filters( 'ovabrw_use_flaticon_font', true ) ) {
				wp_enqueue_style( 'ovabrw-flaticon-car-service', OVABRW_PLUGIN_URI.'assets/libs/flaticons/car_service/flaticon.css', array(), $version );
				wp_enqueue_style( 'ovabrw-flaticon-car2', OVABRW_PLUGIN_URI.'assets/libs/flaticons/car2/flaticon.css', array(), $version );	
				wp_enqueue_style( 'ovabrw-flaticon-essential', OVABRW_PLUGIN_URI.'assets/libs/flaticons/essential_set/flaticon.css', array(), $version );
		    	wp_enqueue_style('ovabrw-flaticon-remons2', OVABRW_PLUGIN_URI.'assets/libs/flaticons/brwicon2/font/brwicon2.css', array(), $version );
		    	wp_enqueue_style('ovabrw-flaticon-remons3', OVABRW_PLUGIN_URI.'assets/libs/flaticons/brwicon3/font/brwicon3.css', array(), $version );
			}

			// Frontend styles
			wp_enqueue_style( 'ovabrw-frontend', OVABRW_PLUGIN_URI.'assets/css/frontend/ovabrw_frontend.css', array(), $version );
		}

		/**
		 * Enqueue scripts
		 */
		public function frontend_scripts() {
			// Get current version
			$version = OVABRW()->version;

			// Ui autocomplete
		    wp_enqueue_script( 'jquery-ui-autocomplete' );

		    // Tippy
			wp_enqueue_script( 'ovabrw-popper', OVABRW_PLUGIN_URI.'assets/libs/tippy/popper.min.js', array('jquery'), $version, true );
			wp_enqueue_script( 'ovabrw-tippy-bundle', OVABRW_PLUGIN_URI.'assets/libs/tippy/tippy-bundle.min.js', array('jquery'), $version, true );

			// Timepicker script
			wp_enqueue_script( 'ovabrw-timepicker', OVABRW_PLUGIN_URI.'assets/libs/timepicker/timepicker.min.js', array('jquery'), $version, true );

			// Easepick script
			wp_enqueue_script( 'ovabrw-easepick', OVABRW_PLUGIN_URI.'assets/libs/easepick/easepick.min.js', array('jquery'), $version, true );

		    // Single Product
			if ( is_product() && get_the_id() ) {
				// Get rental type
				$rental_type = get_post_meta( get_the_id(), 'ovabrw_price_type', true );

				if ( 'taxi' == $rental_type ) {
					// Map
					if ( get_option( 'ova_brw_google_key_map', false ) ) {
						wp_enqueue_script( 'ovabrw-google-maps','https://maps.googleapis.com/maps/api/js?key='.get_option( 'ova_brw_google_key_map' ).'&libraries=places&loading=async&callback=Function.prototype', $version, true );
					} else {
						wp_enqueue_script( 'ovabrw-google-maps','https://maps.googleapis.com/maps/api/js?sensor=false&loading=async&callback=Function.prototype&libraries=places', array('jquery'), $version, true );
					}
				}
			}

		    // Calendar
		    wp_enqueue_script( 'ovabrw-moment', OVABRW_PLUGIN_URI.'assets/libs/fullcalendar/moment.min.js', array('jquery'), $version, true );
		    wp_enqueue_script( 'ovabrw-calendar', OVABRW_PLUGIN_URI.'assets/libs/fullcalendar/main.js', array('jquery'), $version, true );
		    wp_enqueue_script( 'ovabrw-locale', OVABRW_PLUGIN_URI.'assets/libs/fullcalendar/locales-all.js', array('jquery'), $version, true );
		    
		    // Global typography enabled
		    if ( ovabrw_global_typography() ) {
		    	// Fancybox
				wp_enqueue_script( 'ovabrw-fancybox', OVABRW_PLUGIN_URI.'/assets/libs/fancybox/fancybox.umd.js', array('jquery'), $version, true );

				// Carousel
				wp_enqueue_script( 'ovabrw-carousel', OVABRW_PLUGIN_URI.'assets/libs/carousel/owl.carousel.min.js', array('jquery'), $version, true );
		    }

			wp_enqueue_script( 'ovabrw-frontend', OVABRW_PLUGIN_URI.'assets/js/frontend/ova-brw-frontend.min.js', array('jquery'), $version, true );

			// Error messages
			wp_localize_script( 'ovabrw-frontend', 'ovabrwErrorMessages', ovabrw_get_validation_messages() );

			// Timepicker options
			wp_localize_script( 'ovabrw-frontend', 'timePickerOptions', OVABRW()->options->get_timepicker_options() );

			// Datepicker options
			wp_localize_script( 'ovabrw-frontend', 'datePickerOptions', OVABRW()->options->get_datepicker_options() );

			// Ajax object
			wp_localize_script( 'ovabrw-frontend', 'ajax_object', array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'security' => wp_create_nonce( 'ovabrw-security-ajax' )
			));
		}

		/**
		 * Add inline styles
		 */
		public function enqueue_customize() {
			$css = '';

			// Calendar
			$available_color 	= get_option( 'ova_brw_bg_calendar_available', '#FFF' );
			$unavailable_color 	= get_option( 'ova_brw_bg_calendar', '#e56e00' );
			$css .= '--ovabrw-available-color:'.$available_color.';';
			$css .= '--ovabrw-unavailable-color:'.$unavailable_color.';';

			if ( ovabrw_global_typography() ) {
				add_filter( 'body_class', function( $classes ) {
					return array_merge( $classes, array( 'ovabrw-modern' ) );
				});

				// Primary
				$primary_font 	= get_option( 'ovabrw_glb_primary_font', 'Poppins' );
				$primary_color 	= get_option( 'ovabrw_glb_primary_color', '#E56E00' );
				$light_color 	= get_option( 'ovabrw_glb_light_color', '#C3C3C3' );
				$css .= '--ovabrw-primary-font:'.$primary_font.';';
				$css .= '--ovabrw-primary-color:'.$primary_color.';';
				$css .= '--ovabrw-light-color:'.$light_color.';';

				// Heading
				$heading_size 			= get_option( 'ovabrw_glb_heading_font_size', '24px' );
				$heading_weight 		= get_option( 'ovabrw_glb_heading_font_weight', '600' );
				$heading_line_height 	= get_option( 'ovabrw_glb_heading_line_height', '36px' );
				$heading_color 			= get_option( 'ovabrw_glb_heading_color', '#222222' );
				$css .= '--ovabrw-heading-size:'.$heading_size.';';
				$css .= '--ovabrw-heading-weight:'.$heading_weight.';';
				$css .= '--ovabrw-heading-line-height:'.$heading_line_height.';';
				$css .= '--ovabrw-heading-color:'.$heading_color.';';

				// Second Heading
				$second_heading_size 		= get_option( 'ovabrw_glb_second_heading_font_size', '22px' );
				$second_heading_weight 		= get_option( 'ovabrw_glb_second_heading_font_weight', '600' );
				$second_heading_line_height = get_option( 'ovabrw_glb_second_heading_line_height', '33px' );
				$second_heading_color 		= get_option( 'ovabrw_glb_second_heading_color', '#222222' );
				$css .= '--ovabrw-second-heading-size:'.$second_heading_size.';';
				$css .= '--ovabrw-second-heading-weight:'.$second_heading_weight.';';
				$css .= '--ovabrw-second-heading-line-height:'.$second_heading_line_height.';';
				$css .= '--ovabrw-second-heading-color:'.$second_heading_color.';';

				// Label
				$label_size 		= get_option( 'ovabrw_glb_label_font_size', '16px' );
				$label_weight 		= get_option( 'ovabrw_glb_label_font_weight', '500' );
				$label_line_height 	= get_option( 'ovabrw_glb_label_line_height', '24px' );
				$label_color 		= get_option( 'ovabrw_glb_label_color', '#222222' );
				$css .= '--ovabrw-label-size:'.$label_size.';';
				$css .= '--ovabrw-label-weight:'.$label_weight.';';
				$css .= '--ovabrw-label-line-height:'.$label_line_height.';';
				$css .= '--ovabrw-label-color:'.$label_color.';';

				// Text
				$text_size 			= get_option( 'ovabrw_glb_text_font_size', '14px' );
				$text_weight 		= get_option( 'ovabrw_glb_text_font_weight', '400' );
				$text_line_height 	= get_option( 'ovabrw_glb_text_line_height', '22px' );
				$text_color 		= get_option( 'ovabrw_glb_text_color', '#555555' );
				$css .= '--ovabrw-text-size:'.$text_size.';';
				$css .= '--ovabrw-text-weight:'.$text_weight.';';
				$css .= '--ovabrw-text-line-height:'.$text_line_height.';';
				$css .= '--ovabrw-text-color:'.$text_color.';';

				// Get all card templates
    			$card_templates = ovabrw_get_all_card_templates();
    			if ( ! is_array( $card_templates ) ) $card_templates = [];

    			foreach ( array_keys( $card_templates ) as $card ) {
    				// Card thumbnail size
    				$card_thumbnail_size = get_option( 'ovabrw_glb_'.$card.'_thumbnail_size', 'woocommerce_thumbnail' );
    				if ( $card_thumbnail_size === 'custom_height' ) {
    					$card_thumbnail_height 	= get_option( 'ovabrw_glb_'.$card.'_thumbnail_height', '300px' );
    					$css .= '--ovabrw-'.$card.'-thumbnail-height:'.$card_thumbnail_height.';';
    				}

    				// Card display thumbnail
    				$card_display_thumbnail = get_option( 'ovabrw_glb_'.$card.'_display_thumbnail', 'cover' );
    				$css .= '--ovabrw-'.$card.'-display-thumbnail:'.$card_display_thumbnail.';';
    			}
			}

			// Datepicker css
	        $datepicker_css = OVABRW()->options->datepicker_global_css();
	        $css .= $datepicker_css;

			$root = ":root{{$css}}";

			wp_add_inline_style( 'ovabrw-frontend', $root );
		}
	}

	new OVABRW_Assets();
}