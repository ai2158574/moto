<?php
use Automattic\WooCommerce\Utilities\OrderUtil;

defined( 'ABSPATH' ) || exit;

/**
 * Get Data class.
 */
if ( ! class_exists( 'OVABRW_Get_Data' ) ) {
    class OVABRW_Get_Data {
        protected static $_instance = null;
        protected $prefix = OVABRW_PREFIX;

        /**
         * Get booked dates
         */
        public function get_booked_dates( $product_id = false, $order_status = [] ) {
            global $wpdb;

            $order_dates = $unavaiable_dates = $total_each_day = [];
            if ( !$product_id ) return $unavaiable_dates;

            if ( !ovabrw_array_exists( $order_status ) ) {
                $order_status = ovabrw_get_order_status();
            }

            // Rental type
            $rental_type = $this->get_meta_value( $product_id, 'price_type' );

            // Rental type: Appointment
            if ( 'appointment' == $rental_type ) {
                $booked_date = $this->get_booked_dates_for_appointment( $product_id, $order_status );

                return apply_filters( 'ovabrw_get_booked_dates', $booked_date, $product_id, $order_status );
            } // End

            // Date format
            $date_format = 'Y-m-d';

            // Get stock quantity of product
            $stock_qty = $this->get_stock_quantity( $product_id );

            // Calendar background
            $calendar_background = get_option( 'ova_brw_bg_calendar', '#c4c4c4' );
            if ( !$calendar_background ) $calendar_background = '#c4c4c4';

            // Get product ids multi lang
            $product_ids = $this->get_product_ids_multi_lang( $product_id );

            // Get order ids
            $order_ids = $this->get_orders_by_product_id( $product_id, $order_status );
            if ( ovabrw_array_exists( $order_ids ) ) {
                foreach ( $order_ids as $k => $order_id ) {
                    // Get Order
                    $order = wc_get_order( $order_id );

                    // Get order items
                    $order_items = $order->get_items( apply_filters( 'woocommerce_purchase_order_item_types', 'line_item' ) );

                    if ( ovabrw_array_exists( $order_items ) ) {
                        foreach ( $order_items as $item_id => $item ) {
                            if ( $item && is_object( $item ) ) {
                                $p_id = $item->get_product_id();

                                if ( $p_id && !in_array( $p_id , $product_ids ) ) continue;

                                $pickup_date    = strtotime( $item->get_meta( 'ovabrw_pickup_date_real' ) );
                                $dropoff_date   = strtotime( $item->get_meta( 'ovabrw_pickoff_date_real' ) );
                                $qty_booked     = intval( $item->get_meta( 'ovabrw_number_vehicle' ) );

                                if ( $dropoff_date >= current_time( 'timestamp' ) ) {
                                    for ( $i = 0; $i < $qty_booked; $i++ ) {
                                        if ( 'hotel' == $rental_type ) {
                                            $unavaiable = $this->get_unavailable_dates_by_hotel( $product_id, $pickup_date, $dropoff_date );
                                        } else {
                                            $unavaiable = $this->get_unavailable_dates( $product_id, $pickup_date, $dropoff_date );
                                        }

                                        if ( ovabrw_array_exists( $unavaiable ) ) {
                                            $unavaiable_dates   = array_merge_recursive( $unavaiable_dates, $unavaiable['unavaiable_dates'] );
                                            $total_each_day     = array_merge_recursive( $total_each_day, $unavaiable['total_each_day'] );
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Check unavailable time
            $untime_startdate   = $this->get_meta_value( $product_id, 'untime_startdate' );
            $untime_enddate     = $this->get_meta_value( $product_id, 'untime_enddate' );

            if ( ovabrw_array_exists( $untime_startdate ) && ovabrw_array_exists( $untime_enddate ) ) {
                foreach ( $untime_startdate as $k => $start_date ) {
                    $start_date  = strtotime( $start_date );
                    $end_date    = strtotime( ovabrw_get_meta_data( $k, $untime_enddate ) );
                    if ( $end_date < current_time( 'timestamp' ) ) continue;

                    if ( $start_date && $end_date ) {
                        $unavaiable_time = [];

                        // Hotel
                        if ( 'hotel' == $rental_type ) {
                            $unavaiable_time = $this->get_unavailable_times_by_hotel( $start_date, $end_date );
                        } else {
                            $unavaiable_time = $this->get_unavailable_times( $start_date, $end_date );
                        }
                        
                        if ( ovabrw_array_exists( $unavaiable_time ) ) {
                            $unavaiable_dates   = array_merge_recursive( $unavaiable_dates, $unavaiable_time['unavaiable_dates'] );
                            $total_each_day     = array_merge_recursive( $total_each_day, $unavaiable_time['total_each_day'] );

                            for ( $i = 1; $i < $stock_qty; $i++ ) {
                                $unavaiable_dates   = array_merge_recursive( $unavaiable_dates, $unavaiable_time['unavaiable_dates'] );
                                $total_each_day     = array_merge_recursive( $total_each_day, $unavaiable_time['total_each_day'] );
                            }
                        }
                    }
                }
            }

            // Vehicle IDs
            $manage_stock = $this->get_meta_value( $product_id, 'manage_store' );
            if ( 'id_vehicle' == $manage_stock ) {
                $vehicle_ids = $this->get_meta_value( $product_id, 'id_vehicles' );

                if ( ovabrw_array_exists( $vehicle_ids ) ) {
                    foreach ( $vehicle_ids as $k => $vehicle_id ) {
                        $data_vehicle = $this->get_location_title_by_vehicle( $vehicle_id );

                        $vehicle_start_date = isset( $data_vehicle['untime']['startdate'] ) && $data_vehicle['untime']['startdate'] ? strtotime( $data_vehicle['untime']['startdate'] ) : '';
                        $vehicle_end_date   = isset( $data_vehicle['untime']['enddate'] ) && $data_vehicle['untime']['enddate'] ? strtotime( $data_vehicle['untime']['enddate'] ) : '';

                        if ( $vehicle_start_date && $vehicle_end_date ) {
                            $untime_vehicle = $this->get_unavailable_times( $vehicle_start_date, $vehicle_end_date );

                            if ( ovabrw_array_exists( $untime_vehicle ) ) {
                                $unavaiable_dates   = array_merge_recursive( $unavaiable_dates, $untime_vehicle['unavaiable_dates'] );
                                $total_each_day     = array_merge_recursive( $total_each_day, $untime_vehicle['total_each_day'] );
                            }
                        }
                    }
                }
            }

            // Count total each day
            $count_unvailable = array_count_values( $total_each_day );

            // Rental: Day - Hotel
            if ( 'day' == $rental_type ) {
                $charged_by = $this->get_meta_value( $product_id, 'define_1_day' );

                if ( $charged_by == 'hotel' && ovabrw_array_exists( $unavaiable_dates ) ) {
                    $compared_array = array();

                    foreach ( $unavaiable_dates as $k1 => $v1 ) {
                        $pickup_check   = apply_filters( 'brw_real_pickup_time_hotel', '14:00' ). '-24:00';
                        $dropoff_check  = '00:00-' . apply_filters( 'brw_real_dropoff_time_hotel', '11:00' );
                        $time1          = ovabrw_get_meta_data( 'time', $v1 );

                        if ( $time1 == $pickup_check ) {
                            $start = date( 'Y-m-d', strtotime( $v1['start'] ) );
                            
                            if ( !in_array( $start, $compared_array ) ) {
                                $k = 0;
                                array_push( $compared_array, $start );

                                foreach ( $unavaiable_dates as $k2 => $v2 ) {
                                    $start2 = date( 'Y-m-d', strtotime( $v2['start'] ) );
                                    $time2  = ovabrw_get_meta_data( 'time', $v2 );

                                    if ( $start2 == $start && $time2 == $dropoff_check ) {
                                        $k++;
                                    }
                                }

                                if ( $k >= $stock_qty ) {
                                    $count_unvailable[$start] = $k;
                                }
                            }
                        }
                    }
                }
            }

            // Check available for rental: Period
            if ( 'period_time' == $rental_type ) {
                $unfixed_time       = $this->get_meta_value( $product_id, 'unfixed_time' );
                $args_unavailable   = [];

                if ( 'yes' != $unfixed_time && ! empty( $unavaiable_dates ) && is_array( $unavaiable_dates ) ) {
                    foreach ( $unavaiable_dates as $items ) {
                        $start_date = strtotime( ovabrw_get_meta_data( 'start', $items ) );
                        $end_date   = strtotime( ovabrw_get_meta_data( 'end', $items ) );

                        if ( !$start_date || !$end_date ) continue;

                        $check_in   = $start_date ? strtotime( date( 'Y-m-d', $start_date ) ) : '';
                        $check_out  = $end_date ? strtotime( date( 'Y-m-d', $end_date ) ) : '';

                        if ( !$check_in || !$check_out || $check_in != $check_out ) continue;
                        if ( in_array( $check_in, $args_unavailable ) ) continue;

                        $check_vehicle = $this->check_available_package( $product_id, $check_in );

                        if ( !$check_vehicle ) {
                            array_push( $args_unavailable, $check_in );

                            $unavaiable_dates[] = [
                                'start'             => date( 'Y-m-d', $check_in ),
                                'end'               => date( 'Y-m-d', $check_in ),
                                'start_v2'          => date( $date_format, $check_in ),
                                'rendering'         => 'background',
                                'display'           => 'background',
                                'backgroundColor'   => $calendar_background
                            ];
                        }
                    }
                }
            }
        
            // Unavailable dates
            if ( ovabrw_array_exists( $count_unvailable ) ) {
                foreach ( $count_unvailable as $date => $count ) {
                    if ( $count >= $stock_qty ) {
                        array_push( $unavaiable_dates, [
                            'start'             => $date,
                            'end'               => $date,
                            'start_v2'          => date( $date_format, strtotime( $date ) ),
                            'rendering'         => 'background',
                            'display'           => 'background',
                            'backgroundColor'   => $calendar_background,
                            'overlap'           => false
                        ]);
                    }
                }
            }

            // Preparation Time
            $preparation_time = get_post_meta( $product_id, 'ovabrw_preparation_time', true );
            if ( $preparation_time ) {
                $preparation_start  = strtotime( date( $date_format, current_time( 'timestamp' ) ) );
                $preparation_end    = strtotime( date( $date_format, current_time( 'timestamp' ) + $preparation_time*86400 ) );

                $unavaiable_dates[] = [
                    'start'             => date( $date_format, $preparation_start ),
                    'end'               => date( $date_format, $preparation_start ),
                    'start_v2'          => date( $date_format, $preparation_start ),
                    'rendering'         => 'background',
                    'display'           => 'background',
                    'backgroundColor'   => $calendar_background,
                    'overlap'           => false,
                    'title'             => ''
                ];

                while ( $preparation_start < $preparation_end - 86400 ) {
                    $preparation_start += 86400;
                    $unavaiable_dates[] = [
                        'start'             => date( $date_format, $preparation_start ),
                        'end'               => date( $date_format, $preparation_start ),
                        'start_v2'          => date( $date_format, $preparation_start ),
                        'rendering'         => 'background',
                        'display'           => 'background',
                        'backgroundColor'   => $calendar_background,
                        'overlap'           => false,
                        'title'             => ''
                    ];
                }
            }

            // Current time
            array_push( $unavaiable_dates, [
                'start'             => date( 'Y-m-d', current_time( 'timestamp' ) ) . ' 00:00',
                'end'               => date( 'Y-m-d H:i', current_time( 'timestamp' ) ),
                'rendering'         => 'background',
                'display'           => 'background',
                'backgroundColor'   => $calendar_background,
                'overlap'           => false,
                'classNames'        => 'ovabrw-calendar-current-time'
            ]);

            return apply_filters( 'ovabrw_get_booked_dates', $unavaiable_dates, $product_id, $order_status );
        }

        /**
         * Appointment - Get booked dates
         */
        public function get_booked_dates_for_appointment( $product_id, $order_status ) {
            if ( !$product_id ) return [];

            // Background for booked date
            $bg_booked = get_option( 'ova_brw_bg_calendar', '#c4c4c4' );
            if ( !$bg_booked ) $bg_booked = '#c4c4c4';

            // init
            $booked_dates = [];

            // Get booked order ids
            $order_ids = $this->get_booked_orders_for_appointment( $product_id, $order_status );
            
            if ( ovabrw_array_exists( $order_ids ) ) {
                // Order booked
                $order_booked = [];

                // Get product ids multi lang
                $product_ids = $this->get_product_ids_multi_lang( $product_id );

                // Loop
                foreach ( $order_ids as $order_id ) {
                    // Get order
                    $order = wc_get_order( $order_id );

                    if ( !$order || !is_object( $order ) ) continue;

                    // Get items
                    $items = $order->get_items();
                    if ( !ovabrw_array_exists( $items ) ) continue;

                    foreach ( $items as $item_id => $item ) {
                        if ( !$item || !is_object( $item ) ) continue;

                        // Get product ID
                        $product_id = $item->get_product_id();

                        if ( in_array( $product_id, $product_ids ) ) {
                            // Pickup date
                            $pickup_date = strtotime( $item->get_meta( 'ovabrw_pickup_date' ) );
                            if ( !$pickup_date || $pickup_date <= current_time( 'timestamp' ) ) continue;

                            // Quantity booked
                            $qty_booked = (int)$item->get_meta( 'ovabrw_number_vehicle' );
                            if ( !$qty_booked ) continue;

                            // Convert pick-up date by date format
                            $pickup_date = strtotime( date( ovabrw_get_date_format(), $pickup_date ) );

                            if ( array_key_exists( $pickup_date, $order_booked ) ) {
                                $order_booked[$pickup_date] += $qty_booked;
                            } else {
                                $order_booked[$pickup_date] = $qty_booked;
                            }
                        }
                    }
                } // End loop

                // Check quantity available
                if ( ovabrw_array_exists( $order_booked ) ) {
                    // Background for booked date
                    $bg_booked = get_option( 'ova_brw_bg_calendar', '#c4c4c4' );
                    if ( !$bg_booked ) $bg_booked = '#c4c4c4';

                    // Get time slots data
                    $timeslots_start    = ovabrw_get_post_meta( $product_id, 'time_slots_start' );
                    $timeslots_qtys     = ovabrw_get_post_meta( $product_id, 'time_slots_quantity' );

                    foreach ( $order_booked as $pickup_date => $qty_booked ) {
                        // String day of week
                        $dayofweek = OVABRW()->options->get_string_dayofweek( $pickup_date );

                        // Get start times
                        $start_times = ovabrw_get_meta_data( $dayofweek, $timeslots_start );

                        // Get quantites
                        $qtys = ovabrw_get_meta_data( $dayofweek, $timeslots_qtys );

                        if ( ovabrw_array_exists( $start_times ) ) {
                            $qty_available = 0;

                            foreach ( $start_times as $k => $start_time ) {
                                $start_date = strtotime( ovabrw_get_string_date( $pickup_date, strtotime( $start_time ) ) );

                                if ( $start_date > current_time( 'timestamp' ) ) {
                                    $qty_available += (int)ovabrw_get_meta_data( $k, $qtys );
                                }
                            }

                            // Check quantity available
                            if ( $qty_available <= $qty_booked ) {
                                $pickup_date = date( 'Y-m-d', $pickup_date );

                                $booked_dates[] = [
                                    'start'             => $pickup_date,
                                    'end'               => $pickup_date,
                                    'start_v2'          => $pickup_date,
                                    'rendering'         => 'background',
                                    'display'           => 'background',
                                    'backgroundColor'   => $bg_booked,
                                    'overlap'           => false
                                ];
                            }
                        }
                    }
                }
            } // Booked order ids

            // Disabled dates
            $disabled_start = ovabrw_get_post_meta( $product_id, 'untime_startdate' );

            if ( ovabrw_array_exists( $disabled_start ) ) {
                $disabled_end = ovabrw_get_post_meta( $product_id, 'untime_enddate' );

                foreach ( $disabled_start as $k => $start_date ) {
                    $start_date = strtotime( $start_date );
                    $end_date   = strtotime( ovabrw_get_meta_data( $k, $disabled_end ) );

                    if ( $end_date <= current_time( 'timestamp' ) ) continue;

                    // Get disabled dates
                    $disabled_dates = $this->get_disabled_dates_for_appointment( $product_id, $start_date, $end_date );

                    if ( ovabrw_array_exists( $disabled_dates ) ) {
                        $booked_dates = array_merge( $booked_dates, $disabled_dates );
                    }
                }
            }

            // Preparation Time
            $preparation_time = (float)ovabrw_get_post_meta( $product_id, 'preparation_time' );

            if ( $preparation_time ) {
                $preparation_start  = current_time( 'timestamp' );
                $preparation_end    = $preparation_start + $preparation_time*86400;

                // Get disabled dates
                $disabled_dates = $this->get_disabled_dates_for_appointment( $product_id, $preparation_start, $preparation_end );

                if ( ovabrw_array_exists( $disabled_dates ) ) {
                    $booked_dates = array_merge( $booked_dates, $disabled_dates );
                }
            }

            // Check today
            $today          = date( 'Y-m-d', current_time( 'timestamp' ) );
            $check_today    = $this->check_timeslot_for_appointment( $product_id, strtotime( $today . ' 00:00' ), current_time( 'timestamp' ) );

            if ( !$check_today ) {
                array_push( $booked_dates, [
                    'start'             => $today,
                    'end'               => $today,
                    'start_v2'          => $today,
                    'rendering'         => 'background',
                    'display'           => 'background',
                    'backgroundColor'   => $bg_booked,
                    'overlap'           => false
                ]);
            } else {
                array_push( $booked_dates, [
                    'start'             => date( 'Y-m-d', current_time( 'timestamp' ) ) . ' 00:00',
                    'end'               => date( 'Y-m-d H:i', current_time( 'timestamp' ) ),
                    'rendering'         => 'background',
                    'display'           => 'background',
                    'backgroundColor'   => $bg_booked,
                    'overlap'           => false,
                    'classNames'        => 'ovabrw-calendar-current-time'
                ]);
            }

            return apply_filters( 'ovabrw_get_booked_dates_for_appointment', $booked_dates, $product_id, $order_status );
        }

        /**
         * Appointment - Get disabled dates
         */
        public function get_disabled_dates_for_appointment( $product_id, $pickup_date, $dropoff_date ) {
            if ( !$product_id || !$pickup_date || !$dropoff_date ) return [];

            // Disabled dates
            $disabled_dates = [];

            // Background for booked date
            $bg_booked = get_option( 'ova_brw_bg_calendar', '#c4c4c4' );
            if ( !$bg_booked ) $bg_booked = '#c4c4c4';

            // Date time format
            $date_format = 'Y-m-d';
            $time_format = 'H:i';

            // Date & time start
            $start_date = date( $date_format, $pickup_date );
            $start_time = date( $time_format, $pickup_date );

            // Date & time end
            $end_date = date( $date_format, $dropoff_date );
            $end_time = date( $time_format, $dropoff_date );

            // Get number of between days
            $between_days = ovabrw_get_numberof_between_days( $start_date, $end_date );

            if ( 0 == $between_days ) {
                $has_timeslot = $this->check_timeslot_for_appointment( $product_id, $pickup_date, $dropoff_date );
                if ( !$has_timeslot ) {
                    array_push( $disabled_dates, [
                        'start'             => $start_date,
                        'end'               => $start_date,
                        'start_v2'          => $start_date,
                        'rendering'         => 'background',
                        'display'           => 'background',
                        'backgroundColor'   => $bg_booked,
                        'overlap'           => false
                    ]);
                }
            } elseif ( 1 <= $between_days ) {
                // Start date
                $has_timeslot = $this->check_timeslot_for_appointment( $product_id, $pickup_date, strtotime( $start_date . ' 24:00' ) );
                if ( !$has_timeslot ) {
                    array_push( $disabled_dates, [
                        'start'             => $start_date,
                        'end'               => $start_date,
                        'start_v2'          => $start_date,
                        'rendering'         => 'background',
                        'display'           => 'background',
                        'backgroundColor'   => $bg_booked,
                        'overlap'           => false
                    ]);
                }

                // End date
                $has_timeslot = $this->check_timeslot_for_appointment( $product_id, strtotime( $end_date . ' 00:00' ), $dropoff_date );
                if ( !$has_timeslot ) {
                    array_push( $disabled_dates, [
                        'start'             => $end_date,
                        'end'               => $end_date,
                        'start_v2'          => $end_date,
                        'rendering'         => 'background',
                        'display'           => 'background',
                        'backgroundColor'   => $bg_booked,
                        'overlap'           => false
                    ]);
                }

                if ( 1 < $between_days ) {
                    // Get between dates
                    $between_dates = ovabrw_get_range_dates( strtotime( $start_date ), strtotime( $end_date ), 'Y-m-d' );

                    // Remove first and last array
                    array_shift( $between_dates ); 
                    array_pop( $between_dates );

                    foreach ( $between_dates as $date ) {
                        array_push( $disabled_dates, [
                            'start'             => $date,
                            'end'               => $date,
                            'start_v2'          => $date,
                            'rendering'         => 'background',
                            'display'           => 'background',
                            'backgroundColor'   => $bg_booked,
                            'overlap'           => false
                        ]);
                    }
                }
            }

            return apply_filters( 'ovabrw_get_disabled_dates_for_appointment', $disabled_dates, $product_id, $pickup_date, $dropoff_date );
        }

        /**
         * Appointment - Check timeslot available
         */
        public function check_timeslot_for_appointment( $product_id, $pickup_date, $dropoff_date ) {
            if ( !$product_id || !$pickup_date || !$dropoff_date ) return false;

            // init
            $result = false;

            // Current date
            $current_date = date( 'Y-m-d', $pickup_date );

            // String day of week
            $dayofweek = OVABRW()->options->get_string_dayofweek( $pickup_date );

            // Get timeslots start
            $timeslots_start    = ovabrw_get_post_meta( $product_id, 'time_slots_start' );
            $start_times        = ovabrw_get_meta_data( $dayofweek, $timeslots_start );

            // Get timeslots quantity
            $timeslots_qtys = ovabrw_get_post_meta( $product_id, 'time_slots_quantity' );
            $qtys           = ovabrw_get_meta_data( $dayofweek, $timeslots_qtys );
            if ( ovabrw_array_exists( $start_times ) ) {
                foreach ( $start_times as $k => $start_time ) {
                    $date = strtotime( $current_date . ' ' . $start_time );
                    if ( !$date || $date <= current_time( 'timestamp' ) ) continue;

                    // Qty
                    $qty = (int)ovabrw_get_meta_data( $k, $qtys );
                    if ( !$qty ) continue;

                    // Check date
                    if ( !( $date >= $pickup_date && $date <= $dropoff_date ) ) {
                        $result = true;
                        break;
                    }
                }
            }

            return apply_filters( 'ovabrw_check_timeslot_for_appointment', $result, $product_id, $pickup_date, $dropoff_date );
        }

        /**
         * Appointment - Get booked order
         */
        public function get_booked_orders_for_appointment( $product_id, $order_status ) {
            if ( !$product_id ) return [];
            if ( !ovabrw_array_exists( $order_status ) ) {
                $order_status = ovabrw_get_order_status();
            }

            // init
            $order_ids = [];

            // Current time
            $current_time = current_time( 'timestamp' );

            global $wpdb;

            // Get array product ids when use WPML
            $product_ids = $this->get_product_ids_multi_lang( $product_id );

            if ( OrderUtil::custom_orders_table_usage_is_enabled() ) {
                $order_ids = $wpdb->get_col("
                    SELECT DISTINCT o.id
                    FROM {$wpdb->prefix}wc_orders AS o
                    LEFT JOIN {$wpdb->prefix}woocommerce_order_items AS oitems
                    ON o.id = oitems.order_id
                    LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta AS oitem_meta
                    ON oitems.order_item_id = oitem_meta.order_item_id
                    LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta AS oitem_meta2
                    ON oitems.order_item_id = oitem_meta2.order_item_id
                    WHERE o.type = 'shop_order'
                    AND oitems.order_item_type = 'line_item'
                    AND oitem_meta.meta_key = '_product_id'
                    AND oitem_meta.meta_value IN ( ".implode( ',', $product_ids )." )
                    AND oitem_meta2.meta_key = 'ovabrw_pickup_date_strtotime'
                    AND oitem_meta2.meta_value > $current_time
                    AND o.status IN ( '" . implode( "','", $order_status ) . "' )
                ");
            } else {
                $order_ids = $wpdb->get_col("
                    SELECT DISTINCT oitems.order_id
                    FROM {$wpdb->prefix}woocommerce_order_items AS oitems
                    LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta AS oitem_meta
                    ON oitems.order_item_id = oitem_meta.order_item_id
                    LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta AS oitem_meta2
                    ON oitems.order_item_id = oitem_meta2.order_item_id
                    LEFT JOIN {$wpdb->posts} AS posts
                    ON oitems.order_id = posts.ID
                    WHERE posts.post_type = 'shop_order'
                    AND oitems.order_item_type = 'line_item'
                    AND oitem_meta.meta_key = '_product_id'
                    AND oitem_meta2.meta_key = 'ovabrw_pickup_date_strtotime'
                    AND oitem_meta2.meta_value > $current_time
                    AND oitem_meta.meta_value IN ( ".implode( ',', $product_ids )." )
                    AND posts.post_status IN ( '" . implode( "','", $order_status ) . "' )
                ");
            }

            return apply_filters( 'ovabrw_get_booked_orders_for_appointment', $order_ids, $product_id, $order_status );
        }

        /**
         * Get unavailable dates
         */
        public function get_unavailable_dates( $product_id = false, $pickup_date = '', $dropoff_date = '' ) {
            if ( !$product_id || !$pickup_date || !$dropoff_date ) return false;

            // Get Rental Type
            $rental_type = $this->get_meta_value( $product_id, 'price_type' );

            // Prepare time
            $prepare_time = 0;

            if ( !in_array( $rental_type, array( 'day', 'transportation' ) ) ) {
                $prepare_time = floatval( $this->get_meta_value( $product_id, 'prepare_vehicle' ) );
                if ( $prepare_time ) $prepare_time = floatval( $prepare_time ) * 60;
            } else {
                $prepare_time = floatval( $this->get_meta_value( $product_id, 'prepare_vehicle_day' ) );
                if ( $prepare_time ) $prepare_time = floatval( $prepare_time ) * 86400;
            }

            $date_format    = 'Y-m-d';
            $time_format    = 'H:i';
            $dropoff_date   += $prepare_time;

            // Convert date
            $checkin_date   = date( $date_format . ' ' . $time_format, $pickup_date );
            $checkout_date  = date( $date_format . ' ' . $time_format, $dropoff_date );
            $start_date     = date( $date_format, $pickup_date );
            $end_date       = date( $date_format, $dropoff_date );
            $start_time     = date( $time_format, $pickup_date );
            $end_time       = date( $time_format, $dropoff_date );

            if ( '00:00' == $end_time ) {
                $checkout_date  = date( $date_format, $dropoff_date - 86400 ).' 24:00';
                $end_date       = date( $date_format, $dropoff_date - 86400 );
                $end_time       = '24:00';
            } elseif ( '23:59' == $end_time ) {
                $checkout_date  = $end_date . ' 24:00';
                $end_time       = '24:00';
            }

            // Hotel
            if ( 'day' == $rental_type ) {
                $charged_by = $this->get_meta_value( $product_id, 'define_1_day' );

                if ( 'hotel' == $charged_by ) {
                    $start_time = apply_filters( 'brw_real_pickup_time_hotel', '14:00' );
                    $end_time   = apply_filters( 'brw_real_dropoff_time_hotel', '11:00' );
                }
            }

            // Init
            $unavaiable_dates   = $disabled_dates = [];
            $between_days       = ovabrw_get_numberof_between_days( $start_date, $end_date );

            // Filter time
            $filter_title = apply_filters( 'ovabrw_unavailable_filter_time', [
                '00:00-00:00',
                '00:00-24:00',
                '24:00-24:00',
                '24:00-00:00'
            ]);

            if ( 0 == $between_days ) {
                // Get time
                $str_time = $start_time . '-' . $end_time;

                if ( !in_array( $str_time, $filter_title ) ) {
                    $str_time = ovabrw_get_time_string( $start_time ) . esc_html__( '-', 'ova-brw' ) . ovabrw_get_time_string( $end_time );
                } else {
                    $str_time = '';
                }

                // Add unavailable date
                array_push( $unavaiable_dates, [
                    'start' => $checkin_date,
                    'end'   => $checkout_date,
                    'title' => $str_time,
                    'time'  => ovabrw_get_time_string( $start_time ) . '-' . ovabrw_get_time_string( $end_time )
                ]);

                // Check is disable date
                if ( '00:00' == $start_time && '24:00' == $end_time ) {
                    array_push( $disabled_dates, $start_date  );
                }
            } elseif ( 1 == $between_days ) {
                // Get time
                $str_time = $start_time . esc_html__( '-24:00', 'ova-brw' );

                if ( !in_array( $str_time, $filter_title ) ) {
                    $str_time = ovabrw_get_time_string( $start_time ) . esc_html__( '-', 'ova-brw' ) . '24:00';
                } else {
                    $str_time = '';
                }

                // Add unavailable date
                array_push( $unavaiable_dates, [
                    'start' => $checkin_date,
                    'end'   => $start_date . ' 24:00',
                    'title' => $str_time,
                    'time'  => ovabrw_get_time_string( $start_time ) . '-24:00'
                ]);

                // Check is disable date
                if ( '00:00' == $start_time ) {
                    array_push( $disabled_dates, $start_date );
                }

                // Get time
                $str_time = esc_html__( '00:00-', 'ova-brw' ) . $end_time;

                if ( !in_array( $str_time, $filter_title ) ) {
                    $str_time = '00:00' . esc_html__( '-', 'ova-brw' ) . ovabrw_get_time_string( $end_time );
                } else {
                    $str_time = '';
                }

                // Add unavailable date
                array_push( $unavaiable_dates, [
                    'start' => $end_date . ' 00:00',
                    'end'   => $checkout_date,
                    'title' => $str_time,
                    'time'  => '00:00-' . ovabrw_get_time_string( $end_time )
                ]); 

                // Check is disable date
                if ( '24:00' == $end_time ) {
                    array_push( $disabled_dates, $end_date );
                }
            } else {
                // Get time
                $str_time = $start_time . esc_html__( '-24:00', 'ova-brw' );

                if ( !in_array( $str_time, $filter_title ) ) {
                    $str_time = ovabrw_get_time_string( $start_time ) . esc_html__( '-', 'ova-brw' ) . '24:00';
                } else {
                    $str_time = '';
                }

                // Add unavailable date
                array_push( $unavaiable_dates, [
                    'start' => $checkin_date,
                    'end'   => $start_date . ' 24:00',
                    'title' => $str_time,
                    'time'  => ovabrw_get_time_string( $start_time ) . '-24:00'
                ]);

                // Check is disable date
                if ( '00:00' == $start_time ) {
                    array_push( $disabled_dates, $start_date );
                }

                // Get time
                $str_time = esc_html__( '00:00-', 'ova-brw' ) . $end_time;

                if ( !in_array( $str_time, $filter_title ) ) {
                    $str_time = '00:00' . esc_html__( '-', 'ova-brw' ) . ovabrw_get_time_string( $end_time );
                } else {
                    $str_time = '';
                }

                // Add unavailable date
                array_push( $unavaiable_dates, [
                    'start' => $end_date . ' 00:00',
                    'end'   => $checkout_date,
                    'title' => $str_time,
                    'time'  => '00:00-' . ovabrw_get_time_string( $end_time )
                ]);

                // Check is disable date
                if ( '24:00' == $end_time ) {
                    array_push( $disabled_dates, $end_date );
                }
                
                // Get date between
                $date_between = ovabrw_get_range_dates( strtotime( $start_date ), strtotime( $end_date ), $date_format );

                // Remove first and last array
                array_shift( $date_between ); 
                array_pop( $date_between );

                foreach ( $date_between as $key => $date ) {
                    // Add unavailable date
                    array_push( $unavaiable_dates, [
                        'start' => $date,
                        'end'   => $date
                    ]);

                    // Add date to disabled dates
                    array_push( $disabled_dates, $date );
                }
            }

            return apply_filters( 'ovabrw_get_unavailable_dates', [
                'unavaiable_dates'  => $unavaiable_dates,
                'total_each_day'    => $disabled_dates
            ], $product_id, $pickup_date, $dropoff_date );
        }

        /**
         * Get unavailable times
         */
        public function get_unavailable_times( $pickup_date = '', $dropoff_date = '' ) {
            if ( !$pickup_date || !$dropoff_date ) return false;

            // Calendar background
            $calendar_background = get_option( 'ova_brw_bg_calendar', '#c4c4c4' );

            if ( ovabrw_global_typography() ) {
                $calendar_background = get_option( 'ovabrw_glb_primary_color', '#e56e00' );
            }
            if ( !$calendar_background ) $calendar_background = '#c4c4c4';

            // Date & Time format
            $date_format    = 'Y-m-d';
            $time_format    = 'H:i';

            // Convert date
            $checkin_date   = date( $date_format . ' ' . $time_format, $pickup_date );
            $checkout_date  = date( $date_format . ' ' . $time_format, $dropoff_date );
            $start_date     = date( $date_format, $pickup_date );
            $end_date       = date( $date_format, $dropoff_date );
            $start_time     = date( $time_format, $pickup_date );
            $end_time       = date( $time_format, $dropoff_date );

            if ( '00:00' == $end_time ) {
                $checkin_date   = date( $date_format, $dropoff_date - 86400 ) . ' 24:00';
                $end_date       = date( $date_format, $dropoff_date - 86400 );
                $end_time       = '24:00';
            } elseif ( '23:59' == $end_time ) {
                $checkout_date  = $end_date . ' 24:00';
                $end_time       = '24:00';
            }

            // init
            $unavaiable_dates   = $disabled_dates = [];
            $between_days       = ovabrw_get_numberof_between_days( $start_date, $end_date );

            // Filter time
            $filter_title = apply_filters( 'ovabrw_unavailable_filter_time', [
                '00:00-00:00',
                '00:00-24:00',
                '24:00-24:00',
                '24:00-00:00'
            ]);

            if ( 0 == $between_days ) {
                // Get time
                $str_time = $start_time . '-' . $end_time;

                if ( !in_array( $str_time, $filter_title ) ) {
                    $str_time = ovabrw_get_time_string( $start_time ) . esc_html__( '-', 'ova-brw' ) . ovabrw_get_time_string( $end_time );
                } else {
                    $str_time = '';
                }

                // Add unavailable date
                array_push( $unavaiable_dates, [
                    'start'             => $checkin_date,
                    'end'               => $checkout_date,
                    'title'             => $str_time,
                    'time'              => ovabrw_get_time_string( $start_time ) . '-' . ovabrw_get_time_string( $end_time ),
                    'backgroundColor'   => $calendar_background,
                    'borderColor'       => 'transparent'
                ]);
                
                // Check is disabled date
                if ( '00:00' == $start_time && '24:00' == $end_time ) {
                    array_push( $disabled_dates, $start_date  );
                }
            } elseif ( 1 == $between_days ) {
                // Get time
                $str_time = $start_time . esc_html__( '-24:00', 'ova-brw' );
                if ( !in_array( $str_time, $filter_title ) ) {
                    $str_time = ovabrw_get_time_string( $start_time ) . esc_html__( '-', 'ova-brw' ) . '24:00';
                } else {
                    $str_time = '';
                }

                // Add unavailable date
                array_push( $unavaiable_dates, [
                    'start'             => $checkin_date,
                    'end'               => $start_date . ' 24:00',
                    'title'             => $str_time,
                    'time'              => ovabrw_get_time_string( $start_time ) . '-24:00',
                    'backgroundColor'   => $calendar_background,
                    'borderColor'       => 'transparent'
                ]);

                // Check is disabled date
                if ( '00:00' == $start_time ) {
                    array_push( $disabled_dates, $start_date );
                }

                // Get time
                $str_time = esc_html__( '00:00-', 'ova-brw' ) . $end_time;

                if ( !in_array( $str_time, $filter_title ) ) {
                    $str_time = '00:00' . esc_html__( '-', 'ova-brw' ) . ovabrw_get_time_string( $end_time );
                } else {
                    $str_time = '';
                }

                // Add unavailable date
                array_push( $unavaiable_dates, [
                    'start'             => $end_date . ' 00:00',
                    'end'               => $checkout_date,
                    'title'             => $str_time,
                    'time'              => '00:00-' . ovabrw_get_time_string( $end_time ),
                    'backgroundColor'   => $calendar_background,
                    'borderColor'       => 'transparent'
                ]);

                // Check is disabled date
                if ( '24:00' == $end_time ) {
                    array_push( $disabled_dates, $end_date );
                }
            } else {
                // Get time
                $str_time = $start_time . esc_html__( '-24:00', 'ova-brw' );

                if ( !in_array( $str_time, $filter_title ) ) {
                    $str_time = ovabrw_get_time_string( $start_time ) . esc_html__( '-', 'ova-brw' ) . '24:00';
                } else {
                    $str_time = '';
                }

                // Add unavailable date
                array_push( $unavaiable_dates, [
                    'start'             => $checkin_date,
                    'end'               => $start_date . ' 24:00',
                    'title'             => $str_time,
                    'time'              => ovabrw_get_time_string( $start_time ) . '-24:00',
                    'backgroundColor'   => $calendar_background,
                    'borderColor'       => 'transparent'
                ]);

                // Check is disabled date
                if ( '00:00' == $start_time ) {
                    array_push( $disabled_dates, $start_date );
                }


                // Get time
                $str_time = esc_html__( '00:00-', 'ova-brw' ) . $end_time;

                if ( !in_array( $str_time, $filter_title ) ) {
                    $str_time = '00:00' . esc_html__( '-', 'ova-brw' ) . ovabrw_get_time_string( $end_time );
                } else {
                    $str_time = '';
                }

                // Add unavailable date
                array_push( $unavaiable_dates, [
                    'start'             => $end_date . ' 00:00',
                    'end'               => $checkout_date,
                    'title'             => $str_time,
                    'time'              => '00:00-' . ovabrw_get_time_string( $end_time ),
                    'backgroundColor'   => $calendar_background,
                    'borderColor'       => 'transparent'
                ]);

                // Check is disabled date
                if ( '24:00' == $end_time ) {
                    array_push( $disabled_dates, $end_date );
                }

                $date_between = ovabrw_get_range_dates( strtotime( $start_date ), strtotime( $end_date ), $date_format );

                // Remove first and last array
                array_shift( $date_between ); 
                array_pop( $date_between );

                foreach ( $date_between as $key => $date ) {
                    // Add unavailable date
                    array_push( $unavaiable_dates, [
                        'start'             => $date,
                        'end'               => $date,
                        'backgroundColor'   => $calendar_background,
                        'borderColor'       => 'transparent'
                    ]);

                    // Check is disabled date
                    array_push( $disabled_dates, $date );
                }
            }

            return apply_filters( 'ovabrw_get_unavailable_times', array(
                'unavaiable_dates'  => $unavaiable_dates,
                'total_each_day'    => $disabled_dates
            ), $pickup_date, $dropoff_date );
        }

        /**
         * Get unavailable dates for hotel
         */
        public function get_unavailable_dates_by_hotel( $product_id = false, $pickup_date = '', $dropoff_date = '' ) {
            if ( !$product_id || !$pickup_date || !$dropoff_date ) return false;

            // Get Rental Type
            $rental_type = $this->get_meta_value( $product_id, 'price_type' );
            $date_format = 'Y-m-d';

            // Convert date
            $start_date = date( $date_format, $pickup_date );
            $end_date   = date( $date_format, $dropoff_date );

            $unavaiable_dates   = $disabled_dates = [];
            $between_days       = ovabrw_get_numberof_between_days( $start_date, $end_date );

            if ( 0 == $between_days ) {
                array_push( $disabled_dates, $start_date );
            } elseif ( 1 == $between_days ) {
                array_push( $disabled_dates, $start_date );
            } else {
                array_push( $disabled_dates, $start_date );
                
                $date_between = ovabrw_get_range_dates( strtotime( $start_date ), strtotime( $end_date ), $date_format );

                // Remove first and last array
                array_shift( $date_between ); 
                array_pop( $date_between );

                foreach ( $date_between as $key => $value ) {
                    array_push( $disabled_dates, $value );
                }
            }

            return apply_filters( 'ovabrw_get_unavailable_dates_by_hotel', [
                'unavaiable_dates'  => $unavaiable_dates,
                'total_each_day'    => $disabled_dates
            ], $product_id, $pickup_date, $dropoff_date );
        }

        /**
         * Get unavailable times for hotel
         */
        public function get_unavailable_times_by_hotel( $pickup_date = '', $dropoff_date = '' ) {
            if ( !$pickup_date || !$dropoff_date ) return false;

            // Calendar background
            $calendar_background = get_option( 'ova_brw_bg_calendar', '#c4c4c4' );

            if ( ovabrw_global_typography() ) {
                $calendar_background = get_option( 'ovabrw_glb_primary_color', '#e56e00' );
            }
            if ( !$calendar_background ) $calendar_background = '#c4c4c4';

            $date_format = 'Y-m-d';

            // Convert date
            $start_date = date( $date_format, $pickup_date );
            $end_date   = date( $date_format, $dropoff_date );

            $unavaiable_dates   = $disabled_dates = [];
            $between_days       = ovabrw_get_numberof_between_days( $start_date, $end_date );

            if ( $between_days == 0 ) {
                array_push( $disabled_dates, $start_date );
            } elseif ( $between_days == 1 ) {
                array_push( $disabled_dates, $start_date );
                array_push( $disabled_dates, $end_date );
            } else {
                array_push( $disabled_dates, $start_date );
                array_push( $disabled_dates, $end_date );
                
                $date_between = ovabrw_get_range_dates( strtotime( $start_date ), strtotime( $end_date ), $date_format );

                // Remove first and last array
                array_shift( $date_between ); 
                array_pop( $date_between );

                foreach ( $date_between as $key => $value ) {
                    array_push( $disabled_dates, $value );
                }
            }

            return apply_filters( 'ovabrw_get_unavailable_times_by_hotel', [
                'unavaiable_dates'  => $unavaiable_dates,
                'total_each_day'    => $disabled_dates
            ], $pickup_date, $dropoff_date );
        }

        /**
         * Get location title by vehicle
         */
        public function get_location_title_by_vehicle( $vehicle_id = false ) {
            if ( !$vehicle_id ) return false;

            $vehicles = [];

            $args_query = [
                'post_type'         => 'vehicle',
                'post_status'       => 'publish',
                'posts_per_page'    => 1,
                'fields'            => 'ids',
                'meta_query'        => array(
                    array(
                        'key'     => 'ovabrw_id_vehicle',
                        'value'   => $vehicle_id,
                        'compare' => '=',
                    ),
                ),
            ];

            $vehicle_ids = get_posts( $args_query );

            if ( ovabrw_array_exists( $vehicle_ids ) ) {
                foreach ( $vehicle_ids as $id ) {
                    $vehicles['location']   = $this->get_meta_value( $id, 'id_vehicle_location' );
                    $vehicles['required']   = $this->get_meta_value( $id, 'vehicle_require_location' );
                    $vehicles['untime']     = $this->get_meta_value( $id, 'id_vehicle_untime_from_day' );
                    $vehicles['vehicle_id'] = $this->get_meta_value( $id, 'id_vehicle' );
                    $vehicles['title']      = get_the_title( $id );
                }
            }

            return apply_filters( 'ovabrw_get_location_title_by_vehicle', $vehicles, $vehicle_id );
        }

        /**
         * Get vehicle ids available
         */
        public function get_vehicle_ids_available( $data ) {
            if ( !ovabrw_array_exists( $data ) ) return false;

            $product_name       = sanitize_text_field( ovabrw_get_meta_data( 'ovabrw_name_product', $data ) );
            $pickup_location    = sanitize_text_field( ovabrw_get_meta_data( 'ovabrw_pickup_loc', $data ) );
            $dropoff_location   = sanitize_text_field( ovabrw_get_meta_data( 'ovabrw_pickoff_loc', $data ) );
            $pickup_date        = sanitize_text_field( ovabrw_get_meta_data( 'ovabrw_pickup_date', $data ) );
            $dropoff_date       = sanitize_text_field( ovabrw_get_meta_data( 'ovabrw_pickoff_date', $data ) );
            $order              = sanitize_text_field( ovabrw_get_meta_data( 'order', $data, 'DESC' ) );
            $order_by           = sanitize_text_field( ovabrw_get_meta_data( 'orderby', $data, 'ID' ) );
            $attribute_name     = sanitize_text_field( ovabrw_get_meta_data( 'ovabrw_attribute', $data ) );
            $attribute_value    = sanitize_text_field( ovabrw_get_meta_data( $attribute_name, $data ) );
            $category           = sanitize_text_field( ovabrw_get_meta_data( 'cat', $data ) );
            $product_tag        = sanitize_text_field( ovabrw_get_meta_data( 'ovabrw_tag_product', $data ) );
            $quantity           = (int)ovabrw_get_meta_data( 'quantity', $data, 1 );

            // Guests
            $adults     = sanitize_text_field( ovabrw_get_meta_data( 'ovabrw_adults', $data ) );
            $children   = sanitize_text_field( ovabrw_get_meta_data( 'ovabrw_children', $data ) );
            $babies     = sanitize_text_field( ovabrw_get_meta_data( 'ovabrw_babies', $data ) );

            // Taxi
            if ( ovabrw_get_meta_data( 'pickup-date', $data ) ) {
                $pickup_date = ovabrw_get_meta_data( 'pickup-date', $data );

                if ( ovabrw_get_meta_data( 'map-duration', $data ) ) {
                    $dropoff_date = date( 'Y-m-d H:i', strtotime( $pickup_date ) + (int)ovabrw_get_meta_data( 'map-duration', $data ) );
                }
            }

            // Number Seats
            $number_seats = (int)ovabrw_get_meta_data( 'number-seats', $data );

            // Get list taxonomy
            $taxonomies     = [];
            $list_taxonomy  = ovabrw_create_type_taxonomies();
            
            if ( ovabrw_array_exists( $list_taxonomy ) ) {
                foreach ( $list_taxonomy as $taxonomy ) {
                    $slug = ovabrw_get_meta_data( 'slug', $taxonomy );

                    if ( $slug ) {
                        $taxo = sanitize_text_field( ovabrw_get_meta_data( $slug.'_name', $data ) );

                        if ( $taxo ) {
                            $taxonomies[] = [
                                'taxonomy'  => $slug,
                                'field'     => 'slug',
                                'terms'     => $taxo
                            ];
                        }
                    }
                }
            }

            $statuses   = ovabrw_get_order_status();
            $error      = array();
            $item_ids   = $tax_query = array();

            // Base query
            $args_base = [
                'post_type'         => 'product',
                'posts_per_page'    => '-1',
                'post_status'       => 'publish',
                'fields'            => 'ids',
                'tax_query'         => [
                    'relation'      => 'AND',
                    [
                        'taxonomy'  => 'product_type',
                        'field'     => 'slug',
                        'terms'     => 'ovabrw_car_rental'
                    ]
                ]
            ];

            // Product name
            if ( $product_name ) {
                $args_base['s'] = preg_replace( "/[^a-zA-Z]+/", " ", $product_name );
            }

            // Product category
            if ( $category ) {
                $taxonomies[] = [
                    'taxonomy'  => 'product_cat',
                    'field'     => 'slug',
                    'terms'     => $category
                ];
            }

            // Attribute
            if ( $attribute_name && $attribute_value ) {
                $taxonomies[] = [
                    'taxonomy'  => 'pa_' . $attribute_name,
                    'field'     => 'slug',
                    'terms'     => [$attribute_value],
                    'operator'  => 'IN',
                ];
            }

            // Product tag
            if ( $product_tag ) {
                $taxonomies[] = [
                    'taxonomy'  => 'product_tag',
                    'field'     => 'name',
                    'terms'     => $product_tag
                ];
            }

            // Taxonomy query
            if ( ovabrw_array_exists( $taxonomies ) ) {
                $tax_query = [
                    'tax_query' => [
                        $taxonomies
                    ]
                ];
            }

            // Meta Query
            $args_meta_query_arr = $meta_query = [];

            // Search by Guest
            if ( '' != $adults ) {
                $args_meta_query_arr[] = [
                    'key'     => 'ovabrw_max_adults',
                    'value'   => $adults,
                    'type'    => 'numeric',
                    'compare' => '>=',
                ];
            }

            if ( '' != $children ) {
                $args_meta_query_arr[] = [
                    'key'     => 'ovabrw_max_children',
                    'value'   => $children,
                    'type'    => 'numeric',
                    'compare' => '>=',
                ];
            }

            if ( '' != $babies ) {
                $args_meta_query_arr[] = [
                    'key'     => 'ovabrw_max_babies',
                    'value'   => $babies,
                    'type'    => 'numeric',
                    'compare' => '>=',
                ];
            }

            // Number seats
            if ( $number_seats ) {
                $args_meta_query_arr[] = [
                    'key'     => 'ovabrw_max_seats',
                    'value'   => $number_seats,
                    'type'    => 'numeric',
                    'compare' => '>=',
                ];
            }

            if ( ovabrw_array_exists( $args_meta_query_arr ) ) {
                $meta_query = [
                    'meta_query' => [
                        'relation'  => 'AND',
                        $args_meta_query_arr
                    ]
                ];
            }

            // Merge query
            $args_query = array_merge_recursive( $args_base, $tax_query, $meta_query );

            // Get product ids
            $product_ids = get_posts( $args_query );

            if ( ovabrw_array_exists( $product_ids ) ) {
                foreach ( $product_ids as $product_id ) {
                    // Check location
                    if ( $pickup_location || $dropoff_location ) {
                        if ( !ovabrw_check_location( $product_id, $pickup_location, $dropoff_location ) ) continue;
                    }

                    // Check dates
                    if ( strtotime( $pickup_date ) && strtotime( $dropoff_date ) ) {
                        $type = $this->get_meta_value( $product_id, 'price_type' );

                        // Object Rental Types
                        $rental_object = isset( OVABRW_Rental_Types::instance()->rental_types[$type] ) ? OVABRW_Rental_Types::instance()->rental_types[$type] : '';

                        if ( empty( $rental_object ) || ! is_object( $rental_object ) ) {
                            continue;
                        }

                        // Set Product ID
                        $rental_object->set_ID( $product_id );

                        $new_date = [
                            'pickup_date_new'   => '',
                            'dropoff_date_new'  => '',
                        ];

                        switch ( $type ) {
                            case 'day':
                                $new_date = $rental_object->get_strtotime_input_date( strtotime( $pickup_date ), strtotime( $dropoff_date ) );
                                break;
                            case 'hour':
                                $new_date = $rental_object->get_strtotime_input_date( strtotime( $pickup_date ), strtotime( $dropoff_date ) );
                                break;
                            case 'mixed':
                                $new_date = $rental_object->get_strtotime_input_date( strtotime( $pickup_date ), strtotime( $dropoff_date ) );
                                break;
                            case 'period_time':
                                $new_date = [
                                    'pickup_date_new'   => strtotime( $pickup_date ),
                                    'dropoff_date_new'  => strtotime( $dropoff_date ),
                                ];
                                break;
                            case 'transportation':
                                $new_date = $rental_object->get_strtotime_input_date( strtotime( $pickup_date ), strtotime( $dropoff_date ), $pickup_location, $dropoff_location );
                                break;
                            case 'taxi':
                                $new_date = [
                                    'pickup_date_new'   => strtotime( $pickup_date ),
                                    'dropoff_date_new'  => strtotime( $dropoff_date ),
                                ];
                                break;
                            default:
                                break;
                        }
                        
                        // Check Pick-up & Drop-off Date
                        $check_in    = $new_date['pickup_date_new'] ? $new_date['pickup_date_new'] : strtotime( $pickup_date );
                        $check_out   = $new_date['dropoff_date_new'] ? $new_date['dropoff_date_new'] : strtotime( $dropoff_date );

                        // Check available quantity
                        $data_available = $rental_object->get_qty_available( $check_in, $check_out, $pickup_location, $dropoff_location, 'search' );

                        if ( !$data_available ) continue;

                        $qty_available = intval( $data_available['qty_available'] );

                        if ( $qty_available && $qty_available >= $quantity ) {
                            array_push( $item_ids, $product_id );
                        }
                    } else {
                        array_push( $item_ids, $product_id );
                    }
                }
            }

            if ( $item_ids ) {
                $paged      = get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1;
                $per_page   = wc_get_default_products_per_row() * wc_get_default_product_rows_per_page();

                $args_query = [
                    'post_type'         => 'product',
                    'posts_per_page'    => $per_page,
                    'paged'             => $paged,
                    'post_status'       => 'publish',
                    'post__in'          => $item_ids,
                    'order'             => $order,
                    'orderby'           => $order_by
                ];

                // Orderby: rating
                if ( 'rating' == $args_query['orderby'] ) {
                    $args_query['orderby']  = 'meta_value_num';
                    $args_query['meta_key'] = '_wc_average_rating';
                } elseif ( 'rental_order' == $args_query['orderby'] ) {
                    $args_query['orderby']  = 'meta_value_num';
                    $args_query['meta_key'] = 'ovabrw_car_order';
                }

                // Get products
                $products = new WP_Query( $args_query );

                return apply_filters( 'ovabrw_get_vehicle_ids_available', $products, $data );
            }

            return apply_filters( 'ovabrw_get_vehicle_ids_available', false, $data );
        }
        
        /**
         * Get stock quantity
         */
        public function get_stock_quantity( $product_id = false ) {
            if ( !$product_id ) return 0;

            $manage_store   = $this->get_meta_value( $product_id, 'manage_store' );
            $stock_qty      = 0;

            if ( 'store' == $manage_store ) {
                $stock_qty = (int)$this->get_meta_value( $product_id, 'car_count' );
            } elseif ( 'id_vehicle' == $manage_store ) {
                $vehicle_ids    = $this->get_meta_value( $product_id, 'id_vehicles' );
                $stock_qty      = ovabrw_array_exists( $vehicle_ids ) ? count( $vehicle_ids ) : 0;
            }

            return apply_filters( 'ovabrw_get_stock_quantity', $stock_qty, $product_id );
        }

        /**
         * Get product ids - multi language
         */
        public function get_product_ids_multi_lang( $product_id = false ) {
            if ( !$product_id ) return [];

            // Product IDs
            $product_ids = [];

            if ( is_plugin_active( 'polylang/polylang.php' ) || is_plugin_active( 'polylang-pro/polylang.php' ) ) {
                $languages = pll_languages_list();

                if ( ovabrw_array_exists( $languages ) ) {
                    foreach ( $languages as $lang ) {
                        $p_id = pll_get_post( $product_id, $lang );

                        if ( $p_id ) $product_ids[] = $p_id;
                    }
                }
            } elseif ( is_plugin_active( 'sitepress-multilingual-cms/sitepress.php' ) ) {
                global $sitepress;

                if ( $sitepress && is_object( $sitepress ) ) {
                    $trid           = $sitepress->get_element_trid( $product_id, 'post_product' );
                    $translations   = $sitepress->get_element_translations( $trid, 'product' );

                    if ( ovabrw_array_exists( $translations ) ) {
                        foreach ( $translations as $lang => $translation ) {
                            $p_id = $translation->element_id;

                            if ( $p_id ) $product_ids[] = $p_id;
                        }
                    }
                }
            }

            // Check product IDs
            if ( !ovabrw_array_exists( $product_ids ) ) {
                $product_ids[] = $product_id;
            }

            return apply_filters( 'ovabrw_get_product_ids_multi_lang', $product_ids, $product_id );
        }

        /**
         * Get orders by product
         */
        public function get_orders_by_product_id( $product_id = false, $order_status = array( 'wc-completed' ) ) {
            if ( !$product_id ) return [];

            global $wpdb;
            $order_ids = array();

            // Get array product ids when use WPML
            $product_ids = $this->get_product_ids_multi_lang( $product_id );

            if ( OrderUtil::custom_orders_table_usage_is_enabled() ) {
                $order_ids = $wpdb->get_col("
                    SELECT DISTINCT o.id
                    FROM {$wpdb->prefix}wc_orders AS o
                    LEFT JOIN {$wpdb->prefix}woocommerce_order_items AS oitems
                    ON o.id = oitems.order_id
                    LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta AS oitem_meta
                    ON oitems.order_item_id = oitem_meta.order_item_id
                    WHERE o.type = 'shop_order'
                    AND oitems.order_item_type = 'line_item'
                    AND oitem_meta.meta_key = '_product_id'
                    AND oitem_meta.meta_value IN ( ".implode( ',', $product_ids )." )
                    AND o.status IN ( '" . implode( "','", $order_status ) . "' )
                ");
            } else {
                $order_ids = $wpdb->get_col("
                    SELECT DISTINCT oitems.order_id
                    FROM {$wpdb->prefix}woocommerce_order_items AS oitems
                    LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta AS oitem_meta
                    ON oitems.order_item_id = oitem_meta.order_item_id
                    LEFT JOIN {$wpdb->posts} AS posts
                    ON oitems.order_id = posts.ID
                    WHERE posts.post_type = 'shop_order'
                    AND oitems.order_item_type = 'line_item'
                    AND oitem_meta.meta_key = '_product_id'
                    AND oitem_meta.meta_value IN ( ".implode( ',', $product_ids )." )
                    AND posts.post_status IN ( '" . implode( "','", $order_status ) . "' )
                ");
            }
            
            return apply_filters( 'ovabrw_get_orders_by_product_id', $order_ids, $product_id, $order_status );
        }

        /**
         * Get orders by pick-up date
         */
        public function get_orders_by_pickup_date( $product_id = false, $pickup_date = false, $order_status = [ 'wc-completed' ] ) {
            if ( !$product_id || !$pickup_date ) return [];

            global $wpdb;
            $order_ids = array();

            // Get array product ids when use WPML
            $product_ids = $this->get_product_ids_multi_lang( $product_id );

            if ( OrderUtil::custom_orders_table_usage_is_enabled() ) {
                $order_ids = $wpdb->get_col("
                    SELECT DISTINCT o.id
                    FROM {$wpdb->prefix}wc_orders AS o
                    LEFT JOIN {$wpdb->prefix}woocommerce_order_items AS oitems
                    ON o.id = oitems.order_id
                    LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta AS oitem_meta
                    ON oitems.order_item_id = oitem_meta.order_item_id
                    LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta AS oitem_meta2
                    ON oitems.order_item_id = oitem_meta2.order_item_id
                    WHERE o.type = 'shop_order'
                    AND oitems.order_item_type = 'line_item'
                    AND oitem_meta.meta_key = '_product_id'
                    AND oitem_meta.meta_value IN ( ".implode( ',', $product_ids )." )
                    AND oitem_meta2.meta_key = 'ovabrw_pickup_date_strtotime'
                    AND oitem_meta2.meta_value = $pickup_date
                    AND o.status IN ( '" . implode( "','", $order_status ) . "' )
                ");
            } else {
                $order_ids = $wpdb->get_col("
                    SELECT DISTINCT oitems.order_id
                    FROM {$wpdb->prefix}woocommerce_order_items AS oitems
                    LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta AS oitem_meta
                    ON oitems.order_item_id = oitem_meta.order_item_id
                    LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta AS oitem_meta2
                    ON oitems.order_item_id = oitem_meta2.order_item_id
                    LEFT JOIN {$wpdb->posts} AS posts
                    ON oitems.order_id = posts.ID
                    WHERE posts.post_type = 'shop_order'
                    AND oitems.order_item_type = 'line_item'
                    AND oitem_meta.meta_key = '_product_id'
                    AND oitem_meta2.meta_key = 'ovabrw_pickup_date_strtotime'
                    AND oitem_meta2.meta_value = $pickup_date
                    AND oitem_meta.meta_value IN ( ".implode( ',', $product_ids )." )
                    AND posts.post_status IN ( '" . implode( "','", $order_status ) . "' )
                ");
            }
            
            return apply_filters( 'ovabrw_get_orders_by_product_id', $order_ids, $product_id, $order_status );
        }

        /**
         * Get product ids by rental type
         */
        public function get_product_ids_by_rental_type( $type = '', $exclude_type = false ) {
            $args_query = [
                'post_type'         => 'product',
                'posts_per_page'    => '-1',
                'post_status'       => 'publish',
                'fields'            => 'ids', 
                'tax_query'         => [
                    [
                        'taxonomy' => 'product_type',
                        'field'    => 'slug',
                        'terms'    => 'ovabrw_car_rental'
                    ]
                ]
            ];

            if ( $type ) {
                $args_query['meta_query'] = [
                    [
                        'key'     => 'ovabrw_price_type',
                        'value'   => $type,
                        'compare' => '='
                    ]
                ];

                if ( $exclude_type ) {
                    $args_query['meta_query'] = [
                        [
                            'key'     => 'ovabrw_price_type',
                            'value'   => $type,
                            'compare' => '!='
                        ]
                    ];
                }
            }

            // Get product IDs
            $product_ids = get_posts( $args_query );

            return apply_filters( 'ovabrw_get_product_ids_by_rental_type', $product_ids, $type, $exclude_type );
        }

        /**
         * Get all location IDs
         */
        public function get_all_location_ids() {
            $locations = get_posts(
                [
                    'post_type'         => 'location',
                    'post_status'       => 'publish',
                    'posts_per_page'    => '-1',
                    'fields'            => 'ids'
                ]
            );

            return apply_filters( 'ovabrw_get_all_location_ids', $locations );
        }

        /**
         * Get data location
         */
        public function get_data_location() {
            $locations      = $this->get_all_location_ids();
            $data_location  = array();

            if ( ovabrw_array_exists( $locations ) ) {
                foreach ( $locations as $location_id ) {
                    $data_location[trim( get_the_title( $location_id ) )] = trim( get_the_title( $location_id ) );
                }
            }
            
            return apply_filters( 'ovabrw_get_data_location', $data_location );
        }

        /**
         * Get couple location
         */
        public function get_couple_location( $product_id = false ) {
            if ( !$product_id ) return [];

            $pickup_location    = $this->get_meta_value( $product_id, 'st_pickup_loc' );
            $dropoff_location   = $this->get_meta_value( $product_id, 'st_dropoff_loc' );
            $couple_location    = [];

            if ( ovabrw_array_exists( $pickup_location ) && ovabrw_array_exists( $dropoff_location ) ) {
                foreach ( $pickup_location as $k => $pickup_loc ) {
                    $dropoff_loc = isset( $dropoff_location[$k] ) ? $dropoff_location[$k] : '';

                    if ( $pickup_loc && $dropoff_loc ) {
                        $couple_location[$pickup_loc][] = $dropoff_loc;
                        $couple_location[$pickup_loc]   = array_unique( $couple_location[$pickup_loc] );
                    }
                }
            }

            return apply_filters( 'ovabrw_get_couple_location', $couple_location, $product_id );
        }

        /**
         * Get location HTML
         */
        public function get_html_location( $name = '', $required = 'required', $selected = '', $product_id = false, $type = 'pickup', $show_other_location = false ) {
            if ( !$name ) return '';

            // Get location ids
            $location_ids = $this->get_all_location_ids();

            if ( $product_id ) {
                if ( 'pickup' == $type ) {
                    $show_other_location = $this->get_meta_value( $product_id, 'show_other_location_pickup_product' );
                    $show_other_location = $show_other_location == 'no' ? false : true;
                } else {
                    $show_other_location = $this->get_meta_value( $product_id, 'show_other_location_dropoff_product' );
                    $show_other_location = $show_other_location == 'no' ? false : true;
                }
            }

            $html = '<select name="'.$name.'" class="'.$required.'">';
                $html .= '<option value="">'. esc_html__( 'Select Location', 'ova-brw' ).'</option>';

                // Loop locations
                if ( ovabrw_array_exists( $location_ids ) ) {
                    foreach ( $location_ids as $location_id ) {
                        $title = get_the_title( $location_id );

                        if ( $title ) {
                            $active = ( trim( $title ) == trim( $selected ) ) ? 'selected="selected"' : '';
                            $html .= '<option value="'.$title.'" '.$active.'>'.$title.'</option>';
                        }
                    }
                }

                if ( $show_other_location ) {
                    $active = ( 'other_location' == trim( $selected ) ) ? 'selected="selected"' : '';
                    $html   .= '<option value="other_location" '.$active.'>'. esc_html__( 'Other Location', 'ova-brw' ).'</option>';
                }
            $html .= '</select>';

            return apply_filters( 'ovabrw_get_html_location', $html, $name, $required, $selected, $product_id, $type, $show_other_location );
        }

        /**
         * Get couple location transportation
         */
        public function get_couple_location_transportation( $product_id = false ) {
            if ( !$product_id ) return [];

            $pickup_location    = $this->get_meta_value( $product_id, 'pickup_location' );
            $dropoff_location   = $this->get_meta_value( $product_id, 'dropoff_location' );
            $couple_location    = [];

            if ( ovabrw_array_exists( $pickup_location ) && ovabrw_array_exists( $dropoff_location ) ) {
                foreach ( $pickup_location as $k => $pickup_loc ) {
                    $dropoff_loc = isset( $dropoff_location[$k] ) ? $dropoff_location[$k] : '';

                    if ( $pickup_loc && $dropoff_loc ) {
                        $couple_location[$pickup_loc][] = $dropoff_loc;
                        $couple_location[$pickup_loc]   = array_unique( $couple_location[$pickup_loc] );
                    }
                }
            }

            return apply_filters( 'ovabrw_get_couple_location_transportation', $couple_location, $product_id );
        }

        /**
         * Get location transportation HTML
         */
        public function get_html_location_transportation( $name = '', $required = 'required', $selected = '', $product_id = false, $type = 'pickup' ) {
            if ( !$name || !$product_id ) return '';

            $couple_location = $this->get_couple_location_transportation( $product_id );
            $class = 'ovabrw-transport';

            if ( $required ) $class .= ' ovabrw-input-required';

            $html = '<select name="'.$name.'" class="'.$class.'">';
                $html .= '<option value="">'.esc_html__( 'Select Location', 'ova-brw' ).'</option>';

                if ( ovabrw_array_exists( $couple_location ) ) {
                    foreach ( $couple_location as $pickup_loc => $dropoff_loc ) {
                        $active = ( trim( $pickup_loc ) === trim( $selected ) ) ? 'selected="selected"' : '';
                        $html .= '<option data-item_loc="'.esc_attr(json_encode($dropoff_loc)).'" value="'.trim( $pickup_loc ).'" '.$active.'>'.trim( $pickup_loc ).'</option>';
                    }
                }
            $html .= '</select>';

            return apply_filters( 'ovabrw_get_html_location_transportation', $html, $name, $required, $selected, $product_id, $type );
        }

        /**
         * Get couple location HTML
         */
        public function get_html_couple_location( $name = '', $required = 'required', $selected = '', $product_id = false, $type = 'pickup', $validate = '' ) {
            if ( !$name || !$product_id ) return '';

            // Get couple location
            $couple_location = $this->get_couple_location( $product_id );

            // Show other location
            $show_other_location = true;

            if ( 'pickup' == $type ) {
                $show_other_location = $this->get_meta_value( $product_id, 'show_other_location_pickup_product' );
                $show_other_location = $show_other_location == 'no' ? false : true;
            } else {
                $show_other_location = $this->get_meta_value( $product_id, 'show_other_location_dropoff_product' );
                $show_other_location = $show_other_location == 'no' ? false : true;
            }

            // Required
            $class = 'ovabrw-transport';
            if ( $required ) $class .= ' ovabrw-input-required';

            $html = '<select name="'.$name.'" class="'.$class.'">';
                $html .= '<option value="">'. esc_html__( 'Select Location', 'ova-brw' ).'</option>';

            if ( 'pickup' == $type ) {
                if ( ovabrw_array_exists( $couple_location ) ) {
                    foreach ( $couple_location as $loc => $item_loc ) {
                        $active = ( trim( $loc ) === trim( $selected ) ) ? 'selected="selected"' : '';
                        $html .= '<option data-item_loc="'.esc_attr(json_encode($item_loc)).'" value="'.trim( $loc ).'" '.$active.'>'.trim( $loc ).'</option>';
                    }
                }
            } elseif ( 'dropoff' == $type ) {
                $html = '<select name="'.$name.'" class="'.$class.'">';
                $html .= '<option value="">'. esc_html__( 'Select Location', 'ova-brw' ).'</option>';

                if ( ovabrw_array_exists( $couple_location ) ) {
                    foreach ( $couple_location as $loc => $item_loc ) {
                        if ( trim( $loc ) == trim( $validate ) && ovabrw_array_exists( $item_loc ) ) {
                            foreach ( $item_loc as $dropoff_loc ) {
                                $active = ( trim( $dropoff_loc ) == trim( $selected ) ) ? 'selected="selected"' : '';
                                $html .= '<option value="'.trim( $dropoff_loc ).'" '.$active.'>'.trim( $dropoff_loc ).'</option>';
                            }
                        }
                    }
                }
            }

            if ( $show_other_location ) {
                $active = 'other_location' == trim( $selected ) ? 'selected="selected"' : '';
                $html .= '<option value="other_location" '.$active.'>'. esc_html__( 'Other Location', 'ova-brw' ).'</option>';
            }

            $html .= '</select>';

            return apply_filters( 'ovabrw_get_html_couple_location', $html, $name, $required, $selected, $product_id, $type, $validate );
        }

        /**
         * Get all vehicle IDs
         */
        public function get_all_vehicle_ids() {
            $vehicle_ids = get_posts( apply_filters( 'ovabrw_query_get_all_vehicle_ids', [
                'post_type'         => 'vehicle',
                'post_status'       => 'publish',
                'posts_per_page'    => '-1',
                'fields'            => 'ids'
            ]));

            return apply_filters( 'ovabrw_get_all_vehicle_ids', $vehicle_ids );
        }

        /**
         * Get data vehicles
         */
        public function get_data_vehicles() {
            $data_vehicle   = [];
            $vehicle_ids    = $this->get_all_vehicle_ids();

            if ( ovabrw_array_exists( $vehicle_ids ) ) {
                foreach ( $vehicle_ids as $id ) {
                    $vehicle_id = $this->get_meta_value( $id, 'id_vehicle' );

                    if ( $vehicle_id ) {
                        $data_vehicle[$vehicle_id] = get_the_title( $id );
                    }
                }
            }

            return apply_filters( 'ovabrw_get_data_vehicles', $data_vehicle );
        }

        /**
         * Get taxonomies HTML dropdown
         */
        public function get_html_dropdown_taxonomies( $selected = '', $required = '', $exclude_id = '', $slug = '', $name = '' ) {
            $args = [
                'show_option_all'    => '',
                'show_option_none'   => esc_html__( 'All ', 'ova-brw' ) . esc_html( $name ) ,
                'option_none_value'  => '',
                'orderby'            => 'ID',
                'order'              => 'ASC',
                'show_count'         => 0,
                'hide_empty'         => 0,
                'child_of'           => 0,
                'exclude'            => $exclude_id,
                'include'            => '',
                'echo'               => 0,
                'selected'           => $selected,
                'hierarchical'       => 1,
                'name'               => $slug.'_name',
                'id'                 => '',
                'class'              => 'postform '.$required,
                'depth'              => 0,
                'tab_index'          => 0,
                'taxonomy'           => $slug,
                'hide_if_empty'      => false,
                'value_field'        => 'slug',
            ];

            return urldecode( wp_dropdown_categories( $args ) );
        }

        /**
         * Get categories HTML dropdown
         */
        public function get_html_dropdown_categories( $selected = '', $required = '', $exclude_id = '', $label = '', $include_id = '' ) {
            if ( !$label ) {
                $label = esc_html__( 'Select Category', 'ova-brw' );
            }
            
            $args = array(
                'show_option_all'    => '',
                'show_option_none'   => $label,
                'option_none_value'  => '',
                'orderby'            => 'ID',
                'order'              => 'ASC',
                'show_count'         => 0,
                'hide_empty'         => 0,
                'child_of'           => 0,
                'exclude'            => $exclude_id,
                'include'            => $include_id,
                'echo'               => 0,
                'selected'           => $selected,
                'hierarchical'       => 1,
                'name'               => 'cat',
                'id'                 => '',
                'class'              => 'postform '.$required,
                'depth'              => 0,
                'tab_index'          => 0,
                'taxonomy'           => 'product_cat',
                'hide_if_empty'      => false,
                'value_field'        => 'slug',
            );

            return urldecode( wp_dropdown_categories( $args ) );
        }

        /**
         * Get rental period data
         */
        public function get_rental_info_period( $product_id = false, $start_date = '', $rental_type = '', $package_id = '' ) {
            $results = [
                'start_time'    => 0,
                'end_time'      => 0,
                'period_label'  => '',
                'period_price'  => '',
                'package_type'  => '',
            ];

            if ( !$product_id || !$start_date || !$rental_type || !$package_id ) return $results;
            
            $unfixed_time = $this->get_meta_value( $product_id, 'unfixed_time' );

            if ( 'yes' == $unfixed_time ) {
                $start_date = date( 'Y-m-d H:i', $start_date );
            } else {
                $start_date = date( 'Y-m-d', $start_date );
            }

            $start_time     = $end_time = 0;
            $period_price   = 0;
            $pickup_date    = strtotime( $start_date );

            if ( 'period_time' == trim( $rental_type ) ) {
                $petime_ids         = $this->get_meta_value( $product_id, 'petime_id' );
                $petime_prices      = $this->get_meta_value( $product_id, 'petime_price' );
                $petime_days        = $this->get_meta_value( $product_id, 'petime_days' );
                $petime_labels      = $this->get_meta_value( $product_id, 'petime_label' );
                $petime_discounts   = $this->get_meta_value( $product_id, 'petime_discount' );
                $package_types      = $this->get_meta_value( $product_id, 'package_type' );
                $pehour_unfixed     = $this->get_meta_value( $product_id, 'pehour_unfixed' );
                $pehour_start_times = $this->get_meta_value( $product_id, 'pehour_start_time' );
                $pehour_end_times   = $this->get_meta_value( $product_id, 'pehour_end_time' );

                if ( ovabrw_array_exists( $petime_ids ) ) { 
                    foreach ( $petime_ids as $k => $petime_id ) {
                        if ( $petime_id == $package_id ) {
                            $package_type = ovabrw_get_meta_data( $k, $package_types );

                            if ( 'inday' == $package_type ) {
                                $pehour_start_time  = ovabrw_get_meta_data( $k, $pehour_start_times );
                                $pehour_end_time    = ovabrw_get_meta_data( $k, $pehour_end_times );

                                $start_time = strtotime( $start_date . ' ' . $pehour_start_time );
                                $end_time   = strtotime( $start_date . ' ' . $pehour_end_time );

                                if ( 'yes' == $unfixed_time ) {
                                    $pehort_unfixed_time = (int)ovabrw_get_meta_data( $k, $pehour_unfixed );

                                    $start_time = $pickup_date;
                                    $end_time   = $pickup_date + $pehort_unfixed_time*3600;
                                }

                                $results['period_label'] = ovabrw_get_meta_data( $k, $petime_labels );
                                $results['package_type'] = 'inday';

                                $period_price       = (float)ovabrw_get_meta_data( $k, $petime_prices );
                                $petime_discount    = ovabrw_get_meta_data( $k, $petime_discounts );

                                if ( ovabrw_array_exists( $petime_discount ) ) {
                                    $dsc_price  = ovabrw_get_meta_data( 'price', $petime_discount );
                                    $dsc_start  = ovabrw_get_meta_data( 'start_time', $petime_discount );
                                    $dsc_end    = ovabrw_get_meta_data( 'end_time', $petime_discount );

                                    if ( ovabrw_array_exists( $dsc_price ) ) {
                                        foreach ( $dsc_price as $k_p => $price ) {
                                            $start  = strtotime( ovabrw_get_meta_data( $k, $dsc_start ) );
                                            $end    = ovabrw_get_meta_data( $k, $dsc_end );

                                            if ( $start && $end && $start <= $pickup_date && $pickup_date <= $end ) {
                                                $period_price = floatval( $price );
                                                break;
                                            }
                                        }
                                    }
                                }
                            } elseif ( 'other' == $package_type ) {
                                $petime_day = (int)ovabrw_get_meta_data( $k, $petime_days );

                                $start_time = $pickup_date;
                                $end_time   = $start_time + $petime_day*86400;

                                $results['period_label'] = ovabrw_get_meta_data( $k, $petime_labels );
                                $results['package_type'] = 'other';

                                $period_price       = (float)ovabrw_get_meta_data( $k, $petime_prices );
                                $petime_discount    = ovabrw_get_meta_data( $k, $petime_discounts );

                                if ( ovabrw_array_exists( $petime_discount ) ) {
                                    $dsc_price  = ovabrw_get_meta_data( 'price', $petime_discount );
                                    $dsc_start  = ovabrw_get_meta_data( 'start_time', $petime_discount );
                                    $dsc_end    = ovabrw_get_meta_data( 'end_time', $petime_discount );

                                    if ( ovabrw_array_exists( $dsc_price ) ) {
                                        foreach ( $dsc_price as $k_p => $price ) {
                                            $start  = strtotime( ovabrw_get_meta_data( $k, $dsc_start ) );
                                            $end    = strtotime( ovabrw_get_meta_data( $k, $dsc_end ) );

                                            if ( $start && $end && $start <= $pickup_date && $pickup_date <= $end ) {
                                                $period_price = floatval( $price );
                                                break;
                                            }
                                        }
                                    }
                                }
                            }

                            break;
                        }
                    }
                }
            }

            $results['start_time']      = $start_time;
            $results['end_time']        = $end_time;
            $results['period_price']    = $period_price;

            return apply_filters( 'ovabrw_get_rental_info_period', $results, $product_id, $start_date, $rental_type, $package_id );
        }

        /**
         * Get real data
         */
        public function get_real_data( $product_id = false, $rental_type = '', $pickup_date = '', $dropoff_date = '' ) {
            $real_data = [
                'real_quantity' => '',
                'real_price'    => ''
            ];

            if ( !$product_id || !$rental_type || !$pickup_date || !$dropoff_date ) return $real_data;

            $rental_object = isset( OVABRW_Rental_Types::instance()->rental_types[$rental_type] ) ? OVABRW_Rental_Types::instance()->rental_types[$rental_type] : '';

            if ( empty( $rental_object ) || !is_object( $rental_object ) ) {
                return $real_data;
            }

            // Set Product ID
            $rental_object->set_ID( $product_id );

            $real_data = $rental_object->get_real_data( $pickup_date, $dropoff_date );

            return apply_filters( 'ovabrw_get_real_data', $real_data, $product_id, $rental_type, $pickup_date, $dropoff_date );
        }

        /**
         * Get orders future
         */
        public function get_orders_future() {
            global $wpdb;

            $order_ids      = [];
            $order_status   = ovabrw_get_order_status();

            if ( OrderUtil::custom_orders_table_usage_is_enabled() ) {
                $order_ids = $wpdb->get_col( $wpdb->prepare("
                    SELECT DISTINCT o.id
                    FROM {$wpdb->prefix}wc_orders AS o
                    LEFT JOIN {$wpdb->prefix}woocommerce_order_items AS oi
                        ON o.id = oi.order_id
                        AND oi.order_item_type = 'line_item'
                    LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta AS oim
                        ON oi.order_item_id = oim.order_item_id
                    WHERE o.type = 'shop_order'
                        AND oim.meta_key = 'ovabrw_pickup_date_strtotime'
                        AND CAST( oim.meta_value AS INT ) >= %d
                        AND o.status IN ( '" . implode( "','", $order_status ) . "' )",
                    current_time( 'timestamp' )
                ));
            } else {
                $order_ids = $wpdb->get_col( $wpdb->prepare("
                    SELECT DISTINCT oitems.order_id
                    FROM {$wpdb->prefix}woocommerce_order_items AS oitems
                    LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta AS oitem_meta
                        ON oitems.order_item_id = oitem_meta.order_item_id
                    LEFT JOIN {$wpdb->posts} AS posts
                        ON oitems.order_id = posts.ID
                    WHERE oitems.order_item_type = 'line_item'
                        AND posts.post_type = 'shop_order'
                        AND oitem_meta.meta_key = 'ovabrw_pickup_date_strtotime'
                        AND CAST( oitem_meta.meta_value AS INT ) >= %d
                        AND posts.post_status IN ( '" . implode( "','", $order_status ) . "' )",
                    current_time( 'timestamp' )
                ));
            }

            return apply_filters( 'ovabrw_get_orders_future', $order_ids );
        }

        /**
         * Get orders persent
         */
        public function get_orders_present() {
            global $wpdb;

            $order_ids      = [];
            $order_status   = ovabrw_get_order_status();

            if ( OrderUtil::custom_orders_table_usage_is_enabled() ) {
                $order_ids = $wpdb->get_col( $wpdb->prepare("
                    SELECT DISTINCT o.id
                    FROM {$wpdb->prefix}wc_orders AS o
                    LEFT JOIN {$wpdb->prefix}woocommerce_order_items AS oi
                        ON o.id = oi.order_id
                        AND oi.order_item_type = 'line_item'
                    LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta AS oim
                        ON oi.order_item_id = oim.order_item_id
                    WHERE o.type = 'shop_order'
                        AND oim.meta_key = 'ovabrw_pickoff_date_strtotime'
                        AND CAST( oim.meta_value AS INT ) >= %d
                        AND o.status IN ( '" . implode( "','", $order_status ) . "' )",
                    current_time( 'timestamp' )
                ));
            } else {
                $order_ids = $wpdb->get_col( $wpdb->prepare("
                    SELECT DISTINCT oitems.order_id
                    FROM {$wpdb->prefix}woocommerce_order_items AS oitems
                    LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta AS oitem_meta
                        ON oitems.order_item_id = oitem_meta.order_item_id
                    LEFT JOIN {$wpdb->posts} AS posts
                        ON oitems.order_id = posts.ID
                    WHERE oitems.order_item_type = 'line_item'
                        AND posts.post_type = 'shop_order'
                        AND oitem_meta.meta_key = 'ovabrw_pickoff_date_strtotime'
                        AND CAST( oitem_meta.meta_value AS INT ) >= %d
                        AND posts.post_status IN ( '" . implode( "','", $order_status ) . "' )",
                    current_time( 'timestamp' )
                ));
            }

            return apply_filters( 'ovabrw_get_orders_present', $order_ids );
        }

        /**
         * Get order not reamining invoice
         */
        public function get_orders_not_remaining_invoice() {
            global $wpdb;

            $order_ids      = [];
            $order_status   = ovabrw_get_order_status();

            if ( OrderUtil::custom_orders_table_usage_is_enabled() ) {
                $order_ids = $wpdb->get_col("
                    SELECT DISTINCT o.id
                    FROM {$wpdb->prefix}wc_orders AS o
                    LEFT JOIN {$wpdb->prefix}woocommerce_order_items AS oitems
                    ON o.id = oitems.order_id
                    LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta AS oitem_meta
                    ON oitems.order_item_id = oitem_meta.order_item_id
                    WHERE o.type = 'shop_order'
                    AND oitem_meta.meta_key = 'ovabrw_remaining_amount'
                    AND oitem_meta.meta_value != 0
                    AND o.status IN ( '" . implode( "','", $order_status ) . "' )
                ");
            } else {
                $order_ids = $wpdb->get_col("
                    SELECT DISTINCT oitems.order_id
                    FROM {$wpdb->prefix}woocommerce_order_items AS oitems
                    LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta AS oitem_meta
                    ON oitems.order_item_id = oitem_meta.order_item_id
                    LEFT JOIN {$wpdb->posts} AS posts
                    ON oitems.order_id = posts.ID
                    WHERE posts.post_type = 'shop_order'
                    AND oitem_meta.meta_key = 'ovabrw_remaining_amount'
                    AND oitem_meta.meta_value != 0
                    AND posts.post_status IN ( '" . implode( "','", $order_status ) . "' )
                ");
            }

            return apply_filters( 'ovabrw_get_orders_not_remaining_invoice', $order_ids );
        }

        /**
         * Get price include tax
         */
        public function get_price_include_tax( $product_id = false, $product_price = 0 ) {
            $display_price_cart = get_option( 'woocommerce_tax_display_cart', 'incl' );

            if ( wc_tax_enabled() && wc_prices_include_tax() && $product_price && 'excl' == $display_price_cart ) {
                $product_data   = wc_get_product( $product_id );
                $tax_rates_data = WC_Tax::get_rates( $product_data->get_tax_class() );
                $rate_data      = reset($tax_rates_data);

                if ( $rate_data && isset( $rate_data['rate'] ) ) {

                    $rate           = $rate_data['rate'];
                    $tax_price      = $product_price - ( $product_price / ( ( $rate / 100 ) + 1 ) );
                    $product_price  = $product_price - round( $tax_price, wc_get_price_decimals() );
                }
            }
            
            return apply_filters( 'ovabrw_get_price_include_tax', $product_price, $product_id );
        }

        /**
         * Get resources HTML
         */
        public function get_html_resources( $product_id = false, $resources = [], $start_date = false, $end_date = false, $qty = 1, $order_id = false, $resources_qty = [] ) {

            $html = '';
            if ( 'no' == get_option( 'ova_brw_booking_form_show_extra', 'no' ) ) return $html;

            // Currency
            $currency = '';
            if ( $order_id ) {
                $order = wc_get_order( $order_id );

                if ( !empty( $order ) && is_object( $order ) ) {
                    $currency = $order->get_currency();
                }
            }

            if ( ovabrw_array_exists( $resources ) ) {
                foreach ( $resources as $key => $value ) {
                    $rs_data   = [];
                    $rs_data   = [
                        $key => $value
                    ];
                    $rs_price   = ovabrw_convert_price_in_admin( $this->ovabrw_get_total_resources( $product_id, $start_date, $end_date, $rs_data ), $currency );

                    $res_qty = isset( $resources_qty[$key] ) && absint( $resources_qty[$key] ) ? ' (x'.absint( $resources_qty[$key] ).')' : '';
                    $html   .=  '<dt>' . $value . esc_html__( ': ', 'ova-brw' ) . '</dt><dd>' . ovabrw_wc_price( $rs_price * $qty, ['currency' => $currency] ) . $res_qty . '</dd>';
                }
            }

            return apply_filters( 'ovabrw_get_html_resources', $html, $product_id, $resources, $start_date, $end_date, $qty, $order_id, $resources_qty );
        }

        /**
         * Get services HTML
         */
        public function get_html_services( $product_id = false, $services = [], $start_date = false, $end_date = false, $qty = 1, $order_id = false, $services_qty = [] ) {
            $html = '';
            if ( 'no' == get_option( 'ova_brw_booking_form_show_extra', 'no' ) ) return $html;

            // Currency
            $currency = '';
            if ( $order_id ) {
                $order = wc_get_order( $order_id );

                if ( !empty( $order ) && is_object( $order ) ) {
                    $currency = $order->get_currency();
                }
            }

            // Get service data
            $service_id             = $this->get_meta_value( $product_id, 'service_id' );
            $service_name           = $this->get_meta_value( $product_id, 'service_name' );
            $service_price          = $this->get_meta_value( $product_id, 'service_price' );
            $service_duration_type  = $this->get_meta_value( $product_id, 'service_duration_type' );

            if ( ovabrw_array_exists( $services ) && ovabrw_array_exists( $service_id ) ) {
                foreach ( $services as $value ) {
                    if ( $value ) {
                        $sv_data = [];
                        array_push( $sv_data, $value );

                        foreach ( $service_id as $sv_key => $sv_value ) {
                            if ( in_array( $value, $sv_value ) ) {
                                foreach ( $sv_value as $id_key => $id_value ) {
                                    if ( $value == $id_value ) {
                                        $sv_price = ovabrw_convert_price_in_admin( $this->ovabrw_get_total_services( $product_id, $start_date, $end_date, $sv_data ), $currency );
                                        $sv_qty = isset( $services_qty[$value] ) && absint( $services_qty[$value] ) ? ' (x'.absint( $services_qty[$value] ).')' : '';

                                        $html .= '<dt>' . $service_name[$sv_key][$id_key] . esc_html__( ': ', 'ova-brw' ) . '</dt><dd>' . ovabrw_wc_price( $sv_price * $qty, ['currency' => $currency] ) . $sv_qty . '</dd>';
                                    }
                                }
                            }
                        }
                    }
                }
            }

            return apply_filters( 'ovabrw_get_html_services', $html, $product_id, $services, $start_date, $end_date, $qty, $order_id, $services_qty );
        }

        /**
         * Get custom checkout fields
         */
        public function get_html_ckf( $custom_ckf = [], $qty = 1, $order_id = false, $custom_ckf_qty = [] ) {
            $html = '';

            // Currency
            $currency = '';
            if ( $order_id ) {
                $order = wc_get_order( $order_id );

                if ( ! empty( $order ) && is_object( $order ) ) {
                    $currency = $order->get_currency();
                }
            }

            if ( ovabrw_array_exists( $custom_ckf ) ) {
                $list_fields = get_option( 'ovabrw_booking_form', array() );

                foreach ( $custom_ckf as $k => $val ) {
                    if ( ovabrw_get_meta_data( $k, $list_fields ) ) {
                        $type = $list_fields[$k]['type'];

                        if ( 'radio' == $type ) {
                            $val_key = array_search( $val, $list_fields[$k]['ova_values'] );
                            $val_qty = isset( $custom_ckf_qty[$k] ) && absint( $custom_ckf_qty[$k] ) ? absint( $custom_ckf_qty[$k] ) : '';

                            if ( !is_bool( $val_key ) ) {
                                $price = ovabrw_convert_price_in_admin( $list_fields[$k]['ova_prices'][$val_key], $currency );

                                if ( $price ) {
                                    if ( $val_qty ) {
                                        $html .= '<dt>' . $val . esc_html__( ': ', 'ova-brw' ) . '</dt><dd>' . ovabrw_wc_price( $price * $qty, ['currency' => $currency] ) . ' (x'.$val_qty.')</dd>';
                                    } else {
                                        $html .= '<dt>' . $val . esc_html__( ': ', 'ova-brw' ) . '</dt><dd>' . ovabrw_wc_price( $price * $qty, ['currency' => $currency] ) . '</dd>';
                                    }
                                }
                            }
                        } elseif ( 'checkbox' == $type ) {
                            if ( ovabrw_array_exists( $val ) ) {
                                foreach ( $val as $val_cb ) {
                                    $val_key = array_search( $val_cb, $list_fields[$k]['ova_checkbox_key'] );
                                    $val_qty = isset( $custom_ckf_qty[$val_cb] ) && absint( $custom_ckf_qty[$val_cb] ) ? absint( $custom_ckf_qty[$val_cb] ) : '';

                                    if ( !is_bool( $val_key ) ) {
                                        $label = $list_fields[$k]['ova_checkbox_text'][$val_key];
                                        $price = ovabrw_convert_price_in_admin( $list_fields[$k]['ova_checkbox_price'][$val_key], $currency );

                                        if ( $price ) {
                                            if ( $val_qty ) {
                                                $html .= '<dt>' . $label . esc_html__( ': ', 'ova-brw' ) . '</dt><dd>' . ovabrw_wc_price( $price * $qty, ['currency' => $currency] ) . ' (x'.$val_qty.')</dd>';
                                            } else {
                                                $html .= '<dt>' . $label . esc_html__( ': ', 'ova-brw' ) . '</dt><dd>' . ovabrw_wc_price( $price * $qty, ['currency' => $currency] ) . '</dd>';
                                            }
                                        }
                                    }
                                }
                            }
                        } elseif ( 'select' == $type ) {
                            $val_key = array_search( $val, $list_fields[$k]['ova_options_key'] );
                            $val_qty = isset( $custom_ckf_qty[$val] ) && absint( $custom_ckf_qty[$val] ) ? absint( $custom_ckf_qty[$val] ) : '';

                            if ( !is_bool( $val_key ) ) {
                                $label = $list_fields[$k]['ova_options_text'][$val_key];
                                $price = ovabrw_convert_price_in_admin( $list_fields[$k]['ova_options_price'][$val_key], $currency );

                                if ( $price ) {
                                    if ( $val_qty ) {
                                        $html .= '<dt>' . $label . esc_html__( ': ', 'ova-brw' ) . '</dt><dd>' . ovabrw_wc_price( $price * $qty, ['currency' => $currency] ) . ' (x'.$val_qty.')</dd>';
                                    } else {
                                        $html .= '<dt>' . $label . esc_html__( ': ', 'ova-brw' ) . '</dt><dd>' . ovabrw_wc_price( $price * $qty, ['currency' => $currency] ) . '</dd>';
                                    }
                                }
                            }
                        }
                    }
                }
            }

            return apply_filters( 'ovabrw_get_html_ckf', $html, $custom_ckf, $qty, $order_id, $custom_ckf_qty );
        }

        /**
         * Get extra HTML
         */
        public function get_html_extra( $resource_html = '', $service_html = '', $ckf_html = '' ) {
            $html = '';

            if ( !$resource_html || !$service_html || !$ckf_html ) {
                $html .= '<dl class="variation ovabrw_extra_item">';
                $html .= $ckf_html;
                $html .= $resource_html;
                $html .= $service_html;
                $html .= '</dl>';
            }

            return apply_filters( 'ovabrw_get_html_extra', $html, $resource_html, $service_html, $ckf_html );
        }

        /**
         * Get cart item subdeposit amount
         */
        public function get_cart_item_subdeposit( $cart_item ) {
            $deposit_html   = '';
            $deposit_amount = floatval( $cart_item['data']->get_meta( 'deposit_amount' ) );

            if ( $deposit_amount ) {
                // Insurance string
                $insurance_string = '';

                // Tax string
                $tax_string = '';

                // Deposit HTML
                $deposit_html .= '<dt>'.esc_html__( 'Deposit:', 'ova-brw' ).'</dt>';
                $deposit_html .= '<dd>';

                // Convert price
                $deposit_price = ovabrw_wc_price( $deposit_amount, array(), false );

                // Get insurance amount
                $insurance_amount = floatval( $cart_item['data']->get_meta( 'insurance_amount' ) );
                if ( $insurance_amount ) {
                    $insurance_amount   = $this->get_insurance_inclusive_tax( $insurance_amount );
                    $deposit_price      = ovabrw_wc_price( $deposit_amount + $insurance_amount, array(), false );
                    $insurance_string   = ' <small class="tax_label">' . sprintf( esc_html__( '(incl. %s insurance fee)', 'ova-brw' ), ovabrw_wc_price( $insurance_amount, [], false ) ) . '</small>';
                }

                // Taxable
                if ( $cart_item['data']->is_taxable() ) {
                    if ( WC()->cart->display_prices_including_tax() ) {
                        if ( ! wc_prices_include_tax() && WC()->cart->get_subtotal_tax() > 0 ) {
                            $row_price = wc_get_price_including_tax( $cart_item['data'], array(
                                'price' => $deposit_amount
                            ));
                            $row_price += $insurance_amount;

                            $deposit_price  = ovabrw_wc_price( $row_price, array(), false );
                            $tax_string     = ' <small class="tax_label">' . WC()->countries->inc_tax_or_vat() . '</small>';
                        }
                    } else {
                        if ( wc_prices_include_tax() && WC()->cart->get_subtotal_tax() > 0 ) {
                            $row_price = wc_get_price_excluding_tax( $cart_item['data'], array(
                                'price' => $deposit_amount
                            ));
                            $row_price += $insurance_amount;

                            $deposit_price  = ovabrw_wc_price( $row_price, array(), false );
                            $tax_string     = ' <small class="tax_label">' . WC()->countries->ex_tax_or_vat() . '</small>';
                        }
                    }
                }

                $deposit_html .= $deposit_price.$insurance_string.$tax_string;
                $deposit_html .= '</dd>';
            }

            return apply_filters( 'ovabrw_get_cart_item_subdeposit', $deposit_html, $cart_item );
        }

        /**
         * Get cart item subremaining amount
         */
        public function get_cart_item_subremaining( $cart_item ) {
            $remaining_html     = '';
            $remaining_amount   = floatval( $cart_item['data']->get_meta( 'remaining_amount' ) );

            if ( $remaining_amount ) {
                // Insurance string
                $insurance_string = '';

                // Tax string
                $tax_string = '';

                // Remaining HTML
                $remaining_html .= '<dt>'.esc_html__( 'Remaining:', 'ova-brw' ).'</dt>';
                $remaining_html .= '<dd>';

                // Convert price
                $remaining_price = ovabrw_wc_price( $remaining_amount, array(), false );

                // Get insurance amount
                $insurance_amount = floatval( $cart_item['data']->get_meta( 'remaining_insurance' ) );
                if ( $insurance_amount ) {
                    $insurance_amount   = $this->get_insurance_inclusive_tax( $insurance_amount );
                    $remaining_price    = ovabrw_wc_price( $remaining_amount + $insurance_amount, array(), false );
                    $insurance_string   = ' <small class="tax_label">' . sprintf( esc_html__( '(incl. %s insurance fee)', 'ova-brw' ), ovabrw_wc_price( $insurance_amount, [], false ) ) . '</small>';
                }

                // Taxable
                if ( $cart_item['data']->is_taxable() ) {
                    if ( WC()->cart->display_prices_including_tax() ) {
                        if ( ! wc_prices_include_tax() && WC()->cart->get_subtotal_tax() > 0 ) {
                            $row_price = wc_get_price_including_tax( $cart_item['data'], array(
                                'price' => $remaining_amount
                            ));

                            $row_price          += $insurance_amount;
                            $remaining_price    = ovabrw_wc_price( $row_price, array(), false );
                            $tax_string         = ' <small class="tax_label">' . WC()->countries->inc_tax_or_vat() . '</small>';
                        }
                    } else {
                        if ( wc_prices_include_tax() && WC()->cart->get_subtotal_tax() > 0 ) {
                            $row_price = wc_get_price_excluding_tax( $cart_item['data'], array(
                                'price' => $remaining_amount
                            ));

                            $row_price          += $insurance_amount;
                            $remaining_price    = ovabrw_wc_price( $row_price, array(), false );
                            $tax_string         = ' <small class="tax_label">' . WC()->countries->ex_tax_or_vat() . '</small>';
                        }
                    }
                }

                $remaining_html .= $remaining_price.$insurance_string.$tax_string;
                $remaining_html .= '</dd>';
            }

            return apply_filters( 'ovabrw_get_cart_item_subremaining', $remaining_html, $cart_item );
        }

        /**
         * Get cart item subtotal payable
         */
        public function get_cart_item_subtotal_payable( $cart_item ) {
            $payable_html       = '';
            $deposit_amount     = floatval( $cart_item['data']->get_meta( 'deposit_amount' ) );
            $remaining_amount   = floatval( $cart_item['data']->get_meta( 'remaining_amount' ) );

            if ( $deposit_amount || $remaining_amount ) {
                // Get insurance amount
                $insurance_amount = floatval( $cart_item['data']->get_meta( 'insurance_amount' ) );
                if ( $insurance_amount ) {
                    $insurance_amount = $this->get_insurance_inclusive_tax( $insurance_amount );
                }

                // Get remaining insurance amount
                $remaining_insurance = floatval( $cart_item['data']->get_meta( 'remaining_insurance' ) );
                if ( $remaining_insurance ) {
                    $remaining_insurance = $this->get_insurance_inclusive_tax( $remaining_insurance );
                }

                // Payable HTML
                $payable_html .= '<dt>'.esc_html__( 'Total payable:', 'ova-brw' ).'</dt>';
                $payable_html .= '<dd>';

                // Convert price
                $total_payable = ovabrw_wc_price( $deposit_amount + $remaining_amount + $insurance_amount + $remaining_insurance, array(), false );

                // Taxable
                $tax_string = '';

                if ( $cart_item['data']->is_taxable() ) {
                    if ( WC()->cart->display_prices_including_tax() ) {
                        if ( ! wc_prices_include_tax() && WC()->cart->get_subtotal_tax() > 0 ) {
                            $row_deposit    = round( wc_get_price_including_tax( $cart_item['data'], array(
                                'price' => $deposit_amount
                            )), wc_get_price_decimals() );
                            $row_remaining  = round( wc_get_price_including_tax( $cart_item['data'], array(
                                'price' => $remaining_amount
                            )), wc_get_price_decimals() );
                            $row_price      = $row_deposit + $row_remaining + $insurance_amount + $remaining_insurance;
                            $total_payable  = ovabrw_wc_price( $row_price, array(), false );
                            $tax_string     = ' <small class="tax_label">' . WC()->countries->inc_tax_or_vat() . '</small>';
                        }
                    } else {
                        if ( wc_prices_include_tax() && WC()->cart->get_subtotal_tax() > 0 ) {
                            $row_deposit    = round( wc_get_price_excluding_tax( $cart_item['data'], array(
                                'price' => $deposit_amount
                            )), wc_get_price_decimals() );
                            $row_remaining  = round( wc_get_price_excluding_tax( $cart_item['data'], array(
                                'price' => $remaining_amount
                            )), wc_get_price_decimals() );
                            $row_price      = $row_deposit + $row_remaining + $insurance_amount + $remaining_insurance;
                            $total_payable  = ovabrw_wc_price( $row_price, array(), false );
                            $tax_string     = ' <small class="tax_label">' . WC()->countries->ex_tax_or_vat() . '</small>';
                        }
                    }
                }

                $payable_html .= $total_payable.$tax_string;
                $payable_html .= '</dd>';
            }

            return apply_filters( 'ovabrw_get_cart_item_subtotal_payable', $payable_html, $cart_item );
        }

        /**
         * Get order formatted line subdeposit
         */
        public function get_order_formatted_line_subdeposit( $item, $order ) {
            $deposit_html   = '';
            $deposit_amount = floatval( $item->get_meta( 'ovabrw_deposit_amount' ) );

            if ( $deposit_amount ) {
                // Insurance string
                $insurance_string = '';

                // Tax string
                $tax_string = '';

                // Deposit HTML
                $deposit_html .= '<dt>'.esc_html__( 'Deposit:', 'ova-brw' ).'</dt>';
                $deposit_html .= '<dd>';

                // Convert price
                $deposit_price = wc_price( $deposit_amount, [
                    'currency' => $order->get_currency()
                ]);

                // Get insurance amount
                $insurance_amount = floatval( $item->get_meta( 'ovabrw_insurance_amount' ) );
                if ( $insurance_amount ) {
                    $insurance_amount   = $this->get_insurance_inclusive_tax( $insurance_amount );
                    $deposit_price      = wc_price( $deposit_amount + $insurance_amount, array( 'currency' => $order->get_currency() ) );
                    $insurance_string   = ' <small class="tax_label">' . sprintf( esc_html__( '(incl. %s insurance fee)', 'ova-brw' ), wc_price( $insurance_amount, array( 'currency' => $order->get_currency() ) ) ) . '</small>';
                }

                // Taxable
                if ( wc_tax_enabled() ) {
                    $prices_incl_tax    = $order->get_meta( '_ova_prices_include_tax' );
                    $tax_display        = get_option( 'woocommerce_tax_display_cart' );
                    $item_tax           = $item->get_total_tax();

                    if ( $prices_incl_tax ) {
                        if ( 'excl' === $tax_display ) {
                            $deposit_price  = wc_price( $deposit_amount - $item_tax + $insurance_amount, array( 'currency' => $order->get_currency() ) );
                            $tax_string     = ' <small class="tax_label">'.esc_html__( '(ex. tax)', 'ova-brw' ).'</small>';
                        }
                    } else {
                        if ( 'incl' === $tax_display ) {
                            $deposit_price  = wc_price( $deposit_amount + $item_tax + $insurance_amount, array( 'currency' => $order->get_currency() ) );
                            $tax_string     = ' <small class="tax_label">'.esc_html__( '(incl. tax)', 'ova-brw' ).'</small>';
                        }
                    }
                }

                $deposit_html .= $deposit_price.$insurance_string.$tax_string;
                $deposit_html .= '</dd>';
            }

            return apply_filters( 'ovabrw_get_order_formatted_line_subdeposit', $deposit_html, $item, $order );
        }

        /**
         * Get order formatted line subremaining amount
         * @param  [type] $item  [description]
         * @param  [type] $order [description]
         * @return [type]        [description]
         */
        public function get_order_formatted_line_subremaining( $item, $order ) {
            $remaining_html     = '';
            $remaining_amount   = floatval( $item->get_meta( 'ovabrw_remaining_amount' ) );

            if ( $remaining_amount ) {
                // Insurance string
                $insurance_string = '';

                // Tax string
                $tax_string = '';

                // Remaining HTML
                $remaining_html .= '<dt>'.esc_html__( 'Remaining:', 'ova-brw' ).'</dt>';
                $remaining_html .= '<dd>';

                // Convert price
                $remaining_price = wc_price( $remaining_amount, [
                    'currency' => $order->get_currency()
                ]);

                // Get insurance amount
                $insurance_amount = floatval( $item->get_meta( 'ovabrw_remaining_insurance' ) );
                if ( $insurance_amount ) {
                    $insurance_amount   = $this->get_insurance_inclusive_tax( $insurance_amount );
                    $remaining_price    = wc_price( $remaining_amount + $insurance_amount, array( 'currency' => $order->get_currency() ) );
                    $insurance_string   = ' <small class="tax_label">' . sprintf( esc_html__( '(incl. %s insurance fee)', 'ova-brw' ), wc_price( $insurance_amount, array( 'currency' => $order->get_currency() ) ) ) . '</small>';
                }

                // Taxable
                if ( wc_tax_enabled() ) {
                    $prices_incl_tax    = $order->get_meta( '_ova_prices_include_tax' );
                    $tax_display        = get_option( 'woocommerce_tax_display_cart' );
                    $remaining_tax      = floatval( $item->get_meta( 'ovabrw_remaining_tax' ) );

                    if ( $prices_incl_tax ) {
                        if ( 'excl' === $tax_display ) {
                            $remaining_price    = wc_price( $remaining_amount - $remaining_tax + $insurance_amount, array( 'currency' => $order->get_currency() ) );
                            $tax_string         = ' <small class="tax_label">'.esc_html__( '(ex. tax)', 'ova-brw' ).'</small>';
                        }
                    } else {
                        if ( 'incl' === $tax_display ) {
                            $remaining_price    = wc_price( $remaining_amount + $remaining_tax + $insurance_amount, array( 'currency' => $order->get_currency() ) );
                            $tax_string         = ' <small class="tax_label">'.esc_html__( '(incl. tax)', 'ova-brw' ).'</small>';
                        }
                    }
                }

                $remaining_html .= $remaining_price.$insurance_string.$tax_string;
                $remaining_html .= '</dd>';
            }

            return apply_filters( 'ovabrw_get_order_formatted_line_subremaining', $remaining_html, $item, $order );
        }

        /**
         * Get order formatted line subtotal payable
         */
        public function get_order_formatted_line_subtotal_payable( $item, $order ) {
            $payable_html   = '';
            $total_payable  = floatval( $item->get_meta( 'ovabrw_total_payable' ) );

            if ( $total_payable ) {
                // Tax string
                $tax_string = '';

                // Insurance amount
                $insurance_amount = floatval( $item->get_meta( 'ovabrw_insurance_amount' ) );
                if ( $insurance_amount ) {
                    $insurance_amount   = $this->get_insurance_inclusive_tax( $insurance_amount );
                    $total_payable      += $insurance_amount;
                }

                // Remaining insurance amount
                $remaining_insurance = floatval( $item->get_meta( 'ovabrw_remaining_insurance' ) );
                if ( $remaining_insurance ) {
                    $remaining_insurance    = $this->get_insurance_inclusive_tax( $remaining_insurance );
                    $total_payable          += $remaining_insurance;
                }

                // Payable HTML
                $payable_html .= '<dt>'.esc_html__( 'Total payable:', 'ova-brw' ).'</dt>';
                $payable_html .= '<dd>';

                // Convert price
                $payable_price = wc_price( $total_payable, [
                    'currency' => $order->get_currency()
                ]);

                // Taxable
                if ( wc_tax_enabled() ) {
                    $prices_incl_tax    = $order->get_meta( '_ova_prices_include_tax' );
                    $tax_display        = get_option( 'woocommerce_tax_display_cart' );
                    $item_tax           = $item->get_total_tax();
                    $remaining_tax      = floatval( $item->get_meta( 'ovabrw_remaining_tax' ) );

                    if ( $prices_incl_tax ) {
                        if ( 'excl' === $tax_display ) {
                            $payable_price = wc_price( $total_payable - $item_tax - $remaining_tax, array( 'currency' => $order->get_currency() ) );
                            $tax_string = ' <small class="tax_label">'.esc_html__( '(ex. tax)', 'ova-brw' ).'</small>';
                        }
                    } else {
                        if ( 'incl' === $tax_display ) {
                            $payable_price = wc_price( $total_payable + $item_tax + $remaining_tax, array( 'currency' => $order->get_currency() ) );
                            $tax_string = ' <small class="tax_label">'.esc_html__( '(incl. tax)', 'ova-brw' ).'</small>';
                        }
                    }
                }

                $payable_html .= $payable_price.$tax_string;
                $payable_html .= '</dd>';
            }

            return apply_filters( 'ovabrw_get_order_formatted_line_subtotal_payable', $payable_html, $item, $order );
        }

        /**
         * Get taxes by price
         */
        public function get_taxes_by_price( $product, $price ) {
            if ( !$product || !$price ) return 0;

            // Tax amount
            $taxes = 0;

            if ( $product->is_taxable() ) {
                $tax_rates = WC_Tax::get_rates( $product->get_tax_class() );

                if ( wc_prices_include_tax() ) {
                    $incl_tax = WC_Tax::calc_inclusive_tax( $price, $tax_rates );
                    $taxes    = wc_round_tax_total( array_sum( $incl_tax ) );
                } else {
                    $excl_tax = WC_Tax::calc_exclusive_tax( $price, $tax_rates );
                    $taxes    = wc_round_tax_total( array_sum( $excl_tax ) );
                }
            }

            return apply_filters( 'ovabrw_get_taxes_by_price', $taxes, $product, $price );
        }

        /**
         * Get tax amount by tax rates
         */
        public function get_tax_amount_by_tax_rates( $price = 0, $tax_rates = 0, $prices_incl_tax = '' ) {
            if ( !$price || !$prices_incl_tax ) return 0;

            if ( wc_tax_enabled() ) {
                if ( 'yes' == $prices_incl_tax ) {
                    $tax_amount = round( $price - ( $price / ( ( $tax_rates / 100 ) + 1 ) ), wc_get_price_decimals() );
                } else {
                    $tax_amount = round( $price * ( $tax_rates / 100 ), wc_get_price_decimals() );
                }
            }

            return apply_filters( 'ovabrw_get_tax_amount_by_tax_rates', $tax_amount );
        }

        /**
         * Get attributes HTML dropdown
         */
        public function get_html_dropdown_attributes( $label = '' ) {
            if ( !$label ) $label = esc_html__( 'Select Attribute', 'ova-brw' );

            $args       = array(); 
            $html       = $html_attr_value = '';
            $attributes = wc_get_attribute_taxonomies();

            if ( ovabrw_array_exists( $attributes ) ) {
                $html .= '<select name="ovabrw_attribute" class="ovabrw_attribute"><option value="">'.$label.'</option>';

                foreach ( $attributes as $obj_attr ) {
                    if ( taxonomy_exists( wc_attribute_taxonomy_name( $obj_attr->attribute_name ) ) ) {
                        $html .= "<option value='".$obj_attr->attribute_name."'>".$obj_attr->attribute_label."</option>";

                        $term_attributes = get_terms( wc_attribute_taxonomy_name( $obj_attr->attribute_name ), 'orderby=name&hide_empty=0' );
                        if ( ! empty( $term_attributes ) ) {
                            $html_attr_value .= '<div class="label_search s_field ovabrw-value-attribute" id="'.$obj_attr->attribute_name.'"><select name="ovabrw_attribute_value" >';

                            foreach ( $term_attributes as $obj_attr_value ) {
                                $html_attr_value .= '<option value="'.$obj_attr_value->slug.'">'.$obj_attr_value->name.'</option>';
                            }

                            $html_attr_value .= '</select></div>';
                        }
                    }
                }
                $html .= '</select>';
            }

            $args['html_attr']         = $html;
            $args['html_attr_value']   = $html_attr_value;

            return apply_filters( 'ovabrw_get_html_dropdown_attributes', $args, $label );
        }

        /**
         * Get taxonomies search HTML dropdown
         */
        public function get_html_dropdown_taxonomies_search( $slug = '', $name = '', $selected = '' ) {
            $args = array(
                'show_option_all'    => '',
                'show_option_none'   => esc_html__( 'Select ', 'ova-brw' ) . esc_html( $name ) ,
                'option_none_value'  => '',
                'orderby'            => 'ID',
                'order'              => 'ASC',
                'show_count'         => 0,
                'hide_empty'         => 0,
                'child_of'           => 0,
                'exclude'            => '',
                'include'            => '',
                'echo'               => 0,
                'selected'           => $selected,
                'hierarchical'       => 1,
                'name'               => $slug.'_name',
                'id'                 => '',
                'class'              => 'custom_taxonomy',
                'depth'              => 0,
                'tab_index'          => 0,
                'taxonomy'           => $slug,
                'hide_if_empty'      => false,
                'value_field'        => 'slug',
            );

            return apply_filters( 'ovabrw_get_html_dropdown_taxonomies_search', wp_dropdown_categories( $args ), $slug, $name, $selected );
        }

        /**
         * Get products search
         */
        public function get_products_search( $data = [] ) {
            $number     = ovabrw_get_meta_data( 'posts_per_page', $data, 12 );
            $orderby    = ovabrw_get_meta_data( 'orderby', $data, 'date' );
            $order      = ovabrw_get_meta_data( 'order', $data, 'DESC' );

            $products = new WP_Query([
                'post_type'         => 'product',
                'post_status'       => 'publish',
                'posts_per_page'    => $number,
                'orderby'           => $orderby,
                'order'             => $order
            ]);

            return apply_filters( 'ovabrw_get_products_search', $products, $data );
        }

        /**
         * Get pagination HTML
         */
        public function get_html_pagination_ajax( $total, $limit, $current ) {
            $html   = '';
            $pages  = ceil( $total / $limit );

            if ( $pages > 1 ) {
                $html .= '<ul>';

                if ( $current > 1 ) {
                    $html .= '<li><span data-paged="'.( $current - 1 ).'" class="prev page-numbers" >'.esc_html__( 'Previous', 'ova-brw' ).'</span></li>';
                }

                for ( $i = 1; $i <= $pages; $i++ ) {
                    if ( $current == $i ) {
                        $html .='<li><span data-paged="'.$i.'" class="prev page-numbers current" >'.esc_html( $i ).'</span></li>';
                    } else {
                        $html .= '<li><span data-paged="'.$i.'" class="prev page-numbers" >'.esc_html( $i ).'</span></li>';
                    }
                }

                if ( $current < $pages ) {
                    $html .= '<li><span data-paged="'. ( $current + 1 ) .'" class="next page-numbers" >'.esc_html__( 'Next', 'ova-brw' ).'</span></li>';
                }
            }

            return apply_filters( 'ovabrw_get_pagination_ajax', $html, $total, $limit, $current );
        }

        /**
         * Get price HTML
         */
        public function get_html_price( $product_id = false ) {
            if ( !$product_id ) return '';

            $html   = '';
            $min    = $max = 0;

            $rental_type    = $this->get_meta_value( $product_id, 'price_type', 'day' );
            $price_hour     = floatval( $this->get_meta_value( $product_id, 'regul_price_hour' ) );
            $price_day      = floatval( $this->get_meta_value( $product_id, 'regular_price_day' ) );

            if ( !$price_day ) $price_day = floatval( get_post_meta( $product_id, '_regular_price', true ) );

            // Get price
            $petime_price   = $this->get_meta_value( $product_id, 'petime_price' );
            $price_location = $this->get_meta_value( $product_id, 'price_location' );

            if ( 'period_time' == $rental_type && $petime_price && is_array( $petime_price ) ) {
                $min = min( $petime_price );
                $max = max( $petime_price );
            }

            if ( 'transportation' == $rental_type && $price_location && is_array( $price_location ) ) {
                $min = min( $price_location );
                $max = max( $price_location );
            }

            if ( 'period_time' == $rental_type || 'transportation' == $rental_type ) {
                if ( $min && $max && $min == $max ) {
                    $html .= '<div class="amount">'. ovabrw_wc_price( $min ) .'</div>';
                } elseif ( $min && $max ) {
                    $html .= '<div class="amount">'. ovabrw_wc_price( $min ) .' - '. ovabrw_wc_price( $max ) .'</div>';
                } else {
                    $html .= '';
                }
            } elseif ( 'hour' == $rental_type ) {
                $html .= '<div class="amount">'. ovabrw_wc_price( $price_hour ) .'</div>';
            } elseif ( 'day' == $rental_type ) {
                $html .= '<div class="amount">'. ovabrw_wc_price( $price_day, [], false ) .'</div>';
            } elseif ( 'mixed' == $rental_type ) {
                $html .= '<div class="amount">'. ovabrw_wc_price( $price_hour ) . esc_html__('/hour - ', 'ova-brw') . ovabrw_wc_price( $price_day, [], false ) . esc_html__('/day', 'ova-brw') .'</div>';
            } else {
                $html = '';
            }

            return apply_filters( 'ovabrw_get_html_price', $html, $product_id );
        }

        /**
         * Check available package
         */
        public function check_available_package( $product_id = false, $check_in = false ) {
            if ( !$product_id || !$check_in ) return false;

            $package_ids = get_post_meta( $product_id, 'ovabrw_petime_id', true );

            if ( ovabrw_array_exists( $package_ids ) ) {
                foreach ( $package_ids as $k => $package_id ) {
                    $new_input_date     = ovabrw_new_input_date( $product_id, $check_in, '', $package_id, '', '' );
                    $pickup_date_new    = $new_input_date['pickup_date_new'];
                    $pickoff_date_new   = $new_input_date['pickoff_date_new'];
                    $check_vehicle      = ova_validate_manage_store( $product_id, $pickup_date_new, $pickoff_date_new, '', '', false, 'search', 1 );
                
                    if ( $check_vehicle && $check_vehicle['status'] && ( $check_vehicle['vehicle_availables'] || $check_vehicle['number_vehicle_available'] ) ) {
                        return true;
                    }
                }
            }

            return false;
        }

        /**
         * Check table price by hour
         */
        public function check_table_price_by_hour( $product_id = false ) {
            if ( !$product_id ) return false;

            $flag = false;

            $gd_duration_val_min = $this->get_meta_value( $product_id, 'global_discount_duration_val_min' );
            $gd_duration_val_max = $this->get_meta_value( $product_id, 'global_discount_duration_val_max' );

            if ( $gd_duration_val_min ) asort( $gd_duration_val_min );
            if ( $gd_duration_val_max ) asort( $gd_duration_val_max );

            if ( ovabrw_array_exists( $gd_duration_val_min ) || ovabrw_array_exists( $gd_duration_val_max ) ) $flag = true;

            $rt_price_hour = $this->get_meta_value( $product_id, 'rt_price_hour' );

            if ( ovabrw_array_exists( $rt_price_hour ) ) $flag = true;

            return apply_filters( 'ovabrw_check_table_price_by_hour', $flag, $product_id );
        }

        /**
         * Check table price by day
         */
        public function check_table_price_by_day( $product_id = false ) {
            if ( !$product_id ) return false;

            $flag   = false;
            $daily  = ovabrw_get_daily_prices( $product_id );

            if ( $daily ) $flag = true;

            $gd_duration_val_min = $this->get_meta_value( $product_id, 'global_discount_duration_val_min' );
            $gd_duration_val_max = $this->get_meta_value( $product_id, 'global_discount_duration_val_max' );

            if ( $gd_duration_val_min ) asort( $gd_duration_val_min );
            if ( $gd_duration_val_max ) asort( $gd_duration_val_max );

            if ( ovabrw_array_exists( $gd_duration_val_min ) || ovabrw_array_exists( $gd_duration_val_max ) ) $flag = true;

            $rt_price = $this->get_meta_value( $product_id, 'rt_price' );

            if ( ovabrw_array_exists( $rt_price ) ) $flag = true;

            return apply_filters( 'ovabrw_check_table_price_by_day', $flag, $product_id );
        }

        /**
         * Check table price by period time
         */
        public function check_table_price_by_period_time( $product_id = false ) {
            $flag = false;

            $petime_label = $this->get_meta_value( $product_id, 'petime_label' );

            if ( ovabrw_array_exists( $petime_label ) ) $flag = true;

            return apply_filters( 'ovabrw_check_table_price_by_period_time', $flag, $product_id );
        }

        /**
         * Get products rental
         */
        public function get_products_rental() {
            // Get products
            $products = get_posts([
                'post_type'         => 'product',
                'fields'            => 'ids', 
                'post_status'       => 'publish',
                'posts_per_page'    => '-1',
                'orderby'           => 'ID',
                'order'             => 'ASC',
                'tax_query'         => [
                    [
                        'taxonomy' => 'product_type',
                        'field'    => 'slug',
                        'terms'    => 'ovabrw_car_rental',
                    ]
                ]
            ]);

            return apply_filters( 'ovabrw_get_products_rental', $products );
        }

        /**
         * Get product gallery ids
         */
        public function get_products_gallery_ids( $product_id = false ) {
            if ( !$product_id ) return false;

            // Get product
            $product = wc_get_product( $product_id );

            if ( !empty( $product ) && is_object( $product ) ) {
                $image_ids = array();

                $product_image_id = $product->get_image_id();

                if ( $product_image_id ) {
                    array_push( $image_ids, $product_image_id );
                }

                $product_gallery_ids = $product->get_gallery_image_ids();

                if ( $product_gallery_ids && is_array( $product_gallery_ids ) ) {
                    $image_ids = array_merge( $image_ids, $product_gallery_ids );
                }

                return apply_filters( 'ovabrw_get_products_gallery_ids', $image_ids, $product_id );
            }

            return false;
        }

        /**
         * Get pick-up date label
         */
        public function get_label_pickup_date( $product_id = false ) {
            $label = esc_html__( 'Pick-up Date', 'ova-brw' );
            if ( !$product_id ) return $label;

            // Rental type
            $rental_type = $this->get_meta_value( $product_id, 'price_type' );

            // For hotel
            if ( 'hotel' == $rental_type ) $label = esc_html__( 'Check in', 'ova-brw' );

            // Global label
            $global_label = $this->get_meta_value( $product_id, 'label_pickup_date_product' );

            if ( 'new' == $global_label ) {
                $label = $this->get_meta_value( $product_id, 'new_pickup_date_product' );
            } elseif ( 'category' == $global_label ) {
                $terms = wp_get_post_terms( $product_id, 'product_cat', array( 'fields'=>'ids' ));

                if ( $terms && is_array( $terms ) ) {
                    $term_id = reset($terms);
                }

                $label = isset( $term_id ) ? get_term_meta( $term_id, 'ovabrw_lable_pickup_date', true ) : '';
            } else {
                $label = esc_html__( 'Pick-up Date', 'ova-brw' );
            }

            if ( !$label ) {
                $label = esc_html__( 'Pick-up Date', 'ova-brw' );
                if ( 'hotel' == $rental_type ) $label = esc_html__( 'Check in', 'ova-brw' );
            }

            return apply_filters( 'ovabrw_get_label_pickup_date', $label, $product_id );
        }

        /**
         * Get drop-off date label
         */
        public function get_label_pickoff_date( $product_id = false ) {
            $label = esc_html__( 'Drop-off Date', 'ova-brw' );

            if ( !$product_id ) return $label;

            // Get rental type
            $rental_type = $this->get_meta_value( $product_id, 'price_type' );

            // For hotel
            if ( 'hotel' == $rental_type ) $label = esc_html__( 'Check out', 'ova-brw' );

            // Global label
            $global_label = $this->get_meta_value( $product_id, 'label_dropoff_date_product' );

            if ( 'new' == $global_label ) {
                $label = $this->get_meta_value( $product_id, 'new_dropoff_date_product' );
            } elseif ( 'category' == $global_label ) {
                $terms = wp_get_post_terms( $product_id, 'product_cat', array( 'fields'=>'ids' ));

                if ( $terms && is_array( $terms ) ) {
                    $term_id = reset($terms);
                }
                
                $label = isset( $term_id ) ? get_term_meta( $term_id, 'ovabrw_lable_dropoff_date', true ) : '';
            } else {
                $label = esc_html__( 'Drop-off Date', 'ova-brw');
            }

            if ( !$label ) {
                $label = esc_html__( 'Drop-off Date', 'ova-brw' );
                if ( 'hotel' == $rental_type ) $label = esc_html__( 'Check out', 'ova-brw' );
            }

            return apply_filters( 'ovabrw_get_label_pickoff_date', $label, $product_id );
        }

        /**
         * Get average product review by category
         * @param  boolean $category_id [description]
         * @return [type]               [description]
         */
        public function get_average_product_review_by_cagegory( $category_id = false ) {
            if ( !$category_id ) return;

            $average = $count = $total_rating = 0;

            // Get product ids
            $product_ids = get_posts([
                'post_type'         => 'product',
                'post_status'       => 'publish',
                'posts_per_page'    => -1,
                'orderby'           => 'date',
                'order'             => 'DESC',
                'fields'            => 'ids',
                'tax_query'         => [
                    [
                        'taxonomy'  => 'product_cat',
                        'field'     => 'term_id',
                        'terms'     => $category_id,
                        'operator'  => 'IN',
                    ]
                ]
            ]);

            if ( ovabrw_array_exists( $product_ids ) ) {
                foreach ( $product_ids as $product_id ) {
                    $product    = wc_get_product( $product_id );
                    $rating     = $product->get_average_rating();

                    if ( $rating ) {
                        $total_rating += floatval( $rating );
                        $count += 1;
                    }
                }
            }

            if ( floatval( $total_rating ) > 0 && absint( $count ) > 0 ) {
                $average = number_format( $total_rating / $count, 1, '.', ',' );
            }
            
            return apply_filters( 'ovabrw_get_average_product_review_by_cagegory', $average, $category_id );
        }

        /**
         * Get product ajax filter
         */
        public function get_product_ajax_filter( $args = [] ) {
            if ( !ovabrw_array_exists( $args ) ) return;

            $base_query = [
                'post_type'         => 'product',
                'post_status'       => 'publish',
                'paged'             => $args['paged'],
                'posts_per_page'    => $args['posts_per_page'],
                'orderby'           => $args['orderby'],
                'order'             => $args['order'],
                'tax_query'         => [
                    [
                        'taxonomy' => 'product_type',
                        'field'    => 'slug',
                        'terms'    => 'ovabrw_car_rental'
                    ]
                ]
            ];

            // Term ID
            if ( ovabrw_get_meta_data( 'term_id', $args ) ) {
                $args_taxonomy['tax_query'] = [
                    [
                        'taxonomy'  => 'product_cat',
                        'field'     => 'term_id',
                        'terms'     => $args['term_id'],
                        'operator'  => 'IN'
                    ]
                ];

                $base_query = array_merge_recursive( $base_query, $args_taxonomy );
            }

            // Term Slug
            if ( ovabrw_get_meta_data( 'term_slug', $args ) ) {
                $args_taxonomy['tax_query'] = [
                    [
                        'taxonomy'  => 'product_cat',
                        'field'     => 'slug',
                        'terms'     => $args['term_slug'],
                        'operator'  => 'IN'
                    ]
                ];

                $base_query = array_merge_recursive( $base_query, $args_taxonomy );
            }

            // Get products
            $products = new WP_Query( $base_query );
            
            return apply_filters( 'ovabrw_get_product_ajax_filter', $products, $args );
        }

        /**
         * Get product search taxi ajax
         */
        public function get_product_search_taxi_ajax( $args = [] ) {
            if ( !ovabrw_array_exists( $args ) ) return;

            $base_query = [
                'post_type'         => 'product',
                'post_status'       => 'publish',
                'paged'             => $args['paged'],
                'posts_per_page'    => $args['posts_per_page'],
                'orderby'           => $args['orderby'],
                'order'             => $args['order'],
                'tax_query'         => [
                    [
                        'taxonomy' => 'product_type',
                        'field'    => 'slug',
                        'terms'    => 'ovabrw_car_rental', 
                    ]
                ]
            ];

            // Term ID
            if ( ovabrw_get_meta_data( 'term_id', $args ) ) {
                $args_taxonomy['tax_query'] = [
                    [
                        'taxonomy'  => 'product_cat',
                        'field'     => 'term_id',
                        'terms'     => $args['term_id'],
                        'operator'  => 'IN'
                    ]
                ];

                $base_query = array_merge_recursive( $base_query, $args_taxonomy );
            }

            // Term Slug
            if ( ovabrw_get_meta_data( 'term_slug', $args ) ) {
                $args_taxonomy['tax_query'] = [
                    [
                        'taxonomy'  => 'product_cat',
                        'field'     => 'slug',
                        'terms'     => $args['term_slug'],
                        'operator'  => 'IN'
                    ]
                ];

                $base_query = array_merge_recursive( $base_query, $args_taxonomy );
            }

            // Get products
            $products = new WP_Query( $base_query );
            
            return apply_filters( 'ovabrw_get_product_search_taxi_ajax', $products, $args );
        }

        /**
         * Get product filter
         */
        public function get_product_filter( $args = [] ) {
            if ( !ovabrw_array_exists( $args ) ) return;

            $base_query = [
                'post_type'         => 'product',
                'post_status'       => 'publish',
                'posts_per_page'    => $args['posts_per_page'],
                'orderby'           => $args['orderby'],
                'order'             => $args['order'],
                'tax_query'         => [
                    [
                        'taxonomy' => 'product_type',
                        'field'    => 'slug',
                        'terms'    => 'ovabrw_car_rental'
                    ]
                ]
            ];

            if ( ovabrw_array_exists( $args['categories'] ) ) {
                $args_taxonomy['tax_query'] = [
                    [
                        'taxonomy'  => 'product_cat',
                        'field'     => 'term_id',
                        'terms'     => $args['categories'],
                        'operator'  => 'IN'
                    ]
                ];

                $base_query = array_merge_recursive( $base_query, $args_taxonomy );
            }

            // Get products
            $products = new WP_Query( $base_query );
            
            return apply_filters( 'ovabrw_get_product_filter', $products, $args );
        }

        /**
         * Get pick-up time
         */
        public function get_pickup_time_picker( $product_id = false ) {
            if ( !$product_id ) return false;

            $rental_type    = $this->get_meta_value( $product_id, 'price_type' );
            $group_time     = $this->get_meta_value( $product_id, 'manage_time_book_start' );

            if ( 'no' == $group_time ) return false;
            if ( 'day' == $rental_type ) {
                $charged_by = $this->get_meta_value( $product_id, 'define_1_day' );

                if ( 'hotel' != $charged_by ) {
                    return true;
                }
            } elseif ( 'hour' == $rental_type || 'mixed' == $rental_type || 'transportation' == $rental_type || 'appointment' == $rental_type ) {
                return true;
            } elseif ( 'period_time' == $rental_type ) {
                $unfixed_time = $this->get_meta_value( $product_id, 'unfixed_time' );

                if ( 'yes' == $unfixed_time ) {
                    return true;
                }
            }

            return false;
        }

        /**
         * Get drop-off time
         */
        public function get_dropoff_time_picker( $product_id = false ) {
            if ( !$product_id ) return false;

            $rental_type    = $this->get_meta_value( $product_id, 'price_type' );
            $group_time     = $this->get_meta_value( $product_id, 'manage_time_book_start' );

            if ( 'no' == $group_time ) return false;
            if ( 'day' == $rental_type ) {
                $charged_by = $this->get_meta_value( $product_id, 'define_1_day' );

                if ( 'hotel' != $charged_by ) {
                    return true;
                }
            } elseif ( 'hour' == $rental_type || 'mixed' == $rental_type || 'transportation' == $rental_type ) {
                return true;
            } elseif ( 'period_time' == $rental_type ) {
                $unfixed_time = $this->get_meta_value( $product_id, 'unfixed_time' );

                if ( 'yes' == $unfixed_time ) {
                    return true;
                }
            }

            return false;
        }

        /**
         * Get parameter from URL
         */
        public function get_parameter_from_url( $product_id = false, $url = '', $data = [] ) {
            if ( !$product_id || !$url ) return '';

            // Rental type
            $rental_type = $this->get_meta_value( $product_id, 'price_type' );

            // Pickup Location
            $pickup_location = ovabrw_get_meta_data( 'ovabrw_pickup_loc', $data );

            if ( !$pickup_location ) $pickup_location = ovabrw_get_meta_data( 'pickup_loc', $data );
            if ( !$pickup_location ) $pickup_location = ovabrw_get_meta_data( 'pickup-location', $data );
            if ( !$pickup_location ) $pickup_location = ovabrw_get_meta_data( 'pickup_location', $data );
            if ( $pickup_location ) {
                $url = add_query_arg( 'pickup_loc', $pickup_location, $url );
            }

            // Origin location
            $origin_location = stripslashes( stripslashes( ovabrw_get_meta_data( 'origin-location', $data ) ) );
            if ( !$origin_location ) $origin_location = stripslashes( stripslashes( ovabrw_get_meta_data( 'origin_location', $data ) ) );
            if ( $origin_location ) {
                $url = add_query_arg( 'origin_location', $origin_location, $url );
            }

            // Dropoff Location
            $dropoff_location = ovabrw_get_meta_data( 'ovabrw_pickoff_loc', $data );

            if ( !$dropoff_location ) $dropoff_location = ovabrw_get_meta_data( 'dropoff_loc', $data );
            if ( !$dropoff_location ) $dropoff_location = ovabrw_get_meta_data( 'dropoff-location', $data );
            if ( !$dropoff_location ) $dropoff_location = ovabrw_get_meta_data( 'dropoff_location', $data );
            if ( !$dropoff_location ) $dropoff_location = ovabrw_get_meta_data( 'ovabrw_dropoff_loc', $data );
            if ( $dropoff_location ) {
                $url = add_query_arg( 'pickoff_loc', $dropoff_location, $url );
            }

            // Destination location
            $destination_location = stripslashes( stripslashes( ovabrw_get_meta_data( 'destination-location', $data ) ) );
            if ( !$destination_location ) $destination_location = stripslashes( stripslashes( ovabrw_get_meta_data( 'destination_location', $data ) ) );
            if ( $destination_location ) {
                $url = add_query_arg( 'destination_location', $destination_location, $url );
            }

            // Pickup Date
            $pickup_date = ovabrw_get_meta_data( 'ovabrw_pickup_date', $data );

            if ( !$pickup_date ) $pickup_date = ovabrw_get_meta_data( 'start_date', $data );
            if ( !$pickup_date ) $pickup_date = ovabrw_get_meta_data( 'pickup-date', $data );
            if ( !$pickup_date ) $pickup_date = ovabrw_get_meta_data( 'pickup_date', $data );
            if ( $pickup_date ) {
                $url = add_query_arg( 'pickup_date', $pickup_date, $url );
            }

            // Dropoff Date
            $dropoff_date = ovabrw_get_meta_data( 'ovabrw_pickoff_date', $data );

            if ( !$dropoff_date ) $dropoff_date = ovabrw_get_meta_data( 'end_date', $data );
            if ( $dropoff_date ) {
                $url = add_query_arg( 'dropoff_date', $dropoff_date, $url );
            }

            // Duration
            $duration = (int)ovabrw_get_meta_data( 'map-duration', $data );
            if ( !$duration ) $duration = (int)ovabrw_get_meta_data( 'duration', $data );
            if ( $duration ) {
                $url = add_query_arg( 'duration', $duration, $url );
            }

            // Distance
            $distance = (int)ovabrw_get_meta_data( 'map-distance', $data );
            if ( !$distance ) $distance = (int)ovabrw_get_meta_data( 'distance', $data );
            if ( $distance ) {
                $url = add_query_arg( 'distance', $distance, $url );
            }

            // Quantity
            $quantity = (int)ovabrw_get_meta_data( 'quantity', $data );
            if ( $quantity ) {
                $url = add_query_arg( 'ovabrw_quantity', $quantity, $url );
            }

            // Package
            $package = ovabrw_get_meta_data( 'ovabrw_package', $data );
            if ( $package ) {
                $url = add_query_arg( 'ovabrw_package', $package, $url );
            }

            // Number of adults
            $numberof_adults = (int)ovabrw_get_meta_data( 'ovabrw_adults', $data );
            if ( !$numberof_adults ) $numberof_adults = (int)ovabrw_get_meta_data( 'adults', $data );
            if ( $numberof_adults ) {
                $url = add_query_arg( 'ovabrw_adults', $numberof_adults, $url );
            }

            // Number of children
            $numberof_children = (int)ovabrw_get_meta_data( 'ovabrw_children', $data );
            if ( !$numberof_children ) $numberof_children = (int)ovabrw_get_meta_data( 'children', $data );
            if ( $numberof_children ) {
                $url = add_query_arg( 'ovabrw_children', $numberof_children, $url );
            }

            // Number of babies
            $numberof_babies = (int)ovabrw_get_meta_data( 'ovabrw_babies', $data );
            if ( !$numberof_babies ) $numberof_babies = (int)ovabrw_get_meta_data( 'babies', $data );
            if ( $numberof_babies ) {
                $url = add_query_arg( 'ovabrw_babies', $numberof_babies, $url );
            }

            return apply_filters( 'ovabrw_get_parameter_from_url', $url, $data );
        }

        /**
         * Get package id by durations
         */
        public function get_package_id_by_durations( $product_id = false, $durations = '' ) {
            if ( !$product_id || !$durations ) return false;

            $unfixed_time   = $this->get_meta_value( $product_id, 'unfixed_time' );
            $petime_ids     = $this->get_meta_value( $product_id, 'petime_id' );
            $petime_types   = $this->get_meta_value( $product_id, 'package_type' );
            $petime_days    = $this->get_meta_value( $product_id, 'petime_days' );
            $petime_hours   = $this->get_meta_value( $product_id, 'pehour_unfixed' );
            $petime_start   = $this->get_meta_value( $product_id, 'pehour_start_time' );
            $petime_end     = $this->get_meta_value( $product_id, 'pehour_end_time' );

            foreach ( $petime_ids as $k => $package_id ) {
                $type = ovabrw_get_meta_data( $k, $petime_types );

                if ( 'other' == $type ) {
                    $number_day     = ovabrw_get_meta_data( $k, $petime_days );
                    $number_second  = $number_day ? $number_day*86400 : '';

                    if ( $number_second == $durations ) return $package_id;
                } else {
                    if ( 'yes' == $unfixed_time ) {
                        $number_hour    = isset( $petime_hours[$k] ) ? $petime_hours[$k] : '';
                        $number_second  = $number_hour ? $number_hour*3600 : '';

                        if ( $number_second == $durations ) return $package_id;
                    } else {
                        $start_time = strtotime( ovabrw_get_meta_data( $k, $petime_start ) );
                        $end_time   = strtotime( ovabrw_get_meta_data( $k, $petime_end ) );
                        
                        if ( $start_time && $end_time ) {
                            $number_second = $end_time - $start_time;

                            if ( $number_second == $durations ) return $package_id;
                        }
                    }
                }
            }

            return false;
        }

        /**
         * Get data price by format
         */
        public function get_data_price_by_format( $product_id = false ) {
            if ( !$product_id ) return false;

            // Data price
            $prices = [
                'unit'                  => '',
                'regular_price'         => '',
                'hour_price'            => '',
                'min_price'             => '',
                'max_price'             => '',
                'min_daily_price'       => '',
                'max_daily_price'       => '',
                'min_package_price'     => '',
                'max_package_price'     => '',
                'min_location_price'    => '',
                'max_location_price'    => ''
            ];

            // Rental type
            $rental_type = $this->get_meta_value( $product_id, 'price_type' );

            if ( 'day' == $rental_type ) {
                $define = $this->get_meta_value( $product_id, 'define_1_day' );
                $prices['unit'] = esc_html__( 'Day', 'ova-brw' );

                if ( 'hotel' == $define ) $prices['unit'] = esc_html__( 'Night', 'ova-brw' );

                $prices['regular_price'] = get_post_meta( $product_id, '_regular_price', true );
            } elseif ( 'hour' == $rental_type ) {
                $prices['unit']             = esc_html__( 'Hour', 'ova-brw' );
                $prices['regular_price']    = $prices['hour_price'] = $this->get_meta_value( $product_id, 'regul_price_hour' );
            } elseif ( 'mixed' == $rental_type ) {
                $prices['unit']             = esc_html__( 'Day', 'ova-brw' );
                $prices['regular_price']    = $this->get_meta_value( $product_id, 'regular_price_day' );
                $prices['hour_price']       = $this->get_meta_value( $product_id, 'regul_price_hour' );
            } elseif ( 'period_time' == $rental_type ) {
                $petime_price = $this->get_meta_value( $product_id, 'petime_price' );

                if ( ovabrw_array_exists( $petime_price ) ) {
                    $prices['min_package_price'] = min( $petime_price );
                    $prices['max_package_price'] = max( $petime_price );
                }
            } elseif ( 'transportation' == $rental_type ) {
                $price_location = $this->get_meta_value( $product_id, 'price_location' );

                if ( ovabrw_array_exists( $price_location ) ) {
                    $prices['min_location_price'] = min( $price_location );
                    $prices['max_location_price'] = max( $price_location );
                }
            } elseif ( 'taxi' == $rental_type ) {
                $prices['regular_price'] = $this->get_meta_value( $product_id, 'regul_price_taxi' );

                // Get price by
                $price_by = $this->get_meta_value( $product_id, 'map_price_by' );

                if ( 'mi' == $price_by ) {
                    $prices['unit'] = esc_html__( 'Mi', 'ova-brw' );
                } else {
                    $prices['unit'] = esc_html__( 'Km', 'ova-brw' );
                }
            } elseif ( 'hotel' == $rental_type ) {
                $prices['regular_price']    = $this->get_meta_value( $product_id, 'regular_price_hotel' );
                $prices['unit']             = esc_html__( 'Night', 'ova-brw' );
            } elseif ( 'appointment' == $rental_type ) {
                // Get timeslot prices
                $timeslost_prices = $this->get_meta_value( $product_id, 'time_slots_price' );

                if ( ovabrw_array_exists( $timeslost_prices ) ) {
                    foreach ( $timeslost_prices as $items ) {
                        // Min price
                        $min_price = (float)min( $items );
                        if ( '' == $prices['min_price'] ) $prices['min_price'] = $min_price;
                        if ( $prices['min_price'] > $min_price ) $prices['min_price'] = $min_price;

                        $max_price = (float)max( $items );
                        if ( '' == $prices['max_price'] ) $prices['max_price'] = $max_price;
                        if ( $prices['max_price'] < $max_price ) $prices['max_price'] = $max_price;
                    }
                }
            }

            if ( in_array( $rental_type, array( 'day', 'mixed', 'hotel' ) ) ) {
                // Daily price
                $daily_price = array();

                // monday price
                $monday_price = floatval( $this->get_meta_value( $product_id, 'daily_monday' ) );
                if ( $monday_price ) array_push( $daily_price, $monday_price );

                // tuesday price
                $tuesday_price = floatval( $this->get_meta_value( $product_id, 'daily_tuesday' ) );
                if ( $tuesday_price ) array_push( $daily_price, $tuesday_price );

                // wednesday price
                $wednesday_price = floatval( $this->get_meta_value( $product_id, 'daily_wednesday' ) );
                if ( $wednesday_price ) array_push( $daily_price, $wednesday_price );

                // thursday price
                $thursday_price = floatval( $this->get_meta_value( $product_id, 'daily_thursday' ) );
                if ( $thursday_price ) array_push( $daily_price, $thursday_price );

                // friday price
                $friday_price = floatval( $this->get_meta_value( $product_id, 'daily_friday' ) );
                if ( $friday_price ) array_push( $daily_price, $friday_price );

                // saturday price
                $saturday_price = floatval( $this->get_meta_value( $product_id, 'daily_saturday' ) );
                if ( $saturday_price ) array_push( $daily_price, $saturday_price );

                // sunday price
                $sunday_price = floatval( $this->get_meta_value( $product_id, 'daily_sunday' ) );
                if ( $sunday_price ) array_push( $daily_price, $sunday_price );

                if ( ovabrw_array_exists( $daily_price ) ) {
                    $prices['min_daily_price'] = min( $daily_price );
                    $prices['max_daily_price'] = max( $daily_price );
                }
            }

            return apply_filters( 'ovabrw_get_data_price_by_format', $prices, $product_id );
        }

        /**
         * Get single price by format
         */
        public function get_single_price_by_format( $product_id = false ) {
            if ( !$product_id ) return false;

            $price_format = '';
            $product_price_format = $this->get_meta_value( $product_id, 'single_price_format' );

            // Product
            if ( 'new' == $product_price_format ) {
                $price_format = $this->get_meta_value( $product_id, 'single_price_new_format' );
            }
            // Category
            if ( !$price_format ) {
                $category   = wp_get_post_terms( $product_id, 'product_cat' );
                $term_id    = isset( $category[0] ) ? $category[0]->term_id : '';

                $category_price_format = $term_id ? get_term_meta( $term_id, 'ovabrw_select_single_price_format', true ) : '';

                if ( 'new' == $category_price_format ) {
                    $price_format = get_term_meta( $term_id, 'ovabrw_single_new_price_format', true );

                    if ( !$price_format ) return false;
                }
            }
            // Woo settings
            if ( !$price_format ) {
                $price_format = get_option( 'ovabrw_single_price_format' );
            }
            if ( !$price_format ) return false;

            // Get data prices
            $data_prices = $this->get_data_price_by_format( $product_id );

            if ( '' != $data_prices['unit'] ) {
                $price_format = str_replace( '[unit]', $data_prices['unit'], $price_format );
            } else {
                $price_format = str_replace( '[unit]', '', $price_format );
            }
            if ( '' != $data_prices['regular_price'] ) {
                $price_format = str_replace( '[regular_price]', ovabrw_wc_price( $data_prices['regular_price'], [], false ), $price_format );
            } else {
                $price_format = str_replace( '[regular_price]', '', $price_format );
            }
            if ( '' != $data_prices['hour_price'] ) {
                $price_format = str_replace( '[hour_price]', ovabrw_wc_price( $data_prices['hour_price'], [], false ), $price_format );
            } else {
                $price_format = str_replace( '[hour_price]', '', $price_format );
            }
            if ( '' != $data_prices['min_daily_price'] ) {
                $price_format = str_replace( '[min_daily_price]', ovabrw_wc_price( $data_prices['min_daily_price'], [], false ), $price_format );
            } else {
                $price_format = str_replace( '[min_daily_price]', '', $price_format );
            }
            if ( '' != $data_prices['max_daily_price'] ) {
                $price_format = str_replace( '[max_daily_price]', ovabrw_wc_price( $data_prices['max_daily_price'], [], false ), $price_format );
            } else {
                $price_format = str_replace( '[max_daily_price]', '', $price_format );
            }
            if ( '' != $data_prices['min_package_price'] ) {
                $price_format = str_replace( '[min_package_price]', ovabrw_wc_price( $data_prices['min_package_price'], [], false ), $price_format );
            } else {
                $price_format = str_replace( '[min_package_price]', '', $price_format );
            }
            if ( '' != $data_prices['max_package_price'] ) {
                $price_format = str_replace( '[max_package_price]', ovabrw_wc_price( $data_prices['max_package_price'], [], false ), $price_format );
            } else {
                $price_format = str_replace( '[max_package_price]', '', $price_format );
            }
            if ( '' != $data_prices['min_location_price'] ) {
                $price_format = str_replace( '[min_location_price]', ovabrw_wc_price( $data_prices['min_location_price'], [], false ), $price_format );
            } else {
                $price_format = str_replace( '[min_location_price]', '', $price_format );
            }
            if ( '' != $data_prices['max_location_price'] ) {
                $price_format = str_replace( '[max_location_price]', ovabrw_wc_price( $data_prices['max_location_price'], [], false ), $price_format );
            } else {
                $price_format = str_replace( '[max_location_price]', '', $price_format );
            }
            if ( '' != $data_prices['min_price'] ) {
                $price_format = str_replace( '[min_price]', ovabrw_wc_price( $data_prices['min_price'], [], false ), $price_format );
            } else {
                $price_format = str_replace( '[min_price]', '', $price_format );
            }
            if ( '' != $data_prices['max_price'] ) {
                $price_format = str_replace( '[max_price]', ovabrw_wc_price( $data_prices['max_price'], [], false ), $price_format );
            } else {
                $price_format = str_replace( '[max_price]', '', $price_format );
            }

            return apply_filters( 'ovabrw_get_single_price_by_format', $price_format, $product_id );
        }

        /**
         * Get product price by search data
         */
        public function get_price_by_search( $product_id = false, $args = array() ) {
            $price_html = '';

            // Pick-up date
            $pickup_date = strtotime( ovabrw_get_meta_data( 'ovabrw_pickup_date', $args ) );

            // Drop-off data
            $dropoff_date = strtotime( ovabrw_get_meta_data( 'ovabrw_pickoff_date', $args ) );

            // Ajax Hotel
            if ( !$pickup_date ) {
                $pickup_date = strtotime( ovabrw_get_meta_data( 'start_date', $args ) );
            }
            if ( !$dropoff_date ) {
                $dropoff_date = strtotime( ovabrw_get_meta_data( 'end_date', $args ) );
            }

            // Taxi
            if ( !$pickup_date ) {
                $pickup_date = strtotime( ovabrw_get_meta_data( 'pickup-date', $args ) );
            }
            if ( !$pickup_date ) {
                $pickup_date = strtotime( ovabrw_get_meta_data( 'pickup_date', $args ) );
            }

            // Duration
            $duration = ovabrw_get_meta_data( 'map-duration', $args );
            if ( !$duration ) {
                $duration = ovabrw_get_meta_data( 'duration', $args );
            }
            if ( $pickup_date && $duration ) {
                $dropoff_date = $pickup_date + $duration;
            }

            // Distance
            $distance = ovabrw_get_meta_data( 'map-distance', $args );
            if ( !$distance ) {
                $distance = ovabrw_get_meta_data( 'distance', $args );
            }

            if ( $pickup_date && $dropoff_date ) {
                // Pick-up location
                $pickup_location = ovabrw_get_meta_data( 'ovabrw_pickup_loc', $args );

                // Drop-off location
                $dropoff_location = ovabrw_get_meta_data( 'ovabrw_pickoff_loc', $args );

                // Rental type
                $rental_type = $this->get_meta_value( $product_id, 'price_type' );

                // Object Rental Types
                $rental_object = isset( OVABRW_Rental_Types::instance()->rental_types[$rental_type] ) ? OVABRW_Rental_Types::instance()->rental_types[$rental_type] : '';

                if ( !empty( $rental_object ) && is_object( $rental_object ) ) {
                    // Set Product ID
                    $rental_object->set_ID( $product_id );

                    // Get line total
                    $line_total = $rental_object->get_total([
                        'ovabrw_checkin'        => $pickup_date,
                        'ovabrw_checkout'       => $dropoff_date,
                        'ovabrw_pickup_loc'     => $pickup_location,
                        'ovabrw_pickoff_loc'    => $dropoff_location,
                        'distance'              => $distance
                    ]);

                    if ( $line_total ) {
                        $insurance_amount = floatval( $rental_object->get_value( 'amount_insurance' ) );
                        if ( $insurance_amount ) $line_total += $insurance_amount;

                        $price_html .= '<span class="ovabrw-price-search">';
                            $price_html .= '<span class="unit">'.esc_html__( 'From ', 'ova-brw' ).'</span>';
                            $price_html .= '<span class="amount">'.ovabrw_wc_price( $line_total, [], false ).'</span>';
                        $price_html .= '</span>';
                    }
                }
            }

            return apply_filters( 'ovabrw_get_price_by_search', $price_html, $product_id, $args );
        }

        /**
         * Get archive price by format
         */
        public function get_archive_price_by_format( $product_id = false ) {
            if ( !$product_id ) return false;

            $price_format = '';
            $product_price_format = $this->get_meta_value( $product_id, 'archive_price_format' );

            // Product
            if ( 'new' == $product_price_format ) {
                $price_format = $this->get_meta_value( $product_id, 'archive_price_new_format' );
            }
            // Category
            if ( !$price_format ) {
                $category   = wp_get_post_terms( $product_id, 'product_cat' );
                $term_id    = isset( $category[0] ) ? $category[0]->term_id : '';

                $category_price_format = $term_id ? get_term_meta( $term_id, 'ovabrw_select_archive_price_format', true ) : '';

                if ( 'new' == $category_price_format ) {
                    $price_format = get_term_meta( $term_id, 'ovabrw_archive_new_price_format', true );

                    if ( !$price_format ) return false;
                }
            }
            // Woo settings
            if ( !$price_format ) {
                $price_format = get_option( 'ovabrw_archive_price_format' );
            }
            if ( !$price_format ) return false;

            // Get data prices
            $data_prices = $this->get_data_price_by_format( $product_id );

            if ( '' != $data_prices['unit'] ) {
                $price_format = str_replace( '[unit]', $data_prices['unit'], $price_format );
            } else {
                $price_format = str_replace( '[unit]', '', $price_format );
            }
            if ( '' != $data_prices['regular_price'] ) {
                $price_format = str_replace( '[regular_price]', ovabrw_wc_price( $data_prices['regular_price'], [], false ), $price_format );
            } else {
                $price_format = str_replace( '[regular_price]', '', $price_format );
            }
            if ( '' != $data_prices['hour_price'] ) {
                $price_format = str_replace( '[hour_price]', ovabrw_wc_price( $data_prices['hour_price'], [], false ), $price_format );
            } else {
                $price_format = str_replace( '[hour_price]', '', $price_format );
            }
            if ( '' != $data_prices['min_daily_price'] ) {
                $price_format = str_replace( '[min_daily_price]', ovabrw_wc_price( $data_prices['min_daily_price'], [], false ), $price_format );
            } else {
                $price_format = str_replace( '[min_daily_price]', '', $price_format );
            }
            if ( '' != $data_prices['max_daily_price'] ) {
                $price_format = str_replace( '[max_daily_price]', ovabrw_wc_price( $data_prices['max_daily_price'], [], false ), $price_format );
            } else {
                $price_format = str_replace( '[max_daily_price]', '', $price_format );
            }
            if ( '' != $data_prices['min_package_price'] ) {
                $price_format = str_replace( '[min_package_price]', ovabrw_wc_price( $data_prices['min_package_price'], [], false ), $price_format );
            } else {
                $price_format = str_replace( '[min_package_price]', '', $price_format );
            }
            if ( '' != $data_prices['max_package_price'] ) {
                $price_format = str_replace( '[max_package_price]', ovabrw_wc_price( $data_prices['max_package_price'], [], false ), $price_format );
            } else {
                $price_format = str_replace( '[max_package_price]', '', $price_format );
            }
            if ( '' != $data_prices['min_location_price'] ) {
                $price_format = str_replace( '[min_location_price]', ovabrw_wc_price( $data_prices['min_location_price'], [], false ), $price_format );
            } else {
                $price_format = str_replace( '[min_location_price]', '', $price_format );
            }
            if ( '' != $data_prices['max_location_price'] ) {
                $price_format = str_replace( '[max_location_price]', ovabrw_wc_price( $data_prices['max_location_price'], [], false ), $price_format );
            } else {
                $price_format = str_replace( '[max_location_price]', '', $price_format );
            }
            if ( '' != $data_prices['min_price'] ) {
                $price_format = str_replace( '[min_price]', ovabrw_wc_price( $data_prices['min_price'], [], false ), $price_format );
            } else {
                $price_format = str_replace( '[min_price]', '', $price_format );
            }
            if ( '' != $data_prices['max_price'] ) {
                $price_format = str_replace( '[max_price]', ovabrw_wc_price( $data_prices['max_price'], [], false ), $price_format );
            } else {
                $price_format = str_replace( '[max_price]', '', $price_format );
            }

            return apply_filters( 'ovabrw_get_archive_price_by_format', $price_format, $product_id );
        }

        /**
         * Get insurance name
         */
        public function get_insurance_name() {
            return apply_filters( 'ovabrw_get_insurance_name', esc_html__( 'Insurance fees', 'ova-brw' ) );
        }

        /**
         * Enable insurance tax
         */
        public function enable_insurance_tax() {
            if ( wc_tax_enabled() && 'yes' == get_option( 'ova_brw_enable_insurance_tax', 'no' ) ) {
                return true;
            }

            return false;
        }

        /**
         * Remaining amount incl insurance
         */
        public function remaining_amount_incl_insurance() {
            if ( 'yes' != get_option( 'ova_brw_only_add_insurance_to_deposit', 'no' ) ) {
                return true;
            }

            return false;
        }

        /**
         * Get insurance tax class
         */
        public function get_insurance_tax_class() {
            return apply_filters( 'ovabrw_get_insurance_tax_class', '' );
        }

        /**
         * Get insurance inclusive tax
         */
        public function get_insurance_inclusive_tax( $price = 0 ) {
            $tax_display = get_option( 'woocommerce_tax_display_cart' );

            if ( wc_tax_enabled() && 'incl' == $tax_display ) {
                $price += $this->get_insurance_tax_amount( $price );
            }

            return apply_filters( 'get_insurance_inclusive_tax', $price );
        }

        /**
         * Get insurance tax amount
         */
        public function get_insurance_tax_amount( $price ) {
            $tax_amount = 0;

            if ( $this->enable_insurance_tax() ) {
                $tax_rates  = WC_Tax::get_rates( $this->get_insurance_tax_class() );
                $taxes      = WC_Tax::calc_exclusive_tax( $price, $tax_rates );
                $tax_amount += WC_Tax::get_tax_total( $taxes );
            }

            return apply_filters( 'get_insurance_tax_amount', $tax_amount, $price );
        }

        /**
         * Get timezone string
         */
        public function get_timezone_string() {
            $current_offset = get_option( 'gmt_offset' );
            $tzstring       = get_option( 'timezone_string' );

            if ( str_contains( $tzstring, 'Etc/GMT' ) ) {
                $tzstring = '';
            }

            if ( empty( $tzstring ) ) {
                if ( 0 == $current_offset ) {
                    $tzstring = 'UTC+0';
                } elseif ( $current_offset < 0 ) {
                    $tzstring = 'UTC' . $current_offset;
                } else {
                    $tzstring = 'UTC+' . $current_offset;
                }
            }

            $tzstring = str_replace( array( '.25', '.5', '.75' ), array( ':15', ':30', ':45' ), $tzstring );

            return apply_filters( 'ovabrw_get_timezone_string', $tzstring );
        }

        /**
         * Get meta value
         */
        public function get_meta_value( $id = false, $key = '', $default = '' ) {
            if ( !$id ) return $default;
            
            $value = get_post_meta( $id, $this->prefix . $key, true );

            if ( $value == '' && $default != '' ) {
                $value = $default;
            }

            return $value;
        }

        /**
         * Show date field
         */
        public function get_show_date( $product_id = false, $type = 'pickup' ) {
            if ( !$product_id || !$type ) return false;

            // Get show date
            $show_date = $this->get_meta_value( $product_id, 'show_pickup_date_product' );

            if ( 'dropoff' == $type ) {
                $show_date = $this->get_meta_value( $product_id, 'show_pickoff_date_product' );
            }

            switch ( $show_date ) {
                case 'yes':
                    return true;
                case 'no':
                    return false;
                default:
                    if ( 'pickup' == $type ) {
                        return true;
                    } elseif ( 'dropoff' == $type ) {
                        if ( 'yes' == get_option( 'ova_brw_booking_form_show_dropoff_date', 'yes' ) ) {
                            return true;
                        } else {
                            return false;
                        }
                    }
            }

            return false;
        }

        /**
         * Show quantity field
         */
        public function get_show_quantity( $product_id = false ) {
            if ( !$product_id ) return false;

            $show_quantity = $this->get_meta_value( $product_id, 'show_number_vehicle', 'in_setting' );
            
            switch ( $show_quantity ) {
                case 'in_setting':
                    if ( 'yes' == get_option( 'ova_brw_booking_form_show_number_vehicle', 'yes' ) ) {
                        return true;
                    } else {
                        return false;
                    }
                case 'yes':
                    return true;
                case 'no':
                    return false;
                default:
                    return true;
            }

            return true;
        }

        public function get_show_location( $product_id = false, $type = 'pickup' ) {
            if ( !$product_id || !$type ) return false;

            $show_location = $this->get_meta_value( $product_id, 'show_pickup_location_product' );

            if ( $type == 'dropoff' ) {
                $show_location = $this->get_meta_value( $product_id, 'show_pickoff_location_product' );
            }

            switch ( $show_location ) {
                case 'yes':
                    return true;
                case 'no':
                    return false;
                default:
                    $categories     = wp_get_post_terms( $product_id, 'product_cat' );
                    $term_id        = isset( $categories[0] ) ? $categories[0]->term_id : '';
                    $term_location  = $term_id ? get_term_meta( $term_id, 'ovabrw_show_loc_booking_form', true ) : '';

                    if ( $type == 'pickup' ) {
                        if ( ovabrw_array_exists( $term_location ) ) {
                            if ( in_array( 'pickup_loc', $term_location ) ) {
                                return true;
                            } else {
                                return false;
                            }
                        } else {
                            if ( 'yes' == get_option( 'ova_brw_booking_form_show_pickup_location', 'no' ) ) {
                                return true;
                            } else {
                                return false;
                            }
                        }
                    }

                    if ( 'dropoff' == $type ) {
                        if ( ovabrw_array_exists( $term_location ) ) {
                            if ( in_array( 'dropoff_loc', $term_location ) ) {
                                return true;
                            } else {
                                return false;
                            }
                        } else {
                            if ( 'yes' == get_option( 'ova_brw_booking_form_show_pickoff_location', 'no' ) ) {
                                return true;
                            } else {
                                return false;
                            }
                        }
                    }
            }

            return true;
        }

        /**
         * Get current time
         */
        public function get_current_time( $product_id = false ) {
            $current_time = current_time('timestamp');

            if ( $product_id && !OVABRW()->options->get_pickup_time_picker( $product_id ) ) {
                $current_time = strtotime( date( 'Y-m-d', current_time('timestamp') ).' 00:00' );
            }

            return apply_filters( 'ovabrw_get_current_time', $current_time, $product_id );
        }

        /**
         * Reserve stock for order
         */
        public function reserve_stock_for_order( $order ) {
            $minutes = (int)get_option( 'woocommerce_hold_stock_minutes', 60 );
            $minutes = apply_filters( 'ovabrw_order_hold_stock_minutes', $minutes, $order );

            if ( !$minutes ) return;

            try {
                $items = array_filter(
                    $order->get_items(),
                    function ( $item ) {
                        return $item->is_type( 'line_item' ) && $item->get_product() instanceof \WC_Product && $item->get_quantity() > 0;
                    }
                );
                $rows  = array();

                foreach ( $items as $item ) {
                    $product = $item->get_product();

                    if ( !$product->is_type( 'ovabrw_car_rental' ) ) continue;

                    // Get product ID
                    $product_id = $product->get_stock_managed_by_id();
                    
                    // Add reserve stock for product
                    $this->reserve_stock_for_product( $product_id, 0, $order, $minutes );
                }
            } catch ( Exception $e ) {
                $this->release_stock_for_order( $order );
            }
        }

        /**
         * Reserve stock for product
         */
        public function reserve_stock_for_product( $product_id, $stock_quantity, $order, $minutes ) {
            global $wpdb;

            $result = $wpdb->query(
                $wpdb->prepare(
                    "
                    INSERT INTO {$wpdb->wc_reserved_stock} ( `order_id`, `product_id`, `stock_quantity`, `timestamp`, `expires` )
                    SELECT %d, %d, %d, NOW(), ( NOW() + INTERVAL %d MINUTE ) FROM DUAL
                    ON DUPLICATE KEY UPDATE `timestamp` = VALUES( `timestamp` ), `expires` = VALUES( `expires` ), `stock_quantity` = VALUES( `stock_quantity` )
                    ",
                    $order->get_id(),
                    $product_id,
                    $stock_quantity,
                    $minutes
                )
            );
        }

        /**
         * Release stock for order
         */
        public function release_stock_for_order( $order ) {
            global $wpdb;

            $wpdb->delete(
                $wpdb->wc_reserved_stock,
                array(
                    'order_id' => $order->get_id(),
                )
            );
        }

        /**
         * Get reserved quantity
         */
        public function get_reserved_quantity( $product, $checkin_date, $checkout_date ) {
            $reserved_quantity = 0;

            // Enabled
            if ( 'yes' !== get_option( 'woocommerce_manage_stock' ) ) {
                return $reserved_quantity;
            }

            global $wpdb;

            // Product id
            $product_id = $product->get_id();

            // Draft order id
            $draft_order_id = $this->get_draft_order_id();

            // Order ids
            $order_ids = array();

            // Get order ids
            // phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
            if ( OrderUtil::custom_orders_table_usage_is_enabled() ) {
                $order_ids = $wpdb->get_col( $wpdb->prepare( "
                    SELECT DISTINCT stock_table.order_id
                    FROM {$wpdb->prefix}wc_reserved_stock AS stock_table
                    LEFT JOIN {$wpdb->prefix}wc_orders AS orders
                        ON orders.id = stock_table.order_id
                    WHERE orders.status IN ( 'wc-checkout-draft', 'wc-pending' )
                        AND stock_table.expires > NOW()
                        AND stock_table.product_id = %d
                        AND stock_table.order_id != %d
                    ",
                    array(
                        $product_id,
                        $draft_order_id
                    )
                ));
            } else {
                $order_ids = $wpdb->get_col( $wpdb->prepare( "
                    SELECT DISTINCT stock_table.order_id
                    FROM {$wpdb->prefix}wc_reserved_stock AS stock_table
                    LEFT JOIN {$wpdb->prefix}posts AS posts
                        ON posts.ID = stock_table.order_id
                    WHERE posts.post_status IN ( 'wc-checkout-draft', 'wc-pending' )
                        AND stock_table.expires > NOW()
                        AND stock_table.product_id = %d
                        AND stock_table.order_id != %d
                    ",
                    array(
                        $product_id,
                        $draft_order_id
                    )
                ));
            }
            // phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
            
            // Loop order ids
            if ( ovabrw_array_exists( $order_ids ) ) {
                foreach ( $order_ids as $order_id ) {
                    $order = wc_get_order( $order_id );

                    if ( ! $order || ! is_object( $order ) ) continue;

                    $items = $order->get_items();

                    if ( ! ovabrw_array_exists( $items ) ) continue;

                    foreach ( $items as $item_id => $item ) {
                        if ( ! $item || ! is_object( $item ) ) continue;

                        if ( $item->get_product_id() == $product_id ) {
                            $time_between = 0;

                            // Get rental type
                            $rental_type = $this->get_meta_value( $product_id, 'price_type' );

                            if ( 'day' === $rental_type || 'transportation' === $rental_type ) {
                                // 1 day = 86400s
                                $time_between = floatval( $this->get_meta_value( $product_id, 'prepare_vehicle_day' ) ) * 86400;
                            } else {
                                // 1 hour = 60s
                                $time_between = floatval( $this->get_meta_value( $product_id, 'prepare_vehicle' ) ) * 60;
                            }

                            // Pickup date item
                            $pickup_date_item = strtotime( $item->get_meta( OVABRW_PREFIX.'pickup_date' ) );

                            // Pickup date real
                            $pickup_date_real = strtotime( $item->get_meta( OVABRW_PREFIX.'pickup_date_real' ) );

                            if ( !$pickup_date_real || !$pickup_date_item ) continue;
                            $pickup_date_real += $time_between;

                            // Dropoff date item
                            $dropoff_date_item = strtotime( $item->get_meta( OVABRW_PREFIX.'pickoff_date' ) );

                            // Dropoff date real
                            $dropoff_date_real = strtotime( $item->get_meta( OVABRW_PREFIX.'pickoff_date_real' ) );

                            if ( !$dropoff_date_real || !$dropoff_date_item ) continue;
                            $dropoff_date_real += $time_between;

                            // When Drop-off date hidden
                            if ( $pickup_date_item === $dropoff_date_item ) {
                                $dropoff_date_real  -= 1;
                                $dropoff_date       += 1;
                            }

                            // Qty item
                            $qty_item = absint( $item->get_meta( OVABRW_PREFIX.'number_vehicle' ) );
                            if ( ! $qty_item ) continue;

                            // Check booking period
                            if ( $dropoff_date_real >= current_time( 'timestamp' ) ) {
                                if ( apply_filters( 'ovabrw_check_equal_booking_times', false, $product_id ) ) {
                                    if ( ! ( $checkin_date > $dropoff_date_real || $checkout_date < $pickup_date_real ) ) {
                                        $reserved_quantity += $qty_item;
                                    }
                                } else {
                                    if ( ! ( $checkin_date >= $dropoff_date_real || $checkout_date <= $pickup_date_real ) ) {
                                        $reserved_quantity += $qty_item;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            // End loop order ids
            
            return apply_filters( 'ovabrw_get_reserved_quantity', (int)$reserved_quantity, $product, $checkin_date, $checkout_date );
        }

        /**
         * Get draft order ID
         */
        public function get_draft_order_id() {
            if ( ! wc()->session ) {
                wc()->initialize_session();
            }

            return wc()->session->get( 'store_api_draft_order', 0 );
        }

        /**
         * Get total resources
         */
        public function ovabrw_get_total_resources( $product_id = false, $pickup_date = false, $dropoff_date = false, $resources = [], $quantity = [] ) {
            // init
            $total_resource = 0;

            if ( !ovabrw_array_exists( $resources ) ) return $total_resource;
            if ( !ovabrw_array_exists( $quantity ) ) $quantity = [];

            $rent_time      = ovabrw_get_rental_times( $pickup_date, $dropoff_date, $product_id );
            $res_ids        = get_post_meta( $product_id, 'ovabrw_resource_id', true );
            $res_prices     = get_post_meta( $product_id, 'ovabrw_resource_price', true );
            $res_types      = get_post_meta( $product_id, 'ovabrw_resource_duration_type', true );

            foreach ( $resources as $opt_id => $opt_value ) {
                foreach ( $res_ids as $k => $value ) {
                    if ( $opt_id == $value ) {
                        $qty        = absint( ovabrw_get_meta_data( $opt_id, $quantity, 1 ) );
                        $duration   = ovabrw_get_meta_data( $k, $res_types );

                        if ( 'total' == $duration ) {
                            $total_resource += $res_prices[$k] * $qty;
                        } elseif ( 'days' == $duration ) {
                            $total_resource += $res_prices[$k] * $rent_time['rent_time_day'] * $qty;
                        } elseif ( 'hours' == $duration ) {
                            $total_resource += $res_prices[$k] * $rent_time['rent_time_hour'] * $qty;
                        }
                    }
                }
            }

            return apply_filters( 'ovabrw_get_total_resources', $total_resource, $product_id, $pickup_date, $dropoff_date, $resources, $quantity );
        }

        /**
         * Get total services
         */
        public function ovabrw_get_total_services( $product_id = false, $pickup_date = false, $dropoff_date = false, $services = [], $quantity = [] ) {
            $total_service = 0;

            if ( !ovabrw_array_exists( $services ) ) return $total_service;
            if ( empty( $quantity ) ) $quantity = [];

            $rent_time      = ovabrw_get_rental_times( $pickup_date, $dropoff_date, $product_id );
            $rental_type    = get_post_meta( $product_id, 'ovabrw_price_type', true );
            $service_ids    = get_post_meta( $product_id, 'ovabrw_service_id', true );  
            $service_prices = get_post_meta( $product_id, 'ovabrw_service_price', true );  
            $duration_types = get_post_meta( $product_id, 'ovabrw_service_duration_type', true ); 

            foreach ( $services as $sev_id ) {
                if ( $sev_id && ovabrw_array_exists( $service_ids ) ) {
                    foreach ( $service_ids as $sev_key => $sev_ids ) {
                        if ( in_array( $sev_id, $sev_ids) ) {
                            foreach ( $sev_ids as $k => $ops_id ) {
                                if ( $sev_id == $ops_id ) {
                                    $duration   = $duration_types[$sev_key][$k];
                                    $price      = floatval( $service_prices[$sev_key][$k] );
                                    $qty        = absint( ovabrw_get_meta_data( $sev_id, $quantity, 1 ) );

                                    if ( 'total' == $duration ) {
                                        $total_service += $price * $qty;
                                    } elseif ( 'days' == $duration ) {
                                        $total_service += $price * $rent_time['rent_time_day'] * $qty;
                                    } elseif ( 'hours' == $duration ) {
                                        $total_service += $price * $rent_time['rent_time_hour'] * $qty;
                                    }
                                }
                            }
                        }
                    }
                }
            }

            return apply_filters( 'ovabrw_get_total_services', $total_service, $product_id, $pickup_date, $dropoff_date, $services, $quantity );
        }

        /**
         * Get timepicker options
         * @return array
         */
        public function get_timepicker_options() {
            return apply_filters( 'ovabrw_timepicker_options', [
                'timeFormat'        => ovabrw_get_time_format(),
                'step'              => ovabrw_get_time_step(),
                'scrollDefault'     => '07:00',
                'forceRoundTime'    => true,
                'disableTextInput'  => true,
                'autoPickTime'      => true,
                'defaultStartTime'  => ovabrw_get_default_pickup_time(),
                'defaultEndTime'    => ovabrw_get_default_dropoff_time(),
                'allowTimes'        => [],
                'allowStartTimes'   => ovabrw_get_pickup_group_time(),
                'allowEndTimes'     => ovabrw_get_dropoff_group_time(),
                'lang'              => apply_filters( 'ovabrw_timepicker_options_lang', [
                    'am'        => 'am',
                    'pm'        => 'pm',
                    'AM'        => 'AM',
                    'PM'        => 'PM',
                    'decimal'   => '.',
                    'mins'      => 'mins',
                    'hr'        => 'hr',
                    'hrs'       => 'hrs',
                    'pickUp'    => esc_html__( 'Pick-up', 'ova-brw' ),
                    'dropOff'   => esc_html__( 'Drop-off', 'ova-brw' )
                ])
            ]);
        }

        /**
         * Get datepicker options
         * @return array
         */
        public function get_datepicker_options() {
            // Date format
            $date_format = ovabrw_get_date_format();

            // Time format
            $time_format = ovabrw_get_time_format();

            // Min year, Max year
            $min_year = (int)get_option( 'ova_brw_booking_form_year_start', date('Y') );
            $max_year = (int)get_option( 'ova_brw_booking_form_year_end', date('Y')+3 );

            // Get min date
            $min_date = date( $date_format, current_time( 'timestamp' ) );
            if ( $min_year && $min_year > date('Y') ) {
                $min_date = date( $date_format, strtotime( "$min_year-01-01" ) );
            }

            // Get max date
            $max_date = '';
            if ( $max_year ) {
                $december_date = new DateTime("$max_year-12-01");
                $december_date->modify('last day of this month');

                // Get max date
                $max_date = $december_date->format($date_format);
            }

            // Start date when calendar show
            $start_date = '';

            if ( $min_date && strtotime( $min_date ) > current_time( 'timestamp' ) ) {
                $start_date = $min_date;
            }

            // Language
            $language = apply_filters( 'ovabrw_datepicker_language', get_option( 'ova_brw_calendar_language_general', 'en-GB' ) );

            if ( apply_filters( 'wpml_current_language', NULL ) ) { // WPML
                $language = apply_filters( 'wpml_current_language', NULL );
            } elseif ( function_exists('pll_current_language') ) { // Polylang
                $language = pll_current_language();
            }

            // Overcome disabled dates
            $inseparable = get_option( 'ova_brw_booking_form_disable_week_day' );
            if ( 'yes' == $inseparable ) {
                $inseparable = false;
            } else {
                $inseparable = true;
            }

            // Disable weekdays
            $disable_weekdays = apply_filters( 'ovabrw_datepicker_disable_weekdays', get_option( 'ova_brw_calendar_disable_week_day', [] ) );
            
            if ( ovabrw_array_exists( $disable_weekdays ) ) {
                $key = array_search( '0', $disable_weekdays );
                if ( $key !== false ) $disable_weekdays[$key] = '7';
            } else {
                if ( $disable_weekdays && !is_array( $disable_weekdays ) ) {
                    $disable_weekdays = explode( ',', $disable_weekdays );
                    $disable_weekdays = array_map( 'trim', $disable_weekdays );
                }
            }

            // Datepicker CSS
            $datepciker_css = [
                OVABRW_PLUGIN_URI.'assets/libs/easepick/easepick.min.css',
                OVABRW_PLUGIN_URI.'assets/css/datepicker/datepicker.css'
            ];

            // Get customize calendar
            $customize_calendar = get_option( OVABRW_PREFIX.'customize_calendar' );
            if ( 'yes' == $customize_calendar ) {
                $css_path = OVABRW_PLUGIN_PATH.'assets/css/datepicker/customize.css';

                if ( file_exists( $css_path ) ) {
                    $datepciker_css[] = OVABRW_PLUGIN_URI.'assets/css/datepicker/customize.css';
                } else {
                    $additional_css = get_option( OVABRW_PREFIX.'additional_css' );
                    $numberof_byte  = file_put_contents( OVABRW_PLUGIN_PATH.'assets/css/datepicker/customize.css', (string)$additional_css );

                    if ( $numberof_byte ) {
                        $datepciker_css[] = OVABRW_PLUGIN_URI.'assets/css/datepicker/customize.css';
                    }
                }
            }

            return apply_filters( 'ovabrw_datepicker_options', [
                'css'           => apply_filters( 'ovabrw_datepicker_css', $datepciker_css ),
                'firstDay'      => (int)get_option( 'ova_brw_calendar_first_day', 1 ),
                'lang'          => $language,
                'format'        => $date_format,
                'grid'          => 2,
                'calendars'     => 2,
                'zIndex'        => 999999999,
                'inline'        => false,
                'readonly'      => true,
                'header'        => apply_filters( 'ovabrw_datepicker_header', '' ),
                'autoApply'     => true,
                'locale'        => apply_filters( 'ovabrw_datepicker_locale', [
                    'cancel'    => esc_html__( 'Cancel', 'ova-brw' ),
                    'apply'     => esc_html__( 'Apply', 'ova-brw' )
                ]),
                'AmpPlugin'     => apply_filters( 'ovabrw_datepicker_amp_plugin', array(
                    'dropdown'  => array(
                        'months'    => true,
                        'years'     => true,
                        'minYear'   => $min_year ? $min_year : date('Y'),
                        'maxYear'   => $max_year ? $max_year : date('Y')+3,
                    ),
                    'resetButton'   => true,
                    'darkMode'      => false
                )),
                'RangePlugin'   => apply_filters( 'ovabrw_datepicker_range_plugin', [
                    'repick'    => false,
                    'strict'    => true,
                    'tooltip'   => true,
                    'locale'    => [
                        'zero'  => '',
                        'one'   => esc_html__( 'day', 'ova-brw' ),
                        'two'   => '',
                        'many'  => '',
                        'few'   => '',
                        'other' => esc_html__( 'days', 'ova-brw' )
                    ]
                ]),
                'LockPlugin'    => apply_filters( 'ovabrw_datepicker_lock_plugin', [
                    'minDate'           => $min_date,
                    'maxDate'           => $max_date,
                    'minDays'           => '',
                    'maxDays'           => '',
                    'selectForward'     => false,
                    'selectBackward'    => false,
                    'presets'           => true,
                    'inseparable'       => apply_filters( 'ovabrw_datepicker_inseparable', $inseparable )
                ]),
                'PresetPlugin'      => apply_filters( 'ovabrw_datepicker_preset_plugin', [
                    'position'      => 'left',
                    'customLabels'  => [
                        esc_html__( 'Today', 'ova-brw' ),
                        esc_html__( 'Yesterday', 'ova-brw' ),
                        esc_html__( 'Last 7 Days', 'ova-brw' ),
                        esc_html__( 'Last 30 Days', 'ova-brw' ),
                        esc_html__( 'This Month', 'ova-brw' ),
                        esc_html__( 'Last Month', 'ova-brw' )
                    ],
                    'customPreset'  => ovabrw_get_predefined_ranges()
                ]),
                'plugins' => apply_filters( 'ovabrw_datepicker_plugins', [
                    'AmpPlugin',
                    'RangePlugin',
                    'LockPlugin'
                ]),
                'disableWeekDays'   => $disable_weekdays,
                'disableDates'      => apply_filters( 'ovabrw_datepicker_disable_dates', [] ),
                'bookedDates'       => apply_filters( 'ovabrw_datepicker_booked_dates', [] ),
                'allowedDates'      => apply_filters( 'ovabrw_datepicker_allowed_dates', [] ),
                'startDate'         => $start_date
            ]);
        }

        /**
         * Datepicker global css
         */
        public function datepicker_global_css() {
            // CSS
            $css = '';

            $primary_background     = ovabrw_get_option( 'primary_background_calendar', '#00BB98' );
            $color_streak           = ovabrw_get_option( 'color_streak', '#FFFFFF' );
            $color_available        = ovabrw_get_option( 'color_available', '#222222' );
            $background_available   = ovabrw_get_option( 'background_available', '#FFFFFF' );
            $color_unavailable      = ovabrw_get_option( 'color_not_available', '#FFFFFF' );
            $background_unavailable = ovabrw_get_option( 'background_not_available', '#E56E00' );

            $css .= "--ovabrw-primary-calendar:{$primary_background};";
            $css .= "--ovabrw-color-available:{$color_available};";
            $css .= "--ovabrw-background-available:{$background_available};";
            $css .= "--ovabrw-color-unavailable:{$color_unavailable};";
            $css .= "--ovabrw-background-unavailable:{$background_unavailable};";
            $css .= "--ovabrw-color-streak:{$color_streak};";

            return apply_filters( 'ovabrw_datepicker_global_css', $css );
        }

        /**
         * Get string day of week
         * @param  int      $strtotime
         * @return string   $dayofweek
         */
        public function get_string_dayofweek( $strtotime ) {
            if ( !$strtotime ) return false;

            $numberof_day   = date( 'w', $strtotime );
            $dayofweek      = '';

            switch ( $numberof_day ) {
                case '0':
                    $dayofweek = 'sunday';
                    break;
                case '1':
                    $dayofweek = 'monday';
                    break;
                case '2':
                    $dayofweek = 'tuesday';
                    break;
                case '3':
                    $dayofweek = 'wednesday';
                    break;
                case '4':
                    $dayofweek = 'thursday';
                    break;
                case '5':
                    $dayofweek = 'friday';
                    break;
                case '6':
                    $dayofweek = 'saturday';
                    break;
                default:
                    break;
            }

            return apply_filters( 'ovabrw_get_string_dayofweek', $dayofweek, $strtotime );
        }

        /**
         * Get time slots
         */
        public function get_time_slots( $product_id, $pickup_date ) {
            if ( !$product_id || !$pickup_date ) return false;

            // init time slots
            $time_slots = [];

            // Get string day of week
            $dayofweek = $this->get_string_dayofweek( $pickup_date );

            // Get time slots lable
            $timeslots_label = ovabrw_get_post_meta( $product_id, 'time_slots_label', [] );

            // Get time slots start time
            $timeslots_start = ovabrw_get_post_meta( $product_id, 'time_slots_start', [] );

            // Get time slots end time
            $timeslots_end = ovabrw_get_post_meta( $product_id, 'time_slots_end', [] );

            // Get time slots quantity
            $timeslots_qty = ovabrw_get_post_meta( $product_id, 'time_slots_quantity', [] );

            // Time slots by day of week
            $labels         = ovabrw_get_meta_data( $dayofweek, $timeslots_label );
            $start_times    = ovabrw_get_meta_data( $dayofweek, $timeslots_start );
            $end_times      = ovabrw_get_meta_data( $dayofweek, $timeslots_end );
            $quantities     = ovabrw_get_meta_data( $dayofweek, $timeslots_qty );

            if ( ovabrw_array_exists( $start_times ) ) {
                // Object Rental Types
                $rental_object = OVABRW_Rental_Types::instance()->rental_types['appointment'];

                // Set Product ID
                $rental_object->set_ID( $product_id );

                // Get time format
                $time_format = ovabrw_get_time_format();

                foreach ( $start_times as $k => $start_time ) {
                    $label      = ovabrw_get_meta_data( $k, $labels );
                    $start_time = strtotime( $start_time );
                    $end_time   = strtotime( ovabrw_get_meta_data( $k, $end_times ) );
                    $quantity   = (int)ovabrw_get_meta_data( $k, $quantities );
                    $disabled   = false;

                    // Check start time
                    if ( !$start_time ) continue;

                    // Get start date
                    $start_date = ovabrw_get_string_date( $pickup_date, $start_time );
                    if ( !$start_date ) continue;

                    // Get end date
                    $end_date = '';

                    if ( $end_time ) {
                        // Get string end date
                        if ( $start_time > $end_time ) {
                            // $end_date = $checkin_date + 1 day
                            $end_date = ovabrw_get_string_date( $pickup_date + 86400, $end_time );
                        } else {
                            $end_date = ovabrw_get_string_date( $pickup_date, $end_time );
                        }

                        // Check end date > current time
                        if ( !$end_date ) continue;
                    } else {
                        $end_date = $start_date;
                    }

                    // Get Label
                    if ( !$label ) {
                        if ( $end_time ) {
                            $label = sprintf( esc_html__( '%s - %s', 'ova-brw' ), date( ovabrw_get_time_format(), $start_time ), date( ovabrw_get_time_format(), $end_time ) );
                        } else {
                            $label = date( ovabrw_get_time_format(), strtotime( $start_date ) );
                        }
                    }

                    // Check quantity
                    if ( $quantity < 1 ) $disabled = true;

                    // Check start date
                    if ( !$disabled && strtotime( $start_date ) <= current_time( 'timestamp' ) || strtotime( $end_date ) <= current_time( 'timestamp' ) ) {
                        $disabled = true;
                    }

                    // Validation
                    $validation_booking = $rental_object->ovabrw_ajax_validation_booking( strtotime( $start_date ), strtotime( $end_date ), [ 'id' => $product_id ] );
                    if ( !$disabled && $validation_booking ) {
                        $disabled = true;
                    }

                    // Check available quantity
                    $data_available = $rental_object->get_qty_available( strtotime( $start_date ), strtotime( $end_date ), '', '', 'cart' );
                    $qty_available  = $data_available['qty_available'];
                    if ( !$disabled && !$qty_available ) {
                        $disabled = true;
                    }

                    // Add time slots
                    $time_slots[] = [
                        'label'         => $label,
                        'start_date'    => strtotime( $start_date ),
                        'end_date'      => strtotime( $end_date ),
                        'disabled'      => $disabled ? 1 : ''
                    ];
                }
            }

            return apply_filters( 'ovabrw_get_time_slots', $time_slots, $product_id, $pickup_date );
        }

        /**
         * Get time slots use location
         */
        public function get_time_slots_use_location( $product_id, $pickup_date ) {
            if ( !$product_id || !$pickup_date ) return false;

            // init time slots
            $time_slots = [];

            // Get string day of week
            $dayofweek = $this->get_string_dayofweek( $pickup_date );

            // Get time slots lable
            $timeslots_label = ovabrw_get_post_meta( $product_id, 'time_slots_label', [] );

            // Get time slots location
            $timeslots_location = ovabrw_get_post_meta( $product_id, 'time_slots_location', [] );

            // Get time slots start time
            $timeslots_start = ovabrw_get_post_meta( $product_id, 'time_slots_start', [] );

            // Get time slots end time
            $timeslots_end = ovabrw_get_post_meta( $product_id, 'time_slots_end', [] );

            // Get time slots quantity
            $timeslots_qty = ovabrw_get_post_meta( $product_id, 'time_slots_quantity', [] );

            // Time slots by day of week
            $labels         = ovabrw_get_meta_data( $dayofweek, $timeslots_label );
            $locations      = ovabrw_get_meta_data( $dayofweek, $timeslots_location );
            $start_times    = ovabrw_get_meta_data( $dayofweek, $timeslots_start );
            $end_times      = ovabrw_get_meta_data( $dayofweek, $timeslots_end );
            $quantities     = ovabrw_get_meta_data( $dayofweek, $timeslots_qty );

            if ( ovabrw_array_exists( $start_times ) ) {
                // Object Rental Types
                $rental_object = OVABRW_Rental_Types::instance()->rental_types['appointment'];

                // Set Product ID
                $rental_object->set_ID( $product_id );

                // Get time format
                $time_format = ovabrw_get_time_format();

                foreach ( $start_times as $k => $start_time ) {
                    $label      = ovabrw_get_meta_data( $k, $labels );
                    $location   = ovabrw_get_meta_data( $k, $locations );
                    $start_time = strtotime( $start_time );
                    $end_time   = strtotime( ovabrw_get_meta_data( $k, $end_times ) );
                    $quantity   = (int)ovabrw_get_meta_data( $k, $quantities );
                    $disabled   = false;

                    // Check location
                    if ( !$location ) continue;

                    // Check start time
                    if ( !$start_time ) continue;

                    // Get start date
                    $start_date = ovabrw_get_string_date( $pickup_date, $start_time );
                    if ( !$start_date ) continue;

                    // Get end date
                    $end_date = '';

                    if ( $end_time ) {
                        // Get string end date
                        if ( $start_time > $end_time ) {
                            // $end_date = $checkin_date + 1 day
                            $end_date = ovabrw_get_string_date( $pickup_date + 86400, $end_time );
                        } else {
                            $end_date = ovabrw_get_string_date( $pickup_date, $end_time );
                        }

                        // Check end date > current time
                        if ( !$end_date ) continue;
                    } else {
                        $end_date = $start_date;
                    }

                    // Get Label
                    if ( !$label ) {
                        if ( $end_time ) {
                            $label = sprintf( esc_html__( '%s - %s', 'ova-brw' ), date( ovabrw_get_time_format(), $start_time ), date( ovabrw_get_time_format(), $end_time ) );
                        } else {
                            $label = date( ovabrw_get_time_format(), strtotime( $start_date ) );
                        }
                    }

                    // Check quantity
                    if ( $quantity < 1 ) $disabled = true;

                    // Check start date
                    if ( !$disabled && strtotime( $start_date ) <= current_time( 'timestamp' ) || strtotime( $end_date ) <= current_time( 'timestamp' ) ) {
                        $disabled = true;
                    }

                    // Validation
                    $validation_booking = $rental_object->ovabrw_ajax_validation_booking( strtotime( $start_date ), strtotime( $end_date ), [
                        'id'        => $product_id,
                        'location'  => $location
                    ]);
                    if ( !$disabled && $validation_booking ) {
                        $disabled = true;
                    }

                    // Check available quantity
                    $data_available = $rental_object->get_qty_available( strtotime( $start_date ), strtotime( $end_date ), $location, '', 'cart' );
                    $qty_available  = $data_available['qty_available'];
                    if ( !$disabled && !$qty_available ) {
                        $disabled = true;
                    }

                    // Add time slots
                    $time_slots[$location][] = [
                        'label'         => $label,
                        'start_date'    => strtotime( $start_date ),
                        'end_date'      => strtotime( $end_date ),
                        'disabled'      => $disabled ? 1 : ''
                    ];
                }
            }

            return apply_filters( 'ovabrw_get_time_slots_use_location', $time_slots, $product_id, $pickup_date );
        }

        /**
         * Get time slots HTML
         */
        public function get_time_slots_html( $time_slots = [], $name = '' ) {
            // init html
            $html = '';

            // Check has active
            $has_active = false;

            // Default start date, end date
            $default_start = $default_end = '';

            if ( ovabrw_array_exists( $time_slots ) ) {
                // Date format
                $date_format = ovabrw_get_date_format();

                // Time format
                $time_format = ovabrw_get_time_format();

                // Field name
                if ( !$name ) $name = OVABRW_PREFIX.'start_time';

                ob_start();

                foreach ( $time_slots as $time_slot ):
                    // Start time
                    $start_time = date( $time_format, $time_slot['start_date'] );

                    // End date
                    $end_date = ovabrw_get_meta_data( 'end_date', $time_slot );
                    if ( $end_date ) {
                        $end_date = date( $date_format .' '. $time_format, $end_date );
                    }

                    // Disabled
                    $disabled = ovabrw_get_meta_data( 'disabled', $time_slot );

                    // Time slot class
                    $class = '';
                    if ( $disabled ) {
                        $class = 'disabled';
                    } else {
                        if ( !$has_active ) {
                            $class      = 'active';
                            $has_active = true;

                            // Add default date
                            $default_start  = $time_slot['start_date'];
                            $default_end    = $time_slot['end_date'];
                        }
                    }
                ?>
                    <label class="time-slot <?php echo esc_attr( $class ); ?>">
                        <?php echo esc_html( $time_slot['label'] ); ?>
                        <?php ovabrw_text_input([
                            'type'  => 'radio',
                            'name'  => $name,
                            'value' => $start_time,
                            'attrs' => [
                                'data-end-date' => $end_date,
                                'checked'       => 'active' == $class ? 'checked' : '',
                                'disabled'      => $disabled ? 'disabled' : ''
                            ]
                        ]); ?>
                    </label>
                <?php endforeach;

                $html = ob_get_contents();
                ob_end_clean();
            }

            return apply_filters( 'ovabrw_get_time_slots_html', [
                'timeslots'     => $html,
                'start_date'    => $default_start,
                'end_date'      => $default_end
            ], $time_slots, $name );
        }

        /**
         * Get time slots location
         */
        public function get_time_slots_location( $time_slots = [], $name = '' ) {
            // init html
            $html = '';

            // init default timeslots
            $default_timeslots = [];

            // Has active
            $has_active = false;

            if ( ovabrw_array_exists( $time_slots ) ) {
                // Field name
                if ( !$name ) $name = OVABRW_PREFIX.'location';

                ob_start(); ?>
                    <select name="<?php echo esc_attr( $name ); ?>" data-timeslots="<?php echo esc_attr( wp_json_encode( $time_slots ) ); ?>">
                        <?php foreach ( $time_slots as $location => $timeslots ):
                            // Selected
                            $selected = false;

                            if ( !$has_active ) {
                                $selected = !empty( array_filter( $timeslots, function( $item ) {
                                    return !$item['disabled'];
                                }));

                                if ( $selected ) {
                                    // Update has active
                                    $has_active = true;

                                    // Set default timeslots
                                    $default_timeslots = $timeslots;
                                }
                            }
                        ?>
                            <option value="<?php echo esc_attr( $location ); ?>"<?php selected( $selected, true ); ?>>
                                <?php echo esc_html( $location ); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                <?php $html = ob_get_contents();
                ob_end_clean();
            }

            return apply_filters( 'ovabrw_get_time_slots_html', [
                'locations'         => $html,
                'default_timeslots' => $default_timeslots
            ], $time_slots, $name );
        }

        /**
         * Instance
         */
        public static function instance() {
            if ( is_null( self::$_instance ) ) {
                self::$_instance = new self();
            }

            return self::$_instance;
        }
    }
}