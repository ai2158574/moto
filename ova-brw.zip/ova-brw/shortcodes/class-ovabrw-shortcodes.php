<?php if ( ! defined( 'ABSPATH' ) ) exit();

if ( ! class_exists( 'OVABRW_Shortcodes' ) ) {
    class OVABRW_Shortcodes {
        public function __construct() {
            add_filter( 'widget_text', 'do_shortcode' );

            // Add shortcode
            $this->init();
        }

        public function init() {
            $shortcodes = [
                'search',
                'st_booking_form',
                'st_request_booking_form',
                'st_product_calendar',
                'st_table_price_product',
                'st_feature_product',
                'products',
                'product_images',
                'product_unavailable',
                'product_title',
                'product_price',
                'product_review',
                'product_taxonomy',
                'product_meta',
                'product_features',
                'product_specifications',
                'product_short_description',
                'product_tabs',
                'product_related',
                'search_hotel',
                'search_ajax_hotel',
                'search_taxi',
                'search_taxi_ajax'
            ];

            foreach ( $shortcodes as $name ) {
                add_shortcode( OVABRW_PREFIX.$name, array( $this, OVABRW_PREFIX.$name.'_shortcode' ) );
            }
        }

        public function ovabrw_search_shortcode( $atts = [] ) {
            global $product;

            $atts = extract( shortcode_atts(
                array(
                    'template'                  => 'search_form_full',
                    'column'                    => '',
                    'show_name_product'         => '',
                    'show_attribute'            => '',
                    'show_tag_product'          => '',
                    'show_pickup_loc'           => '',
                    'show_dropoff_loc'          => '',
                    'show_pickup_date'          => '',
                    'show_dropoff_date'         => '',
                    'show_cat'                  => '',
                    'show_tax'                  => '',
                    'name_product_required'     => '',
                    'tag_product_required'      => '',
                    'pickup_loc_required'       => '',
                    'dropoff_loc_required'      => '',
                    'pickup_date_required'      => '',
                    'dropoff_date_required'     => '',
                    'category_required'         => '',
                    'attribute_required'        => '',
                    'hide_taxonomies_slug'      => '',
                    'remove_cats_id'            => '',
                    'taxonomies_slug_required'  => '',
                    'timepicker'                => '',
                    'dateformat'                => '',
                    'hour_default'              => '',
                    'time_step'                 => '',
                    'order'                     => 'DESC',
                    'orderby'                   => 'date',
                    'class'                     => '',
                ), $atts
            ));

            if ( $column == '' ) {
                $column = get_option( 'ova_brw_search_column', 'one-column' );
            }

            if ( $timepicker == '' ) {
                $timepicker = get_option( 'ova_brw_search_show_hour', 'yes' ) === 'yes' ? 'true' : 'false';
            }

            if ( $show_name_product == '' ) {
                $show_name_product = get_option( 'ova_brw_search_show_name_product', 'yes' );
            }

            if ( $show_attribute == '' ) {
                $show_attribute = get_option( 'ova_brw_search_show_attribute', 'yes' );
            }

            if ( $show_tag_product == '' ) {
                $show_tag_product = get_option( 'ova_brw_search_show_tag_product', 'yes' );
            }

            if ( $show_pickup_loc == '' ) {
                $show_pickup_loc = get_option( 'ova_brw_search_show_pick_up_location', 'yes' );
            }

            if ( $show_dropoff_loc == '' ) {
                $show_dropoff_loc = get_option( 'ova_brw_search_show_drop_off_location', 'yes' );
            }

            if ( $show_pickup_date == '' ) {
                $show_pickup_date = get_option( 'ova_brw_search_show_pick_up_date', 'yes' );
            }

            if ( $show_dropoff_date == '' ) {
                $show_dropoff_date = get_option( 'ova_brw_search_show_drop_off_date', 'yes' );
            }

            if ( $show_cat == '' ) {
                $show_cat = get_option( 'ova_brw_search_show_category', 'yes' );
            }

            if ( $show_tax == '' ) {
                $show_tax = get_option( 'ova_brw_search_show_taxonomy', 'yes' );
            }

            if ( $name_product_required == '' ) {
                $name_product_required = get_option( 'ova_brw_search_require_name_product', 'no' ) == 'yes' ? 'ovabrw-input-required' : '';
            } else {
                if ( 'yes' == $name_product_required ) {
                    $name_product_required = 'ovabrw-input-required';
                } else {
                    $name_product_required = '';
                }
            }

            if ( $tag_product_required == '' ) {
                $tag_product_required = get_option( 'ova_brw_search_require_tag_product', 'no' ) == 'yes' ? 'ovabrw-input-required' : '';
            } else {
                if ( 'yes' == $tag_product_required ) {
                    $tag_product_required = 'ovabrw-input-required';
                } else {
                    $tag_product_required = '';
                }
            }

            if ( $pickup_loc_required == '' ) {
                $pickup_loc_required = get_option( 'ova_brw_search_require_pick_up_location', 'no' ) == 'yes' ? 'ovabrw-input-required' : '';
            } else {
                if ( 'yes' == $pickup_loc_required ) {
                    $pickup_loc_required = 'ovabrw-input-required';
                } else {
                    $pickup_loc_required = '';
                }
            }

            if ( $dropoff_loc_required == '' ) {
                $dropoff_loc_required = get_option( 'ova_brw_search_require_drop_off_location', 'no' ) == 'yes' ? 'ovabrw-input-required' : '';
            } else {
                if ( 'yes' == $dropoff_loc_required ) {
                    $dropoff_loc_required = 'ovabrw-input-required';
                } else {
                    $dropoff_loc_required = '';
                }
            }

            if ( $pickup_date_required == '' ) {
                $pickup_date_required = get_option( 'ova_brw_search_require_pick_up_date', 'no' ) == 'yes' ? 'ovabrw-input-required' : '';    
            } else {
                if ( 'yes' == $pickup_date_required ) {
                    $pickup_date_required = 'ovabrw-input-required';
                } else {
                    $pickup_date_required = '';
                }
            }

            if ( $dropoff_date_required == '' ) {
                $dropoff_date_required = get_option( 'ova_brw_search_require_drop_off_date', 'no' ) == 'yes' ? 'ovabrw-input-required' : '';
            } else {
                if ( 'yes' == $dropoff_date_required ) {
                    $dropoff_date_required = 'ovabrw-input-required';
                } else {
                    $dropoff_date_required = '';
                }
            }

            if ( $category_required == '' ) {
                $category_required = get_option( 'ova_brw_search_require_category', 'no' ) == 'yes' ? 'ovabrw-input-required' : '';
            } else {
                if ( 'yes' == $category_required ) {
                    $category_required = 'ovabrw-input-required';
                } else {
                    $category_required = '';
                }
            }

            if ( $attribute_required == '' ) {
                $attribute_required = get_option( 'ova_brw_search_require_attribute', 'no' ) == 'yes' ? 'ovabrw-input-required' : '';
            } else {
                if ( 'yes' == $attribute_required ) {
                    $attribute_required = 'ovabrw-input-required';
                } else {
                    $attribute_required = '';
                }
            }

            if ( $dateformat == '' ) {
                $dateformat = ovabrw_get_date_format();
            }

            if ( $hour_default == '' ) {
                $hour_default = get_option( 'ova_brw_booking_form_default_hour', '07:00' );
            }

            if ( $time_step == '' ) {
                $time_step = get_option( 'ova_brw_booking_form_step_time', '30' );
            }

            if ( $hide_taxonomies_slug == '' ) {
                $hide_taxonomies_slug = get_option( 'ova_brw_search_hide_taxonomy_slug', '' );
            }

            if ( $taxonomies_slug_required == '' ) {
                $taxonomies_slug_required = get_option( 'ova_brw_search_require_taxonomy_slug', '' );
            }
            
            $arr_hide_taxonomy      = array_map( 'trim',  explode( ',', $hide_taxonomies_slug ) );
            $arr_require_taxonomy   = array_map( 'trim', explode( ',',  $taxonomies_slug_required ) );
            $taxonomy_list_wrap     = [];

            if ( ! empty( $arr_hide_taxonomy ) && is_array( $arr_hide_taxonomy ) ) {
                foreach ( $arr_hide_taxonomy as $key => $taxo) {
                    $taxonomy_list_wrap['taxonomy_hide'][$taxo] = 'hide';
                }
            }

            if ( ! empty( $arr_require_taxonomy ) && is_array( $arr_require_taxonomy ) ) {
                foreach ( $arr_require_taxonomy as $key => $taxo) {
                    $taxonomy_list_wrap['taxonomy_require'][$taxo] = 'require';
                }
            }

            $list_taxonomy = ovabrw_create_type_taxonomies();
            $taxonomy_list_wrap['taxonomy_list_all'] = $list_taxonomy;

            if ( ! empty( $list_taxonomy ) ) {
                foreach( $list_taxonomy as $tax ) {
                    $taxonomy_list_wrap['taxonomy_get'][$tax['slug']] = isset( $_GET[$tax['slug'].'_name'] ) ? $_GET[$tax['slug'].'_name'] : '';
                }
            }

            $name_product       = isset( $_GET["ovabrw_name_product"] ) ? sanitize_text_field( $_GET["ovabrw_name_product"] ) : '';
            $name_attribute     = isset( $_GET["ovabrw_attribute"] ) ? sanitize_text_field( $_GET["ovabrw_attribute"] ) : '';
            $value_attribute    = isset( $_GET[$name_attribute] ) ? sanitize_text_field( $_GET[$name_attribute] ) : '';
            $tag_product        = isset( $_GET["ovabrw_tag_product"] ) ? sanitize_text_field( $_GET["ovabrw_tag_product"] ) : '';
            $pickup_loc         = isset( $_GET["ovabrw_pickup_loc"] ) ? sanitize_text_field( $_GET["ovabrw_pickup_loc"] ) : '';
            $pickoff_loc        = isset( $_GET["ovabrw_pickoff_loc"] ) ? sanitize_text_field( $_GET["ovabrw_pickoff_loc"] ) : '';
            $pickup_date        = isset( $_GET["ovabrw_pickup_date"] ) ? sanitize_text_field( $_GET["ovabrw_pickup_date"] ) : '';
            $pickoff_date       = isset( $_GET["ovabrw_pickoff_date"] ) ? sanitize_text_field( $_GET["ovabrw_pickoff_date"] ) : '';
            $cat                = isset( $_GET["cat"] ) ? sanitize_text_field( $_GET["cat"] ) : '';

            $attribute_taxonomies   = wc_get_attribute_taxonomies();
            $list_value_attribute   = $tax_attribute = [];
            $html_select_attribute  = $html_select_value_attribute = '';

            if ( $attribute_taxonomies ) :
                $html_select_attribute .= '<select name="ovabrw_attribute" class="'.$attribute_required.'">';
                    $html_select_attribute .= '<option value="">'.esc_html__( 'Select Attribute', 'ova-brw' ).'</option>';
                
                foreach ( $attribute_taxonomies as $tax ):
                    if ( taxonomy_exists( wc_attribute_taxonomy_name( $tax->attribute_name ) ) ):
                        $class_acctive      = ( $name_attribute == $tax->attribute_name ) ? 'active' : '';
                        $checked_name_attr  = ( $name_attribute == $tax->attribute_name ) ? 'selected' : '';

                        $html_select_value_attribute .= '<div class="s_field '.$column.' ovabrw-value-attribute '.$class_acctive.'" id="'.$tax->attribute_name.'">';
                            $html_select_value_attribute .= '<div class="content">';
                                $html_select_value_attribute .= '<label>'.esc_html__( 'Value Attribute', 'ova-brw' ).'</label>';
                                $html_select_value_attribute .= '<select name="'.$tax->attribute_name.'">';
                                    $label_attribute = $tax->attribute_label;
                                    $tax_attribute[$tax->attribute_name] = $tax->attribute_label;
                                    $term_attributes = get_terms( wc_attribute_taxonomy_name($tax->attribute_name), 'orderby=name&hide_empty=0' );

                                    $html_select_attribute .= "<option ".$checked_name_attr." value='".$tax->attribute_name."'>".$tax->attribute_label."</option>";

                                    foreach ( $term_attributes as $attr ) {
                                        $checked_value_attr = ( $value_attribute == $attr->slug ) ? "selected" : "";
                                        $html_select_value_attribute .= '<option '.$checked_value_attr.' value="'.$attr->slug.'">'.$attr->name.'</option>';
                                    }
                                $html_select_value_attribute .= '</select>';
                            $html_select_value_attribute .= '</div>';
                        $html_select_value_attribute .= '</div>';
                    endif;
                endforeach;
                $html_select_attribute .= '</select>';
            endif;

            $remove_cats_id = $remove_cats_id == '' ? get_option( 'ova_brw_search_cat_remove', '' ) : $remove_cats_id;

            $args = array(
                'column'                        => $column,
                'template'                      => $template,
                'show_name_product'             => $show_name_product,
                'show_attribute'                => $show_attribute,
                'show_tag_product'              => $show_tag_product,
                'show_pickup_loc'               => $show_pickup_loc,
                'show_dropoff_loc'              => $show_dropoff_loc,
                'show_pickup_date'              => $show_pickup_date,
                'show_dropoff_date'             => $show_dropoff_date,
                'show_cat'                      => $show_cat,
                'show_tax'                      => $show_tax,
                'name_product_required'         => $name_product_required,
                'tag_product_required'          => $tag_product_required,
                'pickup_loc_required'           => $pickup_loc_required,
                'dropoff_loc_required'          => $dropoff_loc_required,
                'pickup_date_required'          => $pickup_date_required,
                'dropoff_date_required'         => $dropoff_date_required,
                'category_required'             => $category_required,
                'attribute_required'            => $attribute_required,
                'remove_cats_id'                => $remove_cats_id,
                'dateformat'                    => $dateformat,
                'hour_default'                  => $hour_default,
                'time_step'                     => $time_step,
                'order'                         => $order,
                'orderby'                       => $orderby,
                'class'                         => $class,
                'timepicker'                    => 'true' == $timepicker ? true : false,
                'name_product'                  => $name_product,
                'name_attribute'                => $name_attribute,
                'value_attribute'               => $value_attribute,
                'tag_product'                   => $tag_product,        
                'pickup_loc'                    => $pickup_loc,
                'pickoff_loc'                   => $pickoff_loc,
                'pickup_date'                   => $pickup_date,
                'pickoff_date'                  => $pickoff_date,
                'cat'                           => $cat,
                'html_select_attribute'         => $html_select_attribute,
                'html_select_value_attribute'   => $html_select_value_attribute,
                'taxonomy_list_wrap'            => $taxonomy_list_wrap
            );

            // HTML
            $html = '';
            ob_start();

            // Check show custom taxonomy depend category   
            // Custom taxonomies choosed in post
            $all_cus_tax            = array();
            $exist_cus_tax          = array();
            $cus_tax_hide_p_loaded  = array();

            // Get All Custom taxonomy
            $ovabrw_custom_taxonomy = ovabrw_create_type_taxonomies();

            // All custom slug tax
            if ( $ovabrw_custom_taxonomy ) {
                foreach ( $ovabrw_custom_taxonomy as $key => $value ) {
                    array_push($all_cus_tax, $value['slug']);
                }
            }

            $ova_brw_search_show_tax_depend_cat = get_option( 'ova_brw_search_show_tax_depend_cat', 'yes' );
            
            if ( $ova_brw_search_show_tax_depend_cat == 'no' ) {
                $cus_tax_hide_p_loaded = $all_cus_tax = array();
            }

            echo '<script type="text/javascript"> var ova_brw_search_show_tax_depend_cat = "'.$ova_brw_search_show_tax_depend_cat.'"; var cus_tax_hide_p_loaded = "'.implode( ',', $cus_tax_hide_p_loaded ).'"; var all_cus_tax = "'.implode( ',', $all_cus_tax ).'"; </script>';

            $template_file = ovabrw_locate_template( 'shortcode/'.$template.'.php' );

            if ( ! file_exists( $template_file ) ){
                esc_html_e( 'No templates found', 'ova-brw' );
            } else {
                ovabrw_get_template( 'shortcode/'.$template.'.php', $args );
            }
            
            $html = ob_get_contents();
            ob_end_clean();

            return apply_filters( 'ovabrw_search_shortcode_html', $html, $atts );
        }

        public function ovabrw_st_booking_form_shortcode( $atts = [] ) {
            $atts = extract( shortcode_atts(
                array(
                'id'    => '',
                'class' => '',
                ), $atts
            ));

            $args = array(
                'id'    => $id,
                'class' => $class
            );

            // HTML
            $html = '';
            ob_start();

            $template_file = ovabrw_locate_template( 'shortcode/st-booking-form.php' );

            if ( ! file_exists( $template_file ) ) {
                esc_html_e( 'No templates found', 'ova-brw' );
            } else {
                ovabrw_get_template( 'shortcode/st-booking-form.php', $args );
            }

            $html = ob_get_contents();
            ob_end_clean();

            return apply_filters( 'ovabrw_st_booking_form_shortcode_html', $html, $atts );
        }

        public function ovabrw_st_request_booking_form_shortcode( $atts = [] ) {
            $atts = extract( shortcode_atts(
            array(
                'id'  => '',
                'class'   => '',
            ), $atts) );

            $args = array(
                'id' => $id,
                'class'  => $class
            );

            // HTML
            $html = '';
            ob_start();

            $template_file = ovabrw_locate_template( 'shortcode/st-request-booking.php' );
            if ( ! file_exists( $template_file ) ) {
                esc_html_e( 'No templates found', 'ova-brw' );
            } else {
                ovabrw_get_template( 'shortcode/st-request-booking.php', $args );
            }

            $html = ob_get_contents();
            ob_end_clean();

            return apply_filters( 'ovabrw_st_request_booking_form_shortcode_html', $html, $atts );
        }

        public function ovabrw_st_product_calendar_shortcode( $atts = [] ) {
            $atts = extract( shortcode_atts(
                array(
                    'id'    => '',
                    'class' => '',
                ), $atts
            ));

            $args = array(
                'id'    => $id,
                'class' => $class
            );

            // HTML
            $html = '';
            ob_start();

            $template_file = ovabrw_locate_template( 'shortcode/st-calendar.php' );
            if ( ! file_exists( $template_file ) ) {
                esc_html_e( 'No templates found', 'ova-brw' );
            } else {
                ovabrw_get_template( 'shortcode/st-calendar.php', $args );
            }

            $html = ob_get_contents();
            ob_end_clean();

            return apply_filters( 'ovabrw_st_product_calendar_shortcode_html', $html, $atts );
        }

        public function ovabrw_st_table_price_product_shortcode( $atts = [] ) {
            $atts = extract( shortcode_atts(
                array(
                    'id'    => '',
                    'class' => '',
                ), $atts
            ));

            $args = array(
                'id'    => $id,
                'class' => $class
            );

            // HTML
            $html = '';
            ob_start();

            $template_file = ovabrw_locate_template( 'shortcode/st-table-price.php' );

            if ( ! file_exists( $template_file ) ) {
                esc_html_e( 'No templates found', 'ova-brw' );
            } else {
                ovabrw_get_template( 'shortcode/st-table-price.php', $args );
            }

            $html = ob_get_contents();
            ob_end_clean();

            return apply_filters( 'ovabrw_st_table_price_product_shortcode_html', $html, $atts );
        }

        public function ovabrw_st_feature_product_shortcode( $atts = [] ) {
            $atts = extract( shortcode_atts(
                array(
                    'id'    => '',
                    'class' => '',
                ), $atts
            ));

            $args = array(
                'id'    => $id,
                'class' => $class
            );

            // HTML
            $html = '';
            ob_start();

            $template_file = ovabrw_locate_template( 'shortcode/st-features.php' );

            if ( ! file_exists( $template_file ) ) {
                esc_html_e( 'No templates found', 'ova-brw' );
            } else {
                ovabrw_get_template( 'shortcode/st-features.php', $args );
            }

            $html = ob_get_contents();
            ob_end_clean();

            return apply_filters( 'ovabrw_st_feature_product_shortcode_html', $html, $atts );
        }

        public function ovabrw_products_shortcode( $atts = [] ) {
            $atts = extract( shortcode_atts(
                array(
                    'class'             => '',
                    'posts_per_page'    => '',
                    'order'             => '',
                    'orderby'           => '',
                    'categories'        => '',
                    'card'              => '',
                    'column'            => '',
                ), $atts
            ));

            if ( $posts_per_page == '' ) $posts_per_page = 6;
            if ( $order == '' ) $order = 'DESC';
            if ( $orderby == '' ) $orderby = 'date';
            if ( $card == '' ) $card = 'card1';
            if ( $column == '' ) $column = 3;

            $args = array(
                'class'             => $class,
                'posts_per_page'    => $posts_per_page,
                'order'             => $order,
                'orderby'           => $orderby,
                'categories'        => $categories,
                'card'              => $card,
                'column'            => $column,
            );

            // HTML
            $html = '';
            ob_start();

            $template_file = ovabrw_locate_template( 'shortcode/list-products.php' );

            if ( ! file_exists( $template_file ) ) {
                esc_html_e( 'No templates found', 'ova-brw' );
            } else {
                ovabrw_get_template( 'shortcode/list-products.php', $args );
            }

            $html = ob_get_contents();
            ob_end_clean();

            return apply_filters( 'ovabrw_products_shortcode_html', $html, $atts );
        }

        public function ovabrw_product_images_shortcode( $atts ) {
            $atts = extract( shortcode_atts(
                array(
                    'id'    => '',
                    'class' => ''
                ), $atts
            ));

            $args = array(
                'id'    => $id,
                'class' => $class
            );

            // HTML
            $html = '';
            ob_start();

            $template_file = ovabrw_locate_template( 'shortcode/product-images.php' );

            if ( ! file_exists( $template_file ) ) {
                esc_html_e( 'No templates found', 'ova-brw' );
            } else {
                ovabrw_get_template( 'shortcode/product-images.php', $args );
            }

            $html = ob_get_contents();
            ob_end_clean();

            return apply_filters( 'ovabrw_product_images_shortcode_html', $html, $atts );
        }

        public function ovabrw_product_unavailable_shortcode( $atts ) {
            $atts = extract( shortcode_atts(
                array(
                    'id'    => '',
                    'class' => ''
                ), $atts
            ));

            $args = array(
                'id'    => $id,
                'class' => $class
            );

            // HTML
            $html = '';
            ob_start();

            $template_file = ovabrw_locate_template( 'shortcode/product-unavailable.php' );

            if ( ! file_exists( $template_file ) ) {
                esc_html_e( 'No templates found', 'ova-brw' );
            } else {
                ovabrw_get_template( 'shortcode/product-unavailable.php', $args );
            }

            $html = ob_get_contents();
            ob_end_clean();

            return apply_filters( 'ovabrw_product_unavailable_shortcode_html', $html, $atts );
        }

        public function ovabrw_product_title_shortcode( $atts ) {
            $atts = extract( shortcode_atts(
                array(
                    'id'    => '',
                    'class' => ''
                ), $atts
            ));

            $args = array(
                'id'    => $id,
                'class' => $class
            );

            // HTML
            $html = '';
            ob_start();

            $template_file = ovabrw_locate_template( 'shortcode/product-title.php' );

            if ( ! file_exists( $template_file ) ) {
                esc_html_e( 'No templates found', 'ova-brw' );
            } else {
                ovabrw_get_template( 'shortcode/product-title.php', $args );
            }

            $html = ob_get_contents();
            ob_end_clean();

            return apply_filters( 'ovabrw_product_title_shortcode_html', $html, $atts );
        }

        public function ovabrw_product_price_shortcode( $atts ) {
            $atts = extract( shortcode_atts(
                array(
                    'id'    => '',
                    'class' => ''
                ), $atts
            ));

            $args = array(
                'id'    => $id,
                'class' => $class
            );

            // HTML
            $html = '';
            ob_start();

            $template_file = ovabrw_locate_template( 'shortcode/product-price.php' );

            if ( ! file_exists( $template_file ) ) {
                esc_html_e( 'No templates found', 'ova-brw' );
            } else {
                ovabrw_get_template( 'shortcode/product-price.php', $args );
            }

            $html = ob_get_contents();
            ob_end_clean();

            return apply_filters( 'ovabrw_product_price_shortcode_html', $html, $atts );
        }

        public function ovabrw_product_review_shortcode( $atts ) {
            $atts = extract( shortcode_atts(
                array(
                    'id'    => '',
                    'class' => ''
                ), $atts
            ));

            $args = array(
                'id'    => $id,
                'class' => $class
            );

            // HTML
            $html = '';
            ob_start();

            $template_file = ovabrw_locate_template( 'shortcode/product-review.php' );

            if ( ! file_exists( $template_file ) ) {
                esc_html_e( 'No templates found', 'ova-brw' );
            } else {
                ovabrw_get_template( 'shortcode/product-review.php', $args );
            }

            $html = ob_get_contents();
            ob_end_clean();

            return apply_filters( 'ovabrw_product_review_shortcode_html', $html, $atts );
        }

        public function ovabrw_product_taxonomy_shortcode( $atts ) {
            $atts = extract( shortcode_atts(
                array(
                    'id'    => '',
                    'class' => ''
                ), $atts
            ));

            $args = array(
                'id'    => $id,
                'class' => $class
            );

            // HTML
            $html = '';
            ob_start();

            $template_file = ovabrw_locate_template( 'shortcode/product-taxonomy.php' );

            if ( ! file_exists( $template_file ) ) {
                esc_html_e( 'No templates found', 'ova-brw' );
            } else {
                ovabrw_get_template( 'shortcode/product-taxonomy.php', $args );
            }

            $html = ob_get_contents();
            ob_end_clean();

            return apply_filters( 'ovabrw_product_taxonomy_shortcode_html', $html, $atts );
        }

        public function ovabrw_product_meta_shortcode( $atts ) {
            $atts = extract( shortcode_atts(
                array(
                    'id'    => '',
                    'class' => ''
                ), $atts
            ));

            $args = array(
                'id'    => $id,
                'class' => $class
            );

            // HTML
            $html = '';
            ob_start();

            $template_file = ovabrw_locate_template( 'shortcode/product-meta.php' );

            if ( ! file_exists( $template_file ) ) {
                esc_html_e( 'No templates found', 'ova-brw' );
            } else {
                ovabrw_get_template( 'shortcode/product-meta.php', $args );
            }

            $html = ob_get_contents();
            ob_end_clean();

            return apply_filters( 'ovabrw_product_meta_shortcode_html', $html, $atts );
        }

        public function ovabrw_product_features_shortcode( $atts ) {
            $atts = extract( shortcode_atts(
                array(
                    'id'    => '',
                    'class' => ''
                ), $atts
            ));

            $args = array(
                'id'    => $id,
                'class' => $class
            );

            // HTML
            $html = '';
            ob_start();

            $template_file = ovabrw_locate_template( 'shortcode/product-features.php' );

            if ( ! file_exists( $template_file ) ) {
                esc_html_e( 'No templates found', 'ova-brw' );
            } else {
                ovabrw_get_template( 'shortcode/product-features.php', $args );
            }

            $html = ob_get_contents();
            ob_end_clean();

            return apply_filters( 'ovabrw_product_features_shortcode_html', $html, $atts );
        }

        public function ovabrw_product_specifications_shortcode( $atts ) {
            $atts = extract( shortcode_atts(
                array(
                    'id'    => '',
                    'class' => ''
                ), $atts
            ));

            $args = array(
                'id'    => $id,
                'class' => $class
            );

            // HTML
            $html = '';
            ob_start();

            $template_file = ovabrw_locate_template( 'shortcode/product-specifications.php' );

            if ( ! file_exists( $template_file ) ) {
                esc_html_e( 'No templates found', 'ova-brw' );
            } else {
                ovabrw_get_template( 'shortcode/product-specifications.php', $args );
            }

            $html = ob_get_contents();
            ob_end_clean();

            return apply_filters( 'ovabrw_product_specifications_shortcode_html', $html, $atts );
        }

        public function ovabrw_product_short_description_shortcode( $atts ) {
            $atts = extract( shortcode_atts(
                array(
                    'id'    => '',
                    'class' => ''
                ), $atts
            ));

            $args = array(
                'id'    => $id,
                'class' => $class
            );

            // HTML
            $html = '';
            ob_start();

            $template_file = ovabrw_locate_template( 'shortcode/product-short-description.php' );

            if ( ! file_exists( $template_file ) ) {
                esc_html_e( 'No templates found', 'ova-brw' );
            } else {
                ovabrw_get_template( 'shortcode/product-short-description.php', $args );
            }

            $html = ob_get_contents();
            ob_end_clean();

            return apply_filters( 'ovabrw_product_short_description_shortcode_html', $html, $atts );
        }

        public function ovabrw_product_tabs_shortcode( $atts ) {
            $atts = extract( shortcode_atts(
                array(
                    'id'    => '',
                    'class' => ''
                ), $atts
            ));

            $args = array(
                'id'    => $id,
                'class' => $class
            );

            // HTML
            $html = '';
            ob_start();

            $template_file = ovabrw_locate_template( 'shortcode/product-tabs.php' );

            if ( ! file_exists( $template_file ) ) {
                esc_html_e( 'No templates found', 'ova-brw' );
            } else {
                ovabrw_get_template( 'shortcode/product-tabs.php', $args );
            }

            $html = ob_get_contents();
            ob_end_clean();

            return apply_filters( 'ovabrw_product_tabs_shortcode_html', $html, $atts );
        }

        public function ovabrw_product_related_shortcode( $atts ) {
            $atts = extract( shortcode_atts(
                array(
                    'id'    => '',
                    'class' => ''
                ), $atts
            ));

            $args = array(
                'id'    => $id,
                'class' => $class
            );

            // HTML
            $html = '';
            ob_start();

            $template_file = ovabrw_locate_template( 'shortcode/product-related.php' );

            if ( ! file_exists( $template_file ) ) {
                esc_html_e( 'No templates found', 'ova-brw' );
            } else {
                ovabrw_get_template( 'shortcode/product-related.php', $args );
            }

            $html = ob_get_contents();
            ob_end_clean();

            return apply_filters( 'ovabrw_product_related_shortcode_html', $html, $atts );
        }

        public function ovabrw_search_hotel_shortcode( $atts ) {
            $atts = extract( shortcode_atts(
                array(
                    'field_1'            => 'category',
                    'field_2'            => 'pickup_date',
                    'field_3'            => 'dropoff_date',
                    'field_4'            => 'guest',
                    'field_5'            => '',
                    'field_6'            => '',
                    'field_7'            => '',
                    'field_8'            => '',
                    'default_cat'       => '', // term_slug
                    'category_in'       => '', // term_id: 123|456
                    'category_not_in'     => '', // term_id: 123|456
                    'list_taxonomy_custom' => '', // slug: test1|test2
                    'card'              => 'card1',
                    'columns'           => 'column4', // column1 or column2 or column3 or column4 or column5
                    'orderby'           => 'date',
                    'order'             => 'DESC',
                    'result_url'        => '' // redirect to custom page
                ), $atts
            ));

            // Custom taxonomies
            $data_custom_taxonomies = [];
            $list_taxonomy_custom   = explode( '|', $list_taxonomy_custom );

            if ( ! empty( $list_taxonomy_custom ) && is_array( $list_taxonomy_custom ) ) {
                foreach ( $list_taxonomy_custom as $taxonomy_name ) {
                    if ( $taxonomy_name ) {
                        $data_custom_taxonomies[] = [
                            'taxonomy_custom' => trim( $taxonomy_name )
                        ];
                    }
                }
            }

            $args = array(
                'field_1'            => $field_1,
                'field_2'            => $field_2,
                'field_3'            => $field_3,
                'field_4'            => $field_4,
                'field_5'            => $field_5,
                'field_6'            => $field_6,
                'field_7'            => $field_7,
                'field_8'            => $field_8,
                'default_cat'       => $default_cat,
                'category_in'       => explode( '|', $category_in ),
                'category_not_in'   => explode( '|', $category_not_in ),
                'list_taxonomy_custom' => $data_custom_taxonomies,
                'orderby'           => $orderby,
                'order'             => $order,
                'card'              => $card,
                'columns'           => $columns, // column1 or column2 or column3 or column4 or column5
                'result_url'        => $result_url // redirect to custom page
            );

            $template = ovabrw_locate_template( 'shortcode/search-hotel.php' );

            // HTML
            $html = '';
            ob_start();

            if ( ! file_exists( $template ) ) {
                esc_html_e( 'No templates found', 'ova-brw' );
            } else {
                ovabrw_get_template( 'shortcode/search-hotel.php', $args );
            }
            
            $html = ob_get_contents();
            ob_end_clean();

            return apply_filters( 'ovabrw_search_hotel_shortcode_html', $html, $atts );
        }

        public function ovabrw_search_ajax_hotel_shortcode( $atts ) {
            $atts = extract( shortcode_atts(
                array(
                    'field_1'            => 'name',
                    'field_2'            => 'category',
                    'field_3'            => 'pickup_date',
                    'field_4'            => 'dropoff_date',
                    'field_5'            => 'guest',
                    'field_6'            => '',
                    'field_7'            => '',
                    'field_8'            => '',
                    'form_search_position' => 'left',
                    'default_cat'       => '', // term_slug
                    'category_in'       => '', // term_id: 123|456
                    'category_not_in'     => '', // term_id: 123|456
                    'list_taxonomy_custom' => '',
                    'card'              => 'card1',
                    'posts_per_page'    => 6,
                    'result_column'     => 'two-column', // one-column or two-column or three-column
                    'orderby'           => 'date',
                    'order'             => 'DESC',
                ), $atts
            ));

            // Custom taxonomies
            $data_custom_taxonomies = [];
            $list_taxonomy_custom   = explode( '|', $list_taxonomy_custom );

            if ( ! empty( $list_taxonomy_custom ) && is_array( $list_taxonomy_custom ) ) {
                foreach ( $list_taxonomy_custom as $taxonomy_name ) {
                    if ( $taxonomy_name ) {
                        $data_custom_taxonomies[] = [
                            'custom_taxonomy' => $taxonomy_name
                        ];
                    }
                }
            }

            $args = array(
                'field_1'            => $field_1,
                'field_2'            => $field_2,
                'field_3'            => $field_3,
                'field_4'            => $field_4,
                'field_5'            => $field_5,
                'field_6'            => $field_6,
                'field_7'            => $field_7,
                'field_8'            => $field_8,
                'form_search_position' => $form_search_position,
                'default_cat'       => $default_cat,
                'category_in'       => explode( '|', $category_in ),
                'category_not_in'   => explode( '|', $category_not_in ),
                'list_taxonomy_custom' => $data_custom_taxonomies,
                'orderby'           => $orderby,
                'order'             => $order,
                'card'              => $card,
                'posts_per_page'    => $posts_per_page,
                'result_column'     => $result_column, // one-column or two-column or three-column
                'orderby'           => $orderby,
                'order'             => $order,
            );

            $template = ovabrw_locate_template( 'shortcode/search-ajax-hotel.php' );

            // HTML
            $html = '';
            ob_start();

            if ( ! file_exists( $template ) ) {
                esc_html_e( 'No templates found', 'ova-brw' );
            } else {
                ovabrw_get_template( 'shortcode/search-ajax-hotel.php', $args );
            }

            $html = ob_get_contents();
            ob_end_clean();

            return apply_filters( 'ovabrw_search_ajax_hotel_shortcode_html', $html, $atts );
        }

        public function ovabrw_search_taxi_shortcode( $atts ) {
            // enqueue google map
            if ( get_option( 'ova_brw_google_key_map', false ) ) {
                wp_enqueue_script( 'ovabrw-google-maps','https://maps.googleapis.com/maps/api/js?key='.get_option( 'ova_brw_google_key_map', '' ).'&libraries=places&loading=async&callback=Function.prototype', false, true );
            }

            $atts = extract( shortcode_atts(
                array(
                    'layout'            => 'layout1',
                    'column'            => 2,
                    'fields'            => 'pickup-location|dropoff-location|pickup-date|category|number-seats|quantity',
                    'default_category'  => '', // term_slug
                    'incl_category'     => '', // term_id: 123|456
                    'excl_category'     => '', // term_id: 123|456
                    'custom_taxonomies' => '',
                    'result_url'        => '',
                    'orderby'           => 'date',
                    'order'             => 'DESC',
                    'map_type'          => 'geocode',
                    'bounds'            => '',
                    'lat'               => '',
                    'lng'               => '',
                    'radius'            => '',
                    'restrictions'      => '' // Ex: AU|US|FR|VI
                ), $atts
            ));

            // Convert data
            $data_field = [];
            $fields     = explode( '|', $fields );

            if ( ! empty( $fields ) && is_array( $fields ) ) {
                foreach ( $fields as $field_name ) {
                    $field_label = $field_placeholder = '';

                    if ( $field_name === 'pickup-location' ) {
                        $field_label        = esc_html__( 'Pick Up Location', 'ova-brw' );
                        $field_placeholder  = esc_html__( 'Type Location', 'ova-brw' );
                    }
                    if ( $field_name === 'dropoff-location' ) {
                        $field_label        = esc_html__( 'Drop Off Location', 'ova-brw' );
                        $field_placeholder  = esc_html__( 'Type Location', 'ova-brw' );
                    }
                    if ( $field_name === 'pickup-date' ) {
                        $field_label        = esc_html__( 'Pick Up Date', 'ova-brw' );
                        $field_placeholder  = esc_html__( 'Enter Date', 'ova-brw' );
                    }
                    if ( $field_name === 'category' ) {
                        $field_label        = esc_html__( 'Taxi - Type', 'ova-brw' );
                        $field_placeholder  = esc_html__( 'Select Type', 'ova-brw' );
                    }
                    if ( $field_name === 'number-seats' ) {
                        $field_label        = esc_html__( 'Number Of Seats', 'ova-brw' );
                        $field_placeholder  = esc_html__( 'Enter Seat Number', 'ova-brw' );
                    }
                    if ( $field_name === 'quantity' ) {
                        $field_label        = esc_html__( 'Quantity', 'ova-brw' );
                        $field_placeholder  = esc_html__( 'Enter Quantity', 'ova-brw' );
                    }

                    $data_field[] = [
                        'field_name'        => $field_name,
                        'field_label'       => $field_label,
                        'field_placeholder' => $field_placeholder,
                    ];
                }
            }

            // Custom taxonomies
            $data_custom_taxonomies = [];
            $custom_taxonomies      = explode( '|', $custom_taxonomies );

            if ( ! empty( $custom_taxonomies ) && is_array( $custom_taxonomies ) ) {
                foreach ( $custom_taxonomies as $taxonomy_name ) {
                    if ( $taxonomy_name ) {
                        $data_custom_taxonomies[] = [
                            'custom_taxonomy' => trim( $taxonomy_name )
                        ];
                    }
                }
            }

            // Restrictions
            $data_restrictions  = [];
            $restrictions       = explode( '|', $restrictions );

            if ( ! empty( $restrictions ) && is_array( $restrictions ) ) {
                foreach ( $restrictions as $restriction ) {
                    if ( $restriction ) {
                        $data_restrictions[] = $restriction;
                    }
                }
            }

            if ( $incl_category ) {
                $incl_category = explode( '|', $incl_category );
                $incl_category = array_filter( $incl_category, function( $value ) {
                    return trim( $value ) !== '';
                });
            }
            if ( $excl_category ) {
                $excl_category = explode( '|', $excl_category );
                $excl_category = array_filter( $excl_category, function( $value ) {
                    return trim( $value ) !== '';
                });
            }

            $args = array(
                'fields'            => $data_field,
                'default_category'  => $default_category,
                'incl_category'     => $incl_category,
                'excl_category'     => $excl_category,
                'custom_taxonomies' => $data_custom_taxonomies,
                'result_url'        => $result_url,
                'orderby'           => $orderby,
                'order'             => $order,
                'map_type'          => $map_type,
                'bounds'            => $bounds,
                'lat'               => $lat,
                'lng'               => $lng,
                'radius'            => $radius,
                'restrictions'      => $data_restrictions 
            );

            $template   = ovabrw_locate_template( 'shortcode/search-taxi.php' );
            $path       = 'shortcode/search-taxi.php';

            // Layout
            if ( $layout === 'layout1' ) {
                $args['layout1_columns'] = $column;
            }
            if ( $layout === 'layout2' ) {
                $args['layout2_columns'] = $column;

                $template   = ovabrw_locate_template( 'shortcode/search-taxi2.php' );
                $path       = 'shortcode/search-taxi2.php';
            }

            // HTML
            $html = '';
            ob_start();

            if ( ! file_exists( $template ) ) {
                esc_html_e( 'No templates found', 'ova-brw' );
            } else {
                ovabrw_get_template( $path, $args );
            }

            $html = ob_get_contents();
            ob_end_clean();

            return apply_filters( 'ovabrw_search_taxi_shortcode_html', $html, $atts );
        }

        public function ovabrw_search_taxi_ajax_shortcode( $atts ) {
            // enqueue google map
            if ( get_option( 'ova_brw_google_key_map', false ) ) {
                wp_enqueue_script( 'ovabrw-google-maps','https://maps.googleapis.com/maps/api/js?key='.get_option( 'ova_brw_google_key_map', '' ).'&libraries=places&loading=async&callback=Function.prototype', false, true );
            }

            $atts = extract( shortcode_atts(
                array(
                    'fields'            => 'pickup-location|dropoff-location|pickup-date|category|number-seats|quantity',
                    'columns'           => 4,
                    'default_category'  => '', // term_slug
                    'incl_category'     => '', // term_id: 123|456
                    'excl_category'     => '', // term_id: 123|456
                    'custom_taxonomies' => '',
                    'map_type'          => 'geocode',
                    'bounds'            => '',
                    'lat'               => '',
                    'lng'               => '',
                    'radius'            => '',
                    'restrictions'      => '', // Ex: AU|US|FR|VI
                    'card_template'     => 'card1',
                    'posts_per_page'    => 6,
                    'column'            => 'three-column', // one-column or two-column or three-column
                    'orderby'           => 'date',
                    'order'             => 'DESC',
                    'term'              => '', // term_slug
                    'pagination'        => 'yes'
                ), $atts
            ));

            // Convert data
            $data_field = [];
            $fields     = explode( '|', $fields );

            if ( ! empty( $fields ) && is_array( $fields ) ) {
                foreach ( $fields as $field_name ) {
                    $field_label = $field_placeholder = '';

                    if ( $field_name === 'pickup-location' ) {
                        $field_label        = esc_html__( 'Pick Up Location', 'ova-brw' );
                        $field_placeholder  = esc_html__( 'Type Location', 'ova-brw' );
                    }
                    if ( $field_name === 'dropoff-location' ) {
                        $field_label        = esc_html__( 'Drop Off Location', 'ova-brw' );
                        $field_placeholder  = esc_html__( 'Type Location', 'ova-brw' );
                    }
                    if ( $field_name === 'pickup-date' ) {
                        $field_label        = esc_html__( 'Pick Up Date', 'ova-brw' );
                        $field_placeholder  = esc_html__( 'Enter Date', 'ova-brw' );
                    }
                    if ( $field_name === 'category' ) {
                        $field_label        = esc_html__( 'Taxi - Type', 'ova-brw' );
                        $field_placeholder  = esc_html__( 'Select Type', 'ova-brw' );
                    }
                    if ( $field_name === 'number-seats' ) {
                        $field_label        = esc_html__( 'Number Of Seats', 'ova-brw' );
                        $field_placeholder  = esc_html__( 'Enter Seat Number', 'ova-brw' );
                    }
                    if ( $field_name === 'quantity' ) {
                        $field_label        = esc_html__( 'Quantity', 'ova-brw' );
                        $field_placeholder  = esc_html__( 'Enter Quantity', 'ova-brw' );
                    }

                    $data_field[] = [
                        'field_name'        => $field_name,
                        'field_label'       => $field_label,
                        'field_placeholder' => $field_placeholder,
                    ];
                }
            }

            // Custom taxonomies
            $data_custom_taxonomies = [];
            $custom_taxonomies      = explode( '|', $custom_taxonomies );

            if ( ! empty( $custom_taxonomies ) && is_array( $custom_taxonomies ) ) {
                foreach ( $custom_taxonomies as $taxonomy_name ) {
                    if ( $taxonomy_name ) {
                        $data_custom_taxonomies[] = [
                            'custom_taxonomy' => $taxonomy_name
                        ];
                    }
                }
            }

            // Restrictions
            $data_restrictions  = [];
            $restrictions       = explode( '|', $restrictions );

            if ( ! empty( $restrictions ) && is_array( $restrictions ) ) {
                foreach ( $restrictions as $restriction ) {
                    if ( $restriction ) {
                        $data_restrictions[] = $restriction;
                    }
                }
            }

            $args = array(
                'fields'            => $data_field,
                'default_category'  => $default_category,
                'incl_category'     => explode( '|', $incl_category ),
                'excl_category'     => explode( '|', $excl_category ),
                'custom_taxonomies' => $data_custom_taxonomies,
                'orderby'           => $orderby,
                'order'             => $order,
                'map_type'          => $map_type,
                'bounds'            => $bounds,
                'lat'               => $lat,
                'lng'               => $lng,
                'radius'            => $radius,
                'restrictions'      => $data_restrictions,
                'card_template'     => $card_template,
                'posts_per_page'    => $posts_per_page,
                'column'            => $column, // one-column or two-column or three-column
                'orderby'           => $orderby,
                'order'             => $order,
                'term'              => $term, // term_slug
                'pagination'        => $pagination
            );

            $template = ovabrw_locate_template( 'shortcode/search-taxi-ajax.php' );

            // HTML
            $html = '';
            ob_start();

            if ( ! file_exists( $template ) ) {
                esc_html_e( 'No templates found', 'ova-brw' );
            } else {
                ovabrw_get_template( 'shortcode/search-taxi-ajax.php', $args );
            }

            $html = ob_get_contents();
            ob_end_clean();

            return apply_filters( 'ovabrw_search_taxi_ajax_shortcode_html', $html, $atts );
        }
    }

    new OVABRW_Shortcodes();
}