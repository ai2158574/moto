<?php defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'OVABRW_Widget_Product_Title' ) ) {
	class OVABRW_Widget_Product_Title extends \Elementor\Widget_Base {
		public function get_name() {
			return 'ovabrw_product_title';
		}

		public function get_title() {
			return esc_html__( 'Product Title', 'ova-brw' );
		}

		public function get_icon() {
			return 'eicon-t-letter';
		}

		public function get_categories() {
			return [ 'ovabrw-product' ];
		}

		protected function register_controls() {
			$this->start_controls_section(
				'section_demo',
				[
					'label' => esc_html__( 'Demo', 'ova-brw' ),
				]
			);
				// Product demo
				$arr_product 		= array( '0' => esc_html__( 'Choose Product', 'ova-brw' ) );
				$products 			= OVABRW()->options->get_products_rental();;
				$product_default 	= '';

				if ( ! empty( $products ) && is_array( $products ) ) {
					foreach( $products as $product_id ) {
						$arr_product[$product_id] = get_the_title( $product_id );

						if ( $product_default === '' ) $product_default = $product_id;
					}
				} else {
					$arr_product = array(
						'' => esc_html__( 'There are no rental products', 'ova-brw' )
					);
				}

				$this->add_control(
					'product_id',
					[
						'label' 	=> esc_html__( 'Choose Product', 'ova-brw' ),
						'type' 		=> \Elementor\Controls_Manager::SELECT,
						'default' 	=> $product_default,
						'options' 	=> $arr_product,
					]
				);

				// Product templates
				$default_template = 'classic';
				$product_template = array(
					'classic' => esc_html__( 'Classic', 'ova-brw' ),
				);

				if ( ovabrw_global_typography() ) {
					$product_template['modern'] = esc_html__( 'Modern', 'ova-brw' );
					$default_template 			= 'modern';
				}

				$this->add_control(
					'product_template',
					[
						'label' 	=> esc_html__( 'Style', 'ova-brw' ),
						'type' 		=> \Elementor\Controls_Manager::SELECT,
						'default' 	=> $default_template,
						'options' 	=> $product_template
					]
				);

			$this->end_controls_section();
			
			$this->start_controls_section(
				'section_title',
				[
					'label' 	=> esc_html__( 'Title', 'ova-brw' ),
					'condition' => [
						'product_template' => 'classic'
					]
				]
			);
			
				$this->add_control(
					'link',
					[
						'label' => esc_html__( 'Link', 'ova-brw' ),
						'type' 	=> \Elementor\Controls_Manager::URL,
						'dynamic' => [
							'active' => true,
						],
						'default' => [
							'url' => '',
						],
						'separator' => 'before',
					]
				);

				$this->add_control(
					'header_size',
					[
						'label' => esc_html__( 'HTML Tag', 'ova-brw' ),
						'type' 	=> \Elementor\Controls_Manager::SELECT,
						'options' => [
							'h1' 	=> 'H1',
							'h2' 	=> 'H2',
							'h3' 	=> 'H3',
							'h4' 	=> 'H4',
							'h5' 	=> 'H5',
							'h6' 	=> 'H6',
							'div' 	=> 'div',
							'span' 	=> 'span',
							'p' 	=> 'p',
						],
						'default' => 'h2',
					]
				);

				$this->add_responsive_control(
					'align',
					[
						'label' => esc_html__( 'Alignment', 'ova-brw' ),
						'type' 	=> \Elementor\Controls_Manager::CHOOSE,
						'options' => [
							'left' => [
								'title' => esc_html__( 'Left', 'ova-brw' ),
								'icon' 	=> 'eicon-text-align-left',
							],
							'center' => [
								'title' => esc_html__( 'Center', 'ova-brw' ),
								'icon' 	=> 'eicon-text-align-center',
							],
							'right' => [
								'title' => esc_html__( 'Right', 'ova-brw' ),
								'icon' 	=> 'eicon-text-align-right',
							],
							'justify' => [
								'title' => esc_html__( 'Justified', 'ova-brw' ),
								'icon' 	=> 'eicon-text-align-justify',
							],
						],
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .ovabrw_product_title' => 'text-align: {{VALUE}};',
						],
					]
				);

			$this->end_controls_section();

			$this->start_controls_section(
				'section_title_style',
				[
					'label' 	=> esc_html__( 'Title', 'ova-brw' ),
					'tab' 		=> \Elementor\Controls_Manager::TAB_STYLE,
					'condition' => [
						'product_template' => 'classic'
					]
				]
			);

				$this->add_control(
					'title_color',
					[
						'label' => esc_html__( 'Color', 'ova-brw' ),
						'type' 	=> \Elementor\Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .ovabrw_product_title .ovabrw_title' => 'color: {{VALUE}};',
						],
					]
				);

				$this->add_group_control(
					\Elementor\Group_Control_Typography::get_type(),
					[
						'name' 	 	=> 'typography',
						'selector' 	=> '{{WRAPPER}} .ovabrw_product_title .ovabrw_title',
					]
				);

				$this->add_group_control(
					\Elementor\Group_Control_Text_Shadow::get_type(),
					[
						'name' 		=> 'text_shadow',
						'selector' 	=> '{{WRAPPER}} .ovabrw_product_title .ovabrw_title',
					]
				);

				$this->add_control(
					'blend_mode',
					[
						'label' => esc_html__( 'Blend Mode', 'ova-brw' ),
						'type' 	=> \Elementor\Controls_Manager::SELECT,
						'options' => [
							'' => esc_html__( 'Normal', 'ova-brw' ),
							'multiply' 	  => 'Multiply',
							'screen' 	  => 'Screen',
							'overlay' 	  => 'Overlay',
							'darken' 	  => 'Darken',
							'lighten' 	  => 'Lighten',
							'color-dodge' => 'Color Dodge',
							'saturation'  => 'Saturation',
							'color' 	  => 'Color',
							'difference'  => 'Difference',
							'exclusion'   => 'Exclusion',
							'hue' 		  => 'Hue',
							'luminosity'  => 'Luminosity',
						],
						'selectors' => [
							'{{WRAPPER}} .ovabrw_product_title .ovabrw_title' => 'mix-blend-mode: {{VALUE}}',
						],
						'separator' => 'none',
					]
				);

				$this->add_responsive_control(
					'title_margin',
					[
						'type' 			=> \Elementor\Controls_Manager::DIMENSIONS,
						'label' 		=> esc_html__( 'Margin', 'ova-brw' ),
						'size_units' 	=> [ 'px', 'em', '%' ],
						'selectors' 	=> [
							'{{WRAPPER}} .ovabrw_product_title .ovabrw_title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);

			$this->end_controls_section();
		}

		protected function render() {
			$settings 	= $this->get_settings();
			$product_id = $settings['product_id'];
			$template 	= $settings['product_template'];

			global $product;

			if ( ! $product ) {
				$product = wc_get_product( $product_id );
			}

	    	if ( ! $product || ! $product->is_type('ovabrw_car_rental') ) {
				?>
				<div class="ovabrw_elementor_no_product">
					<span><?php echo $this->get_title(); ?></span>
				</div>
				<?php
				return;
			}

			if ( $template === 'modern' ): ?>
				<div class="ovabrw-modern-product">
					<?php ovabrw_get_template( 'modern/single/detail/ovabrw-product-title.php' ); ?>
				</div>
			<?php else:
				$title = $product->get_title();

				if ( $title === '' ) {
					?>
					<div class="ovabrw_elementor_no_product">
						<span><?php echo $this->get_title(); ?></span>
					</div>
					<?php
					return;
				}

				// Get header_size
				$header_size = $settings['header_size'];

				// Get link
				$link 	  	= $settings['link']['url'];
				$blank 		= '_blank';
				$target_url = $settings['link']['is_external'];
				if ( empty( $target_url ) ) {
					$blank = '';
				}
			?>
				<div class="ovabrw_product_title">
					<?php if ( !empty( $link ) ): ?>
						<a href="<?php echo $link; ?>" target="<?php echo $blank; ?>">
							<<?php echo $header_size; ?> class="ovabrw_title"><?php echo esc_html( $title ); ?></<?php echo $header_size; ?>>
						</a>
					<?php else: ?>
						<<?php echo $header_size; ?> class="ovabrw_title"><?php echo esc_html( $title ); ?></<?php echo $header_size; ?>>
					<?php endif; ?>

				</div>
			<?php endif;
		}
	}

	$widgets_manager->register( new OVABRW_Widget_Product_Title() );
}